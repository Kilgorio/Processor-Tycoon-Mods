using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.CompanySystem.Business;
using ProcessorTycoon.Desktop.Inspector;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;

namespace PTCopyCPU
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTCopyCpuPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.copycpu";
        public const string PluginName = "PT Inspector Copy CPU";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log { get; private set; }
        private static Harmony _harmony;
        private static bool _patchesApplied;

        public static ConfigEntry<bool> ModEnabled { get; private set; }
        public static bool IsEnabled => ModEnabled == null || ModEnabled.Value;

        private void Awake()
        {
            Log = Logger;
            _harmony = new Harmony(PluginGuid);

            ModEnabled = Config.Bind("1. General", "Enabled", true,
                "Show the 'Copy CPU' button in Inspector when CPU Creation is open.");
            ModEnabled.SettingChanged += (_, _) => ApplyEnabledState(ModEnabled.Value);

            if (ModEnabled.Value) ApplyEnabledState(true);
            else Log.LogInfo($"{PluginName} v{PluginVersion} loaded (disabled by config).");
        }

        private void OnDestroy()
        {
            if (_patchesApplied && _harmony != null)
            {
                _harmony.UnpatchSelf();
                _patchesApplied = false;
            }
            InspectorCopyCpuPatch.RefreshVisibility();
        }

        private static void ApplyEnabledState(bool enable)
        {
            try
            {
                if (enable && !_patchesApplied)
                {
                    InspectorCopyCpuPatch.ApplyPatches(_harmony);
                    _patchesApplied = true;
                    InspectorCopyCpuPatch.RefreshVisibility();
                    Log.LogInfo($"{PluginName} v{PluginVersion} enabled cleanly.");
                }
                else if (!enable && _patchesApplied)
                {
                    _harmony.UnpatchSelf();
                    _patchesApplied = false;
                    InspectorCopyCpuPatch.RefreshVisibility();
                    Log.LogInfo($"{PluginName} v{PluginVersion} disabled live.");
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed toggling {PluginName}: {ex}");
            }
        }
    }

    internal class InspectorCopyUpdater : MonoBehaviour
    {
        public InspectorWindow Inspector;
        public ButtonUI CopyButton;
        private bool _hasLast;
        private bool _lastEnabled, _lastOpen, _lastVariant, _lastHasCpu;

        private void Update()
        {
            InspectorCopyCpuPatch.SyncButtonState(Inspector, CopyButton, ref _hasLast, ref _lastEnabled, ref _lastOpen, ref _lastVariant, ref _lastHasCpu);
        }
    }

    public static class InspectorCopyCpuPatch
    {
        private static readonly FieldInfo SimpleBtnF = AccessTools.Field(typeof(InspectorWindow), "simpleOrDetailedButton");
        private static readonly FieldInfo CurrentCpuF = AccessTools.Field(typeof(InspectorWindow), "currentCpu");

        private static readonly FieldInfo CmArchF = AccessTools.Field(typeof(CreatorManager), "<CurrentArchitecture>k__BackingField");
        private static readonly FieldInfo CmPkgF = AccessTools.Field(typeof(CreatorManager), "<CurrentPackage>k__BackingField");
        private static readonly FieldInfo CmLithoF = AccessTools.Field(typeof(CreatorManager), "<CurrentLithography>k__BackingField");
        private static readonly FieldInfo CmMemF = AccessTools.Field(typeof(CreatorManager), "<CurrentMemory>k__BackingField");
        private static readonly FieldInfo CmNodeCompF = AccessTools.Field(typeof(CreatorManager), "<CurrentNodeCompany>k__BackingField");

        private static readonly FieldInfo NameInputF = AccessTools.Field(typeof(CreatorCpu), "nameInput");
        private static readonly FieldInfo CoreDropF = AccessTools.Field(typeof(CreatorCpu), "coreCountDropdown");
        private static readonly FieldInfo DieDropF = AccessTools.Field(typeof(CreatorCpu), "dieCountDropdown");
        private static readonly FieldInfo DieCountF = AccessTools.Field(typeof(CreatorCpu), "currentDieCount");
        private static readonly FieldInfo CoreCountF = AccessTools.Field(typeof(CreatorCpu), "currentCoreCount");
        private static readonly FieldInfo DieSizeSliderF = AccessTools.Field(typeof(CreatorCpu), "dieSizeSlider");
        private static readonly FieldInfo FreqSliderF = AccessTools.Field(typeof(CreatorCpu), "frequencySlider");
        private static readonly FieldInfo L1SliderF = AccessTools.Field(typeof(CreatorCpu), "l1CacheSlider");
        private static readonly FieldInfo L2SliderF = AccessTools.Field(typeof(CreatorCpu), "l2CacheSlider");
        private static readonly FieldInfo L3SliderF = AccessTools.Field(typeof(CreatorCpu), "l3CacheSlider");
        private static readonly FieldInfo OverclockToggleF = AccessTools.Field(typeof(CreatorCpu), "overclockToggle");
        private static readonly FieldInfo SmtToggleF = AccessTools.Field(typeof(CreatorCpu), "smtToggle");
        private static readonly FieldInfo SmtBoolF = AccessTools.Field(typeof(CreatorCpu), "smtEnabled");
        private static readonly FieldInfo AutoCacheToggleF = AccessTools.Field(typeof(CreatorCpu), "automateCacheToggle");
        private static readonly FieldInfo MaxFreqF = AccessTools.Field(typeof(CreatorCpu), "maxFrequency");
        private static readonly FieldInfo SliderValuesF = AccessTools.Field(typeof(SliderUI), "values");

        private static readonly MethodInfo UpdateCurrentHardwaresM = AccessTools.Method(typeof(CreatorCpu), "UpdateCurrentHardwares");
        private static readonly MethodInfo UpdateUiM = AccessTools.Method(typeof(CreatorCpu), "UpdateUI");
        private static readonly MethodInfo UpdateImagesM = AccessTools.Method(typeof(CreatorCpu), "UpdateImages");
        private static readonly MethodInfo UpdateCoreCountDropdownM = AccessTools.Method(typeof(CreatorCpu), "UpdateCoreCountDropdown");
        private static readonly MethodInfo UpdateCoreCountM = AccessTools.Method(typeof(CreatorCpu), "UpdateCoreCount");
        private static readonly MethodInfo UpdateNumbersM = AccessTools.Method(typeof(CreatorCpu), "UpdateNumbers");

        private static bool _extResolved;
        private static MethodInfo _dynIsaCanUseArchM;
        private static int _dynIsaCanUseArchParamCount;
        private static Func<bool> _binningVariantGetter;

        private static InspectorWindow _inspector;
        private static InspectorCopyUpdater _updater;
        private static ButtonUI _origDetailBtn, _copyBtn;
        private static Vector2 _origSizeDelta, _origAnchoredPos, _origAnchorMax, _origOffsetMax;
        private static bool _origSaved;
        private static readonly List<ICompany> FoundryScratch = new List<ICompany>(8);
        private static readonly List<(ProcessNode node, ICompany mfr)> NodeScratch = new List<(ProcessNode, ICompany)>(16);
        private static readonly List<string> FallbackScratch = new List<string>(8);
        private static CreatorCpu _creatorCpu;

        public static void ApplyPatches(Harmony harmony)
        {
            var startM = AccessTools.Method(typeof(InspectorWindow), "Start");
            if (startM != null)
                harmony.Patch(startM, postfix: new HarmonyMethod(typeof(InspectorCopyCpuPatch), nameof(InspectorWindow_Start_Postfix)));

            var updM = AccessTools.Method(typeof(InspectorWindow), "UpdateCpuUI");
            if (updM != null)
                harmony.Patch(updM, postfix: new HarmonyMethod(typeof(InspectorCopyCpuPatch), nameof(InspectorWindow_UpdateCpuUI_Postfix)));

            var ccInit = AccessTools.Method(typeof(CreatorCpu), "Initialize");
            if (ccInit != null)
                harmony.Patch(ccInit, postfix: new HarmonyMethod(typeof(InspectorCopyCpuPatch), nameof(CreatorCpu_Cache_Postfix)));

            var ccStart = AccessTools.Method(typeof(CreatorCpu), "Start");
            if (ccStart != null)
                harmony.Patch(ccStart, postfix: new HarmonyMethod(typeof(InspectorCopyCpuPatch), nameof(CreatorCpu_Cache_Postfix)));
        }

        private static void CreatorCpu_Cache_Postfix(CreatorCpu __instance)
        {
            if (__instance != null) _creatorCpu = __instance;
        }

        private static void EnsureExtReflection()
        {
            if (_extResolved) return;
            _extResolved = true;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                var isaType = asm.GetType("DynamicISA.IsaState", false);
                if (isaType != null)
                {
                    foreach (var m in isaType.GetMethods(BindingFlags.Public | BindingFlags.Static))
                    {
                        if (m.Name != "CanCompanyUseArchitecture") continue;
                        int pc = m.GetParameters().Length;
                        if (pc == 3) { _dynIsaCanUseArchM = m; _dynIsaCanUseArchParamCount = 3; break; }
                        if (pc == 4 && _dynIsaCanUseArchM == null) { _dynIsaCanUseArchM = m; _dynIsaCanUseArchParamCount = 4; }
                    }
                }

                var binType = asm.GetType("CPUBinning.VariantCreatorPatch", false);
                var prop = binType?.GetProperty("IsVariantMode", BindingFlags.Public | BindingFlags.Static);
                if (prop?.GetGetMethod(true) is MethodInfo gm)
                    _binningVariantGetter = Expression.Lambda<Func<bool>>(Expression.Property(null, prop)).Compile();
            }
        }

        private static bool IsBinningVariantMode()
        {
            EnsureExtReflection();
            try { return _binningVariantGetter != null && _binningVariantGetter(); }
            catch { return false; }
        }

        private static bool IsArchUsableByPlayer(ICompany player, Architecture arch)
        {
            if (arch == null) return false;
            EnsureExtReflection();
            if (_dynIsaCanUseArchM == null) return true;
            try
            {
                object[] args = _dynIsaCanUseArchParamCount == 3
                    ? new object[] { player, arch, 0f }
                    : new object[] { player, arch, null, 0f };
                return (bool)_dynIsaCanUseArchM.Invoke(null, args);
            }
            catch { return true; }
        }

        private static void InspectorWindow_Start_Postfix(InspectorWindow __instance)
        {
            if (__instance == null) return;
            _inspector = __instance;
            EnsureCopyButton(__instance);
        }

        private static void InspectorWindow_UpdateCpuUI_Postfix(InspectorWindow __instance)
        {
            if (__instance == null) return;
            _inspector = __instance;
            EnsureCopyButton(__instance);
            RefreshVisibility();
        }

        private static void EnsureCopyButton(InspectorWindow win)
        {
            var detailBtn = SimpleBtnF?.GetValue(win) as ButtonUI;
            if (detailBtn == null) return;

            if (_origDetailBtn != detailBtn) _origSaved = false;
            if (_copyBtn != null && _copyBtn.gameObject != null && _origDetailBtn == detailBtn) return;

            _origDetailBtn = detailBtn;
            var parent = detailBtn.transform.parent;
            var existing = parent.Find("Btn_PTMod_CopyCpu");

            if (!_origSaved && existing == null)
            {
                var origRt = detailBtn.GetComponent<RectTransform>();
                _origSaved = true;
                _origSizeDelta = origRt.sizeDelta;
                _origAnchoredPos = origRt.anchoredPosition;
                _origAnchorMax = origRt.anchorMax;
                _origOffsetMax = origRt.offsetMax;
            }

            GameObject btnGo = existing != null ? existing.gameObject : UnityEngine.Object.Instantiate(detailBtn.gameObject, parent, false);
            btnGo.name = "Btn_PTMod_CopyCpu";
            btnGo.transform.SetSiblingIndex(detailBtn.transform.GetSiblingIndex() + 1);
            _copyBtn = btnGo.GetComponent<ButtonUI>();
            if (_copyBtn == null) return;

            ApplySplitLayout(true);

            _copyBtn.ResetOnClick();
            _copyBtn.Text = "Copy CPU";
            _copyBtn.OnClick += () =>
            {
                var cpu = CurrentCpuF?.GetValue(win) as Cpu;
                if (cpu != null) CopyInspectedCpuToCreator(cpu);
            };

            _updater = win.GetComponent<InspectorCopyUpdater>() ?? win.gameObject.AddComponent<InspectorCopyUpdater>();
            _updater.Inspector = win;
            _updater.CopyButton = _copyBtn;
            RefreshVisibility();
        }

        private static void ApplySplitLayout(bool split)
        {
            if (!_origSaved || _origDetailBtn == null || _copyBtn == null) return;
            var origRt = _origDetailBtn.GetComponent<RectTransform>();
            var copyRt = _copyBtn.GetComponent<RectTransform>();
            if (origRt == null || copyRt == null) return;

            if (!split)
            {
                _copyBtn.gameObject.SetActive(false);
                origRt.anchorMax = _origAnchorMax;
                origRt.offsetMax = _origOffsetMax;
                origRt.sizeDelta = _origSizeDelta;
                origRt.anchoredPosition = _origAnchoredPos;
                return;
            }

            _copyBtn.gameObject.SetActive(true);
            bool horizStretched = !Mathf.Approximately(origRt.anchorMin.x, _origAnchorMax.x);
            if (horizStretched)
            {
                float mid = (origRt.anchorMin.x + _origAnchorMax.x) * 0.5f;
                origRt.anchorMax = new Vector2(mid - 0.008f, _origAnchorMax.y);
                origRt.offsetMax = new Vector2(0f, _origOffsetMax.y);

                copyRt.anchorMin = new Vector2(mid + 0.008f, origRt.anchorMin.y);
                copyRt.anchorMax = _origAnchorMax;
                copyRt.offsetMin = new Vector2(0f, origRt.offsetMin.y);
                copyRt.offsetMax = _origOffsetMax;
            }
            else
            {
                const float gap = 6f;
                float halfW = (_origSizeDelta.x - gap) * 0.5f;
                float leftEdgeX = _origAnchoredPos.x - _origSizeDelta.x * origRt.pivot.x;

                origRt.sizeDelta = new Vector2(halfW, _origSizeDelta.y);
                origRt.anchoredPosition = new Vector2(leftEdgeX + halfW * origRt.pivot.x, _origAnchoredPos.y);

                copyRt.sizeDelta = new Vector2(halfW, _origSizeDelta.y);
                copyRt.anchoredPosition = new Vector2(leftEdgeX + halfW + gap + halfW * copyRt.pivot.x, _origAnchoredPos.y);
            }
        }

        internal static void RefreshVisibility()
        {
            bool show = PTCopyCpuPlugin.IsEnabled;
            if (_updater != null) _updater.enabled = show;
            ApplySplitLayout(show);
            if (!show || _inspector == null || _copyBtn == null) return;

            bool h = false, e = false, o = false, v = false, c = false;
            SyncButtonState(_inspector, _copyBtn, ref h, ref e, ref o, ref v, ref c);
        }

        internal static void SyncButtonState(InspectorWindow win, ButtonUI btn, ref bool hasLast, ref bool lastEn, ref bool lastOpen, ref bool lastVar, ref bool lastCpu)
        {
            if (win == null || btn == null) return;
            bool enabled = PTCopyCpuPlugin.IsEnabled;
            bool open = FindActiveCreatorCpu() != null;
            bool varMode = IsBinningVariantMode();
            bool hasCpu = (CurrentCpuF?.GetValue(win) as Cpu) != null;

            if (hasLast && enabled == lastEn && open == lastOpen && varMode == lastVar && hasCpu == lastCpu) return;
            hasLast = true;
            lastEn = enabled; lastOpen = open; lastVar = varMode; lastCpu = hasCpu;

            if (!enabled) { ApplySplitLayout(false); return; }
            if (!btn.gameObject.activeSelf) ApplySplitLayout(true);

            btn.Interactable = !varMode && open && hasCpu;
            btn.Text = varMode ? "Copy (Exit Variant)" : (!open ? "Copy (Open Creator)" : "Copy CPU");
        }

        private static CreatorCpu FindActiveCreatorCpu()
        {
            var win = CreatorManager.Instance?.GetWindowOfType(CreatorWindow.Type.Cpu);
            if (win == null || (!win.IsOpen && !win.gameObject.activeInHierarchy)) return null;
            if (_creatorCpu == null)
                _creatorCpu = UnityEngine.Object.FindFirstObjectByType<CreatorCpu>(FindObjectsInactive.Include);
            return _creatorCpu;
        }

        private static void CopyInspectedCpuToCreator(Cpu target)
        {
            var player = Player.Instance?.Company;
            var creator = FindActiveCreatorCpu();
            var cm = CreatorManager.Instance;
            if (player == null || creator == null || cm == null || target == null || IsBinningVariantMode()) return;

            FallbackScratch.Clear();

            var chosenArch = PickBestArchitecture(player, target, FallbackScratch);
            if (chosenArch == null) { ShowRedError("Cannot Copy CPU", "No usable Instruction Set Architecture is unlocked or licensed."); return; }

            var chosenPkg = PickBestPackage(player, target, FallbackScratch);
            if (chosenPkg == null) { ShowRedError("Cannot Copy CPU", "No CPU Package / Socket is unlocked yet."); return; }

            var (chosenNode, chosenNodeMfr) = PickBestProcessNode(player, target, FallbackScratch);
            if (chosenNode == null)
            {
                ShowRedError("Cannot Copy CPU", player.IsFabless
                    ? "No Foundry Services contract provides a Process Node."
                    : "No Process Node / Lithography is researched yet.");
                return;
            }

            var chosenMem = PickBestMemory(player, target, FallbackScratch);
            if (chosenMem == null) { ShowRedError("Cannot Copy CPU", "No Memory Controller technology is unlocked yet."); return; }

            ApplyToCreatorCpu(creator, cm, target, chosenArch, chosenPkg, chosenNode, chosenNodeMfr, chosenMem, FallbackScratch);
        }

        private static Architecture PickBestArchitecture(ICompany player, Cpu target, List<string> fallbacks)
        {
            var avail = ArchitectureManager.Instance?.GetAvailableArchitectures();
            if (avail == null) return null;

            Architecture best = null;
            for (int i = 0; i < avail.Count; i++)
            {
                var a = avail[i];
                if (a == target.Architecture && IsArchUsableByPlayer(player, a)) return a;
                if (!IsArchUsableByPlayer(player, a)) continue;
                int aYr = a.ReleaseDate != null ? a.ReleaseDate.Year : 0;
                int bYr = best?.ReleaseDate != null ? best.ReleaseDate.Year : 0;
                if (best == null || a.IpcMultiplier > best.IpcMultiplier ||
                    (Mathf.Approximately(a.IpcMultiplier, best.IpcMultiplier) && aYr > bYr))
                    best = a;
            }
            if (best != null && target.Architecture != null && best != target.Architecture)
                fallbacks.Add($"ISA -> {best.Name}");
            return best;
        }

        private static IPackage PickBestPackage(ICompany player, Cpu target, List<string> fallbacks)
        {
            var list = player.Packages;
            if (list == null) return null;

            IPackage best = null;
            float bestScore = float.MinValue;
            for (int i = 0; i < list.Count; i++)
            {
                var p = list[i];
                if (p == null) continue;
                if (ReferenceEquals(p, target.Package)) return p;
                float sc = ScorePackage(p, target.DieCount);
                if (best == null || sc > bestScore) { best = p; bestScore = sc; }
            }
            if (best != null && target.Package != null) fallbacks.Add($"Package -> {best.Name}");
            return best;
        }

        private static (ProcessNode node, ICompany mfr) PickBestProcessNode(ICompany player, Cpu target, List<string> fallbacks)
        {
            CollectUsableProcessNodes(player, NodeScratch);
            ProcessNode exactNode = null;
            ICompany exactMfr = player;
            ProcessNode bestNode = null;
            ICompany bestMfr = player;

            for (int i = 0; i < NodeScratch.Count; i++)
            {
                var cand = NodeScratch[i];
                if (cand.node == target.ProcessNode)
                {
                    if (exactNode == null || cand.mfr == target.Manufacturer) { exactNode = cand.node; exactMfr = cand.mfr; }
                    if (cand.mfr == target.Manufacturer) return (exactNode, exactMfr);
                }
                if (bestNode == null || cand.node.TransistorDensity > bestNode.TransistorDensity ||
                    (Mathf.Approximately(cand.node.TransistorDensity, bestNode.TransistorDensity) && cand.node.Year > bestNode.Year))
                {
                    bestNode = cand.node;
                    bestMfr = cand.mfr;
                }
            }

            if (exactNode != null) return (exactNode, exactMfr);
            if (bestNode != null && target.ProcessNode != null) fallbacks.Add($"Node -> {bestNode.Name}");
            return (bestNode, bestMfr);
        }

        private static Memory PickBestMemory(ICompany player, Cpu target, List<string> fallbacks)
        {
            var list = player.Memories;
            if (list == null) return null;

            Memory best = null;
            for (int i = 0; i < list.Count; i++)
            {
                var m = list[i];
                if (m == null) continue;
                if (m == target.Memory) return m;
                if (best == null || m.IpsThreshold > best.IpsThreshold) best = m;
            }
            if (best != null && target.Memory != null) fallbacks.Add($"Memory -> {best.Name}");
            return best;
        }

        private static void ApplyToCreatorCpu(CreatorCpu creator, CreatorManager cm, Cpu target,
            Architecture arch, IPackage pkg, ProcessNode node, ICompany nodeMfr, Memory mem, List<string> fallbacks)
        {
            if (AutoCacheToggleF?.GetValue(creator) is ToggleUI autoCache && autoCache.Interactable)
                autoCache.IsOn = false;

            CmArchF?.SetValue(cm, arch);
            CmPkgF?.SetValue(cm, pkg);
            CmLithoF?.SetValue(cm, node);
            CmMemF?.SetValue(cm, mem);
            CmNodeCompF?.SetValue(cm, nodeMfr);

            cm.GetHardwareOpenButtonOfType(HardwareType.Architecture, SelectorVariant.CpuCreator)?.SetText(arch.Name);
            cm.GetHardwareOpenButtonOfType(HardwareType.Package, SelectorVariant.CpuCreator)?.SetText(pkg.Name);
            cm.GetHardwareOpenButtonOfType(HardwareType.Lithography, SelectorVariant.CpuCreator)?.SetText(node.Name);
            cm.GetHardwareOpenButtonOfType(HardwareType.Memory, SelectorVariant.CpuCreator)?.SetText(mem.Name);

            UpdateCurrentHardwaresM?.Invoke(creator, null);
            UpdateUiM?.Invoke(creator, new object[] { false });

            if (SmtToggleF?.GetValue(creator) is ToggleUI smtToggle)
            {
                bool wantSmt = target.Smt && smtToggle.Interactable;
                if (target.Smt && !smtToggle.Interactable) fallbacks.Add("SMT locked");
                smtToggle.IsOn = wantSmt;
                SmtBoolF?.SetValue(creator, wantSmt);
            }

            float maxSafeFreq = MaxFreqF != null ? (float)MaxFreqF.GetValue(creator) : target.FrequencyTechnology;
            bool wantOc = maxSafeFreq > 0f && target.Frequency > maxSafeFreq * 1.01f;
            if (OverclockToggleF?.GetValue(creator) is ToggleUI ocToggle)
            {
                if (ocToggle.Interactable) ocToggle.IsOn = wantOc;
                else if (wantOc) { ocToggle.IsOn = false; fallbacks.Add("Overclock locked"); }
            }

            UpdateUiM?.Invoke(creator, new object[] { false });

            if (DieDropF?.GetValue(creator) is DropdownUI dieDd)
            {
                int idx = FindBestNumericOptionIndex(dieDd, Math.Max(1, target.DieCount), out int pickedDies);
                if (idx >= 0) dieDd.SetSelected(idx);
                int setDieCount = pickedDies > 0 ? pickedDies : (dieDd.Value + 1);
                DieCountF?.SetValue(creator, setDieCount);
                if (setDieCount != Math.Max(1, target.DieCount)) fallbacks.Add($"Dies -> {setDieCount}");
            }

            UpdateCoreCountDropdownM?.Invoke(creator, null);
            UpdateCoreCountM?.Invoke(creator, null);

            if (CoreDropF?.GetValue(creator) is DropdownUI coreDd)
            {
                int idx = FindBestNumericOptionIndex(coreDd, Math.Max(1, target.CoreCount), out int pickedCores);
                if (idx >= 0) coreDd.SetSelected(idx);
                if (pickedCores > 0 && pickedCores != Math.Max(1, target.CoreCount)) fallbacks.Add($"Cores -> {pickedCores}");
            }

            UpdateCoreCountM?.Invoke(creator, null);
            int actualDies = Math.Max(1, DieCountF != null ? (int)DieCountF.GetValue(creator) : target.DieCount);
            int actualCores = Math.Max(1, CoreCountF != null ? (int)CoreCountF.GetValue(creator) : target.CoreCount);

            if (AutoCacheToggleF?.GetValue(creator) is ToggleUI autoCache2 && autoCache2.Interactable)
                autoCache2.IsOn = false;

            if (DieSizeSliderF?.GetValue(creator) is SliderUI dieSlider && dieSlider.Slider != null)
            {
                dieSlider.Value = pkg.MaxSize > pkg.MinSize ? Mathf.Clamp01(Mathf.InverseLerp(pkg.MinSize, pkg.MaxSize, target.DieSize)) : 0.5f;
                float actualDie = Mathf.Lerp(pkg.MinSize, pkg.MaxSize, dieSlider.Value);
                if (Mathf.Abs(actualDie - target.DieSize) > 2f) fallbacks.Add($"Die -> {actualDie:0}mm²");
            }

            if (FreqSliderF?.GetValue(creator) is SliderUI freqSlider)
            {
                if (SliderValuesF?.GetValue(freqSlider) is List<float> steps && steps.Count > 0)
                {
                    int bestIdx = 0;
                    float bestDiff = float.MaxValue;
                    for (int i = 0; i < steps.Count; i++)
                    {
                        float d = Mathf.Abs(steps[i] - target.Frequency);
                        if (d < bestDiff) { bestDiff = d; bestIdx = i; }
                    }
                    freqSlider.Value = bestIdx;
                    float chosenFreq = steps[bestIdx];
                    if (Mathf.Abs(chosenFreq - target.Frequency) > Mathf.Max(20f, target.Frequency * 0.08f))
                        fallbacks.Add($"Clock -> {chosenFreq:0}MHz");
                }
                else if (freqSlider.Slider != null)
                    freqSlider.Value = Mathf.Clamp(target.Frequency, freqSlider.Slider.minValue, freqSlider.Slider.maxValue);
            }

            SetClampedSlider(L1SliderF?.GetValue(creator) as SliderUI, Mathf.Round(target.L1Cache / (float)actualCores));
            SetClampedSlider(L2SliderF?.GetValue(creator) as SliderUI, Mathf.Round(target.L2Cache / (float)actualCores));
            SetClampedSlider(L3SliderF?.GetValue(creator) as SliderUI, Mathf.Round(target.L3Cache / (16f * actualDies)));

            if (NameInputF?.GetValue(creator) is TMP_InputField nameInp)
            {
                string rawName = (target.Name ?? "CPU").TrimEnd();
                if (rawName.EndsWith(" Copy", StringComparison.OrdinalIgnoreCase))
                    rawName = rawName.Substring(0, rawName.Length - 5).TrimEnd();
                int limit = nameInp.characterLimit > 0 ? nameInp.characterLimit : 20;
                string copyName = $"{rawName} Copy";
                nameInp.text = copyName.Length > limit ? copyName.Substring(0, limit).TrimEnd() : copyName;
            }

            UpdateImagesM?.Invoke(creator, null);
            UpdateNumbersM?.Invoke(creator, null);

            if (fallbacks.Count > 0)
                PopupManager.Instance?.InstantiateGenericNotification("<color=#FF6B6B>Copied with Best Available Tech</color>", $"<color=#FFA8A8>{string.Join(" · ", fallbacks)}</color>");
            else
                PopupManager.Instance?.InstantiateGenericNotification("<color=#6EE787>Copied Specs to CPU Creator</color>", target.Name);
        }

        private static float ScorePackage(IPackage pkg, int targetDies)
        {
            if (pkg is Package p)
                return (p.MaxDies >= targetDies ? 10000f : p.MaxDies * 500f) + p.MaxCacheKB * 0.05f + p.ThermalEfficiency * 100f + p.Year;
            return pkg.MaxDies * 500f + pkg.ThermalEfficiency * 100f;
        }

        private static void CollectUsableProcessNodes(ICompany player, List<(ProcessNode, ICompany)> res)
        {
            res.Clear();
            if (!player.IsFabless && player.ProcessNodes != null)
            {
                for (int i = 0; i < player.ProcessNodes.Count; i++)
                    if (player.ProcessNodes[i] != null) res.Add((player.ProcessNodes[i], player));
            }
            FoundryScratch.Clear();
            var foundries = CompanyDataProvider.Instance?.GetFoundryCompanies(FoundryScratch, player);
            if (foundries == null) return;
            for (int i = 0; i < foundries.Count; i++)
            {
                var f = foundries[i];
                if (f == null || f == player || f.ProcessNodes == null) continue;
                if (BusinessContractManager.Instance?.GetFoundryServicesContract(f, player) == null) continue;
                for (int j = 0; j < f.ProcessNodes.Count; j++)
                    if (f.ProcessNodes[j] != null) res.Add((f.ProcessNodes[j], f));
            }
        }

        private static void SetClampedSlider(SliderUI s, float target)
        {
            if (s == null || s.Slider == null) return;
            s.Value = Mathf.Clamp(target, s.Slider.minValue, s.Slider.maxValue);
        }

        private static int FindBestNumericOptionIndex(DropdownUI dd, int target, out int chosenVal)
        {
            chosenVal = -1;
            var tmp = dd.GetComponentInChildren<TMP_Dropdown>(true);
            if (tmp == null || tmp.options == null || tmp.options.Count == 0) return -1;

            int bestIdx = 0;
            int bestDiff = int.MaxValue;
            for (int i = 0; i < tmp.options.Count; i++)
            {
                int val = ExtractLeadingInt(tmp.options[i].text);
                if (val == target) { chosenVal = val; return i; }
                int diff = val <= target ? (target - val) : (val - target) + 10000;
                if (diff < bestDiff) { bestDiff = diff; bestIdx = i; chosenVal = val; }
            }
            return bestIdx;
        }

        private static int ExtractLeadingInt(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            int val = 0;
            bool started = false;
            bool inTag = false;
            for (int i = 0; i < s.Length; i++)
            {
                char ch = s[i];
                if (ch == '<') { inTag = true; continue; }
                if (inTag) { if (ch == '>') inTag = false; continue; }
                if (ch >= '0' && ch <= '9') { started = true; val = val * 10 + (ch - '0'); }
                else if (started) break;
            }
            return val;
        }

        private static void ShowRedError(string title, string body) =>
            PopupManager.Instance?.InstantiateGenericNotification($"<color=#FF5555>{title}</color>", $"<color=#FF9999>{body}</color>");
    }
}
