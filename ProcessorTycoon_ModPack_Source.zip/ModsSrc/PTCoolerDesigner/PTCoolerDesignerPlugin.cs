using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.TimeSystem;
using PTModdingAPI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ContractKind = ProcessorTycoon.ContractSystem.ContractType;

namespace PTCoolerDesigner
{
    public sealed class CoolerDesignSpec
    {
        public string Id;
        public string Name;
        public string ArchId;
        public float Mass;       // 0.70 .. 2.20
        public float Airflow;    // 0.60 .. 2.00
        public int DieCoverage;  // 1, 4, 8
        public float ThermalEffBonus;
        public float SafeTempBonus;
        public int BomCost;
        public float RecMaxTdp;
    }

    public sealed class CoolerArchDef
    {
        public string TechId;
        public string DisplayName;
        public int Year;
        public float BaseEff;
        public float BaseSafeTemp;
        public int BaseBomCost;
        public float BaseProjectCost;
        public int BaseProjectDays;
    }

    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    [BepInDependency(PTModdingApiPlugin.PluginGuid)]
    public class PTCoolerDesignerPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.coolerdesigner";
        public const string PluginName = "PT Cooler Designer";
        public const string PluginVersion = "2.0.0";

        internal const string TechTabId = "cooling";
        internal static ManualLogSource Log;

        public static ConfigEntry<bool> EnableMod;
        public static ConfigEntry<float> ResearchSpeedMult;

        private static readonly List<CoolerArchDef> CoolerArchs = new List<CoolerArchDef>
        {
            new CoolerArchDef { TechId = "cool_alfin", DisplayName = "Extruded Aluminum Fin", Year = 1971, BaseEff = 0.22f, BaseSafeTemp = 2.0f, BaseBomCost = 4, BaseProjectCost = 280_000f, BaseProjectDays = 35 },
            new CoolerArchDef { TechId = "cool_blower", DisplayName = "Radial Axial Fan & Shroud", Year = 1982, BaseEff = 0.44f, BaseSafeTemp = 3.0f, BaseBomCost = 9, BaseProjectCost = 620_000f, BaseProjectDays = 48 },
            new CoolerArchDef { TechId = "cool_copper_slug", DisplayName = "Copper Core & Ducted Fan", Year = 1994, BaseEff = 0.72f, BaseSafeTemp = 4.5f, BaseBomCost = 16, BaseProjectCost = 1_250_000f, BaseProjectDays = 62 },
            new CoolerArchDef { TechId = "cool_heatpipe", DisplayName = "Sintered Heatpipe Tower", Year = 2002, BaseEff = 1.12f, BaseSafeTemp = 6.0f, BaseBomCost = 26, BaseProjectCost = 2_400_000f, BaseProjectDays = 76 },
            new CoolerArchDef { TechId = "cool_vapor_dt", DisplayName = "Vapor Chamber Dual-Tower", Year = 2009, BaseEff = 1.55f, BaseSafeTemp = 7.5f, BaseBomCost = 42, BaseProjectCost = 4_200_000f, BaseProjectDays = 92 },
            new CoolerArchDef { TechId = "cool_aio_120", DisplayName = "120mm Closed-Loop AIO Liquid", Year = 2011, BaseEff = 1.75f, BaseSafeTemp = 8.0f, BaseBomCost = 58, BaseProjectCost = 5_400_000f, BaseProjectDays = 100 },
            new CoolerArchDef { TechId = "cool_aio_360", DisplayName = "360mm High-Static AIO Liquid", Year = 2017, BaseEff = 2.25f, BaseSafeTemp = 9.0f, BaseBomCost = 88, BaseProjectCost = 8_500_000f, BaseProjectDays = 118 },
            new CoolerArchDef { TechId = "cool_subzero", DisplayName = "Closed-Loop Chiller Loop", Year = 2023, BaseEff = 2.80f, BaseSafeTemp = 10.0f, BaseBomCost = 145, BaseProjectCost = 14_000_000f, BaseProjectDays = 135 }
        };

        private static readonly DesignCatalog<CoolerDesignSpec> Catalog = new DesignCatalog<CoolerDesignSpec>(d => d.Id);
        private static readonly CpuBomTracker BomTracker = new CpuBomTracker();
        private static readonly PersistentDesignProject<CoolerDesignSpec> DesignProject = new PersistentDesignProject<CoolerDesignSpec>("cooler_design_proj");
        private static readonly List<CoolerArchDef> UnlockedArchScratch = new List<CoolerArchDef>();
        private static string _selectedMode = "AUTO";

        private static StudioWindowShell _shell;
        private static TMP_Text _massLabel, _airLabel;
        private static Button _cov1Btn, _cov4Btn, _cov8Btn;
        private static int _selectedArchIdx;
        private static float _curMass = 1.25f;
        private static float _curAir = 1.20f;
        private static int _curCov = 1;

        private void Awake()
        {
            Log = Logger;
            EnableMod = Config.Bind("1. General", "Enabled", true, "Enable Cooler Designer and Cooling tech tree");
            ResearchSpeedMult = Config.Bind("2. Balance", "Research Speed Multiplier", 1.0f, "Multiplier for Cooling R&D research speed (0.25 - 3.0)");

            RegisterTechTree();
            RegisterHooks();
            Log.LogInfo($"{PluginName} v{PluginVersion} initialized.");
        }

        private static void RegisterTechTree()
        {
            var tab = new ModTechTabDef
            {
                TabId = TechTabId,
                TabTitle = "Cooling",
                Subtitle = "Research cooler architectures, vapor chambers, AIO loops, and multi-die coldplates. Cooler designs execute as real timed R&D projects.",
                ActionButtonLabel = "Open Cooler Designer",
                OnActionButtonClick = OpenWindow,
                IsModEnabled = () => EnableMod.Value,
                GetResearchSpeedMultiplier = () => Mathf.Clamp(ResearchSpeedMult?.Value ?? 1f, 0.25f, 3f)
            };

            tab.Branches.Add(new ModTechBranchDef { Id = 0, Name = "Air & Heatpipe", AccentColor = UiFactory.AccentBlue });
            tab.Branches.Add(new ModTechBranchDef { Id = 1, Name = "Vapor Chamber", AccentColor = UiFactory.AccentAmber });
            tab.Branches.Add(new ModTechBranchDef { Id = 2, Name = "Liquid & Chiller", AccentColor = UiFactory.AccentGreen });
            tab.Branches.Add(new ModTechBranchDef { Id = 3, Name = "Multi-Die Coldplate", AccentColor = new Color(0.70f, 0.45f, 0.90f, 1f) });

            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_alfin", ShortName = "Al Fin", Name = "Aluminum Fin Heatsink", Branch = 0, Tier = 0, Year = 1971, BaseDays = 80f, MonthlyCost = 45_000f, Description = "Passive extruded aluminum fin array for early socketed CPUs.", EffectsSummary = "• Unlocks Aluminum Fin coolers\n• -12% ΔT Heat · BOM ~$4" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_blower", ShortName = "Axial Fan", Name = "Radial & Axial Fan Shroud", Branch = 0, Tier = 1, Year = 1982, BaseDays = 110f, MonthlyCost = 110_000f, Prereqs = new[] { "cool_alfin" }, Description = "Active forced-air DC fan shrouds sharply reducing thermal resistance.", EffectsSummary = "• Unlocks Axial Fan coolers\n• +OEM phone/console contract cooling" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_copper_slug", ShortName = "Cu Insert", Name = "Copper Core & Fin Stack", Branch = 0, Tier = 2, Year = 1994, BaseDays = 135f, MonthlyCost = 260_000f, Prereqs = new[] { "cool_blower" }, Description = "High-conductivity copper baseplate bonded to dense fin arrays.", EffectsSummary = "• Unlocks Copper Core coolers\n• -30% ΔT Heat · Safe Temp +4.5°C" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_heatpipe", ShortName = "Heatpipe", Name = "Sintered Heatpipe Tower", Branch = 0, Tier = 3, Year = 2002, BaseDays = 160f, MonthlyCost = 580_000f, Prereqs = new[] { "cool_copper_slug" }, Description = "Phase-change sintered copper heatpipes for desktop and server workstations.", EffectsSummary = "• Unlocks Heatpipe Towers\n• Boosts laptop & phone heatpipe OEMs" });

            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_dt_pipe", ShortName = "HDT Base", Name = "Direct-Touch Heatpipes", Branch = 1, Tier = 2, Year = 2005, BaseDays = 140f, MonthlyCost = 420_000f, Prereqs = new[] { "cool_copper_slug" }, Description = "Machined flat heatpipe contact surface eliminating intermediate spreader loss.", EffectsSummary = "• -12% OEM contract thermal limits\n• Required for Vapor Chamber" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_vapor_dt", ShortName = "Vapor Chm", Name = "Vapor Chamber Dual-Tower", Branch = 1, Tier = 3, Year = 2009, BaseDays = 175f, MonthlyCost = 880_000f, Prereqs = new[] { "cool_dt_pipe", "cool_heatpipe" }, Description = "2D planar vapor chamber equalizer under dual twin-fan towers.", EffectsSummary = "• Unlocks Vapor Chamber Dual-Towers\n• Boosts slim Phone/Console vapor cooling" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_thin_vapor", ShortName = "Thin Vapor", Name = "Ultra-Thin Graphene Vapor", Branch = 1, Tier = 4, Year = 2016, BaseDays = 190f, MonthlyCost = 1_650_000f, Prereqs = new[] { "cool_vapor_dt" }, Description = "Sub-millimeter graphene + copper vapor spreaders for mobile & console SoCs.", EffectsSummary = "• Major OEM Contract TDP boost for Phone/Console" });

            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_pump_micro", ShortName = "Skived Pump", Name = "Skived Micro-Fin Coldplate", Branch = 2, Tier = 2, Year = 2006, BaseDays = 150f, MonthlyCost = 520_000f, Prereqs = new[] { "cool_heatpipe" }, Description = "Micro-skived copper waterblock geometry for closed-loop liquid pumps.", EffectsSummary = "• Prerequisite for AIO Liquid Loops" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_aio_120", ShortName = "120 AIO", Name = "120mm Closed-Loop AIO", Branch = 2, Tier = 3, Year = 2011, BaseDays = 170f, MonthlyCost = 950_000f, Prereqs = new[] { "cool_pump_micro" }, Description = "Factory-sealed pump-in-block liquid radiator for high-TDP desktop CPUs.", EffectsSummary = "• Unlocks 120mm AIO designs\n• -52% ΔT Heat · Safe Temp +8.0°C" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_aio_360", ShortName = "360 AIO", Name = "360mm High-Static AIO", Branch = 2, Tier = 4, Year = 2017, BaseDays = 205f, MonthlyCost = 1_850_000f, Prereqs = new[] { "cool_aio_120" }, Description = "Triple-fan radiator and high-flow magnetic levitation pump.", EffectsSummary = "• Unlocks 360mm AIO designs\n• Handles 350W+ overclocked CPUs" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_subzero", ShortName = "Chiller", Name = "Closed-Loop Chiller Loop", Branch = 2, Tier = 5, Year = 2023, BaseDays = 240f, MonthlyCost = 3_200_000f, Prereqs = new[] { "cool_aio_360" }, Description = "Active thermoelectric/compressor chilled coolant manifold.", EffectsSummary = "• Unlocks Chiller coolers\n• -63% ΔT Heat · Safe Temp +10.0°C" });

            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_flat_ihs", ShortName = "Full IHS", Name = "Soldered TIM & Flat IHS Prep", Branch = 3, Tier = 1, Year = 2004, BaseDays = 130f, MonthlyCost = 440_000f, Prereqs = new[] { "cool_copper_slug" }, Description = "Preps coldplates for wide multi-die heatspreaders and indium solder TIM.", EffectsSummary = "• Required for Multi-Die Coldplate tech" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_mcm_coldplate", ShortName = "4-Die Plate", Name = "Wide-Footprint 4-Die Coldplate", Branch = 3, Tier = 2, Year = 2010, BaseDays = 165f, MonthlyCost = 920_000f, Prereqs = new[] { "cool_flat_ihs" }, Description = "Enlarged coldplate manifold engineered to evenly cool 2-4 chiplet dies.", EffectsSummary = "• Unlocks 2-4 Die MCM cooler option\n• Eliminates multi-die hotspot buildup" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_offset_mount", ShortName = "Offset Mount", Name = "Asymmetric Chiplet Offset Mount", Branch = 3, Tier = 3, Year = 2016, BaseDays = 185f, MonthlyCost = 1_450_000f, Prereqs = new[] { "cool_mcm_coldplate" }, Description = "Centers jet impingement directly over high-density compute chiplets.", EffectsSummary = "• Passive +2.0°C multi-die safe margin" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_8die_array", ShortName = "8-Die Array", Name = "SP/Epyc 8-Die Server Coldplate", Branch = 3, Tier = 4, Year = 2018, BaseDays = 215f, MonthlyCost = 2_400_000f, Prereqs = new[] { "cool_offset_mount" }, Description = "Full-coverage server coldplate spanning massive multi-MCM socket substrates.", EffectsSummary = "• Unlocks 8-Die Full Array coverage\n• Safe Temp +3°C bonus on >=4-die CPUs" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "cool_direct_die", ShortName = "Direct-Die", Name = "Direct-Die Microchannel Lid", Branch = 3, Tier = 5, Year = 2022, BaseDays = 235f, MonthlyCost = 3_100_000f, Prereqs = new[] { "cool_8die_array" }, Description = "Fluid channels etched directly onto package stiffener for extreme MCM loads.", EffectsSummary = "• +12% effective cooling on all PGA/LGA chips" });

            ModTechRegistry.RegisterTechTab(tab);
        }

        private static void RegisterHooks()
        {
            ModApi.RegisterSaveParticipant("cooler_designer", SerializeDesigns, DeserializeDesigns, ResetState);

            ModApi.RegisterHardwareMenuAction(new HardwareMenuButtonDef
            {
                Id = "new_cooler",
                Label = "New Cooler",
                IsVisible = () => EnableMod.Value,
                OnClick = OpenWindow
            });

            ModApi.RegisterCreatorCpuSlot(new CreatorCpuSlotDef
            {
                SlotId = "cooler_slot",
                Label = "Cooler",
                IsVisible = () => EnableMod.Value,
                IsInteractable = () => { var p = ModApi.CurrentCreatorPackage; return p != null && p.IsPgaOrLga; },
                GetDisplayText = GetCreatorSlotText,
                GetBadgeColor = GetCreatorSlotColor,
                OnPrev = () => CycleSelection(-1),
                OnNext = () => CycleSelection(1),
                OnOpenStudio = OpenWindow,
                OnClick = OpenWindow
            });

            BomTracker.RegisterHooks(() => EnableMod.Value, () => { var s = GetActiveSpec(); return s != null ? s.BomCost : 0; });

            ModApi.RegisterPackageThermalEfficiencyModifier((pkg, cur) =>
            {
                if (!EnableMod.Value || pkg == null || !pkg.IsPgaOrLga) return cur;
                var spec = GetActiveSpec();
                if (spec == null) return cur;
                float reduction = GetTempRiseReduction(spec, ModTechRegistry.GetPlayerState(TechTabId));
                float baseRes = Mathf.Max(0.12f, 2.5f - cur);
                return 2.5f - Mathf.Max(0.08f, baseRes * (1f - reduction));
            });

            ModApi.RegisterPackageSafeTemperatureModifier((pkg, cur) =>
            {
                if (!EnableMod.Value || pkg == null || !pkg.IsPgaOrLga) return cur;
                var spec = GetActiveSpec();
                if (spec == null) return cur;
                var st = ModTechRegistry.GetPlayerState(TechTabId);
                float multiDieBonus = 0f;
                if (st != null && st.IsUnlocked("cool_offset_mount") && pkg.MaxDies >= 2) multiDieBonus += 2.0f;
                if (st != null && st.IsUnlocked("cool_8die_array") && pkg.MaxDies >= 4) multiDieBonus += 3.0f;
                return Mathf.Max(cur, Mathf.Min(95f, cur + ClampedHeadroom(spec) + multiDieBonus));
            });

            ModApi.RegisterCpuStatModifier((ctx, mods) =>
            {
                if (!EnableMod.Value || ctx?.Package == null || !ctx.Package.IsPgaOrLga) return;
                var spec = GetActiveSpec();
                if (spec != null && ctx.DieCount > spec.DieCoverage)
                    mods.FailureMultiplier *= 1f + Mathf.Min(0.35f, (ctx.DieCount - spec.DieCoverage) * 0.05f);
            });

            ModApi.RegisterContractPowerModifier((contract, cpu, curMult) =>
            {
                if (!EnableMod.Value || contract == null || contract.ContractType == ContractKind.Calculator) return curMult;
                return curMult * EstimateOemContractPowerHeadroom(contract.ContractType);
            });
        }

        private static void ResetState()
        {
            Catalog.Clear();
            BomTracker.Clear();
            DesignProject.Clear();
            _selectedMode = "AUTO";
            if (_shell?.OverlayGo != null) _shell.OverlayGo.SetActive(false);
        }

        private static float ClampedHeadroom(CoolerDesignSpec spec) => spec != null ? Mathf.Min(10f, spec.SafeTempBonus) : 0f;

        private static float GetTempRiseReduction(CoolerDesignSpec spec, ModCompanyTechState st)
        {
            if (spec == null) return 0f;
            float power = Mathf.Max(0f, spec.ThermalEffBonus);
            if (st != null && st.IsUnlocked("cool_direct_die")) power *= 1.12f;
            return Mathf.Clamp(power / (power + 1.65f), 0f, 0.72f);
        }

        private static float EstimateOemContractPowerHeadroom(ContractKind kind)
        {
            if (kind == ContractKind.Calculator) return 1f;
            int yr = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
            var pst = ModTechRegistry.GetPlayerState(TechTabId);
            int unlockedCount = pst != null ? pst.UnlockedIds.Count : 0;

            float eraFactor = Mathf.Clamp01((yr - 1975f) / 48f);
            float techFactor = Mathf.Clamp01(unlockedCount / 14f);
            float thinVapor = (pst != null && pst.IsUnlocked("cool_thin_vapor") && (kind == ContractKind.Phone || kind == ContractKind.Console)) ? 0.10f : 0f;
            float combined = Mathf.Clamp01(Mathf.Max(eraFactor * 0.75f, techFactor) + thinVapor);

            return kind switch
            {
                ContractKind.Phone => 1f + combined * 0.58f,
                ContractKind.Console => 1f + combined * 0.72f,
                ContractKind.Computer => 1f + combined * 0.65f,
                _ => 1f
            };
        }

        private static void CycleSelection(int dir)
        {
            _selectedMode = Catalog.CycleMode(_selectedMode, dir);
            ModApi.RefreshCreatorCpu();
            if (_shell?.OverlayGo != null && _shell.OverlayGo.activeInHierarchy) RefreshPreview();
        }

        private static CoolerDesignSpec GetActiveSpec() =>
            Catalog.Resolve(ref _selectedMode, TechTabId, st =>
            {
                CoolerArchDef best = null;
                for (int i = 0; i < CoolerArchs.Count; i++)
                    if (st != null && st.IsUnlocked(CoolerArchs[i].TechId)) best = CoolerArchs[i];
                return best != null ? ComputeSpec($"OEM {best.DisplayName}", best, 1.0f, 1.0f, 1) : null;
            });

        private static string GetCreatorSlotText()
        {
            var pkg = ModApi.CurrentCreatorPackage;
            if (pkg != null && !pkg.IsPgaOrLga) return "Cooler: OEM Device (BGA/DIP)";
            var sp = GetActiveSpec();
            if (_selectedMode == "NONE") return "Cooler: None ($0)";
            if (sp == null) return "Cooler: Locked (Research)";
            int pct = Mathf.RoundToInt(GetTempRiseReduction(sp, ModTechRegistry.GetPlayerState(TechTabId)) * 100f);
            return $"Cooler: {(_selectedMode == "AUTO" ? "Auto" : sp.Name)} (-{pct}% Heat, +${sp.BomCost})";
        }

        private static Color GetCreatorSlotColor()
        {
            var pkg = ModApi.CurrentCreatorPackage;
            if (pkg != null && !pkg.IsPgaOrLga) return UiFactory.CardAltBg;
            if (GetActiveSpec() == null) return UiFactory.CardAltBg;
            return _selectedMode == "AUTO" ? new Color(0.18f, 0.28f, 0.36f, 1f) : new Color(0.16f, 0.34f, 0.26f, 1f);
        }

        private static CoolerDesignSpec ComputeSpec(string name, CoolerArchDef arch, float mass, float air, int cov)
        {
            float covScale = cov >= 8 ? 1.15f : (cov >= 4 ? 1.07f : 1.0f);
            float eff = arch.BaseEff * (0.55f + 0.45f * mass) * (0.55f + 0.45f * air) * covScale;
            float safeT = Mathf.Min(10f, arch.BaseSafeTemp * (0.65f + 0.35f * air) * (0.85f + 0.15f * mass) + (cov >= 8 ? 2.5f : cov >= 4 ? 1.0f : 0f));
            int bom = Mathf.RoundToInt(arch.BaseBomCost * (0.6f + 0.4f * mass) * (0.75f + 0.25f * air) * covScale);
            return new CoolerDesignSpec
            {
                Name = name, ArchId = arch.TechId, Mass = mass, Airflow = air, DieCoverage = cov,
                ThermalEffBonus = eff, SafeTempBonus = safeT, BomCost = bom, RecMaxTdp = 35f + eff * 115f
            };
        }

        private static (int days, float cost) EstimateProject(CoolerArchDef arch, float mass, float air, int cov)
        {
            float scale = (0.7f + 0.3f * mass) * (0.75f + 0.25f * air) * (cov >= 8 ? 1.55f : cov >= 4 ? 1.25f : 1f);
            return (Mathf.Clamp(Mathf.RoundToInt(arch.BaseProjectDays * Mathf.Sqrt(scale)), 25, 180),
                    Mathf.Round(arch.BaseProjectCost * scale / 1000f) * 1000f);
        }

        private static List<CoolerArchDef> GetUnlockedArchs()
        {
            var st = ModTechRegistry.GetPlayerState(TechTabId);
            UnlockedArchScratch.Clear();
            for (int i = 0; i < CoolerArchs.Count; i++)
                if (st != null && st.IsUnlocked(CoolerArchs[i].TechId)) UnlockedArchScratch.Add(CoolerArchs[i]);
            return UnlockedArchScratch;
        }

        public static void OpenWindow()
        {
            UiFactory.EnsureEventSystem();
            if (_shell == null || _shell.OverlayGo == null) BuildWindow();
            _shell.OverlayGo.SetActive(true);
            var unlocked = GetUnlockedArchs();
            _selectedArchIdx = unlocked.Count > 0 ? Mathf.Clamp(_selectedArchIdx, 0, unlocked.Count - 1) : 0;
            RefreshUI();
        }

        private static void BuildWindow()
        {
            _shell = StudioWindowShell.Create(
                "PTCoolerDesigner", 520f, "CPU Cooler Studio & Reference Library", "Cooler Catalog (Select in CPU Creation)",
                "Cooler Model Name", "Cooler Mark I", "e.g. CryoTower 240...",
                "Cooling Architecture (Unlocked Tech)", "Cooling Tech Tree", TechTabId, "Start Cooler Project",
                dir => { var u = GetUnlockedArchs(); if (u.Count > 0) _selectedArchIdx = (_selectedArchIdx + dir + u.Count) % u.Count; RefreshUI(); },
                OnBuildCoolerClicked);

            var rp = _shell.RightPane;
            _massLabel = UiFactory.CreateText("MassLbl", rp, "Heatsink / Radiator Mass: 1.25x", 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary);
            _massLabel.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.585f, 0.96f, 0.645f);
            UiFactory.CreateSlider("MassSld", rp, 0.70f, 2.20f, _curMass, v => { _curMass = Mathf.Round(v * 20f) / 20f; RefreshPreview(); })
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.53f, 0.96f, 0.585f);

            _airLabel = UiFactory.CreateText("AirLbl", rp, "Fan / Pump Airflow: 1.20x", 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary);
            _airLabel.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.47f, 0.96f, 0.525f);
            UiFactory.CreateSlider("AirSld", rp, 0.60f, 2.00f, _curAir, v => { _curAir = Mathf.Round(v * 20f) / 20f; RefreshPreview(); })
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.415f, 0.96f, 0.47f);

            UiFactory.CreateText("CovLbl", rp, "Coldplate Multi-Die Coverage", 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.36f, 0.96f, 0.41f);

            _cov1Btn = UiFactory.CreateButton("Cov1", rp, "1-Die Mono", UiFactory.AccentBlue, () => { _curCov = 1; RefreshUI(); }, 11.5f);
            _cov1Btn.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.295f, 0.33f, 0.355f);
            _cov4Btn = UiFactory.CreateButton("Cov4", rp, "2-4 Die MCM", UiFactory.CardBg, () => { _curCov = 4; RefreshUI(); }, 11.5f);
            _cov4Btn.GetComponent<RectTransform>().SetAnchorStretch(0.35f, 0.295f, 0.65f, 0.355f);
            _cov8Btn = UiFactory.CreateButton("Cov8", rp, "8-Die Array", UiFactory.CardBg, () => { _curCov = 8; RefreshUI(); }, 11.5f);
            _cov8Btn.GetComponent<RectTransform>().SetAnchorStretch(0.67f, 0.295f, 0.96f, 0.355f);
        }

        private static void RefreshUI()
        {
            if (_shell?.WindowGo == null) return;
            var st = ModTechRegistry.GetPlayerState(TechTabId);
            _shell.RebuildCatalogRows(
                Catalog.Items, "No custom coolers engineered yet.\nUse Auto or start a Cooler Project ->",
                d => d.Id, d => d.Name,
                d => $"-{Mathf.RoundToInt(GetTempRiseReduction(d, st) * 100f)}% Heat · +{ClampedHeadroom(d):0.#}°C · +${d.BomCost} · {d.DieCoverage}-Die",
                d =>
                {
                    Catalog.Items.RemoveAll(x => x.Id == d.Id);
                    if (_selectedMode == d.Id) _selectedMode = "AUTO";
                    RefreshUI();
                    ModApi.RefreshCreatorCpu();
                });
            RefreshPreview();
        }

        private static void RefreshPreview()
        {
            if (_shell?.WindowGo == null) return;
            var unlocked = GetUnlockedArchs();
            var st = ModTechRegistry.GetPlayerState(TechTabId);

            bool has4 = st != null && st.IsUnlocked("cool_mcm_coldplate");
            bool has8 = st != null && st.IsUnlocked("cool_8die_array");
            if (_curCov >= 8 && !has8) _curCov = has4 ? 4 : 1;
            if (_curCov >= 4 && !has4) _curCov = 1;

            StudioWindowShell.SetSegmentButton(_cov1Btn, _curCov == 1, true);
            StudioWindowShell.SetSegmentButton(_cov4Btn, _curCov == 4, has4);
            StudioWindowShell.SetSegmentButton(_cov8Btn, _curCov == 8, has8);

            _massLabel.text = $"Heatsink / Radiator Mass: {_curMass:0.00}x";
            _airLabel.text = $"Fan / Pump Airflow: {_curAir:0.00}x";

            if (unlocked.Count == 0)
            {
                _shell.TechLabel.text = "None Unlocked (Research Cooling Tech)";
                _shell.PreviewText.text = "Research 'Aluminum Fin Heatsink' in the Cooling tab first.";
                _shell.BuildButton.interactable = false;
                _shell.BuildButtonText.text = "Locked";
                return;
            }

            _selectedArchIdx = Mathf.Clamp(_selectedArchIdx, 0, unlocked.Count - 1);
            var arch = unlocked[_selectedArchIdx];
            _shell.TechLabel.text = $"{arch.DisplayName} ({arch.Year})";

            var spec = ComputeSpec("Preview", arch, _curMass, _curAir, _curCov);
            var proj = EstimateProject(arch, _curMass, _curAir, _curCov);
            int heatPct = Mathf.RoundToInt(GetTempRiseReduction(spec, st) * 100f);

            _shell.PreviewText.text =
                $"<b>Heat Reduction:</b> -{heatPct}% ΔT    <b>Safe Temp Headroom:</b> +{ClampedHeadroom(spec):0.#}°C\n" +
                $"<b>Est. Cooling Target:</b> ~{spec.RecMaxTdp:0}W     <b>CPU Unit Cost BOM:</b> +${spec.BomCost}\n" +
                $"<b>R&D Project:</b> {UiFactory.FormatMoneyCompact(proj.cost)} over {proj.days} days (daily bank-credit billing)";

            _shell.UpdateBuildState(DesignProject.ProjectId, "Start Cooler Project",
                "Select & bundle coolers in CPU Creation's bottom slot bar.", "Active Cooler project in Side Window -> Projects.");
        }

        private static void OnBuildCoolerClicked()
        {
            var unlocked = GetUnlockedArchs();
            if (unlocked.Count == 0 || DesignProject.IsActive) return;

            var arch = unlocked[Mathf.Clamp(_selectedArchIdx, 0, unlocked.Count - 1)];
            string name = SaveCodec.CleanField(string.IsNullOrWhiteSpace(_shell?.NameInput?.text) ? $"Cooler #{Catalog.Items.Count + 1}" : _shell.NameInput.text.Trim());
            var spec = ComputeSpec(name, arch, _curMass, _curAir, _curCov);
            spec.Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            var proj = EstimateProject(arch, _curMass, _curAir, _curCov);
            StartCoolerProject(spec, proj.days, proj.cost, 0f, notifyStart: true);
        }

        private static void StartCoolerProject(CoolerDesignSpec spec, int days, float cost, float initialProgress, bool notifyStart)
        {
            DesignProject.Start(spec, spec.Name, "Cooler R&D", days, cost, initialProgress, () =>
            {
                Catalog.Items.Add(spec);
                _selectedMode = spec.Id;
                ModApi.RefreshCreatorCpu();
                RefreshUI();
                if (DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating)
                    PopupManager.Instance?.InstantiateGenericNotification($"Cooler Ready: {spec.Name}", $"+{ClampedHeadroom(spec):0.#}°C Safe Temp · +${spec.BomCost} BOM");
            });

            RefreshPreview();
            if (notifyStart)
                PopupManager.Instance?.InstantiateGenericNotification($"Cooler Started: {spec.Name}", $"{days}d · {UiFactory.FormatMoneyCompact(cost)}");
        }

        private static string FormatSpecFields(CoolerDesignSpec d) => string.Join("|", new[]
        {
            d.Id, SaveCodec.CleanField(d.Name), d.ArchId,
            SaveCodec.FormatFloat(d.Mass), SaveCodec.FormatFloat(d.Airflow),
            d.DieCoverage.ToString(CultureInfo.InvariantCulture),
            SaveCodec.FormatFloat(d.ThermalEffBonus), SaveCodec.FormatFloat(d.SafeTempBonus),
            d.BomCost.ToString(CultureInfo.InvariantCulture), SaveCodec.FormatFloat(d.RecMaxTdp)
        });

        private static CoolerDesignSpec ParseSpecFields(string[] p, int s) => new CoolerDesignSpec
        {
            Id = p[s], Name = p[s + 1], ArchId = p[s + 2],
            Mass = SaveCodec.ParseFloat(p[s + 3], 1f), Airflow = SaveCodec.ParseFloat(p[s + 4], 1f),
            DieCoverage = SaveCodec.ParseInt(p[s + 5], 1), ThermalEffBonus = SaveCodec.ParseFloat(p[s + 6], 0.4f),
            SafeTempBonus = SaveCodec.ParseFloat(p[s + 7], 5f), BomCost = SaveCodec.ParseInt(p[s + 8], 10),
            RecMaxTdp = SaveCodec.ParseFloat(p[s + 9], 90f)
        };

        private static string SerializeDesigns()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"MODE|{_selectedMode}");
            DesignProject.WritePendingLine(sb, FormatSpecFields);
            for (int i = 0; i < Catalog.Items.Count; i++) sb.AppendLine($"D|{FormatSpecFields(Catalog.Items[i])}");
            BomTracker.WriteLines(sb);
            return sb.ToString();
        }

        private static void DeserializeDesigns(string raw)
        {
            ResetState();
            if (string.IsNullOrWhiteSpace(raw)) return;
            foreach (var line in raw.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = line.Split('|');
                if (p[0] == "MODE" && p.Length >= 2) _selectedMode = p[1];
                else if (p[0] == "D" && p.Length >= 11) Catalog.Items.Add(ParseSpecFields(p, 1));
                else if (!BomTracker.TryReadLine(p))
                    DesignProject.TryReadPendingLine(p, 14, ParseSpecFields, 45, 600_000f, (spec, days, cost, prog) => StartCoolerProject(spec, days, cost, prog, false));
            }
        }
    }
}
