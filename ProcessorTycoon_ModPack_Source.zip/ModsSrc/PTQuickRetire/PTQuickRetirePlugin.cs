using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem.UI;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.Production.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTQuickRetire
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTQuickRetirePlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.quickretire";
        public const string PluginName = "PT Quick 1-Click Retire";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log;
        internal static PTQuickRetirePlugin Instance;

        internal static ConfigEntry<bool> Enabled;
        internal static ConfigEntry<bool> ShowOnProductionCards;
        internal static ConfigEntry<bool> ShowOnSideWindowCards;
        internal static ConfigEntry<bool> GuardContractFines;
        internal static ConfigEntry<bool> ShowToastNotification;

        internal static readonly FieldInfo ProductionEditBtnField = AccessTools.Field(typeof(ProductionUI), "editButton");
        internal static readonly FieldInfo ProductionNameTextField = AccessTools.Field(typeof(ProductionUI), "cpuNameText");
        internal static readonly FieldInfo SalesInspectBtnField = AccessTools.Field(typeof(CpuSalesUI), "inspectButton");
        internal static readonly FieldInfo SalesNameTextField = AccessTools.Field(typeof(CpuSalesUI), "cpuNameText");
        internal static readonly FieldInfo EditWindowCpuField = AccessTools.Field(typeof(CpuEditWindow), "currentCpu");
        internal static readonly MethodInfo EditWindowCloseMethod = AccessTools.Method(typeof(CpuEditWindow), "Close");

        private Harmony _harmony;
        private bool _patched;

        private void Awake()
        {
            Instance = this;
            Log = Logger;

            Enabled = Config.Bind("1. General", "Enabled", true,
                "Enable 1-click CPU retirement buttons on Production and Side Window cards.");
            ShowOnProductionCards = Config.Bind("1. General", "ShowOnProductionCards", true,
                "Show the 1-click retire button on Production window CPU cards.");
            ShowOnSideWindowCards = Config.Bind("1. General", "ShowOnSideWindowCards", true,
                "Show the 1-click retire button on the right-hand Side Window CPU cards.");
            GuardContractFines = Config.Bind("2. Safety", "GuardContractFines", true,
                "If a CPU has active contract breaking fines, require a second click within 3.5s to confirm. CPUs with no contract fines still retire in 1 click.");
            ShowToastNotification = Config.Bind("2. Safety", "ShowToastNotification", true,
                "Show a brief notification toast when retiring a CPU via 1-click retire.");

            Enabled.SettingChanged += (_, __) => ApplyEnabledState();
            ShowOnProductionCards.SettingChanged += (_, __) => QuickRetireButton.RefreshAllVisibility();
            ShowOnSideWindowCards.SettingChanged += (_, __) => QuickRetireButton.RefreshAllVisibility();

            _harmony = new Harmony(PluginGuid);
            ApplyEnabledState();
            Log.LogInfo($"{PluginName} v{PluginVersion} loaded.");
        }

        private void OnDestroy()
        {
            if (_patched)
            {
                _harmony?.UnpatchSelf();
                _patched = false;
            }
        }

        private void ApplyEnabledState()
        {
            if (Enabled.Value)
            {
                if (!_patched)
                {
                    _harmony.PatchAll(typeof(QuickRetirePatches));
                    _patched = true;
                }
            }
            else if (_patched)
            {
                _harmony.UnpatchSelf();
                _patched = false;
            }

            QuickRetireButton.RefreshAllVisibility();
        }

        internal static bool CanRetire(Cpu cpu)
        {
            return cpu != null && !cpu.IsRetired && cpu.Company != null && cpu.Company.IsPlayer;
        }

        internal static string FormatMoney(float amount)
        {
            float abs = Mathf.Abs(amount);
            if (abs >= 1_000_000_000f) return $"${amount / 1_000_000_000f:0.##}B";
            if (abs >= 1_000_000f) return $"${amount / 1_000_000f:0.##}M";
            if (abs >= 1_000f) return $"${amount / 1_000f:0.#}K";
            return $"${amount:0}";
        }
    }

    internal static class QuickRetirePatches
    {
        [HarmonyPatch(typeof(ProductionUI), nameof(ProductionUI.Initialize))]
        [HarmonyPostfix]
        private static void ProductionUI_Initialize_Postfix(ProductionUI __instance, Cpu cpu)
        {
            if (__instance == null || !PTQuickRetirePlugin.CanRetire(cpu)) return;
            var editBtn = PTQuickRetirePlugin.ProductionEditBtnField?.GetValue(__instance) as Component;
            var nameText = PTQuickRetirePlugin.ProductionNameTextField?.GetValue(__instance) as TMP_Text;
            QuickRetireButton.Attach(editBtn, nameText, cpu, isProductionCard: true);
        }

        [HarmonyPatch(typeof(CpuSalesUI), nameof(CpuSalesUI.Initialize))]
        [HarmonyPostfix]
        private static void CpuSalesUI_Initialize_Postfix(CpuSalesUI __instance, Cpu cpu)
        {
            if (__instance == null || !PTQuickRetirePlugin.CanRetire(cpu)) return;
            var inspectBtn = PTQuickRetirePlugin.SalesInspectBtnField?.GetValue(__instance) as Component;
            var nameText = PTQuickRetirePlugin.SalesNameTextField?.GetValue(__instance) as TMP_Text;
            QuickRetireButton.Attach(inspectBtn, nameText, cpu, isProductionCard: false);
        }
    }

    internal class QuickRetireButton : MonoBehaviour
    {
        private const string ButtonObjectName = "PTQuickRetire_Btn";
        private const float ConfirmWindowSeconds = 3.5f;

        private static readonly Color NormalColor = new Color(0.55f, 0.16f, 0.16f, 0.92f);
        private static readonly Color HoverColor = new Color(0.78f, 0.22f, 0.22f, 1f);
        private static readonly Color PressedColor = new Color(0.42f, 0.10f, 0.10f, 1f);
        private static readonly Color ArmedColor = new Color(0.82f, 0.50f, 0.10f, 1f);
        private static readonly Color ArmedHoverColor = new Color(0.92f, 0.58f, 0.14f, 1f);

        private static readonly List<QuickRetireButton> ActiveButtons = new List<QuickRetireButton>();

        private Cpu _cpu;
        private bool _isProductionCard;
        private Button _button;
        private Image _bg;
        private TMP_Text _label;
        private float _armedUntil;

        private void Awake()
        {
            ActiveButtons.Add(this);
        }

        private void OnDestroy()
        {
            ActiveButtons.Remove(this);
        }

        private void Update()
        {
            if (_armedUntil > 0f && Time.unscaledTime >= _armedUntil)
            {
                Disarm();
            }
        }

        public static void RefreshAllVisibility()
        {
            for (int i = ActiveButtons.Count - 1; i >= 0; i--)
            {
                var btn = ActiveButtons[i];
                if (btn == null)
                {
                    ActiveButtons.RemoveAt(i);
                    continue;
                }
                btn.RefreshVisibility();
            }
        }

        public static void Attach(Component anchorButton, TMP_Text nameText, Cpu cpu, bool isProductionCard)
        {
            if (anchorButton == null || anchorButton.transform.parent == null) return;

            var parent = anchorButton.transform.parent;
            var existing = parent.Find(ButtonObjectName);
            QuickRetireButton ctrl;

            if (existing != null)
            {
                ctrl = existing.GetComponent<QuickRetireButton>();
                if (ctrl != null)
                {
                    ctrl.Bind(cpu, isProductionCard);
                    return;
                }
            }

            var anchorRt = anchorButton.GetComponent<RectTransform>();
            var go = new GameObject(ButtonObjectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(QuickRetireButton));
            go.transform.SetParent(parent, false);

            var rt = go.GetComponent<RectTransform>();
            var hasHorizontalLayout = parent.GetComponent<HorizontalLayoutGroup>() != null;

            float btnWidth = 20f;
            float btnHeight = 20f;
            if (anchorRt != null)
            {
                float w = anchorRt.rect.width > 1f ? anchorRt.rect.width : anchorRt.sizeDelta.x;
                float h = anchorRt.rect.height > 1f ? anchorRt.rect.height : anchorRt.sizeDelta.y;
                if (w > 4f) btnWidth = Mathf.Clamp(w, 16f, 26f);
                if (h > 4f) btnHeight = Mathf.Clamp(h, 16f, 26f);
            }

            if (hasHorizontalLayout)
            {
                go.transform.SetSiblingIndex(anchorButton.transform.GetSiblingIndex());
                rt.sizeDelta = new Vector2(btnWidth, btnHeight);
                var le = go.AddComponent<LayoutElement>();
                le.minWidth = btnWidth;
                le.preferredWidth = btnWidth;
                le.minHeight = btnHeight;
                le.preferredHeight = btnHeight;
                le.flexibleWidth = 0f;
            }
            else if (anchorRt != null)
            {
                rt.anchorMin = anchorRt.anchorMin;
                rt.anchorMax = anchorRt.anchorMax;
                rt.pivot = anchorRt.pivot;
                rt.sizeDelta = new Vector2(btnWidth, btnHeight);

                float anchorWidth = anchorRt.rect.width > 1f ? anchorRt.rect.width : (anchorRt.sizeDelta.x > 1f ? anchorRt.sizeDelta.x : btnWidth);
                rt.anchoredPosition = anchorRt.anchoredPosition - new Vector2(anchorWidth + 4f, 0f);
            }

            var bg = go.GetComponent<Image>();
            bg.raycastTarget = true;
            bg.color = Color.white;

            var button = go.GetComponent<Button>();
            button.targetGraphic = bg;
            ApplyColors(button, NormalColor, HoverColor, PressedColor);

            var labelGo = new GameObject("Label", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            labelGo.transform.SetParent(go.transform, false);
            var labelRt = labelGo.GetComponent<RectTransform>();
            labelRt.anchorMin = Vector2.zero;
            labelRt.anchorMax = Vector2.one;
            labelRt.offsetMin = Vector2.zero;
            labelRt.offsetMax = Vector2.zero;

            var label = labelGo.GetComponent<TextMeshProUGUI>();
            if (nameText != null && nameText.font != null)
                label.font = nameText.font;
            else if (TMP_Settings.defaultFontAsset != null)
                label.font = TMP_Settings.defaultFontAsset;

            label.text = "X";
            label.fontSize = Mathf.Clamp(btnHeight * 0.62f, 10f, 15f);
            label.fontStyle = FontStyles.Bold;
            label.alignment = TextAlignmentOptions.Center;
            label.color = new Color(1f, 0.94f, 0.94f, 1f);
            label.raycastTarget = false;

            ctrl = go.GetComponent<QuickRetireButton>();
            ctrl._button = button;
            ctrl._bg = bg;
            ctrl._label = label;
            button.onClick.AddListener(ctrl.OnClicked);
            ctrl.Bind(cpu, isProductionCard);
        }

        private void Bind(Cpu cpu, bool isProductionCard)
        {
            _cpu = cpu;
            _isProductionCard = isProductionCard;
            Disarm();
            RefreshVisibility();
        }

        private void RefreshVisibility()
        {
            bool show = PTQuickRetirePlugin.Enabled.Value
                && (_isProductionCard
                    ? PTQuickRetirePlugin.ShowOnProductionCards.Value
                    : PTQuickRetirePlugin.ShowOnSideWindowCards.Value)
                && PTQuickRetirePlugin.CanRetire(_cpu);

            if (gameObject.activeSelf != show)
                gameObject.SetActive(show);
        }

        private void OnClicked()
        {
            if (!PTQuickRetirePlugin.CanRetire(_cpu))
            {
                RefreshVisibility();
                return;
            }

            float fines = 0f;
            try
            {
                fines = ContractHelper.FinesFromContracts(_cpu);
            }
            catch (Exception ex)
            {
                PTQuickRetirePlugin.Log.LogWarning($"Failed to read contract fines for {_cpu.Name}: {ex.Message}");
            }

            if (PTQuickRetirePlugin.GuardContractFines.Value && fines > 0.01f && Time.unscaledTime >= _armedUntil)
            {
                Arm();
                PopupManager.Instance?.InstantiateGenericNotification(
                    "Contract Fine Warning",
                    $"{_cpu.Name} has {PTQuickRetirePlugin.FormatMoney(fines)} in contract fines. Click ! again to retire.",
                    4);
                return;
            }

            string cpuName = _cpu.Name;
            Cpu target = _cpu;
            Disarm();

            try
            {
                target.TriggerRetirement();

                var editWin = CpuEditWindow.Instance;
                if (editWin != null && ReferenceEquals(PTQuickRetirePlugin.EditWindowCpuField?.GetValue(editWin), target))
                {
                    PTQuickRetirePlugin.EditWindowCloseMethod?.Invoke(editWin, null);
                }

                if (PTQuickRetirePlugin.ShowToastNotification.Value)
                {
                    string detail = fines > 0.01f
                        ? $"{cpuName} retired (contract fines: {PTQuickRetirePlugin.FormatMoney(fines)})."
                        : $"{cpuName} has been retired.";
                    PopupManager.Instance?.InstantiateGenericNotification("CPU Retired", detail, 3);
                }
            }
            catch (Exception ex)
            {
                PTQuickRetirePlugin.Log.LogError($"Failed to retire {cpuName}: {ex}");
            }

            RefreshAllVisibility();
        }

        private void Arm()
        {
            _armedUntil = Time.unscaledTime + ConfirmWindowSeconds;
            if (_label != null) _label.text = "!";
            if (_button != null) ApplyColors(_button, ArmedColor, ArmedHoverColor, PressedColor);
            if (_bg != null) _bg.CrossFadeColor(ArmedHoverColor, 0f, true, true);
        }

        private void Disarm()
        {
            _armedUntil = 0f;
            if (_label != null) _label.text = "X";
            if (_button != null) ApplyColors(_button, NormalColor, HoverColor, PressedColor);
            if (_bg != null) _bg.CrossFadeColor(NormalColor, 0f, true, true);
        }

        private static void ApplyColors(Button btn, Color normal, Color hover, Color pressed)
        {
            var cb = btn.colors;
            cb.normalColor = normal;
            cb.highlightedColor = hover;
            cb.selectedColor = hover;
            cb.pressedColor = pressed;
            cb.disabledColor = new Color(0.3f, 0.3f, 0.3f, 0.5f);
            cb.colorMultiplier = 1f;
            cb.fadeDuration = 0.08f;
            btn.colors = cb;
        }
    }
}
