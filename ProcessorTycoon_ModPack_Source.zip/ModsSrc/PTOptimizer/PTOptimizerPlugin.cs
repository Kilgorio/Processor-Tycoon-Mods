using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace PTOptimizer
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTOptimizerPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.optimizer";
        public const string PluginName = "PT Performance & Tick Optimizer";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log { get; private set; }
        private static Harmony _harmony;
        private static bool _patchesApplied;
        private static int _originalVSyncCount = -1;

        public static ConfigEntry<bool> ModEnabled { get; private set; }
        public static ConfigEntry<bool> CacheDataFinder { get; private set; }
        public static ConfigEntry<bool> OptimizeAiSimulation { get; private set; }
        public static ConfigEntry<float> AiSimulationSampleScale { get; private set; }
        public static ConfigEntry<bool> OptimizeContractSelling { get; private set; }
        public static ConfigEntry<bool> SkipIdleCpusInPopularity { get; private set; }
        public static ConfigEntry<int> TargetFps { get; private set; }
        public static ConfigEntry<bool> ShowPerfOverlay { get; private set; }

        private void Awake()
        {
            Log = Logger;
            _harmony = new Harmony(PluginGuid);
            if (_originalVSyncCount < 0) _originalVSyncCount = QualitySettings.vSyncCount;

            ModEnabled = Config.Bind("1. General", "Enabled", true,
                "Enable all FPS and simulation tick speed optimizations.");
            CacheDataFinder = Config.Bind("2. Tick Speed", "CacheDataFinder", true,
                "Cache DataFinder lookups to avoid scanning 27,000+ Unity objects on ticks.");
            OptimizeAiSimulation = Config.Bind("2. Tick Speed", "OptimizeAiSimulation", true,
                "Skip redundant AI CPU design brute-force runs when the AI cannot start a project.");
            AiSimulationSampleScale = Config.Bind("2. Tick Speed", "AiSimulationSampleScale", 0.40f,
                new ConfigDescription("Fraction of vanilla random CPU samples evaluated per AI tick (min 150 samples).",
                    new AcceptableValueRange<float>(0.15f, 1.0f)));
            OptimizeContractSelling = Config.Bind("2. Tick Speed", "OptimizeContractSelling", true,
                "Index contracts by CPU ID to replace O(CPUs x Contracts) nested loops.");
            SkipIdleCpusInPopularity = Config.Bind("2. Tick Speed", "SkipIdleRetiredCpus", true,
                "Skip already-zeroed retired CPUs in daily market data and popularity decay loops.");
            TargetFps = Config.Bind("3. FPS & Display", "TargetFps", 0,
                new ConfigDescription("Override Unity FPS cap (0 = game/VSync default).",
                    new AcceptableValueRange<int>(0, 360)));
            ShowPerfOverlay = Config.Bind("4. Diagnostics", "ShowPerfOverlay", false,
                "Display a compact FPS & Tick ms counter in the top-right corner.");

            ModEnabled.SettingChanged += (_, _) => ApplyEnabledState(ModEnabled.Value);
            TargetFps.SettingChanged += (_, _) => ApplyTargetFps();
            ShowPerfOverlay.SettingChanged += (_, _) => PerfOverlayUI.SetVisible(ModEnabled.Value && ShowPerfOverlay.Value);

            SceneManager.sceneLoaded += OnSceneLoaded;

            if (ModEnabled.Value)
                ApplyEnabledState(true);
            else
                Log.LogInfo($"{PluginName} v{PluginVersion} loaded (disabled by config).");
        }

        private void Update()
        {
            if (ModEnabled.Value && ShowPerfOverlay.Value)
                PerfOverlayUI.TickFrame();
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
            OptimizationPatches.UnsubscribeSaveEvents();
            RestoreFrameSettings();
            if (_patchesApplied && _harmony != null)
            {
                _harmony.UnpatchSelf();
                _patchesApplied = false;
            }
            PerfOverlayUI.SetVisible(false);
        }

        private static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            OptimizationPatches.InvalidateAllCaches();
            ApplyTargetFps();
            PerfOverlayUI.SetVisible(ModEnabled != null && ModEnabled.Value && ShowPerfOverlay != null && ShowPerfOverlay.Value);
        }

        private static void RestoreFrameSettings()
        {
            if (_originalVSyncCount >= 0) QualitySettings.vSyncCount = _originalVSyncCount;
            Application.targetFrameRate = -1;
        }

        public static void ApplyTargetFps()
        {
            if (TargetFps == null || ModEnabled == null || !ModEnabled.Value) return;
            if (TargetFps.Value > 0)
            {
                QualitySettings.vSyncCount = 0;
                Application.targetFrameRate = TargetFps.Value;
            }
            else
            {
                RestoreFrameSettings();
            }
        }

        public static void ApplyEnabledState(bool enable)
        {
            try
            {
                if (enable && !_patchesApplied)
                {
                    OptimizationPatches.ApplyPatches(_harmony);
                    _patchesApplied = true;
                    ApplyTargetFps();
                    PerfOverlayUI.SetVisible(ShowPerfOverlay.Value);
                    Log.LogInfo($"{PluginName} v{PluginVersion} enabled cleanly.");
                }
                else if (!enable && _patchesApplied)
                {
                    OptimizationPatches.UnsubscribeSaveEvents();
                    _harmony.UnpatchSelf();
                    _patchesApplied = false;
                    OptimizationPatches.InvalidateAllCaches();
                    RestoreFrameSettings();
                    PerfOverlayUI.SetVisible(false);
                    Log.LogInfo($"{PluginName} v{PluginVersion} disabled live.");
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed toggling {PluginName}: {ex}");
            }
        }
    }
}
