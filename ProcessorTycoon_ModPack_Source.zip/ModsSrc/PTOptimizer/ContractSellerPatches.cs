using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using UnityEngine;

namespace PTOptimizer
{
    public static class ContractSellerPatches
    {
        private static readonly FieldInfo CsActiveContractsF = AccessTools.Field(typeof(ContractSeller), "activeContracts");
        private static readonly FieldInfo CsCpusF = AccessTools.Field(typeof(ContractSeller), "cpus");

        private static readonly Dictionary<int, int> DailyContractDemand = new Dictionary<int, int>();
        private static readonly Dictionary<int, Cpu> ContractCpuLookup = new Dictionary<int, Cpu>();

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(ContractSeller), "SetContractsDemand"),
                prefix: new HarmonyMethod(typeof(ContractSellerPatches), nameof(ContractSeller_SetDemand_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ContractSeller), "SellContracts"),
                prefix: new HarmonyMethod(typeof(ContractSellerPatches), nameof(ContractSeller_SellContracts_Prefix)) { priority = Priority.Low });
        }

        private static bool ContractSeller_SetDemand_Prefix(ContractSeller __instance)
        {
            if (!PTOptimizerPlugin.OptimizeContractSelling.Value || __instance == null) return true;
            if (!(CsCpusF?.GetValue(__instance) is List<Cpu> cpus) ||
                !(CsActiveContractsF?.GetValue(__instance) is List<Contract> contracts))
                return true;

            DailyContractDemand.Clear();
            for (int i = 0; i < contracts.Count; i++)
            {
                var c = contracts[i];
                if (c == null || c.ChosenCpuID < 0) continue;
                DailyContractDemand.TryGetValue(c.ChosenCpuID, out int cur);
                DailyContractDemand[c.ChosenCpuID] = cur + c.Units / 30;
            }

            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu == null) continue;
                cpu.TodayDemandByContracts = (!cpu.IsRetired && DailyContractDemand.TryGetValue(cpu.SaveID, out int d)) ? d : 0;
            }
            return false;
        }

        private static bool ContractSeller_SellContracts_Prefix(ContractSeller __instance)
        {
            if (!PTOptimizerPlugin.OptimizeContractSelling.Value || __instance == null) return true;
            if (!(CsCpusF?.GetValue(__instance) is List<Cpu> cpus) ||
                !(CsActiveContractsF?.GetValue(__instance) is List<Contract> contracts))
                return true;

            ContractCpuLookup.Clear();
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu == null) continue;
                cpu.IncomeLastDayFromContracts = 0f;
                cpu.SoldLastDayByContracts = 0;
                cpu.MissedSalesLastDayByContracts = 0;
                if (cpu.TodayDemandByContracts > 0)
                    ContractCpuLookup[cpu.SaveID] = cpu;
            }

            if (ContractCpuLookup.Count == 0) return false;

            for (int i = 0; i < contracts.Count; i++)
            {
                var contract = contracts[i];
                if (contract == null || !ContractCpuLookup.TryGetValue(contract.ChosenCpuID, out var cpu)) continue;

                int req = contract.Units / 30;
                int sold = Mathf.Clamp(cpu.Market.Stock, 0, req);
                int missed = req > sold ? req - sold : 0;
                cpu.Market.Stock -= sold;
                cpu.SoldLastDayByContracts += sold;
                cpu.MissedSalesLastDayByContracts += missed;

                float rev = contract.PaymentPerUnit * sold;
                cpu.Company.EarnMoney(rev, RevenueOrigin.Contracts);
                cpu.Company.SpendMoney(contract.FinePerUnit * missed, ExpenseOrigin.Fines);

                if (cpu.IsOutsourced)
                {
                    float roy = rev * 0.05f;
                    cpu.Manufacturer.EarnMoney(roy, RevenueOrigin.Royalties);
                    cpu.Company.SpendMoney(roy, ExpenseOrigin.Royalties);
                    var cost = cpu.Market.Cost;
                    if (cost != null && cost.Count > 0) cost[cost.Count - 1] += roy;
                }
                cpu.IncomeLastDayFromContracts += rev;
            }
            return false;
        }
    }
}
