using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTOptimizer
{
    public static class PerfOverlayUI
    {
        private static GameObject _canvasGo;
        private static TMP_Text _label;
        private static float _accumTime;
        private static int _frames;
        private static double _lastTickMs;
        private static int _lastFps;

        public static void SetVisible(bool visible)
        {
            if (visible && _canvasGo == null) BuildOverlay();
            if (_canvasGo != null) _canvasGo.SetActive(visible);
        }

        public static void RecordTickMs(double ms)
        {
            _lastTickMs = ms;
        }

        public static void TickFrame()
        {
            _frames++;
            _accumTime += Time.unscaledDeltaTime;
            if (_accumTime >= 0.35f)
            {
                _lastFps = Mathf.RoundToInt(_frames / _accumTime);
                _frames = 0;
                _accumTime = 0f;
                RefreshText();
            }
        }

        private static void RefreshText()
        {
            if (_label != null && _canvasGo != null && _canvasGo.activeInHierarchy)
            {
                string fpsCol = _lastFps >= 55 ? "#5CE08C" : (_lastFps >= 30 ? "#F2BE49" : "#F25E5E");
                _label.text = $"<color={fpsCol}><b>{_lastFps}</b> FPS</color>  |  Tick <b>{_lastTickMs:0.00}</b> ms";
            }
        }

        private static void BuildOverlay()
        {
            _canvasGo = new GameObject("PTOptimizer_PerfOverlay");
            Object.DontDestroyOnLoad(_canvasGo);

            var canvas = _canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 450;

            var scaler = _canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;

            var pill = new GameObject("Pill", typeof(RectTransform), typeof(Image));
            pill.transform.SetParent(_canvasGo.transform, false);
            var img = pill.GetComponent<Image>();
            img.color = new Color(0.08f, 0.09f, 0.11f, 0.85f);
            img.raycastTarget = false;

            var rt = pill.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(1f, 1f);
            rt.anchoredPosition = new Vector2(-14f, -12f);
            rt.sizeDelta = new Vector2(210f, 28f);

            var txtGo = new GameObject("Text", typeof(RectTransform), typeof(TextMeshProUGUI));
            txtGo.transform.SetParent(pill.transform, false);
            var trt = txtGo.GetComponent<RectTransform>();
            trt.anchorMin = Vector2.zero;
            trt.anchorMax = Vector2.one;
            trt.offsetMin = new Vector2(8f, 2f);
            trt.offsetMax = new Vector2(-8f, -2f);

            _label = txtGo.GetComponent<TextMeshProUGUI>();
            foreach (var t in Object.FindObjectsByType<TMP_Text>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (t != null && t.font != null) { _label.font = t.font; break; }
            }
            _label.fontSize = 13.5f;
            _label.alignment = TextAlignmentOptions.Center;
            _label.color = new Color(0.92f, 0.94f, 0.96f, 1f);
            _label.raycastTarget = false;
            RefreshText();
        }
    }
}
