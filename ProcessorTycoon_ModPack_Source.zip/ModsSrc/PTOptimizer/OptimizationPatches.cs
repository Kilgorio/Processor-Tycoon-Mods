using System.Diagnostics;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Save;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTOptimizer
{
    public static class OptimizationPatches
    {
        private static readonly Stopwatch TickStopwatch = new Stopwatch();
        private static SaveHandler _hookedSaveHandler;
        private static bool _isLoadingSave;
        private static float _loadingStartedRealtime;

        internal static bool IsLoadingOrDisabled
        {
            get
            {
                if (_isLoadingSave && Time.realtimeSinceStartup - _loadingStartedRealtime > 15f)
                    _isLoadingSave = false;
                return !PTOptimizerPlugin.CacheDataFinder.Value ||
                       _isLoadingSave ||
                       (GameManager.Instance != null && GameManager.Instance.IsLoading);
            }
        }

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(DateController), "TriggerTicks"),
                prefix: new HarmonyMethod(typeof(OptimizationPatches), nameof(TriggerTicks_Prefix)),
                finalizer: new HarmonyMethod(typeof(OptimizationPatches), nameof(TriggerTicks_Finalizer)));

            harmony.Patch(AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Load)),
                prefix: new HarmonyMethod(typeof(OptimizationPatches), nameof(SaveHandler_Load_Prefix)),
                postfix: new HarmonyMethod(typeof(OptimizationPatches), nameof(SaveHandler_Load_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(Player), nameof(Player.InitializeAsNewGame)),
                prefix: new HarmonyMethod(typeof(OptimizationPatches), nameof(OnNewGameOrCompleted)));

            DataFinderCachePatches.ApplyPatches(harmony);
            AiSimulationPatches.ApplyPatches(harmony);
            ContractSellerPatches.ApplyPatches(harmony);
            MarketFastPathPatches.ApplyPatches(harmony);
        }

        public static void UnsubscribeSaveEvents()
        {
            if (_hookedSaveHandler == null) return;
            _hookedSaveHandler.DuringLoad -= InvalidateAllCaches;
            _hookedSaveHandler.OnLoaded -= InvalidateAllCaches;
            _hookedSaveHandler.OnLateLoaded -= OnNewGameOrCompleted;
            _hookedSaveHandler.OnLastLoadedTick -= OnNewGameOrCompleted;
            _hookedSaveHandler = null;
        }

        public static void InvalidateAllCaches()
        {
            DataFinderCachePatches.ResetCaches();
            MarketFastPathPatches.ResetMarketCaches();
        }

        private static void SaveHandler_Load_Prefix()
        {
            _isLoadingSave = true;
            _loadingStartedRealtime = Time.realtimeSinceStartup;
            InvalidateAllCaches();
        }

        private static void SaveHandler_Load_Postfix(SaveHandler __instance)
        {
            if (__instance == null)
            {
                _isLoadingSave = false;
                return;
            }
            UnsubscribeSaveEvents();
            _hookedSaveHandler = __instance;
            __instance.DuringLoad += InvalidateAllCaches;
            __instance.OnLoaded += InvalidateAllCaches;
            __instance.OnLateLoaded += OnNewGameOrCompleted;
            __instance.OnLastLoadedTick += OnNewGameOrCompleted;
        }

        private static void OnNewGameOrCompleted()
        {
            _isLoadingSave = false;
            InvalidateAllCaches();
        }

        private static void TriggerTicks_Prefix()
        {
            if (PTOptimizerPlugin.ShowPerfOverlay.Value)
                TickStopwatch.Restart();
        }

        private static void TriggerTicks_Finalizer()
        {
            if (PTOptimizerPlugin.ShowPerfOverlay.Value && TickStopwatch.IsRunning)
            {
                TickStopwatch.Stop();
                PerfOverlayUI.RecordTickMs(TickStopwatch.Elapsed.TotalMilliseconds);
            }
        }
    }
}
