using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTOptimizer
{
    public static class DataFinderCachePatches
    {
        private static readonly FieldInfo CdpCpusF = AccessTools.Field(typeof(CpuDataProvider), "cpus");

        private static List<ICompanyOwner> _ownersCache;
        private static List<ICompany> _companiesCache;
        private static List<ICompany> _aiCompaniesOrderedCache;
        private static List<ICompany> _aiCompaniesUnorderedCache;
        private static int _companyCacheDayKey = int.MinValue;

        private static List<Cpu> _allCpusCache;
        private static readonly Dictionary<int, Cpu> CpuById = new Dictionary<int, Cpu>();
        private static int _lastKnownOwnerCpuTotal = -1;

        private static readonly Dictionary<string, Package> PackageByName = new Dictionary<string, Package>();
        private static readonly Dictionary<string, ProcessNode> LithoByName = new Dictionary<string, ProcessNode>();
        private static readonly Dictionary<string, Memory> MemoryByName = new Dictionary<string, Memory>();

        private static readonly Dictionary<int, Cpu> CdpById = new Dictionary<int, Cpu>();
        private static int _cdpLastCount = -1;
        private static int _cdpLastFirstId = -1;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(CompanySpawner), nameof(CompanySpawner.SpawnCompany)),
                postfix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(InvalidateCompanyCaches)));
            harmony.Patch(AccessTools.Method(typeof(CompanySpawner), nameof(CompanySpawner.SpawnCompanyFromSave)),
                postfix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(InvalidateCompanyCaches)));

            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindAllOwnersOfCompany)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindAllOwners_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindAllCompanies)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindAllCompanies_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindAllAICompanies)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindAllAICompanies_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindCompany)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindCompany_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindOwnerOfCompany)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindOwnerOfCompany_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindAllCpus)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindAllCpus_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindCpu)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindCpu_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindPackage)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindPackage_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindLithography)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindLithography_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(DataFinder), nameof(DataFinder.FindMemory)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(FindMemory_Prefix)));

            harmony.Patch(AccessTools.Method(typeof(CpuDataProvider), nameof(CpuDataProvider.GetCpu)),
                prefix: new HarmonyMethod(typeof(DataFinderCachePatches), nameof(CpuDataProvider_GetCpu_Prefix)));
        }

        internal static void ResetCaches()
        {
            InvalidateCompanyCaches();
            _allCpusCache = null;
            CpuById.Clear();
            _lastKnownOwnerCpuTotal = -1;

            PackageByName.Clear();
            LithoByName.Clear();
            MemoryByName.Clear();

            CdpById.Clear();
            _cdpLastCount = -1;
            _cdpLastFirstId = -1;
        }

        private static void InvalidateCompanyCaches()
        {
            _ownersCache = null;
            _companiesCache = null;
            _aiCompaniesOrderedCache = null;
            _aiCompaniesUnorderedCache = null;
            _companyCacheDayKey = int.MinValue;
        }

        private static int CurrentMonthDayKey =>
            DateController.Instance != null
                ? DateController.Instance.CurrentDate.Year * 10000 + DateController.Instance.CurrentDate.DayOfYear
                : -1;

        private static bool HasDestroyedItems<T>(List<T> list) where T : class
        {
            if (list == null) return true;
            for (int i = 0; i < list.Count; i++)
                if (list[i] == null || (list[i] as UnityEngine.Object) == null) return true;
            return false;
        }

        private static void EnsureCompanyCachesFresh()
        {
            int key = CurrentMonthDayKey;
            bool isDayOne = DateController.Instance != null && DateController.Instance.CurrentDate.Day == 1;
            if (isDayOne && _companyCacheDayKey != key)
            {
                InvalidateCompanyCaches();
                _companyCacheDayKey = key;
            }

            if (_ownersCache == null || _companiesCache == null || _aiCompaniesUnorderedCache == null ||
                HasDestroyedItems(_ownersCache) || HasDestroyedItems(_companiesCache) || HasDestroyedItems(_aiCompaniesUnorderedCache))
            {
                RebuildCompanyCaches();
            }
        }

        private static void RebuildCompanyCaches()
        {
            var mbs = UnityEngine.Object.FindObjectsByType<MonoBehaviour>(FindObjectsSortMode.None);
            _ownersCache = new List<ICompanyOwner>(16);
            _companiesCache = new List<ICompany>(16);
            _aiCompaniesUnorderedCache = new List<ICompany>(16);

            for (int i = 0; i < mbs.Length; i++)
            {
                var mb = mbs[i];
                if (mb == null) continue;
                if (mb is ICompanyOwner owner) _ownersCache.Add(owner);
                if (mb is ICompany comp)
                {
                    _companiesCache.Add(comp);
                    if (comp is AICompany) _aiCompaniesUnorderedCache.Add(comp);
                }
            }

            _aiCompaniesOrderedCache = new List<ICompany>(_aiCompaniesUnorderedCache);
            _aiCompaniesOrderedCache.Sort((a, b) => a.SaveID.CompareTo(b.SaveID));
            _companyCacheDayKey = CurrentMonthDayKey;
        }

        private static List<Cpu> GetCachedAllCpus()
        {
            EnsureCompanyCachesFresh();
            int total = 0;
            for (int i = 0; i < _ownersCache.Count; i++)
                total += _ownersCache[i].GetCpus()?.Count ?? 0;

            if (_allCpusCache == null || total != _lastKnownOwnerCpuTotal)
            {
                _allCpusCache = new List<Cpu>(total + 16);
                CpuById.Clear();
                for (int i = 0; i < _ownersCache.Count; i++)
                {
                    var list = _ownersCache[i].GetCpus();
                    if (list == null) continue;
                    for (int j = 0; j < list.Count; j++)
                    {
                        var cpu = list[j];
                        if (cpu == null) continue;
                        _allCpusCache.Add(cpu);
                        CpuById[cpu.SaveID] = cpu;
                    }
                }
                _lastKnownOwnerCpuTotal = _allCpusCache.Count;
            }
            return _allCpusCache;
        }

        private static bool TryFindCachedByName<T>(string name, Dictionary<string, T> cache, Func<T, string> getName, ref T result) where T : UnityEngine.Object
        {
            if (OptimizationPatches.IsLoadingOrDisabled || string.IsNullOrEmpty(name)) return true;
            if (cache.Count == 0)
            {
                var all = UnityEngine.Object.FindObjectsByType<T>(FindObjectsSortMode.None);
                for (int i = 0; i < all.Length; i++)
                {
                    var item = all[i];
                    if (item == null) continue;
                    string itemName = getName(item);
                    if (!string.IsNullOrEmpty(itemName)) cache[itemName] = item;
                }
            }

            if (cache.TryGetValue(name, out var cached))
            {
                if (cached != null)
                {
                    result = cached;
                    return false;
                }
                cache.Remove(name);
            }
            return true;
        }

        private static bool FindAllOwners_Prefix(ref List<ICompanyOwner> __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            EnsureCompanyCachesFresh();
            __result = new List<ICompanyOwner>(_ownersCache);
            return false;
        }

        private static bool FindAllCompanies_Prefix(ref List<ICompany> __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            EnsureCompanyCachesFresh();
            __result = new List<ICompany>(_companiesCache);
            return false;
        }

        private static bool FindAllAICompanies_Prefix(bool orderByID, ref List<ICompany> __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            EnsureCompanyCachesFresh();
            __result = new List<ICompany>(orderByID ? _aiCompaniesOrderedCache : _aiCompaniesUnorderedCache);
            return false;
        }

        private static bool FindCompany_Prefix(int companyID, ref ICompany __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            EnsureCompanyCachesFresh();
            for (int i = 0; i < _companiesCache.Count; i++)
            {
                var comp = _companiesCache[i];
                if (comp != null && comp.SaveID == companyID)
                {
                    __result = comp;
                    return false;
                }
            }
            return true;
        }

        private static bool FindOwnerOfCompany_Prefix(string companyName, ref ICompanyOwner __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled || string.IsNullOrEmpty(companyName)) return true;
            EnsureCompanyCachesFresh();
            for (int i = 0; i < _ownersCache.Count; i++)
            {
                var owner = _ownersCache[i];
                if (owner?.Company != null && owner.Company.Name == companyName)
                {
                    __result = owner;
                    return false;
                }
            }
            return true;
        }

        private static bool FindAllCpus_Prefix(ref List<Cpu> __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            __result = new List<Cpu>(GetCachedAllCpus());
            return false;
        }

        private static bool FindCpu_Prefix(int saveID, ref Cpu __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled) return true;
            GetCachedAllCpus();
            if (CpuById.TryGetValue(saveID, out var cpu) && cpu != null)
            {
                __result = cpu;
                return false;
            }
            return true;
        }

        private static bool FindPackage_Prefix(string packageName, ref Package __result) =>
            TryFindCachedByName(packageName, PackageByName, p => p.Name, ref __result);

        private static bool FindLithography_Prefix(string processNodeName, ref ProcessNode __result) =>
            TryFindCachedByName(processNodeName, LithoByName, l => l.Name, ref __result);

        private static bool FindMemory_Prefix(string memoryName, ref Memory __result) =>
            TryFindCachedByName(memoryName, MemoryByName, m => m.Name, ref __result);

        private static bool CpuDataProvider_GetCpu_Prefix(CpuDataProvider __instance, int saveID, ref Cpu __result)
        {
            if (OptimizationPatches.IsLoadingOrDisabled || __instance == null) return true;
            if (saveID < 0) { __result = null; return false; }

            if (!(CdpCpusF?.GetValue(__instance) is List<Cpu> list)) return true;
            int firstId = list.Count > 0 && list[0] != null ? list[0].SaveID : -1;
            if (list.Count != _cdpLastCount || firstId != _cdpLastFirstId)
            {
                CdpById.Clear();
                for (int i = 0; i < list.Count; i++)
                    if (list[i] != null) CdpById[list[i].SaveID] = list[i];
                _cdpLastCount = list.Count;
                _cdpLastFirstId = firstId;
            }

            if (CdpById.TryGetValue(saveID, out var found))
            {
                __result = found;
                return false;
            }
            return true;
        }
    }
}
