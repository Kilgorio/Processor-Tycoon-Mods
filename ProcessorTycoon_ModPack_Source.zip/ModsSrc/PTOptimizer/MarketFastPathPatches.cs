using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.Production.Math;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTOptimizer
{
    public static class MarketFastPathPatches
    {
        private static readonly FieldInfo MktCpusF = AccessTools.Field(typeof(Market), "cpus");
        private static readonly FieldInfo MktAllCpusF = AccessTools.Field(typeof(Market), "allCpus");
        private static readonly FieldInfo MktSoldSumsF = AccessTools.Field(typeof(Market), "soldSums");
        private static readonly FieldInfo MktCpusTodayF = AccessTools.Field(typeof(Market), "cpusToday");
        private static readonly MethodInfo MktCacheCpusM = AccessTools.Method(typeof(Market), "CacheCpus");

        private static readonly FieldInfo MdhAllCpusF = AccessTools.Field(typeof(MarketDataHandler), "allCpus");
        private static readonly FieldInfo MdhMonthIdxF = AccessTools.Field(typeof(MarketDataHandler), "currentMonthIndex");
        private static readonly FieldInfo MdhShowExF = AccessTools.Field(typeof(MarketDataHandler), "showHandledExceptions");

        private static readonly HashSet<int> SettledRetiredCpuIds = new HashSet<int>();
        private static readonly HashSet<Cpu> MarketCpuSet = new HashSet<Cpu>();

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(Market), "CheckForCpuChanges"),
                prefix: new HarmonyMethod(typeof(MarketFastPathPatches), nameof(Market_CheckForCpuChanges_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "UpdateCpuPopularities"),
                prefix: new HarmonyMethod(typeof(MarketFastPathPatches), nameof(Market_UpdateCpuPopularities_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(MarketDataHandler), nameof(MarketDataHandler.RegisterDailyCpuSales)),
                prefix: new HarmonyMethod(typeof(MarketFastPathPatches), nameof(MarketDataHandler_RegisterDaily_Prefix)));
        }

        internal static void ResetMarketCaches()
        {
            SettledRetiredCpuIds.Clear();
            MarketCpuSet.Clear();
        }

        private static bool Market_CheckForCpuChanges_Prefix(Market __instance)
        {
            if (!PTOptimizerPlugin.SkipIdleCpusInPopularity.Value || __instance == null) return true;
            if (DateController.Instance != null && DateController.Instance.IsFastFowardSimulating) return false;
            if (!(MktCpusF?.GetValue(__instance) is List<Cpu> activeCpus)) return true;

            var cpusToday = MktCpusTodayF?.GetValue(__instance) as List<Cpu> ?? new List<Cpu>();
            cpusToday = CpuDataProvider.Instance.GetAllCpus(cpusToday);
            MktCpusTodayF?.SetValue(__instance, cpusToday);

            MarketCpuSet.Clear();
            for (int i = 0; i < activeCpus.Count; i++) MarketCpuSet.Add(activeCpus[i]);

            bool changed = false;
            for (int i = 0; i < cpusToday.Count; i++)
            {
                var item = cpusToday[i];
                bool shouldBeIn = !item.IsRetired && item.SellOnMarket;
                if (shouldBeIn != MarketCpuSet.Contains(item))
                {
                    changed = true;
                    break;
                }
            }
            if (changed) MktCacheCpusM?.Invoke(__instance, null);
            return false;
        }

        private static bool Market_UpdateCpuPopularities_Prefix(Market __instance)
        {
            if (!PTOptimizerPlugin.SkipIdleCpusInPopularity.Value || __instance == null || DateController.Instance == null) return true;
            if (!(MktCpusF?.GetValue(__instance) is List<Cpu> cpus) ||
                !(MktAllCpusF?.GetValue(__instance) is List<Cpu> allCpus) ||
                !(MktSoldSumsF?.GetValue(__instance) is int[] soldSums))
                return true;

            int year = DateController.Instance.CurrentDate.Year;
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                soldSums[0] += cpu.SoldLastDayToDesktopHigh;
                soldSums[1] += cpu.SoldLastDayToDesktopMid;
                soldSums[2] += cpu.SoldLastDayToDesktopLow;
                soldSums[3] += cpu.SoldLastDayToIndustries;
                soldSums[4] += cpu.SoldLastDayToMobileHigh;
                soldSums[5] += cpu.SoldLastDayToMobileMid;
                soldSums[6] += cpu.SoldLastDayToMobileLow;
                soldSums[7] += cpu.SoldLastDayToServerHigh;
                soldSums[8] += cpu.SoldLastDayToServerMid;
                soldSums[9] += cpu.SoldLastDayToServerLow;
            }

            float baseGain = 0.025f, passive = 5E-05f;
            if (year >= 2010) { baseGain *= 5f; passive *= 3f; }
            else if (year >= 1990) { baseGain *= 2.5f; passive *= 1.5f; }

            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu2 = cpus[i];
                float g = baseGain, p = passive;
                if (cpu2.MissedSalesLastDay > 0)
                {
                    g = cpu2.MissedSalesLastDay < cpu2.SoldLastDay
                        ? g * Mathf.Clamp01((float)(cpu2.SoldLastDay - cpu2.MissedSalesLastDay) / Math.Max(1, cpu2.SoldLastDay))
                        : 0f;
                    p = 0f;
                }
                if (cpu2.IsOld()) p = 0f;

                var pops = cpu2.Popularities;
                pops[0] += p + g * ((float)cpu2.SoldLastDayToDesktopHigh / Math.Max(1, soldSums[0]));
                pops[1] += p + g * ((float)cpu2.SoldLastDayToDesktopMid / Math.Max(1, soldSums[1]));
                pops[2] += p + g * ((float)cpu2.SoldLastDayToDesktopLow / Math.Max(1, soldSums[2]));
                pops[3] += p + g * ((float)cpu2.SoldLastDayToIndustries / Math.Max(1, soldSums[3]));
                pops[4] += p + g * ((float)cpu2.SoldLastDayToMobileHigh / Math.Max(1, soldSums[4]));
                pops[5] += p + g * ((float)cpu2.SoldLastDayToMobileMid / Math.Max(1, soldSums[5]));
                pops[6] += p + g * ((float)cpu2.SoldLastDayToMobileLow / Math.Max(1, soldSums[6]));
                pops[7] += p + g * ((float)cpu2.SoldLastDayToServerHigh / Math.Max(1, soldSums[7]));
                pops[8] += p + g * ((float)cpu2.SoldLastDayToServerMid / Math.Max(1, soldSums[8]));
                pops[9] += p + g * ((float)cpu2.SoldLastDayToServerLow / Math.Max(1, soldSums[9]));
            }

            for (int i = 0; i < allCpus.Count; i++)
            {
                var allCpu = allCpus[i];
                if (allCpu.IsRetired && SettledRetiredCpuIds.Contains(allCpu.SaveID))
                    continue;

                bool old = allCpu.IsOld();
                float decay = old ? 0.0005f : 0f;
                float floor = old ? 0f : 0.05f;
                var pops = allCpu.Popularities;
                bool allZero = old;

                for (int j = 0; j < pops.Count; j++)
                {
                    float v = pops[j] - decay;
                    if (v <= floor) v = floor;
                    else if (v > 1f) v = 1f;
                    pops[j] = v;
                    if (v > 0f) allZero = false;
                }

                if (allZero && allCpu.IsRetired)
                    SettledRetiredCpuIds.Add(allCpu.SaveID);
            }
            return false;
        }

        private static bool MarketDataHandler_RegisterDaily_Prefix(MarketDataHandler __instance)
        {
            if (!PTOptimizerPlugin.SkipIdleCpusInPopularity.Value || __instance == null) return true;
            if (!(MdhAllCpusF?.GetValue(__instance) is List<Cpu> allCpus)) return true;

            int idx = MdhMonthIdxF?.GetValue(__instance) is int m ? m : 0;
            bool showEx = MdhShowExF?.GetValue(__instance) is bool se && se;

            for (int i = 0; i < allCpus.Count; i++)
            {
                var cpu = allCpus[i];
                bool isRetired = cpu.IsRetired;
                int produced = cpu.ProducedLastDay;
                int failed = cpu.FailedLastDay;
                int missed = cpu.MissedSalesLastDay + cpu.MissedSalesLastDayByContracts;
                float income = cpu.IncomeLastDay + cpu.IncomeLastDayFromContracts;

                if (isRetired &&
                    cpu.SoldLastDay == 0 &&
                    cpu.SoldLastDayByContracts == 0 &&
                    produced == 0 &&
                    failed == 0 &&
                    missed == 0 &&
                    income == 0f &&
                    cpu.Market?.Sold != null &&
                    cpu.Market.Sold.Count > idx)
                {
                    continue;
                }

                float storageCost = isRetired ? 0f : StorageMath.Cost(cpu) / 30f;
                if (storageCost > 0f)
                {
                    cpu.Manufacturer.SpendMoney(storageCost, ExpenseOrigin.Factories);
                    if (cpu.IsOutsourced)
                    {
                        cpu.Company.SpendMoney(storageCost, ExpenseOrigin.Outsourcing);
                        cpu.Manufacturer.EarnMoney(storageCost * 1.5f, RevenueOrigin.Clients);
                    }
                }

                try
                {
                    var mkt = cpu.Market;
                    mkt.Sold[idx] += cpu.SoldLastDay;
                    mkt.SoldToContracts[idx] += cpu.SoldLastDayByContracts;
                    mkt.SoldToDesktopHigh[idx] += cpu.SoldLastDayToDesktopHigh;
                    mkt.SoldToDesktopMid[idx] += cpu.SoldLastDayToDesktopMid;
                    mkt.SoldToDesktopLow[idx] += cpu.SoldLastDayToDesktopLow;
                    mkt.SoldToIndustries[idx] += cpu.SoldLastDayToIndustries;
                    mkt.SoldToMobileHigh[idx] += cpu.SoldLastDayToMobileHigh;
                    mkt.SoldToMobileMid[idx] += cpu.SoldLastDayToMobileMid;
                    mkt.SoldToMobileLow[idx] += cpu.SoldLastDayToMobileLow;
                    mkt.SoldToServerHigh[idx] += cpu.SoldLastDayToServerHigh;
                    mkt.SoldToServerMid[idx] += cpu.SoldLastDayToServerMid;
                    mkt.SoldToServerLow[idx] += cpu.SoldLastDayToServerLow;
                    mkt.Produced[idx] += produced;
                    mkt.Failed[idx] += failed;
                    mkt.MissedSales[idx] += missed;
                    mkt.Income[idx] += income;
                    mkt.Cost[idx] += storageCost;
                }
                catch (Exception ex)
                {
                    if (showEx)
                        Debug.LogError($"PTOptimizer MarketDataHandler exception at CPU {cpu.Name} idx {idx}: {ex.Message}");
                }
            }
            return false;
        }
    }
}
