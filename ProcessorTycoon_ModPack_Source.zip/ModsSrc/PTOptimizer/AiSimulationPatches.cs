using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.AISystem;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTOptimizer
{
    public static class AiSimulationPatches
    {
        private static readonly FieldInfo AiCompF = AccessTools.Field(typeof(AIBehaviourCreation), "company");
        private static readonly FieldInfo AiRefF = AccessTools.Field(typeof(AIBehaviourCreation), "ai");
        private static readonly FieldInfo AiBestCpusF = AccessTools.Field(typeof(AIBehaviourCreation), "bestCpus");
        private static readonly FieldInfo AiFoundriesF = AccessTools.Field(typeof(AIBehaviourCreation), "foundries");

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourCreation), "FindBestCpuDesign"),
                prefix: new HarmonyMethod(typeof(AiSimulationPatches), nameof(AI_FindBestCpuDesign_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourCreation), "SimulateCpus"),
                prefix: new HarmonyMethod(typeof(AiSimulationPatches), nameof(AI_SimulateCpus_Prefix)));
        }

        private static bool HasStaleBankruptFoundry(AIBehaviourCreation instance, AICompany comp, List<CpuDesign> best)
        {
            if (!comp.IsFabless) return false;
            if (AiFoundriesF?.GetValue(instance) is List<ICompany> foundries)
            {
                for (int i = 0; i < foundries.Count; i++)
                    if (foundries[i] == null || foundries[i].IsBankrupt) return true;
            }
            if (best != null && best.Count > 0 && best[0] != null && best[0].OutsourcedID > 0)
            {
                var mfr = DataFinder.FindCompany(best[0].OutsourcedID);
                if (mfr == null || mfr.IsBankrupt) return true;
            }
            return false;
        }

        private static bool AI_FindBestCpuDesign_Prefix(AIBehaviourCreation __instance)
        {
            if (!PTOptimizerPlugin.OptimizeAiSimulation.Value || __instance == null) return true;

            var comp = AiCompF?.GetValue(__instance) as AICompany;
            var ai = AiRefF?.GetValue(__instance) as AI;
            if (comp == null || comp.IsFoundry) return false;

            Segment focus = __instance.MarketFocus;
            if (focus != __instance.MainMarket && comp.CpuProjectsTargetingMarket(__instance.MainMarket) == 0)
                return false;
            if (comp.CpuProjectsTargetingMarket(focus) > 0)
                return false;

            if (DateController.Instance != null)
            {
                int curYear = DateController.Instance.CurrentDate.Year;
                if (ai != null)
                {
                    var baseCpus = ai.GetBaseCpus();
                    Cpu lastFocusCpu = null;
                    for (int i = baseCpus.Count - 1; i >= 0; i--)
                    {
                        if (baseCpus[i].Strategy.TargetMarket == focus)
                        {
                            lastFocusCpu = baseCpus[i];
                            break;
                        }
                    }
                    if (lastFocusCpu != null && lastFocusCpu.Year == curYear)
                        return false;
                }

                if (AiBestCpusF?.GetValue(__instance) is List<CpuDesign> best && best.Count >= 5 &&
                    !HasStaleBankruptFoundry(__instance, comp, best))
                {
                    if ((DateController.Instance.CurrentDate.DayOfYear + comp.SaveID) % 3 != 0)
                        return false;
                }
            }
            return true;
        }

        private static void AI_SimulateCpus_Prefix(ref int amount)
        {
            if (!PTOptimizerPlugin.OptimizeAiSimulation.Value) return;
            float scale = PTOptimizerPlugin.AiSimulationSampleScale.Value;
            if (scale < 0.99f && amount > 150)
                amount = Mathf.Max(150, Mathf.RoundToInt(amount * scale));
        }
    }
}
