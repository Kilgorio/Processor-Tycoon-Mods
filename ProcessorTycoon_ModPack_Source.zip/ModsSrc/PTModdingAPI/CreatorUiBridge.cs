using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModdingAPI
{
    internal static class CreatorUiBridge
    {
        private sealed class SlotWidgetRef
        {
            public GameObject RowGo;
            public Button PrevBtn, CenterBtn, NextBtn, StudioBtn;
            public Image CenterBg;
            public TMP_Text CenterTxt;
        }

        private static readonly FieldInfo CreatorSafeTempTxtF = AccessTools.Field(typeof(CreatorCpu), "safeTemperatureText");
        private static readonly FieldInfo CreatorPkgF = AccessTools.Field(typeof(CreatorCpu), "currentPackage");
        private static readonly FieldInfo CreatorLithoF = AccessTools.Field(typeof(CreatorCpu), "currentLithography");
        private static readonly FieldInfo CreatorTempF = AccessTools.Field(typeof(CreatorCpu), "temperature");
        private static readonly FieldInfo CreatorCreateCpuBtnF = AccessTools.Field(typeof(CreatorCpu), "createCpuButton");
        private static readonly FieldInfo CreatorPkgPlaceholderF = AccessTools.Field(typeof(CreatorCpu), "packagePlaceholder");
        private static readonly MethodInfo CreatorUpdateNumbersM = AccessTools.Method(typeof(CreatorCpu), "UpdateNumbers");
        private static readonly FieldInfo SocketCreateBtnF = AccessTools.Field(typeof(CreatorSocket), "createSocketButton");
        private static readonly FieldInfo SocketPkgPlaceholderF = AccessTools.Field(typeof(CreatorSocket), "basePackagePlaceholder");
        private static readonly MethodInfo SocketUpdateUiM = AccessTools.Method(typeof(CreatorSocket), "UpdateUI");
        private static readonly FieldInfo CreatorWinCanvasGroupF = AccessTools.Field(typeof(CreatorWindow), "canvasGroup");

        public static readonly List<CreatorCpuSlotDef> CreatorSlots = new List<CreatorCpuSlotDef>();
        public static readonly List<CreatorCpuSlotDef> SocketSlots = new List<CreatorCpuSlotDef>();
        public static readonly List<Action<IPackage>> CreatorPackageChangedListeners = new List<Action<IPackage>>();

        private static readonly Dictionary<string, SlotWidgetRef> CpuSlotWidgets = new Dictionary<string, SlotWidgetRef>();
        private static readonly Dictionary<string, SlotWidgetRef> SocketSlotWidgets = new Dictionary<string, SlotWidgetRef>();
        private static readonly Vector3[] CornerScratch = new Vector3[4];

        public static IPackage CurrentCreatorPackage { get; private set; }
        public static ProcessNode CurrentCreatorLitho { get; private set; }

        private static CreatorCpu _cachedCreatorCpu;
        private static CreatorSocket _cachedCreatorSocket;
        private static GameObject _slotBarGo, _socketSlotBarGo;
        private static Transform _slotBarCard, _socketSlotBarCard;
        private static bool _slotBarMasked, _socketSlotBarMasked;
        private static bool _creatorSlotsDirty = true;
        private static bool _socketSlotsDirty = true;
        private static bool _inPackageChangeNotify;
        private static IPackage _lastCreatorPackage;
        private static IPackage _lastUiPkg;
        private static float _lastUiTemp = float.NaN, _lastUiSafeTemp = float.NaN, _lastUiRawSafeTemp = float.NaN;
        private static bool _lastCpuWinVis, _lastSocketWinVis;

        public static void ApplyPatches(Harmony harmony)
        {
            var ccInit = AccessTools.Method(typeof(CreatorCpu), "Initialize");
            if (ccInit != null)
                harmony.Patch(ccInit,
                    prefix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorCpu_Cache_Prefix)),
                    postfix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorCpu_Cache_Postfix)));

            var ccUpdNum = AccessTools.Method(typeof(CreatorCpu), "UpdateNumbers");
            if (ccUpdNum != null) harmony.Patch(ccUpdNum, prefix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorCpu_Cache_Prefix)));

            var ccUpdTxt = AccessTools.Method(typeof(CreatorCpu), "UpdateInfoTexts");
            if (ccUpdTxt != null) harmony.Patch(ccUpdTxt, postfix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorCpu_UpdateInfoTexts_Postfix)));

            foreach (var cwName in new[] { nameof(CreatorWindow.Open), nameof(CreatorWindow.Close), nameof(CreatorWindow.Show), nameof(CreatorWindow.Hide), "OnEnable", "OnDisable" })
            {
                var m = AccessTools.Method(typeof(CreatorWindow), cwName);
                if (m != null) harmony.Patch(m, postfix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorWindow_OpenOrClose_Postfix)));
            }

            var csInit = AccessTools.Method(typeof(CreatorSocket), "Initialize");
            if (csInit != null) harmony.Patch(csInit, postfix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorSocket_Refresh_Postfix)));

            var csUpd = AccessTools.Method(typeof(CreatorSocket), "UpdateUI");
            if (csUpd != null) harmony.Patch(csUpd, postfix: new HarmonyMethod(typeof(CreatorUiBridge), nameof(CreatorSocket_Refresh_Postfix)));
        }

        public static void ResetSessionState()
        {
            CurrentCreatorPackage = null;
            CurrentCreatorLitho = null;
            _lastCreatorPackage = null;
            _lastCpuWinVis = false;
            _lastSocketWinVis = false;
            if (_slotBarGo == null)
            {
                _cachedCreatorCpu = null;
                _slotBarCard = null;
                _slotBarMasked = false;
                CpuSlotWidgets.Clear();
            }
            if (_socketSlotBarGo == null)
            {
                _cachedCreatorSocket = null;
                _socketSlotBarCard = null;
                _socketSlotBarMasked = false;
                SocketSlotWidgets.Clear();
            }
            MarkDirty();
        }

        public static void MarkDirty()
        {
            _creatorSlotsDirty = true;
            _socketSlotsDirty = true;
            _lastUiPkg = null;
            _lastUiTemp = float.NaN;
            _lastUiSafeTemp = float.NaN;
            _lastUiRawSafeTemp = float.NaN;
        }

        public static void RefreshCreatorCpu()
        {
            MarkDirty();
            if (_cachedCreatorCpu == null)
                _cachedCreatorCpu = UnityEngine.Object.FindFirstObjectByType<CreatorCpu>(FindObjectsInactive.Include);
            try { if (_cachedCreatorCpu != null) CreatorUpdateNumbersM?.Invoke(_cachedCreatorCpu, null); } catch { }
            EnsureCreatorSlotBar();
            if (_slotBarMasked && _slotBarGo != null)
            {
                bool vis = IsCreatorWindowVisible(CreatorManager.Instance?.GetWindowOfType(CreatorWindow.Type.Cpu));
                _slotBarGo.SetActive(vis);
                if (vis && _slotBarCard != null) SyncMaskedBarToCard(_slotBarGo, _slotBarCard);
            }
            RefreshSlotBar(_slotBarGo, CreatorSlots, CpuSlotWidgets);
            _creatorSlotsDirty = false;
        }

        public static void RefreshCreatorSocket()
        {
            MarkDirty();
            if (_cachedCreatorSocket == null)
                _cachedCreatorSocket = UnityEngine.Object.FindFirstObjectByType<CreatorSocket>(FindObjectsInactive.Include);
            try { if (_cachedCreatorSocket != null) SocketUpdateUiM?.Invoke(_cachedCreatorSocket, null); } catch { }
            EnsureSocketSlotBar();
            if (_socketSlotBarMasked && _socketSlotBarGo != null)
            {
                bool vis = IsCreatorWindowVisible(CreatorManager.Instance?.GetWindowOfType(CreatorWindow.Type.Socket));
                _socketSlotBarGo.SetActive(vis);
                if (vis && _socketSlotBarCard != null) SyncMaskedBarToCard(_socketSlotBarGo, _socketSlotBarCard);
            }
            RefreshSlotBar(_socketSlotBarGo, SocketSlots, SocketSlotWidgets);
            _socketSlotsDirty = false;
        }

        private static void CreatorCpu_Cache_Prefix(CreatorCpu __instance)
        {
            if (__instance == null) return;
            _cachedCreatorCpu = __instance;
            CurrentCreatorPackage = CreatorPkgF?.GetValue(__instance) as IPackage;
            CurrentCreatorLitho = CreatorLithoF?.GetValue(__instance) as ProcessNode;
        }

        private static void CreatorCpu_Cache_Postfix(CreatorCpu __instance)
        {
            if (__instance == null) return;
            _cachedCreatorCpu = __instance;
            CurrentCreatorPackage = CreatorPkgF?.GetValue(__instance) as IPackage;
            CurrentCreatorLitho = CreatorLithoF?.GetValue(__instance) as ProcessNode;
            MarkDirty();
            EnsureCreatorSlotBar();
            if (_slotBarGo != null)
            {
                RefreshSlotBar(_slotBarGo, CreatorSlots, CpuSlotWidgets);
                _creatorSlotsDirty = false;
            }
        }

        private static void CreatorCpu_UpdateInfoTexts_Postfix(CreatorCpu __instance)
        {
            _cachedCreatorCpu = __instance;
            var pkg = __instance != null ? CreatorPkgF?.GetValue(__instance) as IPackage : null;
            CurrentCreatorPackage = pkg;
            CurrentCreatorLitho = __instance != null ? CreatorLithoF?.GetValue(__instance) as ProcessNode : null;

            if (_slotBarGo == null) EnsureCreatorSlotBar();

            if (__instance == null || pkg == null)
            {
                if (_creatorSlotsDirty) { RefreshSlotBar(_slotBarGo, CreatorSlots, CpuSlotWidgets); _creatorSlotsDirty = false; }
                return;
            }

            if (!_inPackageChangeNotify && !ReferenceEquals(pkg, _lastCreatorPackage))
            {
                _lastCreatorPackage = pkg;
                _creatorSlotsDirty = true;
                _lastUiPkg = null;
                _inPackageChangeNotify = true;
                try
                {
                    for (int i = 0; i < CreatorPackageChangedListeners.Count; i++)
                        CreatorPackageChangedListeners[i](pkg);
                    CreatorUpdateNumbersM?.Invoke(__instance, null);
                }
                finally { _inPackageChangeNotify = false; }
            }

            if (_creatorSlotsDirty)
            {
                RefreshSlotBar(_slotBarGo, CreatorSlots, CpuSlotWidgets);
                _creatorSlotsDirty = false;
            }

            float temp = CreatorTempF?.GetValue(__instance) is float t ? t : 0f;
            float rawSafeTemp;
            HardwarePhysicsPatches.SuppressPackageMods = true;
            try { rawSafeTemp = pkg.SafeTemperature; }
            finally { HardwarePhysicsPatches.SuppressPackageMods = false; }
            float safeTemp = pkg.SafeTemperature;

            if (!ReferenceEquals(pkg, _lastUiPkg) ||
                Mathf.Abs(temp - _lastUiTemp) > 0.005f ||
                Mathf.Abs(safeTemp - _lastUiSafeTemp) > 0.005f ||
                Mathf.Abs(rawSafeTemp - _lastUiRawSafeTemp) > 0.005f)
            {
                _lastUiPkg = pkg;
                _lastUiTemp = temp;
                _lastUiSafeTemp = safeTemp;
                _lastUiRawSafeTemp = rawSafeTemp;

                if (CreatorSafeTempTxtF?.GetValue(__instance) is InfoText stTxt && Colors.Instance != null)
                {
                    if (temp > safeTemp) stTxt.SetVariableColor(Colors.Instance.DynamicNegativeColor(), true);
                    else if (safeTemp > rawSafeTemp + 0.25f) stTxt.SetVariableColor(Colors.Instance.DynamicPositiveColor(), true);
                    else stTxt.ResetColor(true);
                }
            }
        }

        private static void CreatorSocket_Refresh_Postfix(CreatorSocket __instance)
        {
            if (__instance != null) _cachedCreatorSocket = __instance;
            if (_socketSlotBarGo == null) EnsureSocketSlotBar();
            if (_socketSlotsDirty)
            {
                RefreshSlotBar(_socketSlotBarGo, SocketSlots, SocketSlotWidgets);
                _socketSlotsDirty = false;
            }
        }

        private static bool IsCreatorWindowVisible(CreatorWindow win)
        {
            if (win == null || !win.IsOpen || !win.gameObject.activeInHierarchy) return false;
            var cg = CreatorWinCanvasGroupF?.GetValue(win) as CanvasGroup;
            return cg == null || cg.alpha > 0.05f;
        }

        private static void SyncMaskedBarToCard(GameObject barGo, Transform card)
        {
            if (barGo == null || card == null) return;
            if (card is RectTransform cardRt && barGo.transform.parent is RectTransform parentRt)
            {
                var rt = barGo.GetComponent<RectTransform>();
                cardRt.GetWorldCorners(CornerScratch);
                Vector3 bl = parentRt.InverseTransformPoint(CornerScratch[0]);
                Vector3 br = parentRt.InverseTransformPoint(CornerScratch[3]);
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.pivot = new Vector2(0.5f, 1f);
                rt.localPosition = new Vector3((bl.x + br.x) * 0.5f, bl.y - 6f, 0f);
                rt.sizeDelta = new Vector2(Mathf.Max(260f, br.x - bl.x), 46f);
                barGo.transform.SetAsLastSibling();
            }
        }

        private static void CreatorWindow_OpenOrClose_Postfix(CreatorWindow __instance)
        {
            if (__instance == null) return;
            bool vis = IsCreatorWindowVisible(__instance);
            if (__instance.CreatorType == CreatorWindow.Type.Cpu)
            {
                EnsureCreatorSlotBar();
                if (_slotBarMasked && _slotBarGo != null)
                {
                    _slotBarGo.SetActive(vis);
                    if (vis && _slotBarCard != null) SyncMaskedBarToCard(_slotBarGo, _slotBarCard);
                }
                if (vis && !_lastCpuWinVis) RefreshCreatorCpu();
                else if (!vis) { CurrentCreatorPackage = null; CurrentCreatorLitho = null; }
                _lastCpuWinVis = vis;
            }
            else if (__instance.CreatorType == CreatorWindow.Type.Socket)
            {
                EnsureSocketSlotBar();
                if (_socketSlotBarMasked && _socketSlotBarGo != null)
                {
                    _socketSlotBarGo.SetActive(vis);
                    if (vis && _socketSlotBarCard != null) SyncMaskedBarToCard(_socketSlotBarGo, _socketSlotBarCard);
                }
                if (vis && !_lastSocketWinVis) RefreshCreatorSocket();
                _lastSocketWinVis = vis;
            }
        }

        private static Transform FindCreatorWindowCard(Transform a, Transform b)
        {
            if (a == null || b == null) return null;
            var ancestorsA = new HashSet<Transform>();
            for (Transform t = a; t != null; t = t.parent) ancestorsA.Add(t);

            Transform lca = null;
            for (Transform t = b; t != null; t = t.parent)
                if (ancestorsA.Contains(t)) { lca = t; break; }
            if (lca == null) return null;

            Transform cur = lca;
            for (int step = 0; step < 2 && cur.parent != null; step++)
            {
                if (cur.parent.GetComponent<CanvasScaler>() != null) break;
                if (cur.parent is RectTransform prt && cur is RectTransform crt)
                {
                    if (prt.rect.width > 1650f || prt.rect.height > 980f) break;
                    if (crt.rect.width > 50f && prt.rect.width <= crt.rect.width * 1.25f && prt.rect.height <= crt.rect.height * 1.35f)
                    {
                        cur = cur.parent;
                        continue;
                    }
                }
                break;
            }
            return cur;
        }

        private static void EnsureCreatorSlotBar()
        {
            if (_cachedCreatorCpu == null) return;
            EnsureSlotBar(CreatorWindow.Type.Cpu, "PTModAPI_CreatorSlots", CreatorSlots, CpuSlotWidgets,
                ref _slotBarGo, ref _slotBarMasked, ref _slotBarCard,
                (CreatorCreateCpuBtnF?.GetValue(_cachedCreatorCpu) as Component)?.transform,
                (CreatorPkgPlaceholderF?.GetValue(_cachedCreatorCpu) as Component)?.transform,
                ref _creatorSlotsDirty);
        }

        private static void EnsureSocketSlotBar()
        {
            if (_cachedCreatorSocket == null) return;
            EnsureSlotBar(CreatorWindow.Type.Socket, "PTModAPI_SocketSlots", SocketSlots, SocketSlotWidgets,
                ref _socketSlotBarGo, ref _socketSlotBarMasked, ref _socketSlotBarCard,
                (SocketCreateBtnF?.GetValue(_cachedCreatorSocket) as Component)?.transform,
                (SocketPkgPlaceholderF?.GetValue(_cachedCreatorSocket) as Component)?.transform,
                ref _socketSlotsDirty);
        }

        private static void EnsureSlotBar(CreatorWindow.Type winType, string barName, List<CreatorCpuSlotDef> defs, Dictionary<string, SlotWidgetRef> widgets,
            ref GameObject barGo, ref bool barMasked, ref Transform cardRef, Transform anchorA, Transform anchorB, ref bool dirtyFlag)
        {
            if (defs.Count == 0) return;

            if (barGo == null)
            {
                widgets.Clear();
                Transform card = FindCreatorWindowCard(anchorA, anchorB);
                if (card == null) return;
                if (card is RectTransform crt && (crt.rect.width < 120f || crt.rect.height < 80f)) return;

                bool masked = card.GetComponent<Mask>() != null || card.GetComponent<RectMask2D>() != null;
                barMasked = masked;
                cardRef = card;
                Transform barParent = (masked && card.parent != null) ? card.parent : card;
                var leftoverBar = barParent.Find(barName);
                if (leftoverBar != null) UnityEngine.Object.DestroyImmediate(leftoverBar.gameObject);

                barGo = UiFactory.CreatePanel(barName, barParent, UiFactory.HeaderBg, true, true);
                barGo.AddComponent<LayoutElement>().ignoreLayout = true;

                var rt = barGo.GetComponent<RectTransform>();
                rt.localScale = Vector3.one;
                rt.localRotation = Quaternion.identity;

                if (!masked)
                {
                    rt.anchorMin = new Vector2(0f, 0f);
                    rt.anchorMax = new Vector2(1f, 0f);
                    rt.pivot = new Vector2(0.5f, 1f);
                    rt.anchoredPosition = new Vector2(0f, -6f);
                    rt.sizeDelta = new Vector2(0f, 46f);
                }
                else
                {
                    SyncMaskedBarToCard(barGo, card);
                }

                var hlg = barGo.AddComponent<HorizontalLayoutGroup>();
                hlg.padding = new RectOffset(8, 8, 6, 6);
                hlg.spacing = 8f;
                hlg.childControlWidth = true;
                hlg.childControlHeight = true;
                hlg.childForceExpandWidth = true;
                hlg.childForceExpandHeight = true;

                barGo.transform.SetAsLastSibling();
                barGo.SetActive(!masked || IsCreatorWindowVisible(CreatorManager.Instance?.GetWindowOfType(winType)));
                dirtyFlag = true;
                PTModdingApiPlugin.Log?.LogInfo($"Attached {barName} to '{barParent.name}' (card='{card.name}', rect={(card as RectTransform)?.rect.size}, masked={masked}, active={barGo.activeInHierarchy}).");
            }

            for (int i = 0; i < defs.Count; i++)
            {
                var slot = defs[i];
                if (widgets.TryGetValue(slot.SlotId, out var existingW) && existingW.RowGo != null) continue;
                var row = new GameObject($"Slot_{slot.SlotId}", typeof(RectTransform), typeof(HorizontalLayoutGroup));
                row.transform.SetParent(barGo.transform, false);
                var hlg = row.GetComponent<HorizontalLayoutGroup>();
                hlg.spacing = 3f;
                hlg.childControlWidth = true;
                hlg.childControlHeight = true;
                hlg.childForceExpandWidth = false;
                hlg.childForceExpandHeight = true;
                row.AddComponent<LayoutElement>().flexibleWidth = 1f;

                var prevBtn = UiFactory.CreateButton("Prev", row.transform, "<", UiFactory.CardBg, () => slot.OnPrev?.Invoke(), 12f);
                prevBtn.gameObject.AddComponent<LayoutElement>().preferredWidth = 26f;

                var centerBtn = UiFactory.CreateButton("Val", row.transform, slot.Label, UiFactory.CardBg,
                    () => { if (slot.OnNext != null) slot.OnNext(); else (slot.OnOpenStudio ?? slot.OnClick)?.Invoke(); }, 11.5f);
                centerBtn.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1f;

                var nextBtn = UiFactory.CreateButton("Next", row.transform, ">", UiFactory.CardBg, () => slot.OnNext?.Invoke(), 12f);
                nextBtn.gameObject.AddComponent<LayoutElement>().preferredWidth = 26f;

                var studioBtn = UiFactory.CreateButton("Studio", row.transform, "+", UiFactory.AccentBlue,
                    () => (slot.OnOpenStudio ?? slot.OnClick)?.Invoke(), 13f);
                studioBtn.gameObject.AddComponent<LayoutElement>().preferredWidth = 28f;

                widgets[slot.SlotId] = new SlotWidgetRef
                {
                    RowGo = row, PrevBtn = prevBtn, CenterBtn = centerBtn, NextBtn = nextBtn, StudioBtn = studioBtn,
                    CenterBg = centerBtn.GetComponent<Image>(), CenterTxt = centerBtn.GetComponentInChildren<TMP_Text>()
                };
                dirtyFlag = true;
            }
            if (!barMasked) barGo.SetActive(true);
        }

        private static void RefreshSlotBar(GameObject barGo, List<CreatorCpuSlotDef> defs, Dictionary<string, SlotWidgetRef> widgets)
        {
            if (barGo == null) return;
            for (int i = 0; i < defs.Count; i++)
            {
                var slot = defs[i];
                if (!widgets.TryGetValue(slot.SlotId, out var w) || w.RowGo == null) continue;
                bool vis = slot.IsVisible == null || slot.IsVisible();
                w.RowGo.SetActive(vis);
                if (!vis) continue;
                bool canCycle = slot.IsInteractable == null || slot.IsInteractable();
                bool hasCycle = slot.OnPrev != null || slot.OnNext != null;
                w.PrevBtn.gameObject.SetActive(hasCycle);
                w.NextBtn.gameObject.SetActive(hasCycle);
                w.PrevBtn.interactable = canCycle;
                w.NextBtn.interactable = canCycle;
                w.CenterTxt.text = slot.GetDisplayText != null ? slot.GetDisplayText() : slot.Label;
                if (slot.GetBadgeColor != null) w.CenterBg.color = slot.GetBadgeColor();
            }
        }
    }
}
