using System;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.ProjectSystem.UI;
using UnityEngine;

namespace PTModdingAPI
{
    public sealed class CreatorCpuSlotDef
    {
        public string SlotId { get; set; }
        public string Label { get; set; }
        public Func<bool> IsVisible { get; set; }
        public Func<bool> IsInteractable { get; set; }
        public Func<string> GetDisplayText { get; set; }
        public Func<Color> GetBadgeColor { get; set; }
        public Action OnPrev { get; set; }
        public Action OnNext { get; set; }
        public Action OnOpenStudio { get; set; }
        public Action OnClick { get; set; }
    }

    public sealed class HardwareMenuButtonDef
    {
        public string Id { get; set; }
        public string Label { get; set; }
        public Func<bool> IsVisible { get; set; }
        public Action OnClick { get; set; }
    }

    public sealed class CpuPhysicsContext
    {
        public IPackage Package;
        public ProcessNode ProcessNode;
        public Memory Memory;
        public int CoreCount;
        public int DieCount;
        public float Frequency;
        public float BaseConsumption;
        public float BaseTemperature;
    }

    public sealed class CpuPhysicsMods
    {
        public float IpcMultiplier = 1f;
        public float PowerMultiplier = 1f;
        public float FailureMultiplier = 1f;
        public float BomExtraCost = 0f;
    }

    public sealed class FabMods
    {
        public float ThroughputMultiplier = 1f;
        public float YieldBonus = 0f;
        public float MultiDieFailureReduction = 0f;
    }

    public sealed class ActiveModProjectHandle
    {
        public string ProjectId { get; internal set; }
        public string Subtitle { get; internal set; }
        public Project NativeProject { get; internal set; }
        internal ProjectUI UiRef;
        public float Progress => NativeProject != null ? NativeProject.Progress : 0f;
        public bool IsActive => NativeProject != null;
    }
}
