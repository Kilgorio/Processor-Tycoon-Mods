using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Production;
using ProcessorTycoon.Production.Math;
using ProcessorTycoon.Production.UI;
using ProcessorTycoon.UI;
using UnityEngine;

namespace PTModdingAPI
{
    internal static class FabProductionPatches
    {
        private static readonly FieldInfo ProdWinThroughputF = AccessTools.Field(typeof(ProductionWindow), "throughputText");
        private static readonly FieldInfo PuiCpuF = AccessTools.Field(typeof(ProductionUI), "cpu");
        private static readonly FieldInfo PuiIsAutoF = AccessTools.Field(typeof(ProductionUI), "isAutomated");
        private static readonly FieldInfo PuiProdTxtF = AccessTools.Field(typeof(ProductionUI), "productionText");
        private static readonly FieldInfo PuiBalTxtF = AccessTools.Field(typeof(ProductionUI), "balanceText");
        private static readonly FieldInfo PuiSliderF = AccessTools.Field(typeof(ProductionUI), "productionLinesSlider");
        private static readonly Type AutoCpuDataT = AccessTools.Inner(typeof(ProductionAutomation), "CpuData");
        private static readonly Func<object, Cpu> AutoCpuDataGetCpu = CompileCpuGetter();

        public static readonly List<Action<ICompany, int, FabMods>> FabModsList = new List<Action<ICompany, int, FabMods>>();
        public static bool HasFabMods => FabModsList.Count > 0;

        private static readonly FabMods ReusableFabMods = new FabMods();
        private static int _lastShownThroughputPct = -1;
        private static string _lastShownThroughputStr = "100%";
        private static InfoText _lastThroughputInfoText;

        private static Func<object, Cpu> CompileCpuGetter()
        {
            if (AutoCpuDataT == null) return null;
            var m = AccessTools.PropertyGetter(AutoCpuDataT, "Cpu");
            if (m == null) return null;
            var objParam = Expression.Parameter(typeof(object), "o");
            var body = Expression.Call(Expression.Convert(objParam, AutoCpuDataT), m);
            return Expression.Lambda<Func<object, Cpu>>(body, objParam).Compile();
        }

        public static void ResetUiCache()
        {
            _lastShownThroughputPct = -1;
            _lastThroughputInfoText = null;
        }

        public static FabMods EvalFabMods(int dieCount = 1, ICompany comp = null)
        {
            ReusableFabMods.ThroughputMultiplier = 1f;
            ReusableFabMods.YieldBonus = 0f;
            ReusableFabMods.MultiDieFailureReduction = 0f;
            var c = comp ?? Player.Instance?.Company;
            for (int i = 0; i < FabModsList.Count; i++) FabModsList[i](c, dieCount, ReusableFabMods);
            return ReusableFabMods;
        }

        public static void ApplyPatches(Harmony harmony)
        {
            var prodWafers = AccessTools.Method(typeof(Factory), nameof(Factory.ProduceWafers));
            if (prodWafers != null)
            {
                harmony.Patch(prodWafers,
                    prefix: new HarmonyMethod(typeof(FabProductionPatches), nameof(Factory_ProduceWafers_Prefix)),
                    postfix: new HarmonyMethod(typeof(FabProductionPatches), nameof(Factory_ProduceWafers_Postfix)) { priority = Priority.High });
            }

            foreach (var compType in new[] { typeof(Company), typeof(AICompany) })
            {
                var nodeYield = AccessTools.Method(compType, nameof(ICompany.CurrentNodeYield));
                if (nodeYield != null)
                    harmony.Patch(nodeYield, postfix: new HarmonyMethod(typeof(FabProductionPatches), nameof(Company_CurrentNodeYield_Postfix)));
            }

            var pwUpd = AccessTools.Method(typeof(ProductionWindow), "UpdateAvailableProductionLines");
            if (pwUpd != null)
                harmony.Patch(pwUpd, postfix: new HarmonyMethod(typeof(FabProductionPatches), nameof(ProductionWindow_UpdateAvailableProductionLines_Postfix)));

            var reqLinesM = AccessTools.Method(typeof(ProductionMath), nameof(ProductionMath.RequiredProductionLines));
            if (reqLinesM != null)
                harmony.Patch(reqLinesM, prefix: new HarmonyMethod(typeof(FabProductionPatches), nameof(ProductionMath_RequiredProductionLines_Prefix)));

            var puiUpdTxt = AccessTools.Method(typeof(ProductionUI), "UpdateTexts");
            if (puiUpdTxt != null)
                harmony.Patch(puiUpdTxt, postfix: new HarmonyMethod(typeof(FabProductionPatches), nameof(ProductionUI_UpdateTexts_Postfix)));

            var puiUpdLines = AccessTools.Method(typeof(ProductionUI), nameof(ProductionUI.UpdateProductionLines));
            if (puiUpdLines != null)
                harmony.Patch(puiUpdLines, postfix: new HarmonyMethod(typeof(FabProductionPatches), nameof(ProductionUI_UpdateProductionLines_Postfix)));

            if (AutoCpuDataT != null)
            {
                var cdContract = AccessTools.Method(AutoCpuDataT, "ContractDemand");
                if (cdContract != null)
                    harmony.Patch(cdContract, prefix: new HarmonyMethod(typeof(FabProductionPatches), nameof(AutoCpuData_ContractDemand_Prefix)));

                var cdSold = AccessTools.Method(AutoCpuDataT, "SoldLastDay");
                if (cdSold != null)
                    harmony.Patch(cdSold, prefix: new HarmonyMethod(typeof(FabProductionPatches), nameof(AutoCpuData_SoldLastDay_Prefix)));
            }
        }

        private static void Factory_ProduceWafers_Prefix(Cpu cpu, out int __state) =>
            __state = cpu?.Market != null ? cpu.Market.Stock : -1;

        private static void Factory_ProduceWafers_Postfix(Factory __instance, Cpu cpu, int __state)
        {
            if (__state < 0 || FabModsList.Count == 0 || __instance?.Company == null || cpu?.Market == null) return;
            int produced = cpu.Market.Stock - __state;
            if (produced <= 0) return;

            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), __instance.Company);
            if (fm.ThroughputMultiplier > 1.001f)
            {
                int bonusUnits = Mathf.RoundToInt(produced * (fm.ThroughputMultiplier - 1f));
                if (bonusUnits > 0)
                {
                    cpu.Market.Stock = (int)Math.Min(2_000_000_000L, (long)cpu.Market.Stock + bonusUnits);
                    cpu.ProducedLastDay += bonusUnits;
                }
            }
        }

        private static void Company_CurrentNodeYield_Postfix(ICompany __instance, ref float __result)
        {
            if (FabModsList.Count == 0 || __instance == null) return;
            var fm = EvalFabMods(1, __instance);
            if (fm.YieldBonus > 0f) __result = Mathf.Clamp(__result + fm.YieldBonus, 0.01f, 0.99f);
        }

        private static bool ProductionMath_RequiredProductionLines_Prefix(Cpu cpu, int unitsToProduce, ref int __result)
        {
            if (FabModsList.Count == 0 || cpu == null || cpu.Base != null || unitsToProduce <= 0 || cpu.Manufacturer == null) return true;
            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), cpu.Manufacturer);
            if (fm.ThroughputMultiplier <= 1.001f) return true;

            float goodRatio = MathHelper.ReversePercentageScale(cpu.FailureRate);
            int diesPerWafer = ProductionMath.DiesPerWafer(cpu.DieSize, cpu.DieCount, cpu.Manufacturer.CurrentWaferSize, cpu.CurrentNodeYield);
            if (diesPerWafer <= 0 || goodRatio <= 0.0001f) return true;

            int rawUnits = Mathf.RoundToInt(unitsToProduce / goodRatio);
            if (rawUnits <= 0) { __result = 0; return false; }

            int wafers = (rawUnits + diesPerWafer - 1) / diesPerWafer;
            __result = Mathf.Max(1, Mathf.CeilToInt(wafers / (50f * fm.ThroughputMultiplier)));
            return false;
        }

        private static bool AutoCpuData_ContractDemand_Prefix(object __instance, ref int __result)
        {
            if (FabModsList.Count == 0 || __instance == null || AutoCpuDataGetCpu == null) return true;
            var cpu = AutoCpuDataGetCpu(__instance);
            if (cpu == null || cpu.Base != null) return true;

            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), cpu.Manufacturer ?? cpu.Company);
            if (fm.ThroughputMultiplier <= 1.001f) return true;

            int demand = cpu.TodayDemandByContracts;
            if (demand <= 0) { __result = 0; return false; }

            int stock = cpu.Market != null ? cpu.Market.Stock : 0;
            int desired = demand + Mathf.RoundToInt((demand - stock) * 0.5f);
            __result = Mathf.Clamp(desired, 0, Mathf.RoundToInt(demand * 1.5f));
            return false;
        }

        private static bool AutoCpuData_SoldLastDay_Prefix(object __instance, bool ignoreIfThereIsTooMuchStock, ref int __result)
        {
            if (!ignoreIfThereIsTooMuchStock || FabModsList.Count == 0 || __instance == null || AutoCpuDataGetCpu == null) return true;
            var cpu = AutoCpuDataGetCpu(__instance);
            if (cpu == null || cpu.Base != null) return true;

            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), cpu.Manufacturer ?? cpu.Company);
            if (fm.ThroughputMultiplier <= 1.001f) return true;

            int sold = cpu.SoldLastDay;
            if (sold <= 0) { __result = 0; return false; }

            int stock = cpu.Market != null ? cpu.Market.Stock : 0;
            float targetStock = Mathf.Max(100_000f, sold * 5f);
            if (stock <= targetStock) { __result = sold; return false; }

            float taperBand = Mathf.Max(20_000f, sold * 3f);
            float factor = Mathf.Clamp01(1f - (stock - targetStock) / taperBand);
            __result = Mathf.RoundToInt(sold * factor);
            return false;
        }

        private static void ProductionWindow_UpdateAvailableProductionLines_Postfix(ProductionWindow __instance)
        {
            if (__instance == null || FabModsList.Count == 0) return;
            var fm = EvalFabMods(1, Player.Instance?.Company);
            int pct = Mathf.RoundToInt(100f * fm.ThroughputMultiplier);
            if (ProdWinThroughputF?.GetValue(__instance) is InfoText tt)
            {
                if (pct != _lastShownThroughputPct || !ReferenceEquals(tt, _lastThroughputInfoText))
                {
                    _lastShownThroughputPct = pct;
                    _lastShownThroughputStr = $"{pct}%";
                    _lastThroughputInfoText = tt;
                    if (Colors.Instance != null)
                    {
                        if (pct > 100) tt.SetVariableColor(Colors.Instance.DynamicPositiveColor(), true);
                        else tt.ResetColor(true);
                    }
                }
                if (pct != 100) tt.Text = _lastShownThroughputStr;
            }
        }

        private static void ProductionUI_UpdateTexts_Postfix(ProductionUI __instance)
        {
            if (__instance == null || FabModsList.Count == 0) return;
            var cpu = PuiCpuF?.GetValue(__instance) as Cpu;
            if (cpu == null || cpu.Base != null || cpu.Manufacturer == null) return;

            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), cpu.Manufacturer);
            if (fm.ThroughputMultiplier <= 1.001f) return;

            bool isAuto = PuiIsAutoF?.GetValue(__instance) is bool a && a;
            int lines = cpu.CurrentProductionLines + cpu.CurrentContractedProductionLines;
            if (isAuto || cpu.IsOutsourced)
                lines = Mathf.Clamp(lines, 0, cpu.LinesActuallyAllocated);

            float goodRatio = MathHelper.ReversePercentageScale(cpu.FailureRate);
            int diesPerWafer = ProductionMath.DiesPerWafer(cpu.DieSize, cpu.DieCount, cpu.Manufacturer.CurrentWaferSize, cpu.CurrentNodeYield);
            float monthlyProd = lines * 50f * fm.ThroughputMultiplier * diesPerWafer * goodRatio;
            float monthlyDemand = (cpu.SoldLastDay + cpu.MissedSalesLastDay + cpu.TodayDemandByContracts + cpu.MissedSalesLastDayByContracts) * 30f;
            float dailyBal = (monthlyProd - monthlyDemand) / 30f;

            if (PuiProdTxtF?.GetValue(__instance) is InfoText prodTxt)
                prodTxt.Text = StringFormatter.FloatToIntString(monthlyProd, "", true) + "/m";

            if (PuiBalTxtF?.GetValue(__instance) is InfoText balTxt)
            {
                balTxt.Text = StringFormatter.FloatToIntString(dailyBal, "", true) + "/d";
                if (Colors.Instance != null)
                {
                    var col = dailyBal < 0f ? Colors.Instance.DynamicNegativeColor() : Colors.Instance.DynamicPositiveColor();
                    balTxt.SetVariableColor(col, true);
                }
            }
        }

        private static void ProductionUI_UpdateProductionLines_Postfix(ProductionUI __instance)
        {
            if (__instance == null || FabModsList.Count == 0) return;
            var cpu = PuiCpuF?.GetValue(__instance) as Cpu;
            if (cpu == null || cpu.Base != null) return;

            var fm = EvalFabMods(Math.Max(1, cpu.DieCount), cpu.Manufacturer ?? cpu.Company);
            if (fm.ThroughputMultiplier <= 1.001f) return;

            if (PuiSliderF?.GetValue(__instance) is SliderUI slider)
            {
                string cur = slider.Text;
                int pIdx = cur != null ? cur.LastIndexOf('(') : -1;
                if (pIdx >= 0)
                {
                    float wafers = Mathf.Round(50f * fm.ThroughputMultiplier * cpu.LinesActuallyAllocated);
                    slider.Text = $"{cur.Substring(0, pIdx)}({StringFormatter.FloatToIntString(wafers, "", true)} wafers)";
                }
            }
        }
    }
}
