using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.ProjectSystem.UI;
using ProcessorTycoon.TimeSystem;
using TMPro;
using UnityEngine;

namespace PTModdingAPI
{
    internal static class TimedProjectEngine
    {
        private static readonly FieldInfo ProjDailyProgF = AccessTools.Field(typeof(Project), "dailyProgress");
        private static readonly FieldInfo ProjDailyCostF = AccessTools.Field(typeof(Project), "dailyCost");
        private static readonly MethodInfo ProjCalcRemM = AccessTools.Method(typeof(Project), "CalculateRemainingCost");
        private static readonly FieldInfo ProjUiSecTxtF = AccessTools.Field(typeof(ProjectUI), "secondaryText");

        private static readonly Dictionary<string, ActiveModProjectHandle> ActiveProjects =
            new Dictionary<string, ActiveModProjectHandle>(StringComparer.OrdinalIgnoreCase);
        private static readonly List<string> TmpKeys = new List<string>();

        public static void ApplyPatches(Harmony harmony)
        {
            var projTickCost = AccessTools.Method(typeof(Project), "TickCost");
            if (projTickCost != null)
                harmony.Patch(projTickCost, postfix: new HarmonyMethod(typeof(TimedProjectEngine), nameof(Project_TickCost_Postfix)));

            var projUiUpd = AccessTools.Method(typeof(ProjectUI), nameof(ProjectUI.UpdateUI));
            if (projUiUpd != null)
                harmony.Patch(projUiUpd, postfix: new HarmonyMethod(typeof(TimedProjectEngine), nameof(ProjectUI_UpdateUI_Postfix)));

            var schedUnsch = AccessTools.Method(typeof(TimerScheduler), nameof(TimerScheduler.Unschedule));
            if (schedUnsch != null)
                harmony.Patch(schedUnsch, prefix: new HarmonyMethod(typeof(TimedProjectEngine), nameof(TimerScheduler_Unschedule_Prefix)));
        }

        public static ActiveModProjectHandle StartTimedProject(string projectId, string title, string subtitle, int days, float totalCost,
            Action onComplete, float initialProgress = 0f)
        {
            if (string.IsNullOrWhiteSpace(projectId) || TimerScheduler.Instance == null || Player.Instance?.Company == null)
                return null;

            CancelTimedProject(projectId);
            int clampedDays = Math.Max(1, days);
            var proj = new Project();
            var handle = new ActiveModProjectHandle { ProjectId = projectId, Subtitle = subtitle, NativeProject = proj };
            ActiveProjects[projectId] = handle;

            proj.Initialize(title, clampedDays, Mathf.Max(0f, totalCost), () =>
            {
                if (ActiveProjects.TryGetValue(projectId, out var h) && ReferenceEquals(h.NativeProject, proj))
                    ActiveProjects.Remove(projectId);
                try { TimerScheduler.Instance?.Unschedule(proj); } catch { }
                try { onComplete?.Invoke(); }
                catch (Exception ex) { PTModdingApiPlugin.Log?.LogWarning($"TimedProject completion error ({projectId}): {ex.Message}"); }
            }, Player.Instance.Company, progress: Mathf.Clamp01(initialProgress));

            ProjDailyProgF?.SetValue(proj, 1f / clampedDays);
            ProjCalcRemM?.Invoke(proj, null);

            TimerScheduler.Instance.Schedule(proj);
            ProjectUIInstantiator.Instance?.InstantiateProjectUI(proj);

            // Capture ProjectUI reference once on creation so GetActiveProject is O(1)
            foreach (var pui in UnityEngine.Object.FindObjectsByType<ProjectUI>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (pui != null && ReferenceEquals(pui.Project, proj))
                {
                    handle.UiRef = pui;
                    if (!string.IsNullOrEmpty(subtitle) && ProjUiSecTxtF?.GetValue(pui) is TMP_Text st)
                        st.text = subtitle;
                    break;
                }
            }
            return handle;
        }

        public static void CancelTimedProject(string projectId)
        {
            if (string.IsNullOrEmpty(projectId) || !ActiveProjects.TryGetValue(projectId, out var handle)) return;
            ActiveProjects.Remove(projectId);
            ReleaseHandle(handle);
        }

        public static void CancelAll()
        {
            if (ActiveProjects.Count == 0) return;
            TmpKeys.Clear();
            foreach (var k in ActiveProjects.Keys) TmpKeys.Add(k);
            for (int i = 0; i < TmpKeys.Count; i++)
            {
                if (ActiveProjects.TryGetValue(TmpKeys[i], out var handle))
                {
                    ActiveProjects.Remove(TmpKeys[i]);
                    ReleaseHandle(handle);
                }
            }
            TmpKeys.Clear();
        }

        private static void ReleaseHandle(ActiveModProjectHandle handle)
        {
            if (handle?.NativeProject == null) return;
            try { TimerScheduler.Instance?.Unschedule(handle.NativeProject); } catch { }
            if (handle.UiRef != null)
            {
                try { ProjectUIInstantiator.Instance?.DestroyProjectUI(handle.UiRef); } catch { }
                handle.UiRef = null;
            }
        }

        public static ActiveModProjectHandle GetActiveProject(string projectId)
        {
            if (string.IsNullOrEmpty(projectId) || !ActiveProjects.TryGetValue(projectId, out var handle) || handle.NativeProject == null)
                return null;
            if (handle.UiRef == null)
            {
                ActiveProjects.Remove(projectId);
                return null;
            }
            return handle;
        }

        private static ActiveModProjectHandle FindHandleByProject(Project proj)
        {
            if (proj == null || ActiveProjects.Count == 0) return null;
            foreach (var kv in ActiveProjects)
                if (ReferenceEquals(kv.Value.NativeProject, proj)) return kv.Value;
            return null;
        }

        private static void Project_TickCost_Postfix(Project __instance)
        {
            if (ActiveProjects.Count == 0) return;
            if (FindHandleByProject(__instance) == null) return;
            if (ProjDailyCostF?.GetValue(__instance) is float dc && dc > 0f)
                __instance.Company?.SpendMoney(dc, ExpenseOrigin.Development);
        }

        private static void ProjectUI_UpdateUI_Postfix(ProjectUI __instance)
        {
            if (ActiveProjects.Count == 0 || __instance == null) return;
            var handle = FindHandleByProject(__instance.Project);
            if (handle == null) return;
            if (handle.UiRef == null) handle.UiRef = __instance;
            if (!string.IsNullOrEmpty(handle.Subtitle) && ProjUiSecTxtF?.GetValue(__instance) is TMP_Text st)
                st.text = handle.Subtitle;
        }

        private static void TimerScheduler_Unschedule_Prefix(ITimer timer)
        {
            if (timer == null || ActiveProjects.Count == 0) return;
            string removeKey = null;
            foreach (var kv in ActiveProjects)
            {
                if (ReferenceEquals(kv.Value.NativeProject, timer)) { removeKey = kv.Key; break; }
            }
            if (removeKey != null) ActiveProjects.Remove(removeKey);
        }
    }
}
