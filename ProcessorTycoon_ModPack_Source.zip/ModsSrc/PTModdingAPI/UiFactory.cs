using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PTModdingAPI
{
    public static class UiFactory
    {
        public static readonly Color DarkBg = new Color(0.11f, 0.12f, 0.135f, 0.985f);
        public static readonly Color PanelBg = new Color(0.135f, 0.145f, 0.165f, 0.99f);
        public static readonly Color CardBg = new Color(0.175f, 0.188f, 0.21f, 0.98f);
        public static readonly Color CardAltBg = new Color(0.155f, 0.165f, 0.185f, 0.98f);
        public static readonly Color CardCompletedBg = new Color(0.135f, 0.235f, 0.185f, 0.98f);
        public static readonly Color CardActiveBg = new Color(0.145f, 0.22f, 0.30f, 0.99f);
        public static readonly Color HeaderBg = new Color(0.095f, 0.102f, 0.115f, 1f);
        public static readonly Color AccentBlue = new Color(0.22f, 0.56f, 0.86f, 1f);
        public static readonly Color AccentGreen = new Color(0.24f, 0.68f, 0.43f, 1f);
        public static readonly Color AccentRed = new Color(0.76f, 0.25f, 0.27f, 1f);
        public static readonly Color AccentAmber = new Color(0.86f, 0.66f, 0.24f, 1f);
        public static readonly Color BorderCol = new Color(0.28f, 0.31f, 0.36f, 1f);
        public static readonly Color TextPrimary = new Color(0.93f, 0.94f, 0.96f, 1f);
        public static readonly Color TextMuted = new Color(0.65f, 0.68f, 0.74f, 1f);
        public static readonly Color TextYellow = new Color(0.95f, 0.78f, 0.32f, 1f);
        public static readonly Color TextCostRed = new Color(0.94f, 0.40f, 0.40f, 1f);

        private static TMP_FontAsset _cachedFont;
        private static Sprite _whiteSprite;

        public static TMP_FontAsset GetGameFont()
        {
            if (_cachedFont != null) return _cachedFont;
            var existing = UnityEngine.Object.FindFirstObjectByType<TMP_Text>();
            if (existing != null && existing.font != null) { _cachedFont = existing.font; return _cachedFont; }
            _cachedFont = TMP_Settings.defaultFontAsset;
            return _cachedFont;
        }

        public static Sprite GetSolidSprite()
        {
            if (_whiteSprite != null) return _whiteSprite;
            var tex = new Texture2D(4, 4, TextureFormat.RGBA32, false) { hideFlags = HideFlags.HideAndDontSave };
            var cols = new Color[16];
            for (int i = 0; i < cols.Length; i++) cols[i] = Color.white;
            tex.SetPixels(cols);
            tex.Apply();
            _whiteSprite = Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f));
            _whiteSprite.hideFlags = HideFlags.HideAndDontSave;
            return _whiteSprite;
        }

        public static Canvas FindMainUiCanvas()
        {
            Canvas best = null;
            int bestScore = int.MinValue;
            foreach (var c in UnityEngine.Object.FindObjectsByType<Canvas>(FindObjectsInactive.Exclude, FindObjectsSortMode.None))
            {
                if (c == null || !c.isActiveAndEnabled || c.renderMode == RenderMode.WorldSpace) continue;
                var rc = c.rootCanvas != null ? c.rootCanvas : c;
                if (rc.GetComponent<GraphicRaycaster>() == null) continue;
                int score = rc.transform.childCount - Math.Abs(rc.sortingOrder) * 10;
                if (rc.name.IndexOf("Main", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    rc.name.IndexOf("Game", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    rc.name.IndexOf("UI", StringComparison.OrdinalIgnoreCase) >= 0) score += 200;
                if (score > bestScore) { bestScore = score; best = rc; }
            }
            if (best == null)
                best = UnityEngine.Object.FindFirstObjectByType<Canvas>();
            return best;
        }

        public static Canvas AttachModalOverlay(GameObject windowGo, int sortingOrder = 45)
        {
            if (windowGo == null) return null;
            var canvas = windowGo.GetComponent<Canvas>() ?? windowGo.AddComponent<Canvas>();
            canvas.overrideSorting = true;
            canvas.sortingOrder = sortingOrder;
            if (windowGo.GetComponent<GraphicRaycaster>() == null)
                windowGo.AddComponent<GraphicRaycaster>();
            return canvas;
        }

        public static (GameObject overlayRoot, GameObject windowPanel) CreateModalWindowRoot(
            string canvasName, string windowName, float width, float height, int sortingOrder = 150, Action onBackdropClick = null)
        {
            var overlay = new GameObject(canvasName);
            UnityEngine.Object.DontDestroyOnLoad(overlay);

            var c = overlay.AddComponent<Canvas>();
            c.renderMode = RenderMode.ScreenSpaceOverlay;
            c.sortingOrder = sortingOrder;

            var cs = overlay.AddComponent<CanvasScaler>();
            cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            cs.referenceResolution = new Vector2(1920f, 1080f);
            cs.matchWidthOrHeight = 0.5f;

            overlay.AddComponent<GraphicRaycaster>();

            var dim = CreatePanel("Backdrop", overlay.transform, new Color(0f, 0f, 0f, 0.48f), true);
            dim.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            var dimBtn = dim.AddComponent<Button>();
            dimBtn.transition = Selectable.Transition.None;
            if (onBackdropClick != null) dimBtn.onClick.AddListener(() => onBackdropClick());

            var win = CreatePanel(windowName, overlay.transform, DarkBg, true, true);
            var rt = win.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(width, height);
            return (overlay, win);
        }

        public static void EnsureEventSystem()
        {
            if (EventSystem.current != null) return;
            var esGo = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            UnityEngine.Object.DontDestroyOnLoad(esGo);
        }

        public static RectTransform SetAnchorStretch(this RectTransform rt, float minX, float minY, float maxX, float maxY,
            float padL = 0f, float padB = 0f, float padR = 0f, float padT = 0f)
        {
            rt.anchorMin = new Vector2(minX, minY);
            rt.anchorMax = new Vector2(maxX, maxY);
            rt.offsetMin = new Vector2(padL, padB);
            rt.offsetMax = new Vector2(-padR, -padT);
            return rt;
        }

        public static RectTransform SetTopAnchored(this RectTransform rt, float topOffset, float height, float hPad = 0f)
        {
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, -topOffset);
            rt.sizeDelta = new Vector2(-hPad * 2f, height);
            return rt;
        }

        public static GameObject CreatePanel(string name, Transform parent, Color bgColor, bool raycast = true, bool outline = false)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = GetSolidSprite();
            img.color = bgColor;
            img.raycastTarget = raycast;
            if (outline)
            {
                var ol = go.AddComponent<Outline>();
                ol.effectColor = BorderCol;
                ol.effectDistance = new Vector2(1f, -1f);
            }
            return go;
        }

        public static TMP_Text CreateText(string name, Transform parent, string text, float fontSize = 13f,
            TextAlignmentOptions align = TextAlignmentOptions.Left, Color? color = null, FontStyles style = FontStyles.Normal)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            var tmp = go.GetComponent<TextMeshProUGUI>();
            var f = GetGameFont();
            if (f != null) tmp.font = f;
            tmp.text = text ?? "";
            tmp.fontSize = fontSize;
            tmp.alignment = align;
            tmp.color = color ?? TextPrimary;
            tmp.fontStyle = style;
            tmp.textWrappingMode = TextWrappingModes.Normal;
            tmp.overflowMode = TextOverflowModes.Overflow;
            tmp.raycastTarget = false;
            return tmp;
        }

        public static Button CreateButton(string name, Transform parent, string label, Color bgColor, Action onClick,
            float fontSize = 13f, FontStyles style = FontStyles.Bold)
        {
            var go = CreatePanel(name, parent, bgColor, true);
            var btn = go.AddComponent<Button>();
            var img = go.GetComponent<Image>();
            var cb = btn.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1.12f, 1.12f, 1.12f, 1f);
            cb.pressedColor = new Color(0.84f, 0.84f, 0.84f, 1f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.7f);
            btn.colors = cb;
            btn.targetGraphic = img;

            var txt = CreateText("Label", go.transform, label, fontSize, TextAlignmentOptions.Center, TextPrimary, style);
            txt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 4f, 2f, 4f, 2f);
            txt.overflowMode = TextOverflowModes.Ellipsis;
            if (onClick != null) btn.onClick.AddListener(() => onClick());
            return btn;
        }

        public static TMP_InputField CreateInputField(string name, Transform parent, string placeholder, float fontSize = 13f)
        {
            var go = CreatePanel(name, parent, new Color(0.08f, 0.09f, 0.105f, 1f), true, true);
            var vp = new GameObject("TextArea", typeof(RectTransform), typeof(RectMask2D));
            vp.transform.SetParent(go.transform, false);
            vp.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 8f, 2f, 8f, 2f);

            var ph = CreateText("Placeholder", vp.transform, placeholder, fontSize, TextAlignmentOptions.MidlineLeft, TextMuted, FontStyles.Italic);
            ph.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            var txt = CreateText("Text", vp.transform, "", fontSize, TextAlignmentOptions.MidlineLeft, TextPrimary);
            txt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            var inp = go.AddComponent<TMP_InputField>();
            inp.textViewport = vp.GetComponent<RectTransform>();
            inp.textComponent = txt;
            inp.placeholder = ph;
            inp.fontAsset = GetGameFont();
            inp.pointSize = fontSize;
            return inp;
        }

        public static Slider CreateSlider(string name, Transform parent, float minVal, float maxVal, float curVal, Action<float> onChanged, bool wholeNumbers = false)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Slider));
            go.transform.SetParent(parent, false);
            // Transparent clickable track hit-box
            var hitImg = go.GetComponent<Image>();
            hitImg.sprite = GetSolidSprite();
            hitImg.color = new Color(1f, 1f, 1f, 0.005f);
            hitImg.raycastTarget = true;

            var bg = CreatePanel("Background", go.transform, new Color(0.07f, 0.08f, 0.095f, 1f), false);
            bg.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.36f, 1f, 0.64f, 6f, 0f, 6f, 0f);

            var fillArea = new GameObject("FillArea", typeof(RectTransform));
            fillArea.transform.SetParent(go.transform, false);
            fillArea.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.36f, 1f, 0.64f, 6f, 0f, 6f, 0f);

            var fill = CreatePanel("Fill", fillArea.transform, AccentBlue, false);
            fill.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0f, 1f);

            // IMPORTANT: HandleArea must have zero height & be centered vertically so Unity Slider.UpdateVisuals()
            // sets Handle anchorMin.y=0, anchorMax.y=1 without stretching Handle across the whole parent height.
            var handleArea = new GameObject("HandleArea", typeof(RectTransform));
            handleArea.transform.SetParent(go.transform, false);
            var haRt = handleArea.GetComponent<RectTransform>();
            haRt.anchorMin = new Vector2(0f, 0.5f);
            haRt.anchorMax = new Vector2(1f, 0.5f);
            haRt.pivot = new Vector2(0.5f, 0.5f);
            haRt.anchoredPosition = Vector2.zero;
            haRt.sizeDelta = new Vector2(-16f, 0f);

            var handle = CreatePanel("Handle", handleArea.transform, new Color(0.95f, 0.96f, 0.98f, 1f), true);
            var hRt = handle.GetComponent<RectTransform>();
            hRt.anchorMin = new Vector2(0.5f, 0.5f);
            hRt.anchorMax = new Vector2(0.5f, 0.5f);
            hRt.pivot = new Vector2(0.5f, 0.5f);
            hRt.sizeDelta = new Vector2(16f, 16f);
            var hOl = handle.AddComponent<Outline>();
            hOl.effectColor = new Color(0.15f, 0.25f, 0.38f, 0.9f);
            hOl.effectDistance = new Vector2(1f, -1f);

            var slider = go.GetComponent<Slider>();
            slider.fillRect = fill.GetComponent<RectTransform>();
            slider.handleRect = hRt;
            slider.targetGraphic = handle.GetComponent<Image>();
            slider.direction = Slider.Direction.LeftToRight;
            slider.wholeNumbers = wholeNumbers;
            slider.minValue = minVal;
            slider.maxValue = maxVal;
            slider.value = Mathf.Clamp(curVal, minVal, maxVal);
            if (onChanged != null) slider.onValueChanged.AddListener(v => onChanged(v));
            return slider;
        }

        public static Toggle CreateCheckbox(string name, Transform parent, string label, float fontSize, Action<bool> onChanged)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Toggle));
            go.transform.SetParent(parent, false);
            var hitImg = go.GetComponent<Image>();
            hitImg.sprite = GetSolidSprite();
            hitImg.color = new Color(1f, 1f, 1f, 0.005f);
            hitImg.raycastTarget = true;

            var box = CreatePanel("Box", go.transform, new Color(0.08f, 0.09f, 0.11f, 1f), true, true);
            var boxRt = box.GetComponent<RectTransform>();
            boxRt.anchorMin = new Vector2(0f, 0.5f);
            boxRt.anchorMax = new Vector2(0f, 0.5f);
            boxRt.pivot = new Vector2(0f, 0.5f);
            boxRt.anchoredPosition = new Vector2(4f, 0f);
            boxRt.sizeDelta = new Vector2(18f, 18f);

            var check = CreatePanel("Checkmark", box.transform, AccentBlue, false);
            check.GetComponent<RectTransform>().SetAnchorStretch(0.18f, 0.18f, 0.82f, 0.82f);

            var lbl = CreateText("Label", go.transform, label, fontSize, TextAlignmentOptions.MidlineLeft, TextPrimary);
            lbl.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 28f, 0f, 4f, 0f);

            var tgl = go.GetComponent<Toggle>();
            tgl.targetGraphic = box.GetComponent<Image>();
            tgl.graphic = check.GetComponent<Image>();
            if (onChanged != null) tgl.onValueChanged.AddListener(v => onChanged(v));
            return tgl;
        }

        public static (ScrollRect scroll, RectTransform content) CreateScrollView(string name, Transform parent, Color bgColor, float spacing = 6f, RectOffset padding = null)
        {
            var root = CreatePanel(name, parent, bgColor, true, true);

            var vp = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D), typeof(Image));
            vp.transform.SetParent(root.transform, false);
            vp.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 2f, 2f, 12f, 2f);
            var vpImg = vp.GetComponent<Image>();
            vpImg.sprite = GetSolidSprite();
            vpImg.color = new Color(0f, 0f, 0f, 0.004f);

            var content = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            content.transform.SetParent(vp.transform, false);
            var cRt = content.GetComponent<RectTransform>();
            cRt.anchorMin = new Vector2(0f, 1f);
            cRt.anchorMax = new Vector2(1f, 1f);
            cRt.pivot = new Vector2(0.5f, 1f);
            cRt.anchoredPosition = Vector2.zero;
            cRt.sizeDelta = Vector2.zero;

            var vlg = content.GetComponent<VerticalLayoutGroup>();
            vlg.spacing = spacing;
            vlg.padding = padding ?? new RectOffset(6, 6, 6, 6);
            vlg.childControlWidth = true;
            vlg.childControlHeight = false;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;

            content.GetComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            var sbBg = CreatePanel("Scrollbar", root.transform, new Color(0.08f, 0.09f, 0.11f, 0.9f), true);
            var sbRt = sbBg.GetComponent<RectTransform>();
            sbRt.anchorMin = new Vector2(1f, 0f);
            sbRt.anchorMax = new Vector2(1f, 1f);
            sbRt.pivot = new Vector2(1f, 0.5f);
            sbRt.anchoredPosition = new Vector2(-2f, 0f);
            sbRt.sizeDelta = new Vector2(8f, -4f);

            var sbSlide = new GameObject("SlidingArea", typeof(RectTransform));
            sbSlide.transform.SetParent(sbBg.transform, false);
            sbSlide.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            var sbHandle = CreatePanel("Handle", sbSlide.transform, new Color(0.42f, 0.46f, 0.54f, 1f), true);
            sbHandle.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            var sb = sbBg.AddComponent<Scrollbar>();
            sb.handleRect = sbHandle.GetComponent<RectTransform>();
            sb.targetGraphic = sbHandle.GetComponent<Image>();
            sb.direction = Scrollbar.Direction.BottomToTop;

            var scroll = root.AddComponent<ScrollRect>();
            scroll.viewport = vp.GetComponent<RectTransform>();
            scroll.content = cRt;
            scroll.vertical = true;
            scroll.horizontal = false;
            scroll.movementType = ScrollRect.MovementType.Clamped;
            scroll.scrollSensitivity = 28f;
            scroll.verticalScrollbar = sb;
            scroll.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport;
            return (scroll, cRt);
        }

        public static void MakeDraggable(GameObject dragHandle, GameObject targetWindow)
        {
            var dragger = dragHandle.GetComponent<WindowDragger>() ?? dragHandle.AddComponent<WindowDragger>();
            dragger.Target = targetWindow.GetComponent<RectTransform>();
        }

        public static string FormatMoney(float val)
        {
            float abs = Mathf.Abs(val);
            string sign = val < 0f ? "-" : "";
            if (abs >= 1e9f) return $"{sign}${abs / 1e9f:0.##}B";
            if (abs >= 1e6f) return $"{sign}${abs / 1e6f:0.##}M";
            if (abs >= 1e3f) return $"{sign}${abs / 1e3f:0.#}K";
            return $"{sign}${abs:0}";
        }

        public static string FormatMoneyCompact(float val) => FormatMoney(val);
    }

    internal sealed class WindowDragger : MonoBehaviour, IBeginDragHandler, IDragHandler
    {
        public RectTransform Target;
        private Vector2 _offset;

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (Target == null) return;
            Target.SetAsLastSibling();
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                Target.parent as RectTransform, eventData.position, eventData.pressEventCamera, out var lp);
            _offset = Target.anchoredPosition - lp;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (Target == null) return;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                Target.parent as RectTransform, eventData.position, eventData.pressEventCamera, out var lp))
            {
                Target.anchoredPosition = lp + _offset;
            }
        }
    }
}
