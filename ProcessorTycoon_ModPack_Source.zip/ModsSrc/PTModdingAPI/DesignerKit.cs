using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using ProcessorTycoon.Hardware;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModdingAPI
{
    public static class SaveCodec
    {
        public static string CleanField(string s) => (s ?? "").Replace("|", "/").Replace("\r", "").Replace("\n", " ");
        public static string FormatFloat(float v) => v.ToString("R", CultureInfo.InvariantCulture);
        public static float ParseFloat(string s, float def = 0f) =>
            float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out float v) ? v : def;
        public static int ParseInt(string s, int def = 0) =>
            int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int v) ? v : def;
    }

    public sealed class CpuBomTracker
    {
        public readonly Dictionary<string, int> PendingByName = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<int, int> CommittedBySaveId = new Dictionary<int, int>();

        public void Clear()
        {
            PendingByName.Clear();
            CommittedBySaveId.Clear();
        }

        public void RegisterHooks(Func<bool> isEnabled, Func<int> getActivePreviewBom)
        {
            ModApi.RegisterCpuStartedListener(cpu =>
            {
                if (!isEnabled() || cpu?.Package == null || !cpu.Package.IsPgaOrLga || string.IsNullOrEmpty(cpu.Name)) return;
                int bom = getActivePreviewBom();
                if (bom > 0) PendingByName[cpu.Name] = bom;
                else PendingByName.Remove(cpu.Name);
            });

            ModApi.RegisterCpuCompletedListener(cpu =>
            {
                if (cpu == null || cpu.SaveID <= 0 || string.IsNullOrEmpty(cpu.Name)) return;
                if (PendingByName.TryGetValue(cpu.Name, out int bom))
                {
                    PendingByName.Remove(cpu.Name);
                    if (bom > 0) CommittedBySaveId[cpu.SaveID] = bom;
                }
            });

            ModApi.RegisterCpuMaterialCostAdder((cpu, pkg, curCost) =>
            {
                if (!isEnabled()) return 0f;
                if (cpu != null) return CommittedBySaveId.TryGetValue(cpu.SaveID, out int savedBom) ? savedBom : 0f;
                if (pkg == null || !pkg.IsPgaOrLga) return 0f;
                return getActivePreviewBom();
            });
        }

        public void WriteLines(StringBuilder sb)
        {
            foreach (var kv in PendingByName)
                if (kv.Value > 0) sb.AppendLine($"PEND|{SaveCodec.CleanField(kv.Key)}|{kv.Value.ToString(CultureInfo.InvariantCulture)}");
            foreach (var kv in CommittedBySaveId)
                if (kv.Value > 0) sb.AppendLine($"CPU|{kv.Key.ToString(CultureInfo.InvariantCulture)}|{kv.Value.ToString(CultureInfo.InvariantCulture)}");
        }

        public bool TryReadLine(string[] p)
        {
            if (p == null || p.Length < 3) return false;
            if (p[0] == "PEND" && int.TryParse(p[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out int pbom) && pbom > 0)
            {
                PendingByName[p[1]] = pbom;
                return true;
            }
            if (p[0] == "CPU" && int.TryParse(p[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out int cid)
                && int.TryParse(p[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out int bom) && bom > 0)
            {
                CommittedBySaveId[cid] = bom;
                return true;
            }
            return false;
        }
    }

    public sealed class DesignCatalog<TSpec> where TSpec : class
    {
        public readonly List<TSpec> Items = new List<TSpec>();
        private readonly Func<TSpec, string> _getId;

        private ModCompanyTechState _cachedAutoState;
        private int _cachedAutoUnlockedCount = -2;
        private TSpec _cachedAutoSpec;

        public DesignCatalog(Func<TSpec, string> getId) => _getId = getId;

        public void InvalidateAutoCache()
        {
            _cachedAutoState = null;
            _cachedAutoUnlockedCount = -2;
            _cachedAutoSpec = null;
        }

        public void Clear()
        {
            Items.Clear();
            InvalidateAutoCache();
        }

        public string CycleMode(string current, int dir)
        {
            int total = 2 + Items.Count;
            int idx = current == "NONE" ? 0 : (current == "AUTO" ? 1 : -1);
            if (idx < 0)
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    if (_getId(Items[i]) == current) { idx = 2 + i; break; }
                }
            }
            if (idx < 0) idx = 1;
            int next = (idx + dir + total) % total;
            return next == 0 ? "NONE" : (next == 1 ? "AUTO" : _getId(Items[next - 2]));
        }

        public TSpec Resolve(ref string mode, string techTabId, Func<ModCompanyTechState, TSpec> buildAuto)
        {
            if (mode == "NONE") return null;
            if (mode == "AUTO")
            {
                var st = ModTechRegistry.GetPlayerState(techTabId);
                int cnt = st != null ? st.UnlockedIds.Count : -1;
                if (ReferenceEquals(st, _cachedAutoState) && cnt == _cachedAutoUnlockedCount)
                    return _cachedAutoSpec;

                _cachedAutoState = st;
                _cachedAutoUnlockedCount = cnt;
                _cachedAutoSpec = buildAuto != null ? buildAuto(st) : null;
                return _cachedAutoSpec;
            }
            string targetId = mode;
            for (int i = 0; i < Items.Count; i++)
            {
                if (_getId(Items[i]) == targetId) return Items[i];
            }
            mode = "AUTO";
            return Resolve(ref mode, techTabId, buildAuto);
        }
    }

    public sealed class PersistentDesignProject<TSpec> where TSpec : class
    {
        public string ProjectId { get; }
        private TSpec _pendingSpec;
        private int _pendingDays;
        private float _pendingCost;

        public PersistentDesignProject(string projectId) => ProjectId = projectId;

        public bool IsActive => ModApi.GetActiveProject(ProjectId) != null;

        public void Clear() => _pendingSpec = null;

        public void Start(TSpec spec, string title, string subtitle, int days, float cost, float initialProgress, Action onComplete)
        {
            _pendingSpec = spec;
            _pendingDays = days;
            _pendingCost = cost;
            ModApi.StartTimedProject(ProjectId, title, subtitle, days, cost, () =>
            {
                _pendingSpec = null;
                onComplete?.Invoke();
            }, initialProgress);
        }

        public void WritePendingLine(StringBuilder sb, Func<TSpec, string> formatSpec)
        {
            var act = ModApi.GetActiveProject(ProjectId);
            if (act != null && _pendingSpec != null)
            {
                sb.AppendLine($"PENDING|{SaveCodec.FormatFloat(act.Progress)}|{_pendingDays.ToString(CultureInfo.InvariantCulture)}|{SaveCodec.FormatFloat(_pendingCost)}|{formatSpec(_pendingSpec)}");
            }
        }

        public bool TryReadPendingLine(string[] p, int minColumns, Func<string[], int, TSpec> parseSpec, int defaultDays, float defaultCost,
            Action<TSpec, int, float, float> restartProject)
        {
            if (p == null || p.Length < minColumns || p[0] != "PENDING") return false;
            float prog = Mathf.Clamp01(SaveCodec.ParseFloat(p[1], 0f));
            int days = Math.Max(1, SaveCodec.ParseInt(p[2], defaultDays));
            float cost = SaveCodec.ParseFloat(p[3], defaultCost);
            var spec = parseSpec(p, 4);
            if (spec != null) restartProject(spec, days, cost, prog);
            return true;
        }
    }

    public sealed class StudioWindowShell
    {
        private static readonly List<GameObject> RegisteredOverlays = new List<GameObject>();

        public GameObject OverlayGo;
        public GameObject WindowGo;
        public RectTransform ListContent;
        public Transform RightPane;
        public TMP_InputField NameInput;
        public TMP_Text TechLabel;
        public TMP_Text PreviewText;
        public TMP_Text StatusText;
        public Button BuildButton;
        public TMP_Text BuildButtonText;

        public static void CloseAllWindows()
        {
            for (int i = 0; i < RegisteredOverlays.Count; i++)
            {
                if (RegisteredOverlays[i] != null) RegisteredOverlays[i].SetActive(false);
            }
        }

        public static StudioWindowShell Create(
            string prefix, float height, string windowTitle, string catalogTitle, string nameLabel, string defaultName, string namePlaceholder,
            string selectorLabel, string techTreeBtnLabel, string techTabId, string defaultBuildLabel,
            Action<int> onCycleTech, Action onBuildClicked, float previewMinY = 0.155f, float previewMaxY = 0.285f, float selectorMinY = 0.66f, float selectorMaxY = 0.735f)
        {
            var shell = new StudioWindowShell();
            (shell.OverlayGo, shell.WindowGo) = UiFactory.CreateModalWindowRoot(
                $"{prefix}_Overlay", $"{prefix}_Window", 780f, height, 160,
                () => shell.OverlayGo.SetActive(false));
            RegisteredOverlays.Add(shell.OverlayGo);

            var hdr = UiFactory.CreatePanel("Header", shell.WindowGo.transform, UiFactory.HeaderBg, true);
            hdr.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.905f, 1f, 1f);
            UiFactory.MakeDraggable(hdr, shell.WindowGo);
            UiFactory.CreateText("Title", hdr.transform, windowTitle, 15f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0.025f, 0f, 0.85f, 1f);
            UiFactory.CreateButton("Close", hdr.transform, "X", UiFactory.AccentRed, () => shell.OverlayGo.SetActive(false), 13f)
                .GetComponent<RectTransform>().SetAnchorStretch(0.935f, 0.14f, 0.988f, 0.86f);

            var leftPane = UiFactory.CreatePanel("LeftLib", shell.WindowGo.transform, UiFactory.PanelBg, true, true);
            leftPane.GetComponent<RectTransform>().SetAnchorStretch(0.015f, 0.02f, 0.425f, 0.885f);
            UiFactory.CreateText("LibHdr", leftPane.transform, catalogTitle, 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.905f, 0.96f, 0.985f);

            var (_, listContent) = UiFactory.CreateScrollView("CatalogScroll", leftPane.transform, new Color(0.09f, 0.10f, 0.115f, 1f), 6f);
            shell.ListContent = listContent;
            listContent.transform.parent.parent.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.03f, 0.96f, 0.895f);

            var rightPane = UiFactory.CreatePanel("RightForm", shell.WindowGo.transform, UiFactory.PanelBg, true, true);
            rightPane.GetComponent<RectTransform>().SetAnchorStretch(0.44f, 0.02f, 0.985f, 0.885f);
            shell.RightPane = rightPane.transform;

            UiFactory.CreateText("NmLbl", rightPane.transform, nameLabel, 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextMuted, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.895f, 0.70f, 0.965f);
            shell.NameInput = UiFactory.CreateInputField("NmInp", rightPane.transform, namePlaceholder, 12.5f);
            shell.NameInput.text = defaultName;
            shell.NameInput.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.815f, 0.96f, 0.895f);

            UiFactory.CreateText("TechLbl", rightPane.transform, selectorLabel, 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextMuted, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, selectorMaxY + 0.005f, 0.85f, selectorMaxY + 0.07f);

            UiFactory.CreateButton("PrevTech", rightPane.transform, "<", UiFactory.CardBg, () => onCycleTech(-1), 13f)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, selectorMinY, 0.13f, selectorMaxY);

            var box = UiFactory.CreatePanel("TechBox", rightPane.transform, UiFactory.CardBg, false, true);
            box.GetComponent<RectTransform>().SetAnchorStretch(0.145f, selectorMinY, 0.855f, selectorMaxY);
            shell.TechLabel = UiFactory.CreateText("TechVal", box.transform, "None Unlocked", 12f, TextAlignmentOptions.Center, UiFactory.TextPrimary, FontStyles.Bold);
            shell.TechLabel.GetComponent<RectTransform>().SetAnchorStretch(0.02f, 0f, 0.98f, 1f);

            UiFactory.CreateButton("NextTech", rightPane.transform, ">", UiFactory.CardBg, () => onCycleTech(1), 13f)
                .GetComponent<RectTransform>().SetAnchorStretch(0.87f, selectorMinY, 0.96f, selectorMaxY);

            var previewBox = UiFactory.CreatePanel("PrevBox", rightPane.transform, UiFactory.CardAltBg, false, true);
            previewBox.GetComponent<RectTransform>().SetAnchorStretch(0.04f, previewMinY, 0.96f, previewMaxY);
            shell.PreviewText = UiFactory.CreateText("PrevTxt", previewBox.transform, "", 11.5f, TextAlignmentOptions.TopLeft, UiFactory.TextPrimary);
            shell.PreviewText.GetComponent<RectTransform>().SetAnchorStretch(0.03f, 0.06f, 0.97f, 0.94f);

            shell.StatusText = UiFactory.CreateText("StatusTxt", rightPane.transform, "", 11f, TextAlignmentOptions.MidlineLeft, UiFactory.AccentAmber);
            shell.StatusText.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.105f, 0.96f, 0.148f);

            UiFactory.CreateButton("ResearchBtn", rightPane.transform, techTreeBtnLabel, UiFactory.AccentBlue, () =>
            {
                if (shell.OverlayGo != null) shell.OverlayGo.SetActive(false);
                ModApi.OpenResearchTab(techTabId);
            }, 12f).GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.02f, 0.44f, 0.095f);

            shell.BuildButton = UiFactory.CreateButton("BuildBtn", rightPane.transform, defaultBuildLabel, UiFactory.AccentGreen, onBuildClicked, 12f);
            shell.BuildButton.GetComponent<RectTransform>().SetAnchorStretch(0.46f, 0.02f, 0.96f, 0.095f);
            shell.BuildButtonText = shell.BuildButton.GetComponentInChildren<TMP_Text>();
            return shell;
        }

        public void RebuildCatalogRows<T>(IReadOnlyList<T> items, string emptyMessage, Func<T, string> getId, Func<T, string> getTitle,
            Func<T, string> getSub, Action<T> onDelete)
        {
            if (ListContent == null) return;
            foreach (Transform ch in ListContent) UnityEngine.Object.Destroy(ch.gameObject);

            if (items.Count == 0)
            {
                var empty = UiFactory.CreateText("Empty", ListContent, emptyMessage, 11.5f, TextAlignmentOptions.Center, UiFactory.TextMuted);
                empty.gameObject.AddComponent<LayoutElement>().preferredHeight = 64f;
                return;
            }

            for (int i = 0; i < items.Count; i++)
            {
                var item = items[i];
                var row = UiFactory.CreatePanel($"Row_{getId(item)}", ListContent, UiFactory.CardBg, true, true);
                row.AddComponent<LayoutElement>().preferredHeight = 62f;

                UiFactory.CreateText("Nm", row.transform, getTitle(item), 12f, TextAlignmentOptions.TopLeft, UiFactory.TextPrimary, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.50f, 0.82f, 0.92f);

                UiFactory.CreateText("Sub", row.transform, getSub(item), 10.5f, TextAlignmentOptions.BottomLeft, UiFactory.TextMuted)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.08f, 0.82f, 0.50f);

                UiFactory.CreateButton("Del", row.transform, "X", UiFactory.AccentRed, () => onDelete(item), 11f)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.855f, 0.18f, 0.965f, 0.82f);
            }
        }

        public static void SetSegmentButton(Button btn, bool selected, bool unlocked)
        {
            if (btn == null) return;
            btn.interactable = unlocked;
            if (btn.GetComponent<Image>() is Image img)
                img.color = selected ? UiFactory.AccentBlue : (unlocked ? UiFactory.CardBg : UiFactory.CardAltBg);
        }

        public void UpdateBuildState(string projectId, string readyLabel, string idleStatus, string activeStatus)
        {
            var act = ModApi.GetActiveProject(projectId);
            if (act != null)
            {
                BuildButton.interactable = false;
                BuildButtonText.text = $"Developing ({act.Progress * 100f:0}%)";
                StatusText.text = activeStatus;
            }
            else
            {
                BuildButton.interactable = true;
                BuildButtonText.text = readyLabel;
                StatusText.text = idleStatus;
            }
        }
    }
}
