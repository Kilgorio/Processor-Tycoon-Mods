using System;
using System.Collections.Generic;
using ProcessorTycoon.CompanySystem;
using UnityEngine;

namespace PTModdingAPI
{
    public sealed class ModTechBranchDef
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Color AccentColor { get; set; } = UiFactory.AccentBlue;
    }

    public sealed class ModTechNodeDef
    {
        public string Id { get; set; }
        public string ShortName { get; set; }
        public string Name { get; set; }
        public int Branch { get; set; }
        public int Tier { get; set; }
        public int Year { get; set; }
        public float BaseDays { get; set; }
        public float MonthlyCost { get; set; }
        public string[] Prereqs { get; set; } = Array.Empty<string>();
        public string Description { get; set; } = "";
        public string EffectsSummary { get; set; } = "";
    }

    public sealed class ModTechTabDef
    {
        public string TabId { get; set; }
        public string TabTitle { get; set; }
        public string Subtitle { get; set; } = "";
        public string ActionButtonLabel { get; set; }
        public Action OnActionButtonClick { get; set; }
        public List<ModTechBranchDef> Branches { get; } = new List<ModTechBranchDef>();
        public List<ModTechNodeDef> Nodes { get; } = new List<ModTechNodeDef>();
        public Func<float> GetResearchSpeedMultiplier { get; set; }
        public Func<bool> IsModEnabled { get; set; }
        public Action<ICompany, ModTechNodeDef, bool> OnNodeResearched { get; set; }
    }

    public sealed class ModCompanyTechState
    {
        public readonly HashSet<string> UnlockedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<string, float> Progress = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);
        public string ActiveNodeId;
        public float FundingPct = 100f;
        public bool InnovationEffort;

        public bool IsUnlocked(string nodeId) => !string.IsNullOrEmpty(nodeId) && UnlockedIds.Contains(nodeId);
        public float GetProgress(string nodeId) => !string.IsNullOrEmpty(nodeId) && Progress.TryGetValue(nodeId, out float p) ? p : 0f;
    }
}
