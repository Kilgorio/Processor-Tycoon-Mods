using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Save;
using ProcessorTycoon.TimeSystem;

namespace PTModdingAPI
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTModdingApiPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.moddingapi";
        public const string PluginName = "PT Modding API Core";
        public const string PluginVersion = "1.1.0";

        internal static ManualLogSource Log;
        internal static Harmony Harmony;
        private static int _lastDay = -1;

        private void Awake()
        {
            Log = Logger;
            Harmony = new Harmony(PluginGuid);

            ModApi.ApplyPatches(Harmony);

            var triggerTicks = AccessTools.Method(typeof(DateController), "TriggerTicks");
            if (triggerTicks != null)
                Harmony.Patch(triggerTicks, postfix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(DateController_TriggerTicks_Postfix)));

            var saveM = AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Save));
            if (saveM != null)
                Harmony.Patch(saveM, postfix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(SaveHandler_Save_Postfix)));

            var loadM = AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Load));
            if (loadM != null)
            {
                Harmony.Patch(loadM,
                    prefix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(SaveHandler_Load_Prefix)),
                    postfix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(SaveHandler_Load_Postfix)));
            }

            var newGameM = AccessTools.Method(typeof(Player), nameof(Player.InitializeAsNewGame));
            if (newGameM != null)
                Harmony.Patch(newGameM,
                    prefix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(Player_NewGame_Prefix)),
                    postfix: new HarmonyMethod(typeof(PTModdingApiPlugin), nameof(Player_NewGame_Postfix)));

            Log.LogInfo($"{PluginName} v{PluginVersion} loaded (zero-content framework).");
        }

        private static string _pendingLoadFileName;
        private static bool _loadedPendingSave;

        private static void DateController_TriggerTicks_Postfix()
        {
            if (DateController.Instance == null || (GameManager.Instance != null && GameManager.Instance.IsLoading)) return;
            int dayKey = DateController.Instance.CurrentDate.Year * 1000 + DateController.Instance.CurrentDate.DayOfYear;
            if (dayKey == _lastDay) return;
            _lastDay = dayKey;
            ModTechRegistry.OnDailyTick();
        }

        private static void SaveHandler_Save_Postfix(string saveName) => ModApi.SaveAllSidecars(saveName);

        private static void SaveHandler_Load_Prefix(string fileName)
        {
            _pendingLoadFileName = fileName;
            _loadedPendingSave = false;
            _lastDay = -1;
        }

        private static void SaveHandler_Load_Postfix(SaveHandler __instance, string fileName)
        {
            if (__instance == null || string.IsNullOrEmpty(fileName)) return;
            __instance.DuringLoad -= OnSaveDuringLoad;
            __instance.DuringLoad += OnSaveDuringLoad;
            __instance.OnLoaded -= OnSaveLoaded;
            __instance.OnLoaded += OnSaveLoaded;
            __instance.OnLateLoaded -= OnSaveLateLoaded;
            __instance.OnLateLoaded += OnSaveLateLoaded;
        }

        private static void OnSaveDuringLoad()
        {
            _lastDay = -1;
            ModApi.ClearAllSidecars();
        }

        private static void OnSaveLoaded()
        {
            if (_loadedPendingSave || string.IsNullOrEmpty(_pendingLoadFileName)) return;
            _loadedPendingSave = true;
            _lastDay = -1;
            ModApi.LoadAllSidecars(_pendingLoadFileName);
        }

        private static void OnSaveLateLoaded()
        {
            if (!_loadedPendingSave && !string.IsNullOrEmpty(_pendingLoadFileName))
                OnSaveLoaded();
            ModApi.MarkCreatorSlotsDirty();
            ModTechTreeUI.RefreshIfOpen();
        }

        private static void Player_NewGame_Prefix()
        {
            _pendingLoadFileName = null;
            _loadedPendingSave = false;
            _lastDay = -1;
            ModApi.ClearAllSidecars();
        }

        private static void Player_NewGame_Postfix()
        {
            ModTechRegistry.SeedEraDefaultsForNewGame();
        }
    }
}
