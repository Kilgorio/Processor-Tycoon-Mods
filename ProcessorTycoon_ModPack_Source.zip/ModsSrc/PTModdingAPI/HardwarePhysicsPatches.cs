using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.Hardware.Math;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.Save;
using UnityEngine;

namespace PTModdingAPI
{
    internal static class HardwarePhysicsPatches
    {
        private static readonly FieldInfo ContractMaxPowerF = AccessTools.Field(typeof(Contract), "<MaxPowerConsumption>k__BackingField");

        public static readonly List<Func<IPackage, float, float>> ThermalEffMods = new List<Func<IPackage, float, float>>();
        public static readonly List<Func<IPackage, float, float>> SafeTempMods = new List<Func<IPackage, float, float>>();
        public static readonly List<Func<IPackage, float, float>> PkgConsumptionMods = new List<Func<IPackage, float, float>>();
        public static readonly List<Action<CpuPhysicsContext, CpuPhysicsMods>> CpuStatMods = new List<Action<CpuPhysicsContext, CpuPhysicsMods>>();
        public static readonly List<Func<IPackage, float, float>> MaterialCostAdders = new List<Func<IPackage, float, float>>();
        public static readonly List<Func<Cpu, IPackage, float, float>> CpuMaterialCostAdders = new List<Func<Cpu, IPackage, float, float>>();
        public static readonly List<Action<Cpu>> CpuStartedListeners = new List<Action<Cpu>>();
        public static readonly List<Action<Cpu>> CpuCompletedListeners = new List<Action<Cpu>>();
        public static readonly List<Action<CustomHardware>> SocketCreatedListeners = new List<Action<CustomHardware>>();
        public static readonly List<Func<Contract, Cpu, float, float>> ContractPowerMultipliers = new List<Func<Contract, Cpu, float, float>>();

        private static readonly CpuPhysicsContext ReusableCtx = new CpuPhysicsContext();
        private static readonly CpuPhysicsMods ReusableMods = new CpuPhysicsMods();
        private static readonly HashSet<int> NotifiedCreatedSocketIds = new HashSet<int>();

        public static int CreatorContextDepth;
        public static bool InPlayerCreatorContext => CreatorContextDepth > 0;
        public static bool SuppressPackageMods;

        private static float _curContractSavedMaxPower = -1f;
        private static bool _contractMaxPowerPatched;
        private static bool _creatingPlayerCpu;
        private static bool _creatingPlayerSocket;
        private static Cpu _updatingCostForCpu;

        public static void ApplyPatches(Harmony harmony)
        {
            foreach (var pkgType in new[] { typeof(Package), typeof(CustomSocket) })
            {
                var te = AccessTools.PropertyGetter(pkgType, nameof(IPackage.ThermalEfficiency));
                if (te != null) harmony.Patch(te, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(IPackage_ThermalEfficiency_Postfix)));
                var st = AccessTools.PropertyGetter(pkgType, nameof(IPackage.SafeTemperature));
                if (st != null) harmony.Patch(st, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(IPackage_SafeTemperature_Postfix)));
                var cm = AccessTools.PropertyGetter(pkgType, nameof(IPackage.ConsumptionMultiplier));
                if (cm != null) harmony.Patch(cm, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(IPackage_ConsumptionMultiplier_Postfix)));
            }

            // Track player CreatorCpu call stack cleanly so studio mods never leak onto AI simulation
            foreach (var mName in new[] { "Initialize", "UpdateUI", "UpdateNumbers", "UpdateInfoTexts", "CreateCpu" })
            {
                var m = AccessTools.Method(typeof(CreatorCpu), mName);
                if (m != null)
                {
                    harmony.Patch(m,
                        prefix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorContext_Enter_Prefix)) { priority = Priority.First },
                        finalizer: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorContext_Exit_Finalizer)) { priority = Priority.First });
                }
            }

            var ipcM = AccessTools.Method(typeof(CpuMath), nameof(CpuMath.Ipc));
            if (ipcM != null) harmony.Patch(ipcM, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuMath_Ipc_Postfix)));

            var consM = AccessTools.Method(typeof(CpuMath), nameof(CpuMath.Consumption));
            if (consM != null) harmony.Patch(consM, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuMath_Consumption_Postfix)));

            var failM = AccessTools.Method(typeof(CpuMath), nameof(CpuMath.FailureRate));
            if (failM != null) harmony.Patch(failM, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuMath_FailureRate_Postfix)));

            var matM = AccessTools.Method(typeof(CpuMath), nameof(CpuMath.MaterialCost));
            if (matM != null) harmony.Patch(matM, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuMath_MaterialCost_Postfix)));

            var ccCreate = AccessTools.Method(typeof(CreatorCpu), "CreateCpu");
            if (ccCreate != null)
                harmony.Patch(ccCreate,
                    prefix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorCpu_CreateCpu_Prefix)),
                    finalizer: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorCpu_CreateCpu_Finalizer)));

            var cpuToProj = AccessTools.Method(typeof(DataConverter), nameof(DataConverter.CpuToSaveProject));
            if (cpuToProj != null) harmony.Patch(cpuToProj, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(DataConverter_CpuToSaveProject_Postfix)));

            var pchAddCpu = AccessTools.Method(typeof(ProjectCompletedHandler), nameof(ProjectCompletedHandler.AddCpu));
            if (pchAddCpu != null) harmony.Patch(pchAddCpu, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(ProjectCompletedHandler_AddCpu_Postfix)));

            var csCreate = AccessTools.Method(typeof(CreatorSocket), "CreateSocket");
            if (csCreate != null)
                harmony.Patch(csCreate,
                    prefix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorSocket_CreateSocket_Prefix)),
                    finalizer: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CreatorSocket_CreateSocket_Finalizer)));

            var compAddHw = AccessTools.Method(typeof(Company), nameof(ICompany.AddCustomHardware));
            if (compAddHw != null) harmony.Patch(compAddHw, postfix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(Company_AddCustomHardware_Postfix)));

            var costUpd = AccessTools.Method(typeof(CpuUnitCostUpdater), nameof(CpuUnitCostUpdater.UpdateUnitCost));
            if (costUpd != null)
                harmony.Patch(costUpd,
                    prefix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuUnitCostUpdater_UpdateUnitCost_Prefix)),
                    finalizer: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(CpuUnitCostUpdater_UpdateUnitCost_Finalizer)));

            var contractFail = AccessTools.Method(typeof(Contract), nameof(Contract.FailsAtAnyRequirement));
            if (contractFail != null)
                harmony.Patch(contractFail,
                    prefix: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(Contract_FailsAtAnyRequirement_Prefix)),
                    finalizer: new HarmonyMethod(typeof(HardwarePhysicsPatches), nameof(Contract_FailsAtAnyRequirement_Finalizer)));
        }

        private static void CreatorContext_Enter_Prefix() => CreatorContextDepth++;
        private static void CreatorContext_Exit_Finalizer() { if (CreatorContextDepth > 0) CreatorContextDepth--; }

        private static void IPackage_ThermalEfficiency_Postfix(IPackage __instance, ref float __result)
        {
            if (SuppressPackageMods || !InPlayerCreatorContext || __instance == null || ThermalEffMods.Count == 0) return;
            float orig = __result;
            for (int i = 0; i < ThermalEffMods.Count; i++) __result = ThermalEffMods[i](__instance, __result);
            if (orig < 2.45f && __result > 2.45f) __result = 2.45f;
        }

        private static void IPackage_SafeTemperature_Postfix(IPackage __instance, ref float __result)
        {
            if (SuppressPackageMods || !InPlayerCreatorContext || __instance == null || SafeTempMods.Count == 0) return;
            for (int i = 0; i < SafeTempMods.Count; i++) __result = SafeTempMods[i](__instance, __result);
        }

        private static void IPackage_ConsumptionMultiplier_Postfix(IPackage __instance, ref float __result)
        {
            if (SuppressPackageMods || !InPlayerCreatorContext || __instance == null || PkgConsumptionMods.Count == 0) return;
            for (int i = 0; i < PkgConsumptionMods.Count; i++) __result = PkgConsumptionMods[i](__instance, __result);
        }

        private static CpuPhysicsMods EvaluateCpuMods(IPackage pkg, ProcessNode node, Memory mem, int cores, int dies, float freq, float baseCons, float baseTemp)
        {
            ReusableCtx.Package = pkg;
            ReusableCtx.ProcessNode = node;
            ReusableCtx.Memory = mem;
            ReusableCtx.CoreCount = cores;
            ReusableCtx.DieCount = dies;
            ReusableCtx.Frequency = freq;
            ReusableCtx.BaseConsumption = baseCons;
            ReusableCtx.BaseTemperature = baseTemp;

            ReusableMods.IpcMultiplier = 1f;
            ReusableMods.PowerMultiplier = 1f;
            ReusableMods.FailureMultiplier = 1f;
            ReusableMods.BomExtraCost = 0f;

            for (int i = 0; i < CpuStatMods.Count; i++) CpuStatMods[i](ReusableCtx, ReusableMods);
            return ReusableMods;
        }

        private static void CpuMath_Ipc_Postfix(Memory memory, float frequency, int coreCount, int dieCount, ref float __result)
        {
            if (CpuStatMods.Count == 0 || !InPlayerCreatorContext) return;
            var m = EvaluateCpuMods(CreatorUiBridge.CurrentCreatorPackage, CreatorUiBridge.CurrentCreatorLitho, memory, coreCount, dieCount, frequency, 0f, 0f);
            __result *= m.IpcMultiplier;
        }

        private static void CpuMath_Consumption_Postfix(IPackage package, ProcessNode processNode, int coreCount, int dieCount, float frequency, ref float __result)
        {
            if (CpuStatMods.Count == 0 || !InPlayerCreatorContext) return;
            var m = EvaluateCpuMods(package, processNode, null, coreCount, dieCount, frequency, __result, 0f);
            __result *= m.PowerMultiplier;
        }

        private static void CpuMath_FailureRate_Postfix(IPackage package, ProcessNode processNode, float temperature, float frequency, int coreCount, int dieCount, ref float __result)
        {
            if (!InPlayerCreatorContext) return;
            if (CpuStatMods.Count > 0)
            {
                var m = EvaluateCpuMods(package, processNode, null, coreCount, dieCount, frequency, 0f, temperature);
                __result = Mathf.Clamp(__result * m.FailureMultiplier, 0.005f, 0.99f);
            }
            if (dieCount > 1 && FabProductionPatches.HasFabMods)
            {
                var fm = FabProductionPatches.EvalFabMods(dieCount);
                float multiDiePenaltyFactor = 1f - Mathf.Clamp01(fm.MultiDieFailureReduction);
                float baseSingleGuess = __result * 0.65f;
                float extraDieFail = Math.Max(0f, __result - baseSingleGuess);
                __result = Mathf.Clamp(baseSingleGuess + extraDieFail * multiDiePenaltyFactor, 0.005f, 0.99f);
            }
        }

        private static void CpuMath_MaterialCost_Postfix(IPackage package, ref float __result)
        {
            if (package == null) return;
            bool allowStudioPreview = _updatingCostForCpu != null || InPlayerCreatorContext;
            if (!allowStudioPreview) return;

            for (int i = 0; i < MaterialCostAdders.Count; i++)
                __result += Mathf.Max(0f, MaterialCostAdders[i](package, __result));
            for (int i = 0; i < CpuMaterialCostAdders.Count; i++)
                __result += Mathf.Max(0f, CpuMaterialCostAdders[i](_updatingCostForCpu, package, __result));
        }

        private static void CreatorCpu_CreateCpu_Prefix() => _creatingPlayerCpu = true;
        private static void CreatorCpu_CreateCpu_Finalizer() => _creatingPlayerCpu = false;

        private static void DataConverter_CpuToSaveProject_Postfix(Cpu cpu)
        {
            if (!_creatingPlayerCpu || cpu == null) return;
            for (int i = 0; i < CpuStartedListeners.Count; i++) CpuStartedListeners[i](cpu);
        }

        private static void ProjectCompletedHandler_AddCpu_Postfix(Cpu cpu)
        {
            if (cpu?.Company == null || !cpu.Company.IsPlayer) return;
            for (int i = 0; i < CpuCompletedListeners.Count; i++) CpuCompletedListeners[i](cpu);
        }

        private static void CreatorSocket_CreateSocket_Prefix()
        {
            _creatingPlayerSocket = true;
            NotifiedCreatedSocketIds.Clear();
        }

        private static void CreatorSocket_CreateSocket_Finalizer()
        {
            _creatingPlayerSocket = false;
            NotifiedCreatedSocketIds.Clear();
        }

        private static void Company_AddCustomHardware_Postfix(CustomHardware customHardware)
        {
            if (!_creatingPlayerSocket || customHardware == null) return;
            if (!NotifiedCreatedSocketIds.Add(customHardware.SaveID)) return;
            for (int i = 0; i < SocketCreatedListeners.Count; i++) SocketCreatedListeners[i](customHardware);
        }

        private static void CpuUnitCostUpdater_UpdateUnitCost_Prefix(Cpu cpu) => _updatingCostForCpu = cpu;
        private static void CpuUnitCostUpdater_UpdateUnitCost_Finalizer() => _updatingCostForCpu = null;

        private static void Contract_FailsAtAnyRequirement_Prefix(Contract __instance, Cpu cpu)
        {
            _contractMaxPowerPatched = false;
            if (__instance == null || cpu == null || ContractPowerMultipliers.Count == 0) return;
            float mult = 1f;
            for (int i = 0; i < ContractPowerMultipliers.Count; i++) mult = ContractPowerMultipliers[i](__instance, cpu, mult);
            if (mult > 1.005f && ContractMaxPowerF != null)
            {
                _curContractSavedMaxPower = __instance.MaxPowerConsumption;
                ContractMaxPowerF.SetValue(__instance, _curContractSavedMaxPower * mult);
                _contractMaxPowerPatched = true;
            }
        }

        private static void Contract_FailsAtAnyRequirement_Finalizer(Contract __instance)
        {
            if (_contractMaxPowerPatched && __instance != null && ContractMaxPowerF != null)
            {
                ContractMaxPowerF.SetValue(__instance, _curContractSavedMaxPower);
                _contractMaxPowerPatched = false;
            }
        }
    }
}
