using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.ResearchSystem.Math;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTModdingAPI
{
    public static class ModTechRegistry
    {
        private static readonly List<ModTechTabDef> RegisteredTabs = new List<ModTechTabDef>();
        private static readonly Dictionary<string, ModTechTabDef> TabsById = new Dictionary<string, ModTechTabDef>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, Dictionary<string, ModTechNodeDef>> NodesByTab =
            new Dictionary<string, Dictionary<string, ModTechNodeDef>>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, Dictionary<int, ModCompanyTechState>> States =
            new Dictionary<string, Dictionary<int, ModCompanyTechState>>(StringComparer.OrdinalIgnoreCase);

        private static readonly ModCompanyTechState FallbackReadOnlyState = new ModCompanyTechState();
        private static AICompany[] _cachedAiCompanies;
        private static int _aiCacheRefreshCounter;

        public static IReadOnlyList<ModTechTabDef> Tabs => RegisteredTabs;

        public static void RegisterTechTab(ModTechTabDef tab)
        {
            if (tab == null || string.IsNullOrWhiteSpace(tab.TabId)) return;
            if (TabsById.ContainsKey(tab.TabId))
                RegisteredTabs.RemoveAll(t => string.Equals(t.TabId, tab.TabId, StringComparison.OrdinalIgnoreCase));

            RegisteredTabs.Add(tab);
            TabsById[tab.TabId] = tab;

            var nodeMap = new Dictionary<string, ModTechNodeDef>(tab.Nodes.Count, StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < tab.Nodes.Count; i++)
            {
                var n = tab.Nodes[i];
                if (n != null && !string.IsNullOrEmpty(n.Id)) nodeMap[n.Id] = n;
            }
            NodesByTab[tab.TabId] = nodeMap;

            ModApi.RegisterSaveParticipant(
                "tech_" + tab.TabId,
                () => SerializeTab(tab.TabId),
                data => DeserializeTab(tab.TabId, data),
                () => ClearTabState(tab.TabId));
        }

        public static ModTechTabDef GetTab(string tabId) =>
            !string.IsNullOrEmpty(tabId) && TabsById.TryGetValue(tabId, out var t) ? t : null;

        internal static ModTechNodeDef FindNode(string tabId, string nodeId) =>
            !string.IsNullOrEmpty(tabId) && !string.IsNullOrEmpty(nodeId) &&
            NodesByTab.TryGetValue(tabId, out var map) && map.TryGetValue(nodeId, out var node)
                ? node
                : null;

        public static ModCompanyTechState GetState(string tabId, ICompany company)
        {
            if (string.IsNullOrEmpty(tabId) || company == null) return FallbackReadOnlyState;
            return GetOrCreateTabMap(tabId, company.SaveID);
        }

        private static ModCompanyTechState GetOrCreateTabMap(string tabId, int companySaveId)
        {
            if (!States.TryGetValue(tabId, out var byCompany))
            {
                byCompany = new Dictionary<int, ModCompanyTechState>();
                States[tabId] = byCompany;
            }
            if (!byCompany.TryGetValue(companySaveId, out var st))
            {
                st = new ModCompanyTechState();
                byCompany[companySaveId] = st;
            }
            return st;
        }

        public static ModCompanyTechState GetPlayerState(string tabId) =>
            Player.Instance?.Company != null ? GetState(tabId, Player.Instance.Company) : null;

        public static bool IsUnlocked(string tabId, ICompany company, string nodeId) =>
            !string.IsNullOrEmpty(nodeId) && company != null && GetState(tabId, company).IsUnlocked(nodeId);

        public static bool ArePrereqsMet(ModTechTabDef tab, ModCompanyTechState st, ModTechNodeDef node)
        {
            if (node?.Prereqs == null || node.Prereqs.Length == 0) return true;
            for (int i = 0; i < node.Prereqs.Length; i++)
                if (!st.IsUnlocked(node.Prereqs[i])) return false;
            return true;
        }

        public static float EffectiveSpeed(ModTechTabDef tab, ModTechNodeDef node, ModCompanyTechState st, ICompany company, int year)
        {
            float fundingFrac = Mathf.Max(0.1f, (st?.FundingPct ?? 100f) / 100f);
            float baseSpeed = company != null ? ResearchMath.ResearchSpeed(fundingFrac, company) : fundingFrac;
            float modMult = tab.GetResearchSpeedMultiplier != null ? Mathf.Clamp(tab.GetResearchSpeedMultiplier(), 0.2f, 5f) : 1f;
            float innovBoost = (st != null && st.InnovationEffort) ? 1.65f : 1f;

            int yearsEarly = Mathf.Max(0, node.Year - year);
            float earlyPenalty = yearsEarly > 0 ? Mathf.Pow(1.85f, yearsEarly) : 1f;
            int yearsLate = Mathf.Max(0, year - node.Year);
            float catchupBonus = yearsLate > 0 ? 1f + Mathf.Min(1.5f, yearsLate * 0.15f) : 1f;

            return Mathf.Clamp(baseSpeed * modMult * innovBoost * catchupBonus / earlyPenalty, 0.005f, 12f);
        }

        public static int EstimateDaysLeft(ModTechTabDef tab, ModTechNodeDef node, ModCompanyTechState st, ICompany company, int year)
        {
            float spd = Mathf.Max(0.005f, EffectiveSpeed(tab, node, st, company, year));
            float prog = st?.GetProgress(node.Id) ?? 0f;
            return Mathf.Max(1, Mathf.CeilToInt(Mathf.Clamp01(1f - prog) * node.BaseDays / spd));
        }

        public static float EstimateMonthlyCost(ModTechNodeDef node, ModCompanyTechState st)
        {
            float fundingFrac = Mathf.Clamp((st?.FundingPct ?? 100f) / 100f, 0.1f, 3f);
            float innovCost = (st != null && st.InnovationEffort) ? 2.0f : 1f;
            return node.MonthlyCost * fundingFrac * innovCost;
        }

        public static void ClearAllState()
        {
            States.Clear();
            _cachedAiCompanies = null;
            _aiCacheRefreshCounter = 0;
            CreatorUiBridge.MarkDirty();
        }

        private static void ClearTabState(string tabId)
        {
            if (States.TryGetValue(tabId, out var byCompany)) byCompany.Clear();
            CreatorUiBridge.MarkDirty();
        }

        internal static void SeedEraDefaultsForNewGame() => SeedEraDefaultsInternal(null);
        internal static void SeedEraDefaultsForTab(string tabId) => SeedEraDefaultsInternal(tabId);

        private static void SeedEraDefaultsInternal(string onlyTabId)
        {
            int curYear = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
            var companies = new List<ICompany>();
            if (Player.Instance?.Company != null) companies.Add(Player.Instance.Company);
            foreach (var ai in UnityEngine.Object.FindObjectsByType<AICompany>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                if (ai != null) companies.Add(ai);

            for (int t = 0; t < RegisteredTabs.Count; t++)
            {
                var tab = RegisteredTabs[t];
                if (!string.IsNullOrEmpty(onlyTabId) && !string.Equals(tab.TabId, onlyTabId, StringComparison.OrdinalIgnoreCase)) continue;
                if (tab.IsModEnabled != null && !tab.IsModEnabled()) continue;

                for (int c = 0; c < companies.Count; c++)
                {
                    var st = GetState(tab.TabId, companies[c]);
                    if (st.UnlockedIds.Count > 0) continue;

                    // Fixed-point pass so out-of-order prerequisites within the same year seed reliably
                    bool changed;
                    do
                    {
                        changed = false;
                        for (int ni = 0; ni < tab.Nodes.Count; ni++)
                        {
                            var n = tab.Nodes[ni];
                            if (n.Year <= curYear && !st.IsUnlocked(n.Id) && ArePrereqsMet(tab, st, n))
                            {
                                st.UnlockedIds.Add(n.Id);
                                changed = true;
                            }
                        }
                    } while (changed);
                }
            }
            CreatorUiBridge.MarkDirty();
        }

        internal static void OnDailyTick()
        {
            if (GameManager.Instance != null && GameManager.Instance.IsLoading) return;
            if (RegisteredTabs.Count == 0 || DateController.Instance == null) return;
            int year = DateController.Instance.CurrentDate.Year;

            bool aiStep = DateController.Instance.CurrentDate.Day % 3 == 0;
            if (aiStep)
            {
                bool needsScan = _cachedAiCompanies == null || (_aiCacheRefreshCounter++ % 10 == 0) ||
                                 (_cachedAiCompanies.Length > 0 && _cachedAiCompanies[0] == null);
                if (needsScan)
                    _cachedAiCompanies = UnityEngine.Object.FindObjectsByType<AICompany>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
            }

            var playerComp = Player.Instance?.Company;
            for (int t = 0; t < RegisteredTabs.Count; t++)
            {
                var tab = RegisteredTabs[t];
                if (tab.IsModEnabled != null && !tab.IsModEnabled()) continue;

                if (playerComp != null && !playerComp.IsBankrupt)
                    TickCompanyTabResearch(tab, playerComp, year, isPlayer: true);

                if (aiStep && _cachedAiCompanies != null)
                {
                    for (int i = 0; i < _cachedAiCompanies.Length; i++)
                    {
                        var ai = _cachedAiCompanies[i];
                        if (ai == null || ai.IsBankrupt) continue;
                        EnsureAiResearchSelection(tab, ai, year);
                        TickCompanyTabResearch(tab, ai, year, isPlayer: false, dayStep: 3f);
                    }
                }
            }

            ModTechTreeUI.RefreshIfOpen();
        }

        private static void EnsureAiResearchSelection(ModTechTabDef tab, AICompany ai, int year)
        {
            var st = GetState(tab.TabId, ai);
            if (!string.IsNullOrEmpty(st.ActiveNodeId) && !st.IsUnlocked(st.ActiveNodeId)) return;

            ModTechNodeDef best = null;
            for (int i = 0; i < tab.Nodes.Count; i++)
            {
                var n = tab.Nodes[i];
                if (st.IsUnlocked(n.Id) || n.Year > year + 1 || !ArePrereqsMet(tab, st, n)) continue;
                if (best == null || n.Year < best.Year || (n.Year == best.Year && n.Tier < best.Tier))
                    best = n;
            }

            if (best != null)
            {
                st.ActiveNodeId = best.Id;
                st.FundingPct = ai.MoneyAmount > 2_000_000f ? 120f : 75f;
                st.InnovationEffort = false;
            }
            else st.ActiveNodeId = null;
        }

        private static void TickCompanyTabResearch(ModTechTabDef tab, ICompany company, int year, bool isPlayer, float dayStep = 1f)
        {
            var st = GetState(tab.TabId, company);
            if (string.IsNullOrEmpty(st.ActiveNodeId)) return;

            var node = FindNode(tab.TabId, st.ActiveNodeId);
            if (node == null || st.IsUnlocked(node.Id) || !ArePrereqsMet(tab, st, node))
            {
                st.ActiveNodeId = null;
                return;
            }

            float dailyCost = EstimateMonthlyCost(node, st) / 30f * dayStep;
            if (dailyCost > 0f) company.SpendMoney(dailyCost, ExpenseOrigin.Research);

            float spd = EffectiveSpeed(tab, node, st, company, year);
            float cur = st.GetProgress(node.Id) + (spd * dayStep) / Mathf.Max(10f, node.BaseDays);
            if (cur >= 1f)
            {
                st.Progress[node.Id] = 1f;
                st.UnlockedIds.Add(node.Id);
                st.ActiveNodeId = null;
                try { tab.OnNodeResearched?.Invoke(company, node, isPlayer); }
                catch (Exception ex) { PTModdingApiPlugin.Log?.LogWarning($"OnNodeResearched error ({tab.TabId}): {ex.Message}"); }

                if (isPlayer)
                {
                    CreatorUiBridge.MarkDirty();
                    if (DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating)
                        PopupManager.Instance?.InstantiateTechnologyNotification($"{tab.TabTitle}: {node.Name}");
                }
            }
            else st.Progress[node.Id] = cur;
        }

        private static string SerializeTab(string tabId)
        {
            if (!States.TryGetValue(tabId, out var byCompany) || byCompany.Count == 0) return "";
            var sb = new StringBuilder();
            foreach (var kv in byCompany)
            {
                int cid = kv.Key;
                if (cid < 0) continue;
                var st = kv.Value;
                sb.AppendLine($"C|{cid.ToString(CultureInfo.InvariantCulture)}|{st.ActiveNodeId ?? ""}|{st.FundingPct.ToString("R", CultureInfo.InvariantCulture)}|{(st.InnovationEffort ? "1" : "0")}");
                foreach (var u in st.UnlockedIds)
                    sb.AppendLine($"U|{cid.ToString(CultureInfo.InvariantCulture)}|{u}");
                foreach (var p in st.Progress)
                    if (!st.UnlockedIds.Contains(p.Key) && p.Value > 0.0001f)
                        sb.AppendLine($"P|{cid.ToString(CultureInfo.InvariantCulture)}|{p.Key}|{p.Value.ToString("R", CultureInfo.InvariantCulture)}");
            }
            return sb.ToString();
        }

        private static void DeserializeTab(string tabId, string data)
        {
            ClearTabState(tabId);
            if (string.IsNullOrWhiteSpace(data))
            {
                SeedEraDefaultsForTab(tabId);
                return;
            }
            foreach (var raw in data.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = raw.Split('|');
                if (p.Length < 3) continue;
                if (!int.TryParse(p[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out int cid) || cid < 0) continue;
                var st = GetOrCreateTabMap(tabId, cid);
                if (p[0] == "C" && p.Length >= 5)
                {
                    st.ActiveNodeId = string.IsNullOrEmpty(p[2]) ? null : p[2];
                    if (float.TryParse(p[3], NumberStyles.Float, CultureInfo.InvariantCulture, out float fp))
                        st.FundingPct = Mathf.Clamp(fp, 10f, 300f);
                    st.InnovationEffort = p[4] == "1";
                }
                else if (p[0] == "U") st.UnlockedIds.Add(p[2]);
                else if (p[0] == "P" && p.Length >= 4 && float.TryParse(p[3], NumberStyles.Float, CultureInfo.InvariantCulture, out float pr))
                    st.Progress[p[2]] = Mathf.Clamp01(pr);
            }
            _cachedAiCompanies = null;
            CreatorUiBridge.MarkDirty();
        }
    }
}
