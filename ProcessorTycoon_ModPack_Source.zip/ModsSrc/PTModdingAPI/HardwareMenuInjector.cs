using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModdingAPI
{
    internal static class HardwareMenuInjector
    {
        private static readonly FieldInfo CreateHwSocketBtnF = AccessTools.Field(typeof(CreateHardwareWindow), "createSocketButton");

        public static readonly List<HardwareMenuButtonDef> MenuButtons = new List<HardwareMenuButtonDef>();
        private static readonly Dictionary<string, ButtonUI> ClonedHardwareBtns = new Dictionary<string, ButtonUI>();
        private static readonly Dictionary<int, float> ExpandedHwDeltas = new Dictionary<int, float>();

        public static void ApplyPatches(Harmony harmony)
        {
            var chwOnEn = AccessTools.Method(typeof(CreateHardwareWindow), "OnEnable");
            if (chwOnEn != null)
                harmony.Patch(chwOnEn, postfix: new HarmonyMethod(typeof(HardwareMenuInjector), nameof(CreateHardwareWindow_Refresh_Postfix)) { priority = Priority.Low });
            var chwUpd = AccessTools.Method(typeof(CreateHardwareWindow), "UpdateButtonStates");
            if (chwUpd != null)
                harmony.Patch(chwUpd, postfix: new HarmonyMethod(typeof(HardwareMenuInjector), nameof(CreateHardwareWindow_Refresh_Postfix)) { priority = Priority.Low });
        }

        public static void ResetSessionState()
        {
            var deadKeys = new List<string>();
            foreach (var kv in ClonedHardwareBtns)
                if (kv.Value == null) deadKeys.Add(kv.Key);
            for (int i = 0; i < deadKeys.Count; i++)
                ClonedHardwareBtns.Remove(deadKeys[i]);
            if (ClonedHardwareBtns.Count == 0)
                ExpandedHwDeltas.Clear();
        }

        private static void CreateHardwareWindow_Refresh_Postfix(CreateHardwareWindow __instance)
        {
            if (__instance == null || MenuButtons.Count == 0) return;
            var allButtons = __instance.GetComponentsInChildren<ButtonUI>(true);
            ButtonUI template = null;
            for (int i = 0; i < allButtons.Length; i++)
            {
                var b = allButtons[i];
                if (b == null || b.name.StartsWith("PTModHwBtn_", StringComparison.Ordinal)) continue;
                var lbl = b.GetComponentInChildren<TMP_Text>(true)?.text;
                if (string.IsNullOrEmpty(lbl)) continue;
                if (lbl.IndexOf("Variant", StringComparison.OrdinalIgnoreCase) >= 0) { template = b; break; }
                if (lbl.IndexOf("New CPU", StringComparison.OrdinalIgnoreCase) >= 0) template = b;
            }
            if (template == null) template = CreateHwSocketBtnF?.GetValue(__instance) as ButtonUI;
            if (template == null) return;

            var parent = template.transform.parent;
            bool hasVlg = parent.GetComponent<VerticalLayoutGroup>() != null;

            float lowestY = template.GetComponent<RectTransform>().anchoredPosition.y;
            for (int i = 0; i < allButtons.Length; i++)
            {
                var b = allButtons[i];
                if (b == null || b.transform.parent != parent || b.name.StartsWith("PTModHwBtn_", StringComparison.Ordinal)) continue;
                float y = b.GetComponent<RectTransform>().anchoredPosition.y;
                if (y < lowestY) lowestY = y;
            }

            float baseY = lowestY - (template.GetComponent<RectTransform>().sizeDelta.y + 8f);
            int idx = 0;
            for (int i = 0; i < MenuButtons.Count; i++)
            {
                var def = MenuButtons[i];
                bool visible = def.IsVisible == null || def.IsVisible();

                ButtonUI existing = null;
                for (int j = 0; j < allButtons.Length && existing == null; j++)
                {
                    var b = allButtons[j];
                    if (b == null || b.name.StartsWith("PTModHwBtn_", StringComparison.Ordinal)) continue;
                    var texts = b.GetComponentsInChildren<TMP_Text>(true);
                    for (int k = 0; k < texts.Length; k++)
                    {
                        var t = texts[k];
                        if (t != null && string.Equals(t.text?.Trim(), def.Label, StringComparison.OrdinalIgnoreCase))
                        {
                            existing = b;
                            break;
                        }
                    }
                }

                if (existing != null)
                {
                    if (visible)
                    {
                        var cg = existing.GetComponent<CanvasGroup>();
                        if (cg != null) { cg.alpha = 1f; cg.interactable = true; cg.blocksRaycasts = true; }
                        foreach (var t in existing.GetComponentsInChildren<TMP_Text>(true))
                            if (t != null && string.Equals(t.text?.Trim(), def.Label, StringComparison.OrdinalIgnoreCase))
                                t.color = Color.white;
                    }
                    WireHardwareButton(existing.gameObject, __instance, existing, def.OnClick, visible);
                    continue;
                }

                if (!ClonedHardwareBtns.TryGetValue(def.Id, out var cloned) || cloned == null)
                {
                    var existingChild = parent.Find($"PTModHwBtn_{def.Id}");
                    if (existingChild != null)
                    {
                        cloned = existingChild.GetComponent<ButtonUI>();
                    }
                    else
                    {
                        cloned = UnityEngine.Object.Instantiate(template, parent);
                        cloned.name = $"PTModHwBtn_{def.Id}";
                    }
                    foreach (var t in cloned.GetComponentsInChildren<TMP_Text>(true))
                    {
                        if (t == null) continue;
                        string curT = t.text?.Trim() ?? "";
                        t.text = string.Equals(curT, "CPU", StringComparison.OrdinalIgnoreCase) ? "" : def.Label;
                    }
                    ClonedHardwareBtns[def.Id] = cloned;
                }

                WireHardwareButton(cloned.gameObject, __instance, cloned, def.OnClick, visible);
                if (visible)
                {
                    if (!hasVlg)
                    {
                        var rt = cloned.GetComponent<RectTransform>();
                        var tRt = template.GetComponent<RectTransform>();
                        rt.anchorMin = tRt.anchorMin; rt.anchorMax = tRt.anchorMax; rt.pivot = tRt.pivot;
                        rt.sizeDelta = tRt.sizeDelta;
                        rt.anchoredPosition = new Vector2(tRt.anchoredPosition.x, baseY - idx * (tRt.sizeDelta.y + 8f));
                    }
                    else cloned.transform.SetAsLastSibling();
                    idx++;
                }
            }

            int winId = __instance.GetInstanceID();
            float desiredH = 46f * idx;
            ExpandedHwDeltas.TryGetValue(winId, out float appliedH);
            float delta = desiredH - appliedH;
            if (Mathf.Abs(delta) > 0.1f)
            {
                ExpandedHwDeltas[winId] = desiredH;
                var winRt = __instance.GetComponent<RectTransform>();
                if (winRt != null) winRt.sizeDelta += new Vector2(0f, delta);
                if (parent != __instance.transform && parent.GetComponent<RectTransform>() is RectTransform pRt &&
                    Mathf.Approximately(pRt.anchorMin.y, pRt.anchorMax.y))
                {
                    pRt.sizeDelta += new Vector2(0f, delta);
                }
            }

            if (parent is RectTransform parentRt) LayoutRebuilder.ForceRebuildLayoutImmediate(parentRt);
            if (__instance.GetComponent<RectTransform>() is RectTransform rootRt) LayoutRebuilder.ForceRebuildLayoutImmediate(rootRt);
        }

        private static void WireHardwareButton(GameObject targetGo, CreateHardwareWindow win, ButtonUI btnUi, Action onClick, bool visible)
        {
            if (targetGo == null) return;
            foreach (var cob in targetGo.GetComponentsInChildren<CreatorOpenButton>(true))
                if (cob != null) UnityEngine.Object.DestroyImmediate(cob);

            targetGo.SetActive(visible);
            if (btnUi != null)
            {
                btnUi.ResetOnClick();
                btnUi.Interactable = visible;
            }

            var ub = targetGo.GetComponent<Button>();
            if (ub != null)
            {
                ub.onClick = new Button.ButtonClickedEvent();
                ub.interactable = visible;
                if (visible)
                {
                    ub.onClick.AddListener(() =>
                    {
                        if (win != null) win.gameObject.SetActive(false);
                        onClick?.Invoke();
                    });
                }
            }
        }
    }
}
