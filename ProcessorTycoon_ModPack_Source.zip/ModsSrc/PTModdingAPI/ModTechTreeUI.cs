using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ResearchSystem;
using ProcessorTycoon.ResearchSystem.Math;
using ProcessorTycoon.TimeSystem;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModdingAPI
{
    internal static class ModTechTreeUI
    {
        private static readonly FieldInfo RtwCpuTabF = AccessTools.Field(typeof(ResearchTreeWindow), "cpuTab");
        private static readonly FieldInfo RtwCurrentResearchUiF = AccessTools.Field(typeof(ResearchTreeWindow), "currentResearchUI");

        private sealed class TabUiBinding
        {
            public ModTechTabDef Def;
            public Button TabButton;
            public Image TabBtnImg;
            public GameObject PanelGo;

            public TMP_Text ActiveTitleTxt, ActiveSpeedTxt, ActiveTimeTxt, ActiveCostTxt, ActiveEarlyTxt;
            public RectTransform ActiveProgFill;
            public Slider FundingSlider;
            public TMP_Text FundingValTxt;
            public Toggle InnovationToggle;
            public Button StopResearchBtn;

            public TMP_Text DetTitleTxt, DetBodyTxt;
            public Button DetResearchBtn;
            public Image DetResearchBtnImg;
            public TMP_Text DetResearchBtnTxt;
            public string SelectedNodeId;

            public readonly List<CardUiRef> Cards = new List<CardUiRef>();
        }

        private sealed class CardUiRef
        {
            public ModTechNodeDef Node;
            public Image BgImg;
            public Outline Outline;
            public TMP_Text YearTxt, NameTxt, TimeTxt, CostTxt;
            public RectTransform ProgFill;
        }

        private static readonly StringBuilder PrereqSb = new StringBuilder();
        private static ResearchTreeWindow _rtw;
        private static GameObject _cpuTab;
        private static Button _fallbackCpuBtn;
        private static string _activeTabId;
        private static readonly Dictionary<string, TabUiBinding> Bindings = new Dictionary<string, TabUiBinding>(StringComparer.OrdinalIgnoreCase);

        public static void ApplyPatches(Harmony harmony)
        {
            var rtwInit = AccessTools.Method(typeof(ResearchTreeWindow), "InitializeUI");
            if (rtwInit != null)
                harmony.Patch(rtwInit, postfix: new HarmonyMethod(typeof(ModTechTreeUI), nameof(ResearchTreeWindow_InitializeUI_Postfix)) { priority = Priority.Low });

            var rtwUpd = AccessTools.Method(typeof(ResearchTreeWindow), "UpdateButtonStates");
            if (rtwUpd != null)
                harmony.Patch(rtwUpd, postfix: new HarmonyMethod(typeof(ModTechTreeUI), nameof(ResearchTreeWindow_UpdateButtonStates_Postfix)) { priority = Priority.Low });

            var rtwForce = AccessTools.Method(typeof(ResearchTreeWindow), "ForceUIUpdate");
            if (rtwForce != null)
                harmony.Patch(rtwForce, postfix: new HarmonyMethod(typeof(ModTechTreeUI), nameof(ResearchTreeWindow_UpdateButtonStates_Postfix)) { priority = Priority.Low });
        }

        public static void ResetSessionState()
        {
            if (_rtw == null)
            {
                _activeTabId = null;
                _cpuTab = null;
                _fallbackCpuBtn = null;
                Bindings.Clear();
                return;
            }

            if (_cpuTab == null) _cpuTab = RtwCpuTabF?.GetValue(_rtw) as GameObject;
            SwitchToVanillaOrExternal();
            EnsureTabsBuilt();
        }

        private static bool EnsureWindowRefs()
        {
            if (_rtw == null)
                _rtw = UnityEngine.Object.FindFirstObjectByType<ResearchTreeWindow>(FindObjectsInactive.Include);
            if (_rtw != null && _cpuTab == null)
                _cpuTab = RtwCpuTabF?.GetValue(_rtw) as GameObject;
            return _rtw != null && _cpuTab != null;
        }

        private static void ResearchTreeWindow_InitializeUI_Postfix(ResearchTreeWindow __instance)
        {
            _rtw = __instance;
            _cpuTab = RtwCpuTabF?.GetValue(__instance) as GameObject;
            if (_cpuTab == null) return;
            EnsureTabsBuilt();
        }

        private static void ResearchTreeWindow_UpdateButtonStates_Postfix(ResearchTreeWindow __instance)
        {
            if (__instance != null) _rtw = __instance;
            if (!EnsureWindowRefs()) return;
            EnsureTabsBuilt();
            if (_cpuTab.activeSelf && !string.IsNullOrEmpty(_activeTabId))
                SwitchToVanillaOrExternal();
            LayoutTopTabButtons();
            RefreshIfOpen();
        }

        private static Transform HookExternalIsaBar()
        {
            if (_rtw == null) return null;
            var isaBar = _rtw.transform.Find("DynamicISA_ResearchTabBar");
            if (isaBar != null)
            {
                foreach (var b in isaBar.GetComponentsInChildren<Button>(true))
                {
                    if (b != null && b.gameObject.GetComponent<ModTabExternalHook>() == null)
                    {
                        b.gameObject.AddComponent<ModTabExternalHook>();
                        b.onClick.AddListener(SwitchToVanillaOrExternal);
                    }
                }
                if (_fallbackCpuBtn != null) _fallbackCpuBtn.gameObject.SetActive(false);
            }
            return isaBar;
        }

        private static void EnsureTabsBuilt()
        {
            if (_rtw == null || _cpuTab == null) return;
            var isaBar = HookExternalIsaBar();
            if (isaBar == null && _fallbackCpuBtn == null)
            {
                _fallbackCpuBtn = UiFactory.CreateButton("PTModTabBtn_CPU", _rtw.transform, "CPU Tech", UiFactory.AccentBlue, () =>
                {
                    SwitchToVanillaOrExternal();
                    if (_cpuTab != null) _cpuTab.SetActive(true);
                    RestoreVanillaCurrentResearchVisibility();
                }, 13f, FontStyles.Bold);
                var cRt = _fallbackCpuBtn.GetComponent<RectTransform>();
                cRt.anchorMin = cRt.anchorMax = cRt.pivot = new Vector2(0f, 1f);
                cRt.anchoredPosition = new Vector2(210f, -6f);
                cRt.sizeDelta = new Vector2(112f, 32f);
            }

            var tabs = ModTechRegistry.Tabs;
            for (int i = 0; i < tabs.Count; i++)
            {
                var def = tabs[i];
                bool enabled = def.IsModEnabled == null || def.IsModEnabled();
                if (!Bindings.TryGetValue(def.TabId, out var binding) || binding.PanelGo == null)
                {
                    binding = BuildTab(def);
                    Bindings[def.TabId] = binding;
                }
                if (binding.TabButton != null) binding.TabButton.gameObject.SetActive(enabled);
            }

            LayoutTopTabButtons();
        }

        private static void LayoutTopTabButtons()
        {
            if (_rtw == null) return;
            var isaBar = HookExternalIsaBar();
            float cursorRightX;
            const float topY = -6f;
            const float btnHeight = 32f;

            if (isaBar != null)
            {
                var isaRt = isaBar.GetComponent<RectTransform>();
                cursorRightX = isaRt.anchoredPosition.x + isaRt.sizeDelta.x + 8f;
            }
            else
            {
                if (_fallbackCpuBtn != null) _fallbackCpuBtn.gameObject.SetActive(true);
                cursorRightX = 330f;
            }

            var tabs = ModTechRegistry.Tabs;
            for (int i = 0; i < tabs.Count; i++)
            {
                var def = tabs[i];
                if (!Bindings.TryGetValue(def.TabId, out var binding) || binding.TabButton == null) continue;
                bool enabled = def.IsModEnabled == null || def.IsModEnabled();
                binding.TabButton.gameObject.SetActive(enabled);
                if (!enabled) continue;

                var brt = binding.TabButton.GetComponent<RectTransform>();
                brt.anchorMin = brt.anchorMax = brt.pivot = new Vector2(0f, 1f);
                float w = Mathf.Max(92f, def.TabTitle.Length * 9f + 26f);
                brt.sizeDelta = new Vector2(w, btnHeight);
                brt.anchoredPosition = new Vector2(cursorRightX, topY);
                cursorRightX += w + 8f;
            }
        }

        private static TabUiBinding BuildTab(ModTechTabDef def)
        {
            var oldBtn = _rtw.transform.Find($"PTModTabBtn_{def.TabId}");
            if (oldBtn != null) UnityEngine.Object.DestroyImmediate(oldBtn.gameObject);
            var oldPanel = _rtw.transform.Find($"PTModTabPanel_{def.TabId}");
            if (oldPanel != null) UnityEngine.Object.DestroyImmediate(oldPanel.gameObject);

            var binding = new TabUiBinding { Def = def };
            var tabBtn = UiFactory.CreateButton($"PTModTabBtn_{def.TabId}", _rtw.transform, def.TabTitle, UiFactory.CardBg,
                () => SelectModTab(def.TabId), 12.5f, FontStyles.Bold);
            binding.TabButton = tabBtn;
            binding.TabBtnImg = tabBtn.GetComponent<Image>();

            var panel = UiFactory.CreatePanel($"PTModTabPanel_{def.TabId}", _rtw.transform, new Color(0.115f, 0.125f, 0.142f, 0.99f), true);
            panel.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 4f, 4f, 4f, 42f);
            binding.PanelGo = panel;

            BuildTopStrip(def, panel.transform, binding);
            BuildTreeGrid(def, panel.transform, binding);
            BuildDetailPane(def, panel.transform, binding);

            binding.SelectedNodeId = def.Nodes.Count > 0 ? def.Nodes[0].Id : null;
            panel.SetActive(false);
            return binding;
        }

        private static void BuildTopStrip(ModTechTabDef def, Transform panelTransform, TabUiBinding binding)
        {
            var topStrip = UiFactory.CreatePanel("CurrentResearchStrip", panelTransform, UiFactory.HeaderBg, true, true);
            topStrip.GetComponent<RectTransform>().SetAnchorStretch(0.008f, 0.875f, 0.992f, 0.992f);

            var topProgBg = UiFactory.CreatePanel("TopProgBg", topStrip.transform, new Color(0.06f, 0.07f, 0.08f, 1f), false);
            topProgBg.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 0.07f);
            var topProgFill = UiFactory.CreatePanel("TopProgFill", topProgBg.transform, UiFactory.AccentGreen, false);
            topProgFill.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0f, 1f);
            binding.ActiveProgFill = topProgFill.GetComponent<RectTransform>();

            binding.ActiveTitleTxt = UiFactory.CreateText("ActTitle", topStrip.transform, $"{def.TabTitle} Lab Idle — Select a technology", 13.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary, FontStyles.Bold);
            binding.ActiveTitleTxt.GetComponent<RectTransform>().SetAnchorStretch(0.012f, 0.50f, 0.44f, 0.96f);

            binding.ActiveSpeedTxt = UiFactory.CreateText("ActSpd", topStrip.transform, "Speed: 100%", 11.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextMuted);
            binding.ActiveSpeedTxt.GetComponent<RectTransform>().SetAnchorStretch(0.012f, 0.08f, 0.17f, 0.48f);

            binding.ActiveTimeTxt = UiFactory.CreateText("ActTime", topStrip.transform, "Time: —", 11.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary);
            binding.ActiveTimeTxt.GetComponent<RectTransform>().SetAnchorStretch(0.17f, 0.08f, 0.31f, 0.48f);

            binding.ActiveCostTxt = UiFactory.CreateText("ActCost", topStrip.transform, "$0/m", 11.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextCostRed, FontStyles.Bold);
            binding.ActiveCostTxt.GetComponent<RectTransform>().SetAnchorStretch(0.31f, 0.08f, 0.44f, 0.48f);

            binding.ActiveEarlyTxt = UiFactory.CreateText("ActEarly", topStrip.transform, "", 11f, TextAlignmentOptions.MidlineLeft, UiFactory.AccentAmber);
            binding.ActiveEarlyTxt.GetComponent<RectTransform>().SetAnchorStretch(0.45f, 0.52f, 0.72f, 0.94f);

            binding.InnovationToggle = UiFactory.CreateCheckbox("InnovToggle", topStrip.transform, "Innovation Effort (+65% Spd, 2x Cost)", 11f, isOn =>
            {
                var st = ModTechRegistry.GetPlayerState(def.TabId);
                if (st == null) return;
                st.InnovationEffort = isOn;
                float newMax = isOn ? 300f : 200f;
                if (binding.FundingSlider != null)
                {
                    binding.FundingSlider.maxValue = newMax;
                    if (st.FundingPct > newMax) { st.FundingPct = newMax; binding.FundingSlider.SetValueWithoutNotify(newMax); }
                }
                RefreshBinding(binding);
            });
            binding.InnovationToggle.GetComponent<RectTransform>().SetAnchorStretch(0.45f, 0.10f, 0.72f, 0.48f);

            binding.FundingValTxt = UiFactory.CreateText("FundLbl", topStrip.transform, "Funding: 100%", 11.5f, TextAlignmentOptions.MidlineRight, UiFactory.TextPrimary, FontStyles.Bold);
            binding.FundingValTxt.GetComponent<RectTransform>().SetAnchorStretch(0.73f, 0.52f, 0.89f, 0.94f);

            binding.FundingSlider = UiFactory.CreateSlider("FundingSlider", topStrip.transform, 10f, 200f, 100f, val =>
            {
                var st = ModTechRegistry.GetPlayerState(def.TabId);
                if (st == null) return;
                st.FundingPct = Mathf.Round(val / 5f) * 5f;
                RefreshBinding(binding);
            });
            binding.FundingSlider.GetComponent<RectTransform>().SetAnchorStretch(0.73f, 0.12f, 0.89f, 0.48f);

            binding.StopResearchBtn = UiFactory.CreateButton("StopBtn", topStrip.transform, "Stop", UiFactory.AccentRed, () =>
            {
                var st = ModTechRegistry.GetPlayerState(def.TabId);
                if (st != null) st.ActiveNodeId = null;
                RefreshBinding(binding);
            }, 12f);
            binding.StopResearchBtn.GetComponent<RectTransform>().SetAnchorStretch(0.905f, 0.22f, 0.99f, 0.82f);
        }

        private static void BuildTreeGrid(ModTechTabDef def, Transform panelTransform, TabUiBinding binding)
        {
            var treeBg = UiFactory.CreatePanel("TreeScrollBg", panelTransform, new Color(0.095f, 0.105f, 0.12f, 1f), true, true);
            treeBg.GetComponent<RectTransform>().SetAnchorStretch(0.008f, 0.015f, 0.735f, 0.86f);
            var vp = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D), typeof(Image));
            vp.transform.SetParent(treeBg.transform, false);
            vp.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 4f, 14f, 4f, 4f);
            vp.GetComponent<Image>().color = new Color(0, 0, 0, 0.005f);

            const float colStep = 194f, rowStep = 120f, leftPad = 162f, cardW = 166f, cardH = 96f;
            int maxTier = 3;
            for (int i = 0; i < def.Nodes.Count; i++)
                if (def.Nodes[i].Tier > maxTier) maxTier = def.Nodes[i].Tier;

            float canvasW = Math.Max(760f, 170f + (maxTier + 1) * colStep);
            float canvasH = Math.Max(380f, def.Branches.Count * 122f + 44f);
            var canvasGo = new GameObject("TreeCanvas", typeof(RectTransform));
            canvasGo.transform.SetParent(vp.transform, false);
            var cRt = canvasGo.GetComponent<RectTransform>();
            cRt.anchorMin = cRt.anchorMax = cRt.pivot = new Vector2(0f, 1f);
            cRt.anchoredPosition = Vector2.zero;
            cRt.sizeDelta = new Vector2(canvasW, canvasH);

            var hSbBg = UiFactory.CreatePanel("HScrollbar", treeBg.transform, new Color(0.07f, 0.08f, 0.095f, 0.9f), true);
            var hSbRt = hSbBg.GetComponent<RectTransform>();
            hSbRt.anchorMin = new Vector2(0f, 0f); hSbRt.anchorMax = new Vector2(1f, 0f); hSbRt.pivot = new Vector2(0.5f, 0f);
            hSbRt.anchoredPosition = new Vector2(0f, 2f); hSbRt.sizeDelta = new Vector2(-12f, 8f);
            var hSlide = new GameObject("SlidingArea", typeof(RectTransform));
            hSlide.transform.SetParent(hSbBg.transform, false);
            hSlide.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            var hHandle = UiFactory.CreatePanel("Handle", hSlide.transform, new Color(0.42f, 0.46f, 0.54f, 1f), true);
            hHandle.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            var hSb = hSbBg.AddComponent<Scrollbar>();
            hSb.handleRect = hHandle.GetComponent<RectTransform>();
            hSb.targetGraphic = hHandle.GetComponent<Image>();
            hSb.direction = Scrollbar.Direction.LeftToRight;

            var sr = treeBg.AddComponent<ScrollRect>();
            sr.viewport = vp.GetComponent<RectTransform>();
            sr.content = cRt;
            sr.horizontal = true; sr.vertical = true;
            sr.scrollSensitivity = 30f;
            sr.movementType = ScrollRect.MovementType.Clamped;
            sr.horizontalScrollbar = hSb;
            sr.horizontalScrollbarVisibility = ScrollRect.ScrollbarVisibility.AutoHide;

            for (int bIdx = 0; bIdx < def.Branches.Count; bIdx++)
            {
                var br = def.Branches[bIdx];
                float rowY = -(24f + bIdx * rowStep);
                var lblPanel = UiFactory.CreatePanel($"Branch_{br.Id}", cRt, new Color(0.14f, 0.155f, 0.18f, 0.95f), false, true);
                var lrt = lblPanel.GetComponent<RectTransform>();
                lrt.anchorMin = lrt.anchorMax = lrt.pivot = new Vector2(0f, 1f);
                lrt.anchoredPosition = new Vector2(12f, rowY);
                lrt.sizeDelta = new Vector2(140f, cardH);

                UiFactory.CreatePanel("Stripe", lblPanel.transform, br.AccentColor, false)
                    .GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.06f, 1f);
                UiFactory.CreateText("BName", lblPanel.transform, br.Name, 12.5f, TextAlignmentOptions.Center, UiFactory.TextPrimary, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.10f, 0.05f, 0.94f, 0.95f);
            }

            var nodePositions = new Dictionary<string, Vector2>(def.Nodes.Count, StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < def.Nodes.Count; i++)
            {
                var n = def.Nodes[i];
                int bIdx = Math.Max(0, def.Branches.FindIndex(b => b.Id == n.Branch));
                nodePositions[n.Id] = new Vector2(leftPad + n.Tier * colStep, -(24f + bIdx * rowStep));
            }

            for (int i = 0; i < def.Nodes.Count; i++)
            {
                var n = def.Nodes[i];
                if (n.Prereqs == null || !nodePositions.TryGetValue(n.Id, out var toPos)) continue;
                for (int j = 0; j < n.Prereqs.Length; j++)
                {
                    if (!nodePositions.TryGetValue(n.Prereqs[j], out var fromPos)) continue;
                    CreateConnectorLine(cRt, new Vector2(fromPos.x + cardW, fromPos.y - cardH * 0.5f), new Vector2(toPos.x, toPos.y - cardH * 0.5f));
                }
            }

            for (int i = 0; i < def.Nodes.Count; i++)
            {
                var n = def.Nodes[i];
                var cardGo = UiFactory.CreatePanel($"Node_{n.Id}", cRt, UiFactory.CardBg, true);
                var rt = cardGo.GetComponent<RectTransform>();
                rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0f, 1f);
                rt.anchoredPosition = nodePositions[n.Id];
                rt.sizeDelta = new Vector2(cardW, cardH);

                var ol = cardGo.AddComponent<Outline>();
                ol.effectColor = UiFactory.BorderCol;
                ol.effectDistance = new Vector2(1.2f, -1.2f);

                var btn = cardGo.AddComponent<Button>();
                btn.targetGraphic = cardGo.GetComponent<Image>();
                btn.onClick.AddListener(() => { binding.SelectedNodeId = n.Id; RefreshBinding(binding); });

                var yrTxt = UiFactory.CreateText("Yr", cardGo.transform, $"{n.Year} · {n.ShortName}", 10.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextYellow, FontStyles.Bold);
                yrTxt.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.76f, 0.95f, 0.97f);

                var nameTxt = UiFactory.CreateText("Nm", cardGo.transform, n.Name, 11.2f, TextAlignmentOptions.TopLeft, UiFactory.TextPrimary, FontStyles.Bold);
                nameTxt.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.33f, 0.95f, 0.75f);
                nameTxt.overflowMode = TextOverflowModes.Ellipsis;
                nameTxt.maxVisibleLines = 2;

                var tmTxt = UiFactory.CreateText("Tm", cardGo.transform, "", 10.5f, TextAlignmentOptions.MidlineLeft, UiFactory.TextMuted);
                tmTxt.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.08f, 0.48f, 0.30f);

                var cstTxt = UiFactory.CreateText("Cs", cardGo.transform, "", 10.5f, TextAlignmentOptions.MidlineRight, UiFactory.TextCostRed, FontStyles.Bold);
                cstTxt.GetComponent<RectTransform>().SetAnchorStretch(0.46f, 0.08f, 0.95f, 0.30f);

                var pBg = UiFactory.CreatePanel("PBg", cardGo.transform, new Color(0.07f, 0.08f, 0.095f, 1f), false);
                pBg.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 0.06f);
                var pFill = UiFactory.CreatePanel("PFill", pBg.transform, UiFactory.AccentGreen, false);
                pFill.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0f, 1f);

                binding.Cards.Add(new CardUiRef
                {
                    Node = n, BgImg = cardGo.GetComponent<Image>(), Outline = ol,
                    YearTxt = yrTxt, NameTxt = nameTxt, TimeTxt = tmTxt, CostTxt = cstTxt,
                    ProgFill = pFill.GetComponent<RectTransform>()
                });
            }
        }

        private static void BuildDetailPane(ModTechTabDef def, Transform panelTransform, TabUiBinding binding)
        {
            var detPanel = UiFactory.CreatePanel("DetailsPane", panelTransform, UiFactory.PanelBg, true, true);
            detPanel.GetComponent<RectTransform>().SetAnchorStretch(0.744f, 0.015f, 0.992f, 0.86f);

            binding.DetTitleTxt = UiFactory.CreateText("DetTitle", detPanel.transform, def.TabTitle, 15f, TextAlignmentOptions.TopLeft, UiFactory.TextPrimary, FontStyles.Bold);
            binding.DetTitleTxt.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.85f, 0.95f, 0.97f);

            binding.DetBodyTxt = UiFactory.CreateText("DetBody", detPanel.transform, def.Subtitle, 12f, TextAlignmentOptions.TopLeft, UiFactory.TextMuted);
            binding.DetBodyTxt.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.24f, 0.95f, 0.84f);

            if (!string.IsNullOrEmpty(def.ActionButtonLabel) && def.OnActionButtonClick != null)
            {
                var actBtn = UiFactory.CreateButton("ActionBtn", detPanel.transform, def.ActionButtonLabel, UiFactory.AccentBlue, () => def.OnActionButtonClick(), 12.5f);
                actBtn.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.135f, 0.95f, 0.22f);
            }

            binding.DetResearchBtn = UiFactory.CreateButton("StartResBtn", detPanel.transform, "Start Research", UiFactory.AccentGreen, () =>
            {
                var st = ModTechRegistry.GetPlayerState(def.TabId);
                var node = ModTechRegistry.FindNode(def.TabId, binding.SelectedNodeId);
                if (st == null || node == null) return;
                if (st.IsUnlocked(node.Id) || !ModTechRegistry.ArePrereqsMet(def, st, node)) return;
                st.ActiveNodeId = (st.ActiveNodeId == node.Id) ? null : node.Id;
                RefreshBinding(binding);
            }, 13f);
            binding.DetResearchBtn.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.025f, 0.95f, 0.115f);
            binding.DetResearchBtnImg = binding.DetResearchBtn.GetComponent<Image>();
            binding.DetResearchBtnTxt = binding.DetResearchBtn.GetComponentInChildren<TMP_Text>();
        }

        private static void CreateConnectorLine(RectTransform parent, Vector2 a, Vector2 b)
        {
            var diff = b - a;
            float dist = diff.magnitude;
            if (dist < 1f) return;
            var lineGo = UiFactory.CreatePanel("DepLine", parent, new Color(0.32f, 0.36f, 0.43f, 0.85f), false);
            lineGo.transform.SetAsFirstSibling();
            var rt = lineGo.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 0.5f);
            rt.anchoredPosition = a;
            rt.sizeDelta = new Vector2(dist, 2.5f);
            rt.localRotation = Quaternion.Euler(0f, 0f, Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg);
        }

        private static void SelectModTab(string tabId)
        {
            if (!EnsureWindowRefs()) return;
            EnsureTabsBuilt();
            _cpuTab.SetActive(false);

            var isaPanel = _rtw.transform.Find("DynamicISA_IsaTabPanel");
            if (isaPanel != null) isaPanel.gameObject.SetActive(false);

            var curUi = RtwCurrentResearchUiF?.GetValue(_rtw) as CurrentResearchUI;
            var cg = curUi != null ? curUi.GetComponent<CanvasGroup>() : null;
            if (cg != null) { cg.alpha = 0f; cg.blocksRaycasts = false; }

            var isaBar = _rtw.transform.Find("DynamicISA_ResearchTabBar");
            if (isaBar != null)
                foreach (var b in isaBar.GetComponentsInChildren<Button>(true))
                    if (b?.GetComponent<Image>() is Image bi) bi.color = UiFactory.CardBg;

            if (_fallbackCpuBtn != null && _fallbackCpuBtn.GetComponent<Image>() is Image fci)
                fci.color = UiFactory.CardBg;

            _activeTabId = tabId;
            TabUiBinding activeBinding = null;
            foreach (var kv in Bindings)
            {
                bool active = string.Equals(kv.Key, tabId, StringComparison.OrdinalIgnoreCase);
                if (kv.Value.PanelGo != null) kv.Value.PanelGo.SetActive(active);
                if (kv.Value.TabBtnImg != null) kv.Value.TabBtnImg.color = active ? UiFactory.AccentBlue : UiFactory.CardBg;
                if (active) activeBinding = kv.Value;
            }

            if (activeBinding?.PanelGo != null)
            {
                activeBinding.PanelGo.transform.SetAsLastSibling();
                RefreshBinding(activeBinding);
            }

            if (isaBar != null) isaBar.SetAsLastSibling();
            if (_fallbackCpuBtn != null) _fallbackCpuBtn.transform.SetAsLastSibling();
            foreach (var kv in Bindings)
                if (kv.Value.TabButton != null) kv.Value.TabButton.transform.SetAsLastSibling();
        }

        private static void SwitchToVanillaOrExternal()
        {
            _activeTabId = null;
            foreach (var kv in Bindings)
            {
                if (kv.Value.PanelGo != null) kv.Value.PanelGo.SetActive(false);
                if (kv.Value.TabBtnImg != null) kv.Value.TabBtnImg.color = UiFactory.CardBg;
            }
            if (_fallbackCpuBtn != null && _fallbackCpuBtn.GetComponent<Image>() is Image fci)
                fci.color = UiFactory.AccentBlue;
            RestoreVanillaCurrentResearchVisibility();
        }

        private static void RestoreVanillaCurrentResearchVisibility()
        {
            if (_rtw == null || _cpuTab == null || !_cpuTab.activeSelf) return;
            var curUi = RtwCurrentResearchUiF?.GetValue(_rtw) as CurrentResearchUI;
            var cg = curUi != null ? curUi.GetComponent<CanvasGroup>() : null;
            if (cg != null)
            {
                bool hasRes = Player.Instance?.Company?.ResearchSector?.CurrentResearch() != null;
                cg.alpha = hasRes ? 1f : 0f;
                cg.blocksRaycasts = hasRes;
            }
        }

        public static void OpenTab(string tabId)
        {
            if (!EnsureWindowRefs()) return;
            if (!_rtw.gameObject.activeInHierarchy) _rtw.gameObject.SetActive(true);
            _rtw.transform.SetAsLastSibling();
            EnsureTabsBuilt();
            SelectModTab(tabId);
        }

        public static void RefreshIfOpen()
        {
            if (_rtw == null || !_rtw.gameObject.activeInHierarchy || string.IsNullOrEmpty(_activeTabId)) return;
            if (Bindings.TryGetValue(_activeTabId, out var b) && b.PanelGo != null && b.PanelGo.activeInHierarchy)
                RefreshBinding(b);
        }

        private static void RefreshBinding(TabUiBinding binding)
        {
            var comp = Player.Instance?.Company;
            if (comp == null) return;
            var st = ModTechRegistry.GetState(binding.Def.TabId, comp);
            int year = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;

            if (binding.InnovationToggle != null) binding.InnovationToggle.SetIsOnWithoutNotify(st.InnovationEffort);
            float maxFund = st.InnovationEffort ? 300f : 200f;
            if (binding.FundingSlider != null)
            {
                binding.FundingSlider.maxValue = maxFund;
                binding.FundingSlider.SetValueWithoutNotify(Mathf.Clamp(st.FundingPct, 10f, maxFund));
            }
            binding.FundingValTxt.text = $"Funding: {st.FundingPct:0}%";

            var actNode = ModTechRegistry.FindNode(binding.Def.TabId, st.ActiveNodeId);
            if (actNode != null)
            {
                float spd = ModTechRegistry.EffectiveSpeed(binding.Def, actNode, st, comp, year);
                int daysLeft = ModTechRegistry.EstimateDaysLeft(binding.Def, actNode, st, comp, year);
                float mCost = ModTechRegistry.EstimateMonthlyCost(actNode, st);
                int yrsEarly = Math.Max(0, actNode.Year - year);

                binding.ActiveTitleTxt.text = $"Researching: {actNode.Name} ({actNode.Year})";
                binding.ActiveSpeedTxt.text = $"Speed: {spd * 100f:0}%";
                binding.ActiveTimeTxt.text = $"Left: {daysLeft}d";
                binding.ActiveCostTxt.text = $"-{UiFactory.FormatMoneyCompact(mCost)}/m";
                binding.ActiveEarlyTxt.text = yrsEarly > 0 ? $"Early ({yrsEarly}yr ahead: /{Mathf.Pow(1.85f, yrsEarly):0.#} speed)" : "";
                binding.ActiveProgFill.SetAnchorStretch(0f, 0f, Mathf.Clamp01(st.GetProgress(actNode.Id)), 1f);
                binding.StopResearchBtn.interactable = true;
            }
            else
            {
                binding.ActiveTitleTxt.text = $"{binding.Def.TabTitle} Lab Idle — Select a node below";
                float baseSpd = ResearchMath.ResearchSpeed(Mathf.Max(0.1f, st.FundingPct / 100f), comp) * 100f;
                binding.ActiveSpeedTxt.text = $"Lab Speed: {baseSpd:0}%";
                binding.ActiveTimeTxt.text = "Left: —";
                binding.ActiveCostTxt.text = "$0/m";
                binding.ActiveEarlyTxt.text = "";
                binding.ActiveProgFill.SetAnchorStretch(0f, 0f, 0f, 1f);
                binding.StopResearchBtn.interactable = false;
            }

            for (int i = 0; i < binding.Cards.Count; i++)
            {
                var c = binding.Cards[i];
                var n = c.Node;
                bool unlocked = st.IsUnlocked(n.Id);
                bool active = st.ActiveNodeId == n.Id;
                bool avail = !unlocked && ModTechRegistry.ArePrereqsMet(binding.Def, st, n);
                bool selected = binding.SelectedNodeId == n.Id;
                float prog = unlocked ? 1f : st.GetProgress(n.Id);

                c.BgImg.color = unlocked ? UiFactory.CardCompletedBg : (active ? UiFactory.CardActiveBg : (avail ? UiFactory.CardBg : UiFactory.CardAltBg));
                c.Outline.effectColor = active ? UiFactory.TextYellow : (selected ? UiFactory.AccentBlue : UiFactory.BorderCol);
                c.YearTxt.color = unlocked ? UiFactory.AccentGreen : (avail ? UiFactory.TextYellow : UiFactory.TextMuted);
                c.NameTxt.color = unlocked || avail ? UiFactory.TextPrimary : UiFactory.TextMuted;
                c.ProgFill.SetAnchorStretch(0f, 0f, Mathf.Clamp01(prog), 1f);

                if (unlocked) { c.TimeTxt.text = "UNLOCKED"; c.TimeTxt.color = UiFactory.AccentGreen; c.CostTxt.text = ""; }
                else if (!avail) { c.TimeTxt.text = "LOCKED (Prereq)"; c.TimeTxt.color = UiFactory.TextMuted; c.CostTxt.text = ""; }
                else
                {
                    int d = ModTechRegistry.EstimateDaysLeft(binding.Def, n, st, comp, year);
                    float mc = ModTechRegistry.EstimateMonthlyCost(n, st);
                    int yrsEarly = Math.Max(0, n.Year - year);
                    c.TimeTxt.text = yrsEarly > 0 ? $"~{d}d (!)" : $"~{d}d";
                    c.TimeTxt.color = yrsEarly > 0 ? UiFactory.AccentAmber : UiFactory.TextPrimary;
                    c.CostTxt.text = $"-{UiFactory.FormatMoneyCompact(mc)}/m";
                }
            }

            var sel = ModTechRegistry.FindNode(binding.Def.TabId, binding.SelectedNodeId) ?? (binding.Def.Nodes.Count > 0 ? binding.Def.Nodes[0] : null);
            if (sel != null)
            {
                bool unlocked = st.IsUnlocked(sel.Id);
                bool active = st.ActiveNodeId == sel.Id;
                bool avail = !unlocked && ModTechRegistry.ArePrereqsMet(binding.Def, st, sel);
                int days = ModTechRegistry.EstimateDaysLeft(binding.Def, sel, st, comp, year);
                float mc = ModTechRegistry.EstimateMonthlyCost(sel, st);
                int yrsEarly = Math.Max(0, sel.Year - year);

                string prereqStr = "None";
                if (sel.Prereqs != null && sel.Prereqs.Length > 0)
                {
                    PrereqSb.Clear();
                    for (int i = 0; i < sel.Prereqs.Length; i++)
                    {
                        if (i > 0) PrereqSb.Append(", ");
                        var pn = ModTechRegistry.FindNode(binding.Def.TabId, sel.Prereqs[i]);
                        bool ok = st.IsUnlocked(sel.Prereqs[i]);
                        PrereqSb.Append(ok ? "<color=#63DE91>" : "<color=#E66C6C>")
                                .Append(pn?.Name ?? sel.Prereqs[i])
                                .Append("</color>");
                    }
                    prereqStr = PrereqSb.ToString();
                }

                string branchName = "General";
                for (int i = 0; i < binding.Def.Branches.Count; i++)
                    if (binding.Def.Branches[i].Id == sel.Branch) { branchName = binding.Def.Branches[i].Name; break; }

                binding.DetTitleTxt.text = $"{sel.Name} ({sel.Year})";
                binding.DetBodyTxt.text =
                    $"{sel.Description}\n\n" +
                    $"<b>Branch:</b> {branchName}\n" +
                    $"<b>Prerequisites:</b> {prereqStr}\n" +
                    (unlocked
                        ? "<b>Status:</b> <color=#63DE91>Unlocked</color>\n\n"
                        : $"<b>Est. Time:</b> ~{days} days {(yrsEarly > 0 ? $"<color=#EBB44D>({yrsEarly}y ahead penalty)</color>" : "")}\n" +
                          $"<b>Monthly Cost:</b> <color=#F06666>-{UiFactory.FormatMoneyCompact(mc)}/m</color>\n\n") +
                    $"<b>Unlocks / Effects:</b>\n{sel.EffectsSummary}";

                if (unlocked) { binding.DetResearchBtn.interactable = false; binding.DetResearchBtnImg.color = UiFactory.CardCompletedBg; binding.DetResearchBtnTxt.text = "Already Researched"; }
                else if (active) { binding.DetResearchBtn.interactable = true; binding.DetResearchBtnImg.color = UiFactory.AccentRed; binding.DetResearchBtnTxt.text = "Pause Research"; }
                else if (!avail) { binding.DetResearchBtn.interactable = false; binding.DetResearchBtnImg.color = UiFactory.CardAltBg; binding.DetResearchBtnTxt.text = "Requires Prerequisites"; }
                else { binding.DetResearchBtn.interactable = true; binding.DetResearchBtnImg.color = UiFactory.AccentGreen; binding.DetResearchBtnTxt.text = "Start Research"; }
            }
        }
    }

    internal sealed class ModTabExternalHook : MonoBehaviour { }
}
