using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace PTModdingAPI
{
    internal static class SidecarSaveManager
    {
        private sealed class SaveParticipant
        {
            public string ModId;
            public Func<string> Serialize;
            public Action<string> Deserialize;
            public Action Clear;
        }

        private static readonly List<SaveParticipant> Participants = new List<SaveParticipant>();
        private static string SaveDir => Path.Combine(Application.persistentDataPath, "PTModAPI_Saves");

        public static void Register(string modId, Func<string> serialize, Action<string> deserialize, Action clear = null)
        {
            if (string.IsNullOrWhiteSpace(modId)) return;
            Participants.RemoveAll(s => string.Equals(s.ModId, modId, StringComparison.OrdinalIgnoreCase));
            Participants.Add(new SaveParticipant { ModId = modId, Serialize = serialize, Deserialize = deserialize, Clear = clear });
        }

        public static string Sanitize(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "DefaultSave";
            var sb = new StringBuilder(s.Length);
            foreach (char c in s) sb.Append(char.IsLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
            return sb.ToString();
        }

        private static string NormalizeSavePrefix(string rawName)
        {
            string name = (rawName ?? "").Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                if (DateController.Instance != null)
                {
                    var d = DateController.Instance.CurrentDate;
                    name = $"{d.Year}_{d.Month}_{d.Day}";
                }
                else name = "DefaultSave";
            }
            name = Path.GetFileName(name);
            if (name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                name = name.Substring(0, name.Length - 4);
            else if (name.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                name = name.Substring(0, name.Length - 5);
            return Sanitize(name);
        }

        public static void ClearAllSidecars()
        {
            TimedProjectEngine.CancelAll();
            ModTechRegistry.ClearAllState();
            ModTechTreeUI.ResetSessionState();
            CreatorUiBridge.ResetSessionState();
            HardwareMenuInjector.ResetSessionState();
            FabProductionPatches.ResetUiCache();
            StudioWindowShell.CloseAllWindows();

            for (int i = 0; i < Participants.Count; i++)
            {
                try { Participants[i].Clear?.Invoke(); } catch { }
            }
        }

        public static void SaveAllSidecars(string saveName)
        {
            try
            {
                Directory.CreateDirectory(SaveDir);
                string prefix = NormalizeSavePrefix(saveName);
                for (int i = 0; i < Participants.Count; i++)
                {
                    var sp = Participants[i];
                    string data = sp.Serialize?.Invoke() ?? "";
                    File.WriteAllText(Path.Combine(SaveDir, $"{prefix}__{Sanitize(sp.ModId)}.txt"), data, Encoding.UTF8);
                }
                PTModdingApiPlugin.Log?.LogInfo($"Saved {Participants.Count} mod sidecars for '{prefix}'.");
            }
            catch (Exception ex) { PTModdingApiPlugin.Log?.LogWarning($"SaveAllSidecars failed: {ex.Message}"); }
        }

        public static void LoadAllSidecars(string saveName)
        {
            try
            {
                string prefix = NormalizeSavePrefix(saveName);
                int foundCount = 0;
                for (int i = 0; i < Participants.Count; i++)
                {
                    var sp = Participants[i];
                    string p = Path.Combine(SaveDir, $"{prefix}__{Sanitize(sp.ModId)}.txt");
                    bool exists = File.Exists(p);
                    if (exists) foundCount++;
                    string data = exists ? File.ReadAllText(p, Encoding.UTF8) : "";
                    try { sp.Deserialize?.Invoke(data); }
                    catch (Exception iex) { PTModdingApiPlugin.Log?.LogWarning($"Deserialize {sp.ModId} failed: {iex.Message}"); }
                }
                PTModdingApiPlugin.Log?.LogInfo($"Loaded {foundCount}/{Participants.Count} mod sidecars for '{prefix}'.");
            }
            catch (Exception ex) { PTModdingApiPlugin.Log?.LogWarning($"LoadAllSidecars failed: {ex.Message}"); }
            FabProductionPatches.ResetUiCache();
            CreatorUiBridge.MarkDirty();
        }
    }
}
