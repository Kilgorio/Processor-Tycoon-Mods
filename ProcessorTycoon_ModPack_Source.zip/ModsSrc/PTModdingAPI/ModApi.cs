using System;
using HarmonyLib;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;

namespace PTModdingAPI
{
    public static class ModApi
    {
        public static IPackage CurrentCreatorPackage => CreatorUiBridge.CurrentCreatorPackage;

        internal static void ApplyPatches(Harmony harmony)
        {
            HardwarePhysicsPatches.ApplyPatches(harmony);
            CreatorUiBridge.ApplyPatches(harmony);
            HardwareMenuInjector.ApplyPatches(harmony);
            FabProductionPatches.ApplyPatches(harmony);
            TimedProjectEngine.ApplyPatches(harmony);
            ModTechTreeUI.ApplyPatches(harmony);
        }

        // ==================== Registration APIs for Discrete Mods ====================

        public static void RegisterSaveParticipant(string modId, Func<string> serialize, Action<string> deserialize, Action clear = null) =>
            SidecarSaveManager.Register(modId, serialize, deserialize, clear);

        public static void RegisterCreatorCpuSlot(CreatorCpuSlotDef def)
        {
            if (def == null || string.IsNullOrWhiteSpace(def.SlotId)) return;
            CreatorUiBridge.CreatorSlots.RemoveAll(s => string.Equals(s.SlotId, def.SlotId, StringComparison.OrdinalIgnoreCase));
            CreatorUiBridge.CreatorSlots.Add(def);
        }

        public static void RegisterCreatorSocketSlot(CreatorCpuSlotDef def)
        {
            if (def == null || string.IsNullOrWhiteSpace(def.SlotId)) return;
            CreatorUiBridge.SocketSlots.RemoveAll(s => string.Equals(s.SlotId, def.SlotId, StringComparison.OrdinalIgnoreCase));
            CreatorUiBridge.SocketSlots.Add(def);
        }

        public static void RegisterHardwareMenuAction(HardwareMenuButtonDef def)
        {
            if (def == null || string.IsNullOrWhiteSpace(def.Id)) return;
            HardwareMenuInjector.MenuButtons.RemoveAll(b => string.Equals(b.Id, def.Id, StringComparison.OrdinalIgnoreCase));
            HardwareMenuInjector.MenuButtons.Add(def);
        }

        public static void RegisterPackageThermalEfficiencyModifier(Func<IPackage, float, float> fn) { if (fn != null) HardwarePhysicsPatches.ThermalEffMods.Add(fn); }
        public static void RegisterPackageSafeTemperatureModifier(Func<IPackage, float, float> fn) { if (fn != null) HardwarePhysicsPatches.SafeTempMods.Add(fn); }
        public static void RegisterPackageConsumptionModifier(Func<IPackage, float, float> fn) { if (fn != null) HardwarePhysicsPatches.PkgConsumptionMods.Add(fn); }
        public static void RegisterCpuStatModifier(Action<CpuPhysicsContext, CpuPhysicsMods> fn) { if (fn != null) HardwarePhysicsPatches.CpuStatMods.Add(fn); }
        public static void RegisterMaterialCostAdder(Func<IPackage, float, float> fn) { if (fn != null) HardwarePhysicsPatches.MaterialCostAdders.Add(fn); }
        public static void RegisterCpuMaterialCostAdder(Func<Cpu, IPackage, float, float> fn) { if (fn != null) HardwarePhysicsPatches.CpuMaterialCostAdders.Add(fn); }
        public static void RegisterCpuStartedListener(Action<Cpu> fn) { if (fn != null) HardwarePhysicsPatches.CpuStartedListeners.Add(fn); }
        public static void RegisterCpuCompletedListener(Action<Cpu> fn) { if (fn != null) HardwarePhysicsPatches.CpuCompletedListeners.Add(fn); }
        public static void RegisterSocketCreatedListener(Action<CustomHardware> fn) { if (fn != null) HardwarePhysicsPatches.SocketCreatedListeners.Add(fn); }
        public static void RegisterCreatorPackageChangedListener(Action<IPackage> fn) { if (fn != null) CreatorUiBridge.CreatorPackageChangedListeners.Add(fn); }
        public static void RegisterFabModifier(Action<ICompany, int, FabMods> fn) { if (fn != null) FabProductionPatches.FabModsList.Add(fn); }
        public static void RegisterContractPowerModifier(Func<Contract, Cpu, float, float> fn) { if (fn != null) HardwarePhysicsPatches.ContractPowerMultipliers.Add(fn); }

        public static void MarkCreatorSlotsDirty() => CreatorUiBridge.MarkDirty();
        public static void RefreshCreatorCpu() => CreatorUiBridge.RefreshCreatorCpu();
        public static void RefreshCreatorSocket() => CreatorUiBridge.RefreshCreatorSocket();
        public static void OpenResearchTab(string tabId) => ModTechTreeUI.OpenTab(tabId);

        public static ActiveModProjectHandle StartTimedProject(string projectId, string title, string subtitle, int days, float totalCost,
            Action onComplete, float initialProgress = 0f) =>
            TimedProjectEngine.StartTimedProject(projectId, title, subtitle, days, totalCost, onComplete, initialProgress);

        public static void CancelTimedProject(string projectId) => TimedProjectEngine.CancelTimedProject(projectId);
        public static ActiveModProjectHandle GetActiveProject(string projectId) => TimedProjectEngine.GetActiveProject(projectId);

        public static void ClearAllSidecars() => SidecarSaveManager.ClearAllSidecars();
        public static void SaveAllSidecars(string saveName) => SidecarSaveManager.SaveAllSidecars(saveName);
        public static void LoadAllSidecars(string saveName) => SidecarSaveManager.LoadAllSidecars(saveName);
    }
}
