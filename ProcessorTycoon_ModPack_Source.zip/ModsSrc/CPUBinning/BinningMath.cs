using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using ProcessorTycoon;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Production.Math;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace CPUBinning
{
    public static class BinningMath
    {
        private static readonly Dictionary<int, float> FractionalConsumedAccumulator = new Dictionary<int, float>();
        private static readonly Dictionary<int, int> HighBinStockPools = new Dictionary<int, int>();
        private static readonly Dictionary<int, (int dayKey, int demand)> ContractDemandCache = new Dictionary<int, (int, int)>();

        private static string HighBinStorageFile
        {
            get
            {
                string cfg = Paths.ConfigPath;
                if (string.IsNullOrEmpty(cfg))
                {
                    string root = Paths.BepInExRootPath;
                    cfg = !string.IsNullOrEmpty(root) ? Path.Combine(root, "config") : Application.persistentDataPath;
                }
                return Path.Combine(cfg, "CPUBinning_HighBinPools.txt");
            }
        }

        public static void ClearRuntimeState()
        {
            FractionalConsumedAccumulator.Clear();
            HighBinStockPools.Clear();
            ContractDemandCache.Clear();
        }

        public static bool IsHighBin(Cpu cpu) =>
            cpu != null && cpu.Base != null && cpu.Base != cpu && cpu.Frequency > cpu.Base.Frequency * 1.001f;

        public static float CalculateBinningYield(Cpu baseCpu, int enabledCores, float freqKhz, int totalL1Units, int totalL2Units, int totalL3Units, bool smtEnabled)
        {
            if (baseCpu == null) return 0f;

            int pCores = Math.Max(1, baseCpu.CoreCount);
            int vCores = Math.Max(1, enabledCores);
            float coreCut = pCores > 1 ? Mathf.Clamp01((float)(pCores - vCores) / pCores) : 0f;

            float rawFreqCut = baseCpu.Frequency > 1f ? Mathf.Clamp01((baseCpu.Frequency - freqKhz) / baseCpu.Frequency) : 0f;
            float freqCut = rawFreqCut >= 0.002f ? rawFreqCut : 0f;

            int pL1PerCore = baseCpu.L1Cache / pCores, pL2PerCore = baseCpu.L2Cache / pCores;
            float l1Cut = pL1PerCore > 0 ? Mathf.Clamp01((float)(pL1PerCore - totalL1Units / vCores) / pL1PerCore) : 0f;
            float l2Cut = pL2PerCore > 0 ? Mathf.Clamp01((float)(pL2PerCore - totalL2Units / vCores) / pL2PerCore) : 0f;
            float l3Cut = baseCpu.L3Cache > 0 ? Mathf.Clamp01((float)(baseCpu.L3Cache - totalL3Units) / baseCpu.L3Cache) : 0f;
            float smtCut = (baseCpu.Smt && !smtEnabled) ? 1f : 0f;

            if (coreCut <= 0f && freqCut <= 0f && l1Cut <= 0f && l2Cut <= 0f && l3Cut <= 0f && smtCut <= 0f) return 0f;

            bool hasL3 = baseCpu.L3Cache > 0;
            float yield = pCores > 1
                ? coreCut * 0.60f + (hasL3 ? l3Cut * 0.42f : 0f) + (pL2PerCore > 0 ? l2Cut * (hasL3 ? 0.16f : 0.35f) : 0f) +
                  (pL1PerCore > 0 ? l1Cut * 0.12f : 0f) + freqCut * (hasL3 ? 0.45f : 0.65f) + smtCut * 0.08f
                : freqCut * 0.80f + (pL2PerCore > 0 ? l2Cut * 0.35f : 0f) + (pL1PerCore > 0 ? l1Cut * 0.30f : 0f) +
                  (hasL3 ? l3Cut * 0.25f : 0f) + smtCut * 0.10f;

            float recoveryScale = BinningPlugin.LowBinYieldRecoveryScale?.Value ?? 1f;
            return Mathf.Clamp(yield * recoveryScale, 0.01f, 0.90f);
        }

        public static float GetHighBinMaxFreqMultiplier() =>
            1f + 0.25f * (BinningPlugin.HighBinBonusScale?.Value ?? 1f);

        public static float CalculateHighBinYield(Cpu baseCpu, float freqKhz)
        {
            if (baseCpu == null || baseCpu.Frequency <= 1f) return 0f;
            float boostRatio = (freqKhz - baseCpu.Frequency) / baseCpu.Frequency;
            float bonusScale = Mathf.Max(0.25f, BinningPlugin.HighBinBonusScale?.Value ?? 1f);
            return boostRatio < 0.002f ? 0f : Mathf.Clamp(0.55f * Mathf.Exp(-9.0f * (boostRatio / bonusScale)), 0.01f, 0.60f);
        }

        public static float CalculateVariantAssemblyCost(Cpu baseCpu, IPackage package, Memory memory, ProcessNode processNode, int l1Cache, int l2Cache, int l3Cache)
        {
            if (package == null) return 10f;
            float cacheMat = (memory != null && processNode != null && processNode.CacheCostReduction > 0f)
                ? ((l1Cache * 2.35f + l2Cache / 1.25f + l3Cache) * memory.UnitCostPerCache / processNode.CacheCostReduction * 0.20f) : 0f;
            float cost = package.BaseUnitCost * 0.65f + cacheMat;
            if (baseCpu != null && baseCpu.UnitCost > 0f) cost = Mathf.Clamp(cost, 1f, Mathf.Max(2f, baseCpu.UnitCost * 0.75f));
            return Mathf.Max(1f, Mathf.Round(cost));
        }

        public static float CalculateHighBinValidationFee(IPackage package, Cpu baseCpu)
        {
            float fee = (package != null ? package.BaseUnitCost : 15f) * 0.20f + 5f;
            if (baseCpu != null && baseCpu.UnitCost > 0f) fee = Mathf.Clamp(fee, 2f, Mathf.Max(4f, baseCpu.UnitCost * 0.25f));
            return Mathf.Max(1f, Mathf.Round(fee));
        }

        public static float CalculateHighBinDisplayUnitCost(Cpu baseCpu, IPackage package)
        {
            if (baseCpu == null) return 20f;
            float baseReal = (baseCpu.Base == null || baseCpu.Base == baseCpu) ? baseCpu.RealUnitCost : baseCpu.UnitCost;
            return baseReal + CalculateHighBinValidationFee(package, baseCpu);
        }

        public static float GetVariantBaseUnitCost(Cpu cpu) =>
            IsHighBin(cpu)
                ? CalculateHighBinDisplayUnitCost(cpu.Base, cpu.Package)
                : CalculateVariantAssemblyCost(cpu.Base, cpu.Package, cpu.Memory, cpu.ProcessNode, cpu.L1Cache, cpu.L2Cache, cpu.L3Cache);

        public static int GetVariantAvailableUnits(Cpu variant)
        {
            if (variant?.Base == null) return 0;
            if (IsHighBin(variant)) return GetHighBinPool(variant);
            float yield = Mathf.Clamp01(1f - variant.FailureRate);
            return (yield <= 0f || variant.Base.FailedStock <= 0) ? 0 : Mathf.FloorToInt(variant.Base.FailedStock * yield);
        }

        public static int GetHighBinPool(Cpu variant) =>
            variant != null && HighBinStockPools.TryGetValue(variant.SaveID, out int pool) ? Mathf.Max(0, pool) : 0;

        public static void InitializeHighBinOnRelease(Cpu variant)
        {
            if (variant?.Base == null || !IsHighBin(variant) || HighBinStockPools.ContainsKey(variant.SaveID)) return;
            int initialPull = Mathf.Clamp(Mathf.FloorToInt(variant.Base.Market.Stock * Mathf.Clamp01(1f - variant.FailureRate)), 0, variant.Base.Market.Stock);
            variant.Base.Market.Stock -= initialPull;
            HighBinStockPools[variant.SaveID] = initialPull;
        }

        public static void AddHighBinPool(Cpu variant, int amount)
        {
            if (variant == null || amount <= 0) return;
            HighBinStockPools.TryGetValue(variant.SaveID, out int cur);
            HighBinStockPools[variant.SaveID] = Mathf.Min(2000000000, cur + amount);
        }

        public static int ConsumeVariantStock(Cpu variant, int demand)
        {
            if (variant?.Base == null || demand <= 0) return 0;
            if (IsHighBin(variant))
            {
                HighBinStockPools.TryGetValue(variant.SaveID, out int pool);
                int deliveredHigh = Mathf.Clamp(demand, 0, pool);
                if (deliveredHigh > 0) HighBinStockPools[variant.SaveID] = pool - deliveredHigh;
                return deliveredHigh;
            }

            float yield = Mathf.Clamp(1f - variant.FailureRate, 0.01f, 1f);
            int delivered = Mathf.Clamp(demand, 0, Mathf.FloorToInt(variant.Base.FailedStock * yield));
            if (delivered <= 0) return 0;

            FractionalConsumedAccumulator.TryGetValue(variant.SaveID, out float acc);
            acc += delivered / yield;
            int intToDeduct = Mathf.FloorToInt(acc);
            acc -= intToDeduct;
            if (intToDeduct == 0 && variant.Base.FailedStock > 0) { intToDeduct = 1; acc = Mathf.Max(0f, acc - 1f); }

            variant.Base.FailedStock -= Mathf.Clamp(intToDeduct, 0, variant.Base.FailedStock);
            FractionalConsumedAccumulator[variant.SaveID] = acc;
            return delivered;
        }

        public static int PopHighBinPoolOnRetire(Cpu variant)
        {
            if (variant == null || !HighBinStockPools.TryGetValue(variant.SaveID, out int rem)) return 0;
            HighBinStockPools.Remove(variant.SaveID);
            return Mathf.Max(0, rem);
        }

        public static void DistributeDailyProductionToHighBins(Cpu baseCpu, int newlyProducedGood)
        {
            var companyCpus = (baseCpu != null && baseCpu.Base == null && newlyProducedGood > 0) ? baseCpu.Company?.Owner?.GetCpus() : null;
            if (companyCpus == null) return;

            for (int i = 0; i < companyCpus.Count; i++)
            {
                var candidate = companyCpus[i];
                if (candidate == null || candidate.IsRetired || candidate.Base != baseCpu || !IsHighBin(candidate)) continue;
                if (baseCpu.Market.Stock <= 0) break;

                float yield = Mathf.Clamp01(1f - candidate.FailureRate);
                if (yield <= 0f) continue;

                int idealReserve = Mathf.RoundToInt(newlyProducedGood * yield);
                int dailyDemand = candidate.SoldLastDay + candidate.MissedSalesLastDay + candidate.TodayDemandByContracts;
                int bufferCap = Mathf.Max(100, Math.Max(idealReserve * 2, dailyDemand * 5));
                int curPool = GetHighBinPool(candidate);
                if (curPool >= bufferCap) continue;

                int reserve = Mathf.Clamp(Math.Min(idealReserve, bufferCap - curPool), 0, baseCpu.Market.Stock);
                if (reserve > 0) { baseCpu.Market.Stock -= reserve; AddHighBinPool(candidate, reserve); }
            }
        }

        private static string NormalizeSaveName(string saveName)
        {
            string s = (saveName ?? "").Trim();
            if (s.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)) s = s.Substring(0, s.Length - 4);
            if (string.IsNullOrWhiteSpace(s) && DateController.Instance != null)
            {
                var d = DateController.Instance.CurrentDate;
                s = $"{d.Year}_{d.Month}_{d.Day}";
            }
            return s;
        }

        public static void SaveHighBinPoolsForSaveFile(string saveName, List<Cpu> allCpus)
        {
            try
            {
                saveName = NormalizeSaveName(saveName);
                if (string.IsNullOrEmpty(saveName) || allCpus == null) return;
                string file = HighBinStorageFile;
                string dir = Path.GetDirectoryName(file);
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

                var lines = File.Exists(file)
                    ? File.ReadAllLines(file).Where(l => !l.StartsWith(saveName + "|", StringComparison.OrdinalIgnoreCase)).ToList()
                    : new List<string>();

                for (int i = 0; i < allCpus.Count; i++)
                {
                    var cpu = allCpus[i];
                    if (cpu != null && IsHighBin(cpu) && !cpu.IsRetired)
                        lines.Add($"{saveName}|{cpu.SaveID}={GetHighBinPool(cpu)}");
                }

                File.WriteAllLines(file, lines);
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogWarning($"Could not persist High Bin pools: {ex.Message}");
            }
        }

        public static void LoadHighBinPoolsForSaveFile(string saveName, List<Cpu> allCpus)
        {
            try
            {
                saveName = NormalizeSaveName(saveName);
                var loadedBySaveId = new Dictionary<int, int>();
                string file = HighBinStorageFile;
                if (!string.IsNullOrEmpty(saveName) && File.Exists(file))
                {
                    string prefix = saveName + "|";
                    foreach (var line in File.ReadAllLines(file))
                    {
                        if (!line.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                        string rest = line.Substring(prefix.Length);
                        int eq = rest.IndexOf('=');
                        if (eq > 0 && int.TryParse(rest.Substring(0, eq), out int id) && int.TryParse(rest.Substring(eq + 1), out int pool))
                            loadedBySaveId[id] = Mathf.Max(0, pool);
                    }
                }
                if (allCpus == null) return;
                for (int i = 0; i < allCpus.Count; i++)
                {
                    var cpu = allCpus[i];
                    if (cpu?.Base != null && IsHighBin(cpu) && !cpu.IsRetired)
                        HighBinStockPools[cpu.SaveID] = loadedBySaveId.TryGetValue(cpu.SaveID, out int pool)
                            ? pool : Mathf.FloorToInt(cpu.Base.Market.Stock * Mathf.Clamp01(1f - cpu.FailureRate));
                }
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogWarning($"Could not load High Bin pools: {ex.Message}");
            }
        }

        public static int GetActiveContractsMonthlyDemand(Cpu cpu, Contract exclude = null)
        {
            if (cpu == null || ContractManager.Instance == null) return 0;
            int dayKey = DateController.Instance != null
                ? DateController.Instance.CurrentDate.Year * 1000 + DateController.Instance.CurrentDate.DayOfYear : -1;
            if (exclude == null && dayKey >= 0 && ContractDemandCache.TryGetValue(cpu.SaveID, out var cached) && cached.dayKey == dayKey)
                return cached.demand;

            var active = ContractManager.Instance.GetActiveContracts();
            if (active == null) return 0;
            int sum = 0;
            for (int i = 0; i < active.Count; i++)
            {
                var c = active[i];
                if (c != null && c != exclude && c.ChosenCpuID == cpu.SaveID && c.Units > 0)
                    sum += c.Units;
            }
            if (exclude == null && dayKey >= 0) ContractDemandCache[cpu.SaveID] = (dayKey, sum);
            return sum;
        }

        public static int GetEffectiveDailyContractDemand(Cpu cpu) =>
            cpu == null ? 0 : Math.Max(cpu.TodayDemandByContracts, Mathf.CeilToInt(GetActiveContractsMonthlyDemand(cpu) / 30f));

        public static int GetVariantMarketAvailableUnits(Cpu variant)
        {
            int total = GetVariantAvailableUnits(variant);
            if (total <= 0) return 0;
            int dailyContracts = GetEffectiveDailyContractDemand(variant);
            return dailyContracts <= 0 ? total : Math.Max(0, total - Mathf.CeilToInt(dailyContracts * 1.05f));
        }

        public static float GetVariantMonthlyIncomingSupply(Cpu variant, Contract exclude = null)
        {
            if (variant?.Base == null || variant.Base.IsRetired) return 0f;
            Cpu baseCpu = variant.Base;
            bool isHigh = IsHighBin(variant);
            float rawBaseFlow = EstimateBaseMonthlyFlow(baseCpu, isHigh);
            if (rawBaseFlow <= 0f) return 0f;

            float siblingBaseDraw = 0f;
            var active = ContractManager.Instance?.GetActiveContracts();
            if (active != null)
            {
                for (int i = 0; i < active.Count; i++)
                {
                    var c = active[i];
                    if (c == null || c == exclude || c.ChosenCpuID < 0) continue;
                    Cpu owner = CpuDataProvider.Instance?.GetCpu(c.ChosenCpuID);
                    if (owner != null && owner != variant && owner.Base == baseCpu && IsHighBin(owner) == isHigh)
                        siblingBaseDraw += Math.Max(0, c.Units) / Mathf.Clamp(1f - owner.FailureRate, 0.01f, 1f);
                }
            }
            return Math.Max(0f, rawBaseFlow - siblingBaseDraw) * Mathf.Clamp01(1f - variant.FailureRate);
        }

        private static float EstimateBaseMonthlyFlow(Cpu baseCpu, bool forHighBin)
        {
            if (baseCpu == null || baseCpu.IsRetired) return 0f;
            if (!forHighBin && baseCpu.FailedLastDay > 0) return baseCpu.FailedLastDay * 30f;
            if (forHighBin && baseCpu.ProducedLastDay > 0) return Math.Max(0f, (baseCpu.ProducedLastDay - baseCpu.TodayDemandByContracts) * 30f);

            int lines = Math.Max(baseCpu.LinesActuallyAllocated, baseCpu.CurrentProductionLines + (forHighBin ? 0 : baseCpu.CurrentContractedProductionLines));
            if (lines <= 0) return 0f;

            float waferSize = baseCpu.Manufacturer != null ? baseCpu.Manufacturer.CurrentWaferSize : 200f;
            float diesPerMonth = lines * 50f * ProductionMath.DiesPerWafer(baseCpu.DieSize, baseCpu.DieCount, waferSize, baseCpu.CurrentNodeYield);
            float failRate = Mathf.Clamp01(baseCpu.FailureRate);
            return forHighBin ? Math.Max(0f, diesPerMonth * (1f - failRate) - baseCpu.TodayDemandByContracts * 30f) : Math.Max(0f, diesPerMonth * failRate);
        }

        public static bool CanBinnedCpuSupplyContract(Cpu cpu, Contract contract, int extraReservedMonthly = 0)
        {
            if (cpu?.Base == null || contract == null) return true;
            if (cpu.IsRetired) return false;

            int totalMonthlyDemand = GetActiveContractsMonthlyDemand(cpu, contract) + Math.Max(0, contract.Units) + Math.Max(0, extraReservedMonthly);
            if (totalMonthlyDemand <= 0) return true;

            float incomingPerMonth = GetVariantMonthlyIncomingSupply(cpu, contract);
            if (!cpu.Base.IsRetired && incomingPerMonth >= totalMonthlyDemand * 1.10f) return true;

            DateTime accDate = (DateTime)contract.AcceptanceDate, termDate = (DateTime)contract.TerminationDate;
            DateTime now = DateController.Instance != null ? DateController.Instance.CurrentDate : accDate;
            if (now < accDate && !cpu.Base.IsRetired && cpu.Price > 0f) return false;

            float durationMonths = Mathf.Max(1f, (float)(Math.Max(30.0, (termDate - (now > accDate ? now : accDate)).TotalDays) / 30.0));
            float sustainableUnits = GetVariantAvailableUnits(cpu) + (!cpu.Base.IsRetired ? incomingPerMonth * durationMonths * 0.90f : 0f);
            return sustainableUnits >= totalMonthlyDemand * durationMonths * 1.05f;
        }
    }
}
