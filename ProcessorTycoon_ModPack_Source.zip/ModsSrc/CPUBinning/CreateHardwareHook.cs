using System;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.UI;
using UnityEngine;
using UnityEngine.UI;

namespace CPUBinning
{
    public static class CreateHardwareHook
    {
        private static readonly FieldInfo CreatorTypeField = AccessTools.Field(typeof(CreatorOpenButton), "creatorType");
        private static readonly FieldInfo FirstOnEnableField = AccessTools.Field(typeof(CreateHardwareWindow), "firstOnEnable");
        private static ButtonUI _variantButton;

        public static void ApplyPatches(Harmony harmony)
        {
            var onEnable = AccessTools.Method(typeof(CreateHardwareWindow), "OnEnable");
            if (onEnable != null)
                harmony.Patch(onEnable,
                    prefix: new HarmonyMethod(typeof(CreateHardwareHook), nameof(CreateHardwareWindow_OnEnable_Prefix)),
                    postfix: new HarmonyMethod(typeof(CreateHardwareHook), nameof(CreateHardwareWindow_OnEnable_Postfix)));

            var updateStates = AccessTools.Method(typeof(CreateHardwareWindow), "UpdateButtonStates");
            if (updateStates != null)
                harmony.Patch(updateStates, postfix: new HarmonyMethod(typeof(CreateHardwareHook), nameof(UpdateVariantButtonState)));
        }

        private static void CreateHardwareWindow_OnEnable_Prefix(CreateHardwareWindow __instance, out bool __state) =>
            __state = FirstOnEnableField != null && (bool)FirstOnEnableField.GetValue(__instance);

        private static void CreateHardwareWindow_OnEnable_Postfix(CreateHardwareWindow __instance, bool __state)
        {
            if (__state) return;
            if (!BinningPlugin.IsEnabled)
            {
                SetButtonVisible(false);
                return;
            }
            try
            {
                EnsureVariantButton(__instance);
                SetButtonVisible(true);
                UpdateVariantButtonState();
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogError($"Error in CreateHardwareWindow_OnEnable_Postfix: {ex}");
            }
        }

        internal static void SetButtonVisible(bool visible)
        {
            if (_variantButton != null)
                _variantButton.gameObject.SetActive(visible);
        }

        private static void UpdateVariantButtonState()
        {
            if (_variantButton == null) return;
            if (!BinningPlugin.IsEnabled) { _variantButton.gameObject.SetActive(false); return; }
            var baseCpus = Player.Instance?.GetBaseCpus();
            _variantButton.Interactable = baseCpus != null && baseCpus.Count > 0;
        }

        private static void EnsureVariantButton(CreateHardwareWindow window)
        {
            if (_variantButton != null) return;

            CreatorOpenButton cpuOpenBtn = null;
            foreach (var openBtn in window.GetComponentsInChildren<CreatorOpenButton>(true))
            {
                if (openBtn != null && (CreatorWindow.Type)CreatorTypeField.GetValue(openBtn) == CreatorWindow.Type.Cpu)
                {
                    cpuOpenBtn = openBtn;
                    break;
                }
            }
            if (cpuOpenBtn == null) return;

            var parent = cpuOpenBtn.transform.parent;
            var existing = parent.Find("Btn_NewCpuVariant");
            if (existing != null)
            {
                _variantButton = existing.GetComponent<ButtonUI>();
                return;
            }

            var cloneGO = UnityEngine.Object.Instantiate(cpuOpenBtn.gameObject, parent, false);
            cloneGO.name = "Btn_NewCpuVariant";
            var clonedOpenBtn = cloneGO.GetComponent<CreatorOpenButton>();
            if (clonedOpenBtn != null) UnityEngine.Object.DestroyImmediate(clonedOpenBtn);

            cloneGO.transform.SetSiblingIndex(cpuOpenBtn.transform.GetSiblingIndex() + 1);
            cloneGO.SetActive(true);

            AdjustLayoutForAddedButton(window, cpuOpenBtn.transform as RectTransform, cloneGO.transform as RectTransform, parent);

            _variantButton = cloneGO.GetComponent<ButtonUI>();
            if (_variantButton != null)
            {
                _variantButton.ResetOnClick();
                _variantButton.Text = "New CPU Variant";
                _variantButton.OnClick += () =>
                {
                    VariantCreatorPatch.StartNewVariantFlow();
                    window.gameObject.SetActive(false);
                };
            }
        }

        private static void AdjustLayoutForAddedButton(CreateHardwareWindow window, RectTransform cpuRect, RectTransform cloneRect, Transform parent)
        {
            if (cpuRect == null || cloneRect == null || parent == null) return;

            var vLayout = parent.GetComponent<VerticalLayoutGroup>();
            bool hasLayoutGroup = vLayout != null || parent.GetComponent<LayoutGroup>() != null;
            float addedHeight = cpuRect.rect.height > 1f ? cpuRect.rect.height + (vLayout != null ? vLayout.spacing : 6f) : 40f;

            if (!hasLayoutGroup)
            {
                float bestDiff = float.MaxValue;
                foreach (Transform child in parent)
                {
                    if (child == cpuRect || child == cloneRect || !(child is RectTransform rt)) continue;
                    float diff = cpuRect.anchoredPosition.y - rt.anchoredPosition.y;
                    if (diff > 5f && diff < bestDiff) bestDiff = diff;
                }
                if (bestDiff < 200f) addedHeight = bestDiff;

                float cutY = cpuRect.anchoredPosition.y;
                foreach (Transform child in parent)
                {
                    if (child != cpuRect && child != cloneRect && child is RectTransform rt && rt.anchoredPosition.y < cutY - 1f)
                        rt.anchoredPosition -= new Vector2(0f, addedHeight);
                }
                cloneRect.anchoredPosition = cpuRect.anchoredPosition - new Vector2(0f, addedHeight);
            }

            Transform cur = parent;
            while (cur != null)
            {
                var rt = cur as RectTransform;
                var fitter = cur.GetComponent<ContentSizeFitter>();
                bool autoFitsVert = fitter != null && fitter.verticalFit == ContentSizeFitter.FitMode.PreferredSize;
                bool isVertStretched = rt != null && !Mathf.Approximately(rt.anchorMin.y, rt.anchorMax.y);
                if (rt != null && !autoFitsVert && !isVertStretched) rt.sizeDelta += new Vector2(0f, addedHeight);

                if (cur == window.transform)
                {
                    if (!hasLayoutGroup && cur.GetComponent<LayoutGroup>() == null)
                    {
                        float pY = (parent as RectTransform)?.anchoredPosition.y ?? 0f;
                        foreach (Transform sec in cur)
                            if (sec != parent && sec is RectTransform secRt && secRt.anchoredPosition.y < pY - 1f)
                                secRt.anchoredPosition -= new Vector2(0f, addedHeight);
                    }
                    if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
                    break;
                }
                cur = cur.parent;
            }
        }
    }
}
