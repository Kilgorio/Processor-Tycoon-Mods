using System;
using System.Collections.Generic;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.Hardware.Math;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CPUBinning
{
    public static partial class VariantCreatorPatch
    {
        private static HardwareSelectorOpenButton FindOpenButton(HardwareType type)
        {
            var btn = CreatorManager.Instance?.GetHardwareOpenButtonOfType(type, SelectorVariant.CpuCreator);
            if (btn != null || _cpuWindow == null) return btn;

            foreach (var b in _cpuWindow.GetComponentsInChildren<HardwareSelectorOpenButton>(true))
                if (b != null && b.Hardware == type && b.SelectorVariant == SelectorVariant.CpuCreator && !b.IsPortrait)
                    return b;
            return null;
        }

        private static void EnsureVariantWidgetsBuilt(CreatorCpu cpu)
        {
            if (_widgetsBuilt || !cpu.gameObject.activeInHierarchy) return;
            try
            {
                _widgetsBuilt = true;
                var pkgBtn = FindOpenButton(HardwareType.Package);
                var lithoBtn = FindOpenButton(HardwareType.Lithography);
                var archBtn = FindOpenButton(HardwareType.Architecture);
                var memBtn = FindOpenButton(HardwareType.Memory);

                _packageSlot = pkgBtn != null ? FindSlotContainer(pkgBtn) : null;
                _lithoSlot = lithoBtn != null ? FindSlotContainer(lithoBtn) : null;
                _archSlot = archBtn != null ? FindSlotContainer(archBtn) : null;
                _memoryOpenBtn = memBtn != null ? memBtn.GetComponent<ButtonUI>() : null;

                var coreDropdown = CoreDropF.GetValue(cpu) as DropdownUI;
                _coreDropdownSlot = coreDropdown != null ? FindSlotContainer(coreDropdown) : null;

                var dieDropdown = DieDropF.GetValue(cpu) as DropdownUI;
                _dieDropdownSlot = dieDropdown != null ? FindDieDropdownContainer(dieDropdown) : null;

                if (_archSlot != null && _packageSlot != null && _archSlot.transform.parent != _packageSlot.transform.parent)
                {
                    var row2Parent = _archSlot.transform.parent;
                    bool onlyArchAndCore = true;
                    foreach (Transform ch in row2Parent)
                        if (ch.gameObject != _archSlot && ch.gameObject != _coreDropdownSlot) { onlyArchAndCore = false; break; }
                    _isolatedRow2Container = onlyArchAndCore ? row2Parent.gameObject : null;
                }

                if (_packageSlot != null)
                {
                    var existingCpuSlot = _packageSlot.transform.parent.Find("VariantSlot_CPU");
                    if (existingCpuSlot != null) _cpuSelectSlot = existingCpuSlot.gameObject;
                    else
                    {
                        _cpuSelectSlot = UnityEngine.Object.Instantiate(_packageSlot, _packageSlot.transform.parent, false);
                        _cpuSelectSlot.name = "VariantSlot_CPU";
                        _cpuSelectSlot.transform.SetSiblingIndex(_packageSlot.transform.GetSiblingIndex() + 1);
                        var openBtn = _cpuSelectSlot.GetComponentInChildren<HardwareSelectorOpenButton>(true);
                        if (openBtn != null) UnityEngine.Object.DestroyImmediate(openBtn);
                    }

                    _cpuSelectSlot.SetActive(true);
                    _cpuSelectButton = _cpuSelectSlot.GetComponentInChildren<ButtonUI>(true);
                    if (_cpuSelectButton != null)
                    {
                        _cpuSelectButton.ResetOnClick();
                        _cpuSelectButton.OnClick += () => CpuSelectorWindow.Open(isSwitchingExisting: true);
                        _cpuSelectButtonText = _cpuSelectButton.GetComponentInChildren<TMP_Text>(true);
                    }

                    foreach (var t in _cpuSelectSlot.GetComponentsInChildren<TMP_Text>(true))
                        if (_cpuSelectButton == null || !t.transform.IsChildOf(_cpuSelectButton.transform)) { t.text = "CPU"; break; }

                    CopyRect(_packageSlot.transform as RectTransform, _cpuSelectSlot.transform as RectTransform);
                    _cpuSelectSlot.SetActive(false);
                }

                if (_coreDropdownSlot != null && _lithoSlot != null)
                {
                    var existingTypeSlot = _lithoSlot.transform.parent.Find("VariantSlot_Type");
                    if (existingTypeSlot != null) _variantTypeSlot = existingTypeSlot.gameObject;
                    else
                    {
                        _variantTypeSlot = UnityEngine.Object.Instantiate(_coreDropdownSlot, _lithoSlot.transform.parent, false);
                        _variantTypeSlot.name = "VariantSlot_Type";
                        _variantTypeSlot.transform.SetSiblingIndex(_lithoSlot.transform.GetSiblingIndex() + 1);
                    }

                    _variantTypeSlot.SetActive(true);
                    _variantTypeDropdown = _variantTypeSlot.GetComponentInChildren<DropdownUI>(true);
                    if (_variantTypeDropdown != null)
                    {
                        _variantTypeDropdown.UpdateOptions(new List<string> { "Low Bin", "High Bin" });
                        _variantTypeDropdown.SetSelected(0);
                        _variantTypeDropdown.Interactable = true;
                        _variantTypeDropdown.OnValueChanged += () =>
                        {
                            if (!IsVariantMode || SelectedBaseCpu == null) return;
                            bool wantHigh = _variantTypeDropdown.Value == 1;
                            if (wantHigh != IsHighBinSelected)
                            {
                                IsHighBinSelected = wantHigh;
                                _needsInitialSliderSync = true;
                                UpdateUiM?.Invoke(cpu, new object[] { false });
                                UpdateCoreCountM?.Invoke(cpu, null);
                                UpdateNumbersM?.Invoke(cpu, null);
                            }
                        };
                    }

                    foreach (var t in _variantTypeSlot.GetComponentsInChildren<TMP_Text>(true))
                        if (_variantTypeDropdown == null || !t.transform.IsChildOf(_variantTypeDropdown.transform)) { t.text = "Variant Type"; break; }

                    CopyRect(_lithoSlot.transform as RectTransform, _variantTypeSlot.transform as RectTransform);
                    _variantTypeSlot.SetActive(false);
                }

                var freqSlider = FreqSliderF.GetValue(cpu) as SliderUI;
                var dieSizeSlider = DieSizeSliderF.GetValue(cpu) as SliderUI;
                if (freqSlider != null)
                {
                    var parent = freqSlider.transform.parent;
                    _slidersContainerRt = parent as RectTransform;
                    var vLayout = parent.GetComponent<VerticalLayoutGroup>();
                    bool hasLayout = vLayout != null || parent.GetComponent<LayoutGroup>() != null;

                    if (!_slidersGeometrySaved && _slidersContainerRt != null)
                    {
                        _slidersOrigPos = _slidersContainerRt.anchoredPosition;
                        _slidersOrigSize = _slidersContainerRt.sizeDelta;
                        _slidersOrigSpacing = vLayout != null ? vLayout.spacing : 0f;
                        _slidersGeometrySaved = true;
                    }

                    float freqY = (freqSlider.transform as RectTransform).anchoredPosition.y;
                    float dieSizeY = dieSizeSlider != null ? (dieSizeSlider.transform as RectTransform).anchoredPosition.y : freqY + 55f;
                    float step = Mathf.Clamp(Mathf.Max(42f, dieSizeY - freqY) * 0.72f, 36f, 64f);

                    GameObject dieGO = parent.Find("Slider_VariantDieCount")?.gameObject ?? UnityEngine.Object.Instantiate(freqSlider.gameObject, parent, false);
                    dieGO.name = "Slider_VariantDieCount";
                    dieGO.transform.SetSiblingIndex(freqSlider.transform.GetSiblingIndex());
                    dieGO.SetActive(true);
                    _variantDieCountSlider = dieGO.GetComponent<SliderUI>();
                    _variantDieCountSlider.Title = "Die Count";
                    if (!hasLayout && dieGO.transform is RectTransform dRt) dRt.anchoredPosition = new Vector2(dRt.anchoredPosition.x, freqY + step * 2f);
                    dieGO.SetActive(false);

                    GameObject coresGO = parent.Find("Slider_VariantEnabledCores")?.gameObject ?? UnityEngine.Object.Instantiate(freqSlider.gameObject, parent, false);
                    coresGO.name = "Slider_VariantEnabledCores";
                    coresGO.transform.SetSiblingIndex(freqSlider.transform.GetSiblingIndex());
                    coresGO.SetActive(true);
                    _variantCoresSlider = coresGO.GetComponent<SliderUI>();
                    _variantCoresSlider.Title = "Enabled Cores";
                    _variantCoresSlider.OnValueChanged += () =>
                    {
                        if (!IsVariantMode || SelectedBaseCpu == null) return;
                        int c = Mathf.Max(1, Mathf.RoundToInt(_variantCoresSlider.Value));
                        CoreCountF.SetValue(cpu, c);
                        _variantCoresSlider.Text = c == 1 ? "1 Core" : $"{c} Cores";
                    };
                    if (!hasLayout && coresGO.transform is RectTransform cRt) cRt.anchoredPosition = new Vector2(cRt.anchoredPosition.x, freqY + step);
                    coresGO.SetActive(false);
                }
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogError($"Error building Variant mode widgets: {ex}");
            }
        }

        private static GameObject FindSlotContainer(Component comp)
        {
            var p = comp.transform.parent;
            if (p != null && p.GetComponentsInChildren<SliderUI>(true).Length == 0 &&
                (p.GetComponentsInChildren<ButtonUI>(true).Length + p.GetComponentsInChildren<DropdownUI>(true).Length) == 1)
                return p.gameObject;
            return comp.gameObject;
        }

        private static GameObject FindDieDropdownContainer(DropdownUI dieDropdown)
        {
            var p = dieDropdown.transform.parent;
            if (p != null && p.GetComponentsInChildren<SliderUI>(true).Length == 0 && p.GetComponentsInChildren<DropdownUI>(true).Length == 1)
                return p.gameObject;
            return dieDropdown.gameObject;
        }

        private static void CopyRect(RectTransform src, RectTransform dst)
        {
            if (src == null || dst == null) return;
            dst.anchorMin = src.anchorMin; dst.anchorMax = src.anchorMax; dst.pivot = src.pivot;
            dst.sizeDelta = src.sizeDelta; dst.anchoredPosition = src.anchoredPosition;
        }

        private static void AdjustSlidersVerticalArea(CreatorCpu cpu, bool variantMode)
        {
            if (!_slidersGeometrySaved || _slidersContainerRt == null) return;

            var vLayout = _slidersContainerRt.GetComponent<VerticalLayoutGroup>();
            var ocToggle = OverclockToggleF.GetValue(cpu) as ToggleUI;
            bool togglesInSameParent = ocToggle != null && ocToggle.transform.parent == _slidersContainerRt;

            _slidersContainerRt.anchoredPosition = _slidersOrigPos;
            _slidersContainerRt.sizeDelta = _slidersOrigSize;
            if (vLayout != null) vLayout.spacing = _slidersOrigSpacing;
            if (!variantMode)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(_slidersContainerRt);
                return;
            }

            var topRef = (_cpuSelectSlot != null ? _cpuSelectSlot.transform : _packageSlot?.transform) as RectTransform;
            if (topRef?.parent is RectTransform topParentRt)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(topParentRt);
                if (topParentRt.parent is RectTransform grandParentRt) LayoutRebuilder.ForceRebuildLayoutImmediate(grandParentRt);
            }

            if (!togglesInSameParent)
            {
                if (_slidersContainerRt.parent is RectTransform outerRt) LayoutRebuilder.ForceRebuildLayoutImmediate(outerRt);
                var botRef = ocToggle != null ? ocToggle.transform as RectTransform : null;
                if (topRef != null && botRef != null)
                {
                    var topC = new Vector3[4]; var botC = new Vector3[4]; var sldC = new Vector3[4];
                    topRef.GetWorldCorners(topC); botRef.GetWorldCorners(botC); _slidersContainerRt.GetWorldCorners(sldC);

                    float scale = _slidersContainerRt.lossyScale.y > 0.0001f ? _slidersContainerRt.lossyScale.y : 1f;
                    float padWorld = 6f * scale;
                    float targetTop = topC[0].y - padWorld, targetBot = botC[1].y + padWorld * 0.5f;
                    float availLocalH = Mathf.Max(90f, (targetTop - targetBot) / scale);
                    float deltaCenterLocal = ((targetTop + targetBot) * 0.5f - (sldC[1].y + sldC[0].y) * 0.5f) / scale;
                    float curLocalH = Mathf.Max(1f, (sldC[1].y - sldC[0].y) / scale);

                    bool outerHasLayout = _slidersContainerRt.parent?.GetComponent<LayoutGroup>() != null;
                    if (!outerHasLayout)
                    {
                        _slidersContainerRt.anchoredPosition = _slidersOrigPos + new Vector2(0f, deltaCenterLocal);
                        _slidersContainerRt.sizeDelta = _slidersOrigSize + new Vector2(0f, availLocalH - curLocalH);
                    }
                    else if (availLocalH > curLocalH)
                    {
                        _slidersContainerRt.sizeDelta = _slidersOrigSize + new Vector2(0f, availLocalH - curLocalH);
                    }

                    if (vLayout != null)
                    {
                        float estSliderH = (FreqSliderF.GetValue(cpu) as SliderUI)?.GetComponent<RectTransform>()?.rect.height ?? 36f;
                        if (estSliderH < 10f) estSliderH = 38f;
                        vLayout.spacing = Mathf.Clamp((availLocalH - 3f * estSliderH) / 2f, -2f, Mathf.Max(2f, _slidersOrigSpacing));
                    }

                    if (outerHasLayout) LayoutRebuilder.ForceRebuildLayoutImmediate(_slidersContainerRt.parent as RectTransform);
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(_slidersContainerRt);
        }

        private static void ApplyLayoutMode(CreatorCpu cpu, bool variantMode)
        {
            if (cpu == null) return;
            EnsureVariantWidgetsBuilt(cpu);

            _packageSlot?.SetActive(!variantMode);
            _lithoSlot?.SetActive(!variantMode);
            _archSlot?.SetActive(!variantMode);
            _coreDropdownSlot?.SetActive(!variantMode);
            _isolatedRow2Container?.SetActive(!variantMode);
            _dieDropdownSlot?.SetActive(!variantMode);
            (DieDropF.GetValue(cpu) as DropdownUI)?.gameObject.SetActive(!variantMode);

            _cpuSelectSlot?.SetActive(variantMode);
            _variantTypeSlot?.SetActive(variantMode);

            if (DieSizeSliderF.GetValue(cpu) is SliderUI dieSizeSlider)
            {
                dieSizeSlider.gameObject.SetActive(!variantMode);
                if (!variantMode) dieSizeSlider.Interactable = true;
            }
            if (!variantMode)
            {
                if (OverclockToggleF.GetValue(cpu) is ToggleUI ocToggle) ocToggle.Interactable = true;
                if (FreqSliderF.GetValue(cpu) is SliderUI freqSlider) freqSlider.Interactable = true;
                if (L1SliderF.GetValue(cpu) is SliderUI l1Slider) l1Slider.Interactable = true;
            }

            _variantDieCountSlider?.gameObject.SetActive(variantMode);
            _variantCoresSlider?.gameObject.SetActive(variantMode);
            if (_memoryOpenBtn != null) _memoryOpenBtn.Interactable = !variantMode;

            if (AutoCacheToggleF.GetValue(cpu) is ToggleUI autoCache)
            {
                autoCache.gameObject.SetActive(!variantMode);
                if (variantMode) autoCache.SetValueWithoutNotify(false);
            }

            AdjustSlidersVerticalArea(cpu, variantMode);

            var costInfo = ProjectCostTextF.GetValue(cpu) as InfoText;
            var timeInfo = ProjectTimeTextF.GetValue(cpu) as InfoText;
            var dateInfo = ConclusionDateTextF.GetValue(cpu) as InfoText;
            var createBtn = CreateBtnF.GetValue(cpu) as ButtonUI;

            if (costInfo != null) costInfo.Title = variantMode ? "Defective Units" : "Project Cost";
            if (timeInfo != null) timeInfo.Title = variantMode ? "Usable Units" : "Project Time";
            dateInfo?.gameObject.SetActive(!variantMode);
            if (createBtn != null) createBtn.Text = variantMode ? "Create Variant" : "Develop";
        }

        private static void PrepareNormalModeReset(CreatorCpu cpu)
        {
            _needsNormalResetOnNextUpdate = true;
            if (cpu == null) return;
            if (DieSizeSliderF.GetValue(cpu) is SliderUI ds) ds.Interactable = true;
            if (FreqSliderF.GetValue(cpu) is SliderUI fs) fs.Interactable = true;
            if (L1SliderF.GetValue(cpu) is SliderUI l1) l1.Interactable = true;
            if (OverclockToggleF.GetValue(cpu) is ToggleUI oc) { oc.SetValueWithoutNotify(false); oc.Interactable = true; }
            if (SmtToggleF.GetValue(cpu) is ToggleUI smt) smt.SetValueWithoutNotify(false);
            SmtF.SetValue(cpu, false);
            HasInitF.SetValue(cpu, false);
        }

        private static bool UpdateUI_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null)
            {
                if (_needsNormalResetOnNextUpdate) { _needsNormalResetOnNextUpdate = false; HasInitF.SetValue(__instance, false); }
                ApplyLayoutMode(__instance, false);
                return true;
            }

            _needsNormalResetOnNextUpdate = true;
            _activeCreator = __instance;
            ApplyLayoutMode(__instance, true);

            var b = SelectedBaseCpu;
            CpuMath.CurrentModifiers = Player.Instance.Company.ResearchModifiers;
            MaxFreqF.SetValue(__instance, b.FrequencyTechnology > 0f ? b.FrequencyTechnology : b.Frequency);

            if (_cpuSelectButtonText != null) _cpuSelectButtonText.text = b.Name;
            _variantTypeDropdown?.SetSelected(IsHighBinSelected ? 1 : 0);

            if (NameInputF.GetValue(__instance) is TMP_InputField nameInput)
            {
                nameInput.characterLimit = 20;
                if (_needsInitialSliderSync) nameInput.text = "";
            }

            int dies = Math.Max(1, b.DieCount);
            if (_variantDieCountSlider != null)
            {
                _variantDieCountSlider.Setup(true, 1f, dies);
                _variantDieCountSlider.Value = dies;
                _variantDieCountSlider.Interactable = false;
                _variantDieCountSlider.Text = dies > 1 ? $"{dies} Dies" : "1 Die";
            }
            DieCountF.SetValue(__instance, dies);

            int pCores = Math.Max(1, b.CoreCount);
            if (_variantCoresSlider != null)
            {
                if (IsHighBinSelected || pCores <= 1)
                {
                    _variantCoresSlider.Setup(true, 1f, pCores);
                    _variantCoresSlider.Value = pCores;
                    _variantCoresSlider.Interactable = false;
                }
                else if (dies > 1 && pCores >= dies && pCores % dies == 0)
                {
                    _variantCoresSlider.SetupInt(dies, pCores, dies);
                    _variantCoresSlider.Interactable = true;
                }
                else
                {
                    _variantCoresSlider.Setup(true, 1f, pCores);
                    _variantCoresSlider.Interactable = true;
                }

                if (_needsInitialSliderSync || IsHighBinSelected) _variantCoresSlider.SetValueToMaximum();
                int curCores = Mathf.Max(1, Mathf.RoundToInt(_variantCoresSlider.Value));
                CoreCountF.SetValue(__instance, curCores);
                _variantCoresSlider.Text = curCores == 1 ? "1 Core" : $"{curCores} Cores";
            }

            if (FreqSliderF.GetValue(__instance) is SliderUI freqSlider)
            {
                float parentFreq = Mathf.Max(10f, b.Frequency);
                if (IsHighBinSelected)
                {
                    float maxHigh = parentFreq * BinningMath.GetHighBinMaxFreqMultiplier();
                    freqSlider.Setup(5f, parentFreq, maxHigh);
                    if (SliderValuesF?.GetValue(freqSlider) is List<float> vals)
                    {
                        vals.RemoveAll(v => v < parentFreq - 0.1f);
                        if (vals.Count == 0 || vals[0] > parentFreq + 0.1f) vals.Insert(0, parentFreq);
                        else vals[0] = parentFreq;

                        if (vals.Count < 6)
                        {
                            vals.Clear();
                            for (int i = 0; i <= 10; i++) vals.Add(Mathf.Lerp(parentFreq, maxHigh, i / 10f));
                        }
                        else if (vals[vals.Count - 1] < maxHigh - 1f) vals.Add(maxHigh);

                        freqSlider.Slider.minValue = 0f;
                        freqSlider.Slider.maxValue = vals.Count - 1;
                        freqSlider.Interactable = vals.Count > 1;
                    }
                    if (_needsInitialSliderSync) freqSlider.SetValueToMinimum();
                }
                else
                {
                    float minFreq = Mathf.Max(5f, parentFreq * 0.25f);
                    if (minFreq >= parentFreq) minFreq = parentFreq * 0.5f;
                    freqSlider.Setup(5f, minFreq, parentFreq);
                    if (SliderValuesF?.GetValue(freqSlider) is List<float> vals)
                    {
                        if (vals.Count == 0) { vals.Add(parentFreq); freqSlider.Slider.minValue = freqSlider.Slider.maxValue = 0f; }
                        else if (vals[vals.Count - 1] < parentFreq - 0.5f) { vals.Add(parentFreq); freqSlider.Slider.maxValue = vals.Count - 1; }
                        freqSlider.Interactable = vals.Count > 1;
                    }
                    if (_needsInitialSliderSync) freqSlider.SetValueToMaximum();
                }
            }

            if (OverclockToggleF.GetValue(__instance) is ToggleUI ocToggle)
            {
                ocToggle.SetValueWithoutNotify(IsHighBinSelected || (b.FrequencyTechnology > 0f && b.Frequency > b.FrequencyTechnology * 1.01f));
                ocToggle.Interactable = false;
            }

            if (SmtToggleF.GetValue(__instance) is ToggleUI smtToggle)
            {
                smtToggle.Interactable = !IsHighBinSelected && b.Smt;
                if (!b.Smt) { smtToggle.SetValueWithoutNotify(false); SmtF.SetValue(__instance, false); }
                else if (_needsInitialSliderSync || IsHighBinSelected) { smtToggle.SetValueWithoutNotify(true); SmtF.SetValue(__instance, true); }
            }

            SetupCacheSlider(L1SliderF.GetValue(__instance) as SliderUI, b.L1Cache / pCores);
            SetupCacheSlider(L2SliderF.GetValue(__instance) as SliderUI, b.L2Cache / pCores);
            SetupCacheSlider(L3SliderF.GetValue(__instance) as SliderUI, b.L3Cache / (16 * dies));

            LastPkgF.SetValue(__instance, b.Package);

            var mfr = b.Manufacturer ?? Player.Instance.Company;
            if (YieldRateTextF.GetValue(__instance) is TMP_Text yieldTxt && b.ProcessNode != null)
                yieldTxt.text = StringFormatter.FloatToPercentageString(mfr.CurrentNodeYield(b.ProcessNode)) ?? "";
            if (MemMipsTextF.GetValue(__instance) is TMP_Text memMipsTxt && b.Memory != null)
                memMipsTxt.text = StringFormatter.FloatToIps(b.Memory.IpsThreshold) ?? "";

            _needsInitialSliderSync = false;
            HasInitF.SetValue(__instance, true);
            return false;
        }

        private static void SetupCacheSlider(SliderUI slider, int maxSteps)
        {
            if (slider == null) return;
            slider.Setup(true, 0f, maxSteps);
            slider.Interactable = !IsHighBinSelected && maxSteps > 0;
            if (_needsInitialSliderSync || IsHighBinSelected) slider.Value = maxSteps;
        }
    }
}
