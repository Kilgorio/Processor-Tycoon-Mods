using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;

namespace CPUBinning
{
    public static class CpuSelectorWindow
    {
        private static HardwareSelectorWindow _instance;
        private static bool _initialized;
        private static bool _isOpeningForSwitch;
        private static Cpu _tentativeCpu;

        private static readonly FieldInfo PrefabField = AccessTools.Field(typeof(HardwareSelectorWindow), "selectorOptionPrefab");
        private static readonly FieldInfo ContentAreaField = AccessTools.Field(typeof(HardwareSelectorWindow), "contentArea");
        private static readonly FieldInfo ParentCgField = AccessTools.Field(typeof(HardwareSelectorWindow), "parentCanvasGroup");
        private static readonly FieldInfo ShowObsoleteField = AccessTools.Field(typeof(HardwareSelectorWindow), "showObsoleteToggle");
        private static readonly FieldInfo ShowLicensedField = AccessTools.Field(typeof(HardwareSelectorWindow), "showLicensedToggle");
        private static readonly FieldInfo SelectButtonField = AccessTools.Field(typeof(HardwareSelectorWindow), "selectButton");
        private static readonly FieldInfo AnySelectedField = AccessTools.Field(typeof(HardwareSelectorWindow), "anyHardwareIsSelected");
        private static readonly MethodInfo UniqueIdPropSetter = AccessTools.PropertySetter(typeof(HardwareSelectorWindow), "UniqueID");
        private static readonly FieldInfo SelectorOptionsField = AccessTools.Field(typeof(HardwareSelectorWindow), "selectorOptions");

        public static bool IsOpen => _instance != null && _instance.gameObject.activeInHierarchy;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(HardwareSelectorWindow), "Start"),
                prefix: new HarmonyMethod(typeof(CpuSelectorWindow), nameof(HardwareSelectorWindow_Start_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(HardwareSelectorWindow), "Open"),
                prefix: new HarmonyMethod(typeof(CpuSelectorWindow), nameof(HardwareSelectorWindow_Open_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(HardwareSelectorWindow), "Close"),
                postfix: new HarmonyMethod(typeof(CpuSelectorWindow), nameof(HardwareSelectorWindow_Close_Postfix)));
        }

        public static void EnsureCreated()
        {
            if (_instance != null || CreatorManager.Instance?.HardwareSelectors == null) return;

            HardwareSelectorWindow template = null;
            foreach (var sel in CreatorManager.Instance.HardwareSelectors)
            {
                if (sel != null && sel.SelectorVariant == SelectorVariant.CpuCreator && sel.Hardware == HardwareType.Package)
                {
                    template = sel;
                    break;
                }
            }
            if (template == null && CreatorManager.Instance.HardwareSelectors.Count > 0)
                template = CreatorManager.Instance.HardwareSelectors[0];
            if (template == null) return;

            var cloneGO = UnityEngine.Object.Instantiate(template.gameObject, template.transform.parent, false);
            cloneGO.name = "CpuVariantSelectorWindow";

            var startBeh = cloneGO.GetComponent<WindowStartBehaviour>();
            if (startBeh != null) UnityEngine.Object.DestroyImmediate(startBeh);

            _instance = cloneGO.GetComponent<HardwareSelectorWindow>();
            if (ContentAreaField?.GetValue(_instance) is Transform clonedContent)
            {
                for (int i = clonedContent.childCount - 1; i >= 0; i--)
                    if (clonedContent.GetChild(i) is Transform ch) UnityEngine.Object.DestroyImmediate(ch.gameObject);
            }
            SelectorOptionsField?.SetValue(_instance, new List<HardwareSelectorOption>());
            _initialized = false;
            _tentativeCpu = null;
        }

        private static void InitializeSelector(HardwareSelectorWindow win)
        {
            if (win == null || _initialized) return;
            ParentCgField?.SetValue(win, win.transform.parent != null ? win.transform.parent.GetComponent<CanvasGroup>() : null);
            if (SelectableButtonsHandler.Instance != null)
                UniqueIdPropSetter?.Invoke(win, new object[] { SelectableButtonsHandler.Instance.GetNewID() });

            foreach (var txt in win.GetComponentsInChildren<TMP_Text>(true))
            {
                if (!string.IsNullOrEmpty(txt?.text) && txt.text.TrimStart().StartsWith("Select", StringComparison.OrdinalIgnoreCase) && txt.GetComponentInParent<ButtonUI>() == null)
                {
                    txt.text = "Select CPU";
                    break;
                }
            }

            if (ShowObsoleteField?.GetValue(win) is ToggleUI obsoleteToggle)
            {
                if (obsoleteToggle.GetComponentInChildren<TMP_Text>(true) != null) obsoleteToggle.Text = "Show Retired";
                obsoleteToggle.IsOn = false;
                obsoleteToggle.Interactable = true;
                obsoleteToggle.OnClick += () => PopulateCpuCards(win);
            }

            if (ShowLicensedField?.GetValue(win) is ToggleUI licensedToggle)
            {
                licensedToggle.IsOn = false;
                licensedToggle.Interactable = false;
            }

            if (SelectButtonField?.GetValue(win) is ButtonUI selectBtn)
            {
                selectBtn.ResetOnClick();
                selectBtn.OnClick += () =>
                {
                    if (_tentativeCpu != null)
                    {
                        VariantCreatorPatch.SelectBaseCpuAndRefresh(_tentativeCpu);
                        _isOpeningForSwitch = false;
                        win.Close();
                    }
                };
            }
            _initialized = true;
        }

        public static void Open(bool isSwitchingExisting)
        {
            EnsureCreated();
            if (_instance == null) return;
            _isOpeningForSwitch = isSwitchingExisting;
            _instance.Open();
        }

        public static void CloseIfOpen()
        {
            if (_instance != null && _instance.gameObject.activeSelf) _instance.Close();
        }

        private static bool HardwareSelectorWindow_Start_Prefix(HardwareSelectorWindow __instance)
        {
            if (_instance == null || __instance != _instance) return true;
            InitializeSelector(__instance);
            return false;
        }

        private static bool HardwareSelectorWindow_Open_Prefix(HardwareSelectorWindow __instance)
        {
            if (_instance == null || __instance != _instance) return true;
            __instance.gameObject.SetActive(true);
            InitializeSelector(__instance);
            PopulateCpuCards(__instance);
            return false;
        }

        private static void HardwareSelectorWindow_Close_Postfix(HardwareSelectorWindow __instance)
        {
            if (_instance == null || __instance != _instance) return;
            if (!_isOpeningForSwitch && VariantCreatorPatch.IsVariantMode && !VariantCreatorPatch.HasConfirmedCpuSelection)
                VariantCreatorPatch.CancelAndCloseCreator();
            _isOpeningForSwitch = false;
        }

        private static void PopulateCpuCards(HardwareSelectorWindow win)
        {
            try
            {
                var optionsList = SelectorOptionsField?.GetValue(win) as List<HardwareSelectorOption>;
                if (optionsList != null)
                {
                    foreach (var opt in optionsList) if (opt != null) UnityEngine.Object.Destroy(opt.gameObject);
                    optionsList.Clear();
                }

                _tentativeCpu = null;
                AnySelectedField?.SetValue(win, false);

                var prefab = PrefabField?.GetValue(win) as HardwareSelectorOption;
                var contentArea = ContentAreaField?.GetValue(win) as Transform;
                if (prefab == null || contentArea == null) return;

                for (int i = contentArea.childCount - 1; i >= 0; i--)
                {
                    var ch = contentArea.GetChild(i);
                    if (ch != null) { ch.SetParent(null, false); UnityEngine.Object.Destroy(ch.gameObject); }
                }

                var obsoleteToggle = ShowObsoleteField?.GetValue(win) as ToggleUI;
                bool showRetired = obsoleteToggle != null && obsoleteToggle.IsOn;
                var baseCpus = Player.Instance?.GetBaseCpus();
                if (baseCpus == null) return;

                int uniqueId = win.UniqueID;
                foreach (var cpu in baseCpus)
                {
                    if (cpu == null || (cpu.IsRetired && !showRetired)) continue;
                    var opt = UnityEngine.Object.Instantiate(prefab, contentArea, false);
                    if (!opt.gameObject.activeSelf) opt.gameObject.SetActive(true);
                    Cpu capturedCpu = cpu;

                    opt.Button?.Initialize(uniqueId, () =>
                    {
                        _tentativeCpu = capturedCpu;
                        AnySelectedField?.SetValue(win, true);
                    });

                    opt.Company = null;
                    opt.HardwareOption = null;
                    opt.SetTexts(BuildCardDescriptions(capturedCpu));
                    opt.InitializeEditButton(null, null);
                    optionsList?.Add(opt);
                }
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogError($"Error populating Select CPU cards: {ex}");
            }
        }

        private static List<string> BuildCardDescriptions(Cpu cpu)
        {
            string arch = cpu.Architecture != null ? cpu.Architecture.Name : "Unknown";
            string socket = cpu.Package != null ? HardwareHelper.PackageName(cpu.Package, cpu.DieSize) : "Unknown";
            string failed = cpu.FailedStock.ToString("N0", CultureInfo.InvariantCulture);
            string goodStock = cpu.Market != null ? StringFormatter.FloatToIntString(cpu.Market.Stock, "", true) : "0";
            return new List<string>
            {
                cpu.Name ?? "CPU",
                $"Architecture: {arch}",
                $"Socket: {socket}",
                $"Defective: {failed}  |  Stock: {goodStock}",
                $"Cores: {cpu.CoreCount} {(cpu.CoreCount == 1 ? "Core" : "Cores")}, {cpu.DieCount} {(cpu.DieCount > 1 ? "Dies" : "Die")}",
                $"MIPS: {StringFormatter.FloatToIps(cpu.Ips)}"
            };
        }
    }
}
