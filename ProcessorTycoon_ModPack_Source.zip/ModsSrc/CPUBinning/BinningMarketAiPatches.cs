using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.AISystem;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Math;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.Save;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace CPUBinning
{
    public static class BinningMarketAiPatches
    {
        private static readonly FieldInfo MarketCpusF = AccessTools.Field(typeof(Market), "cpus");
        private static readonly FieldInfo AiMarketAiF = AccessTools.Field(typeof(AIBehaviourMarket), "ai");
        private static readonly FieldInfo AiMarketCompF = AccessTools.Field(typeof(AIBehaviourMarket), "company");

        internal static bool InMarketSell;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(Market), "CalculateRatings"),
                prefix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_CalculateRatings_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_CalculateRatings_Postfix)),
                finalizer: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_CalculateRatings_Finalizer)));
            harmony.Patch(AccessTools.Method(typeof(Market), "SellCpuToPopulation"),
                prefix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_SellCpuToPopulation_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_SellCpuToPopulation_Postfix)),
                finalizer: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(Market_SellCpuToPopulation_Finalizer)));
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourMarket), "RetireOldCpus"),
                prefix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(AIBehaviourMarket_RetireOldCpus_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourMarket), nameof(AIBehaviourMarket.OnMonthlyTick)),
                postfix: new HarmonyMethod(typeof(BinningMarketAiPatches), nameof(AIBehaviourMarket_OnMonthlyTick_Postfix)));
        }

        private static void Market_CalculateRatings_Prefix(Market __instance, bool ignoreIfOutOfStock, out List<Cpu> __state)
        {
            __state = null;
            if (!ignoreIfOutOfStock || !(MarketCpusF?.GetValue(__instance) is List<Cpu> cpus)) return;
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu?.Base == null) continue;
                int avail = BinningMath.GetVariantMarketAvailableUnits(cpu);
                if (avail > 0)
                {
                    (__state ??= new List<Cpu>()).Add(cpu);
                    cpu.Market.Stock = avail;
                }
            }
        }

        private static void Market_CalculateRatings_Postfix(Market __instance, bool ignoreIfOutOfStock)
        {
            if (!ignoreIfOutOfStock || !(MarketCpusF?.GetValue(__instance) is List<Cpu> cpus)) return;
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu?.Base != null && cpu.Ratings.Overall > 0f && BinningMath.GetVariantMarketAvailableUnits(cpu) <= 0)
                {
                    var r = cpu.Ratings;
                    r.Overall = 0f;
                    cpu.Ratings = r;
                }
            }
        }

        private static void Market_CalculateRatings_Finalizer(List<Cpu> __state)
        {
            if (__state == null) return;
            for (int i = 0; i < __state.Count; i++)
            {
                var cpu = __state[i];
                if (cpu?.Market != null) cpu.Market.Stock = 0;
            }
        }

        private static void Market_SellCpuToPopulation_Prefix(Cpu cpu, out int __state)
        {
            InMarketSell = true;
            __state = cpu != null ? cpu.SoldLastDay : 0;
        }

        private static void Market_SellCpuToPopulation_Finalizer() => InMarketSell = false;

        private static void Market_SellCpuToPopulation_Postfix(Cpu cpu, int __state) =>
            BinningProductionPatches.ChargeVariantAssemblyExpense(cpu, cpu != null ? cpu.SoldLastDay - __state : 0);

        private static bool AIBehaviourMarket_RetireOldCpus_Prefix(AIBehaviourMarket __instance)
        {
            var ai = AiMarketAiF?.GetValue(__instance) as AI;
            if (ai == null) return true;
            var cpus = ai.GetCpus();
            for (int i = cpus.Count - 1; i >= 0; i--)
            {
                var cpu = cpus[i];
                if (cpu == null || cpu.IsRetired) continue;
                bool emptyOrphan = cpu.Base != null && cpu.Base.IsRetired && BinningMath.GetVariantAvailableUnits(cpu) <= 50;
                if (cpu.IsOld(-1, 1) || emptyOrphan)
                {
                    if (ContractHelper.FinesFromContracts(cpu) >= 5000000f) { cpu.SellOnMarket = false; cpu.SellOnContracts = false; }
                    else cpu.TriggerRetirement();
                }
            }
            for (int seg = 0; seg < MarketHelper.SegmentCount; seg++)
            {
                int baseCount = 0, varCount = 0;
                for (int i = cpus.Count - 1; i >= 0; i--)
                {
                    var cpu = cpus[i];
                    if (cpu == null || cpu.IsRetired || cpu.Strategy.TargetMarket != (Segment)seg) continue;
                    bool isVar = cpu.Base != null;
                    if (isVar) varCount++; else baseCount++;
                    if ((!isVar && baseCount > 2) || (isVar && varCount > 1))
                    {
                        if (ContractHelper.FinesFromContracts(cpu) >= 5000000f) { cpu.SellOnMarket = false; cpu.SellOnContracts = false; }
                        else cpu.TriggerRetirement();
                    }
                }
            }
            return false;
        }

        private static bool HasVariantOfKind(List<Cpu> cpus, Cpu baseCpu, bool highBin)
        {
            for (int i = 0; i < cpus.Count; i++)
            {
                var c = cpus[i];
                if (c != null && c.Base == baseCpu && BinningMath.IsHighBin(c) == highBin) return true;
            }
            return false;
        }

        private static void AIBehaviourMarket_OnMonthlyTick_Postfix(AIBehaviourMarket __instance)
        {
            if (!BinningPlugin.IsEnabled || !(BinningPlugin.EnableAiBinning?.Value ?? true)) return;
            if (GameManager.Instance != null && GameManager.Instance.IsLoading) return;
            var ai = AiMarketAiF?.GetValue(__instance) as AI;
            var comp = AiMarketCompF?.GetValue(__instance) as AICompany;
            if (ai == null || comp == null || comp.IsBankrupt || !comp.IsCpuCompany) return;

            var cpus = ai.GetCpus();
            var baseCpus = ai.GetBaseCpus();
            if (cpus == null || baseCpus == null || baseCpus.Count == 0) return;

            int activeVariants = 0;
            for (int i = 0; i < cpus.Count; i++)
                if (cpus[i] != null && !cpus[i].IsRetired && cpus[i].Base != null) activeVariants++;
            if (activeVariants >= 2) return;

            for (int i = baseCpus.Count - 1; i >= 0; i--)
            {
                if (activeVariants >= 2) break;
                var b = baseCpus[i];
                if (b == null || b.IsRetired || b.Base != null || b.Package == null || b.ProcessNode == null || b.Memory == null) continue;
                if (comp.MoneyAmount < 250000f) continue;

                if (b.FailedStock >= 12000 && b.FailureRate >= 0.10f && !HasVariantOfKind(cpus, b, false))
                {
                    Segment lowSeg = b.Strategy.TargetMarket switch
                    {
                        Segment.DesktopHigh => Segment.DesktopLow,
                        Segment.DesktopMid => Segment.DesktopLow,
                        Segment.ServerHigh => Segment.ServerLow,
                        Segment.ServerMid => Segment.ServerLow,
                        Segment.MobileHigh => Segment.MobileLow,
                        Segment.MobileMid => Segment.MobileLow,
                        _ => b.Strategy.TargetMarket
                    };
                    int vCores = b.CoreCount > 2 ? Math.Max(2, b.CoreCount - 2) : 1;
                    bool vSmt = b.CoreCount <= 1 && b.Smt;
                    float vFreq = Mathf.Max(5f, Mathf.Round(b.Frequency * (b.CoreCount > 1 ? 0.90f : 0.85f)));
                    int vL1 = (b.L1Cache / Math.Max(1, b.CoreCount)) * vCores;
                    int vL2 = Mathf.Max(0, (b.L2Cache / Math.Max(1, b.CoreCount)) / 2) * vCores;
                    int vL3 = b.L3Cache >= 64 ? (b.L3Cache / 2 / 32) * 32 : 0;
                    float yield = BinningMath.CalculateBinningYield(b, vCores, vFreq, vL1, vL2, vL3, vSmt);
                    if (yield >= 0.15f)
                    {
                        float devFee = Mathf.Max(50000f, CpuMath.ProjectCost(b.Package, b.ProcessNode, b.Memory, b.Architecture, comp) * 0.25f);
                        if (comp.MoneyAmount >= devFee + 50000f)
                        {
                            comp.SpendMoney(devFee, ExpenseOrigin.Development);
                            SpawnAiBinnedVariant(comp, ai, b, vCores, vFreq, vL1, vL2, vL3, vSmt, 1f - yield, lowSeg, false);
                            activeVariants++;
                            break;
                        }
                    }
                }

                if ((Player.Instance == null || Player.Instance.DifficultyLevel >= 2) &&
                    (b.Strategy.TargetMarket == Segment.DesktopHigh || b.Strategy.TargetMarket == Segment.ServerHigh) &&
                    b.Market?.Stock >= 8000 && b.FailureRate <= 0.45f && b.Price > 0f &&
                    !HasVariantOfKind(cpus, b, true))
                {
                    float bonusScale = BinningPlugin.HighBinBonusScale?.Value ?? 1f;
                    float vFreq = Mathf.Round(b.Frequency * (1f + 0.08f * bonusScale));
                    float yield = BinningMath.CalculateHighBinYield(b, vFreq);
                    if (yield >= 0.08f)
                    {
                        float devFee = Mathf.Max(50000f, CpuMath.ProjectCost(b.Package, b.ProcessNode, b.Memory, b.Architecture, comp) * 0.25f);
                        if (comp.MoneyAmount >= devFee + 50000f)
                        {
                            comp.SpendMoney(devFee, ExpenseOrigin.Development);
                            SpawnAiBinnedVariant(comp, ai, b, b.CoreCount, vFreq, b.L1Cache, b.L2Cache, b.L3Cache, b.Smt, 1f - yield, b.Strategy.TargetMarket, true);
                            activeVariants++;
                            break;
                        }
                    }
                }
            }
        }

        private static void SpawnAiBinnedVariant(AICompany comp, AI ai, Cpu b, int vCores, float vFreq, int vL1, int vL2, int vL3, bool vSmt, float failRate, Segment targetSeg, bool isHighBin)
        {
            if (SaveIDHandler.Instance == null || DateController.Instance == null) return;
            Cpu v = DataConverter.Convert<Cpu>(b);
            v.SaveID = SaveIDHandler.Instance.NewID();
            v.Company = comp;
            v.Base = b;
            v.Architecture = b.Architecture;
            v.Package = b.Package;
            v.ProcessNode = b.ProcessNode;
            v.Memory = b.Memory;
            v.Name = b.Name + (isHighBin ? " XT" : " SE");
            v.Year = DateController.Instance.CurrentDate.Year;
            v.Month = DateController.Instance.CurrentDate.Month;
            v.CoreCount = vCores;
            v.Smt = vSmt;
            v.Frequency = vFreq;
            v.L1Cache = vL1;
            v.L2Cache = vL2;
            v.L3Cache = vL3;
            v.FailureRate = failRate;

            int maxCache = CpuMath.MaxCacheSize(v.Package, v.DieSize, v.DieCount);
            float cacheEff = HardwareMath.TotalCacheKB(vL1, vL2, vL3) > maxCache
                ? CpuMath.CacheEfficiency(vL1, vL2, vL3, maxCache, v.Memory) : 1f;
            v.Ipc = CpuMath.MulticoreIpc(CpuMath.Ipc(v.Architecture, v.Memory, vFreq, v.Transistors, vL1, vL2, vL3, cacheEff, vCores, v.DieCount, vSmt), vL1, vL2, vL3, vCores, v.DieCount, vSmt);
            v.Ips = CpuMath.Ips(vFreq, v.Ipc);
            v.PowerConsumption = CpuMath.Consumption(v.Architecture, v.Package, v.ProcessNode, v.DieSize, vFreq, v.FrequencyTechnology, vCores, v.DieCount, vSmt);
            v.Temperature = CpuMath.Temperature(v.PowerConsumption, v.Package, v.DieCount);
            v.UnitCost = isHighBin
                ? BinningMath.CalculateHighBinDisplayUnitCost(b, v.Package)
                : BinningMath.CalculateVariantAssemblyCost(b, v.Package, v.Memory, v.ProcessNode, vL1, vL2, vL3);
            v.CurrentProductionLines = v.CurrentContractedProductionLines = v.LinesActuallyAllocated = 0;
            v.Market = new CpuBase.MarketData();
            var pops = new List<float>(MarketHelper.SegmentCount);
            for (int i = 0; i < MarketHelper.SegmentCount; i++) pops.Add(0.05f);
            v.Popularities = pops;

            float budget = Market.Instance != null ? Market.Instance.GetSegmentBudget((int)targetSeg) : 150f;
            float price = isHighBin
                ? Mathf.Clamp(Mathf.Round(Mathf.Max(v.UnitCost * 1.45f, b.Price * 1.20f)), 10f, budget * 1.15f)
                : Mathf.Clamp(Mathf.Round(Mathf.Max(v.UnitCost * 1.80f, budget * 0.72f)), 5f, budget * 0.95f);
            v.Price = price;
            v.Strategy = new CpuBase.AIStrategy
            {
                TargetMarket = targetSeg,
                MarketVariant = b.Strategy != null ? b.Strategy.MarketVariant : 0,
                TargetPrice = price
            };
            v.IsReleased = true;
            v.IsRetired = false;
            v.SellOnMarket = true;
            v.SellOnContracts = !isHighBin;
            if (isHighBin) BinningMath.InitializeHighBinOnRelease(v);

            ai.AddCpu(v);
            CpuDataProvider.Instance?.OnNewCpu?.Invoke();
            Market.Instance?.TriggerCache();
        }
    }
}
