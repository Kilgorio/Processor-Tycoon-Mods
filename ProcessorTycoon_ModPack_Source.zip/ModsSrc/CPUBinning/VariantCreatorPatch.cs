using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;

namespace CPUBinning
{
    public static partial class VariantCreatorPatch
    {
        public static bool IsVariantMode { get; private set; }
        public static bool IsHighBinSelected { get; private set; }
        public static bool HasConfirmedCpuSelection { get; private set; }
        public static Cpu SelectedBaseCpu { get; private set; }

        private static bool _pendingOpenVariant, _needsInitialSliderSync, _needsNormalResetOnNextUpdate, _widgetsBuilt, _slidersGeometrySaved;
        private static CreatorCpu _activeCreator;
        private static CreatorWindow _cpuWindow;

        private static GameObject _packageSlot, _lithoSlot, _archSlot, _coreDropdownSlot, _dieDropdownSlot, _isolatedRow2Container, _cpuSelectSlot, _variantTypeSlot;
        private static ButtonUI _memoryOpenBtn, _cpuSelectButton;
        private static TMP_Text _cpuSelectButtonText;
        private static DropdownUI _variantTypeDropdown;
        private static SliderUI _variantDieCountSlider, _variantCoresSlider;

        private static RectTransform _slidersContainerRt;
        private static Vector2 _slidersOrigPos, _slidersOrigSize;
        private static float _slidersOrigSpacing;

        private static readonly MethodInfo UpdateCurrentHwM = AccessTools.Method(typeof(CreatorCpu), "UpdateCurrentHardwares");
        private static readonly MethodInfo UpdateUiM = AccessTools.Method(typeof(CreatorCpu), "UpdateUI");
        private static readonly MethodInfo UpdateCoreCountM = AccessTools.Method(typeof(CreatorCpu), "UpdateCoreCount");
        private static readonly MethodInfo UpdateNumbersM = AccessTools.Method(typeof(CreatorCpu), "UpdateNumbers");

        private static readonly FieldInfo CurrentArchF = AccessTools.Field(typeof(CreatorCpu), "currentArchitecture");
        private static readonly FieldInfo CurrentPkgF = AccessTools.Field(typeof(CreatorCpu), "currentPackage");
        private static readonly FieldInfo LastPkgF = AccessTools.Field(typeof(CreatorCpu), "lastPackage");
        private static readonly FieldInfo CurrentLithoF = AccessTools.Field(typeof(CreatorCpu), "currentLithography");
        private static readonly FieldInfo CurrentMemF = AccessTools.Field(typeof(CreatorCpu), "currentMemory");
        private static readonly FieldInfo NodeMfrF = AccessTools.Field(typeof(CreatorCpu), "nodeManufacturer");
        private static readonly FieldInfo MarkupF = AccessTools.Field(typeof(CreatorCpu), "markupPrice");
        private static readonly FieldInfo WaferSizeF = AccessTools.Field(typeof(CreatorCpu), "waferSize");
        private static readonly FieldInfo NodeYieldF = AccessTools.Field(typeof(CreatorCpu), "currentNodeYield");
        private static readonly FieldInfo MaxFreqF = AccessTools.Field(typeof(CreatorCpu), "maxFrequency");
        private static readonly FieldInfo HasInitF = AccessTools.Field(typeof(CreatorCpu), "hasInitialized");

        private static readonly FieldInfo DieSizeF = AccessTools.Field(typeof(CreatorCpu), "dieSize");
        private static readonly FieldInfo DieCountF = AccessTools.Field(typeof(CreatorCpu), "currentDieCount");
        private static readonly FieldInfo CoreCountF = AccessTools.Field(typeof(CreatorCpu), "currentCoreCount");
        private static readonly FieldInfo TransistorsF = AccessTools.Field(typeof(CreatorCpu), "transistorCount");
        private static readonly FieldInfo FreqF = AccessTools.Field(typeof(CreatorCpu), "frequency");
        private static readonly FieldInfo L1F = AccessTools.Field(typeof(CreatorCpu), "l1Cache");
        private static readonly FieldInfo L2F = AccessTools.Field(typeof(CreatorCpu), "l2Cache");
        private static readonly FieldInfo L3F = AccessTools.Field(typeof(CreatorCpu), "l3Cache");
        private static readonly FieldInfo SmtF = AccessTools.Field(typeof(CreatorCpu), "smtEnabled");
        private static readonly FieldInfo ConsF = AccessTools.Field(typeof(CreatorCpu), "consumption");
        private static readonly FieldInfo TempF = AccessTools.Field(typeof(CreatorCpu), "temperature");
        private static readonly FieldInfo IpcF = AccessTools.Field(typeof(CreatorCpu), "ipc");
        private static readonly FieldInfo IpsF = AccessTools.Field(typeof(CreatorCpu), "ips");
        private static readonly FieldInfo FailRateF = AccessTools.Field(typeof(CreatorCpu), "failureRate");
        private static readonly FieldInfo DiesPerWaferF = AccessTools.Field(typeof(CreatorCpu), "diesPerWafer");
        private static readonly FieldInfo HighestDiesF = AccessTools.Field(typeof(CreatorCpu), "highestDiesPerWafer");

        private static readonly FieldInfo NameInputF = AccessTools.Field(typeof(CreatorCpu), "nameInput");
        private static readonly FieldInfo CoreDropF = AccessTools.Field(typeof(CreatorCpu), "coreCountDropdown");
        private static readonly FieldInfo DieDropF = AccessTools.Field(typeof(CreatorCpu), "dieCountDropdown");
        private static readonly FieldInfo DieSizeSliderF = AccessTools.Field(typeof(CreatorCpu), "dieSizeSlider");
        private static readonly FieldInfo FreqSliderF = AccessTools.Field(typeof(CreatorCpu), "frequencySlider");
        private static readonly FieldInfo L1SliderF = AccessTools.Field(typeof(CreatorCpu), "l1CacheSlider");
        private static readonly FieldInfo L2SliderF = AccessTools.Field(typeof(CreatorCpu), "l2CacheSlider");
        private static readonly FieldInfo L3SliderF = AccessTools.Field(typeof(CreatorCpu), "l3CacheSlider");
        private static readonly FieldInfo OverclockToggleF = AccessTools.Field(typeof(CreatorCpu), "overclockToggle");
        private static readonly FieldInfo SmtToggleF = AccessTools.Field(typeof(CreatorCpu), "smtToggle");
        private static readonly FieldInfo AutoCacheToggleF = AccessTools.Field(typeof(CreatorCpu), "automateCacheToggle");
        private static readonly FieldInfo CreateBtnF = AccessTools.Field(typeof(CreatorCpu), "createCpuButton");
        private static readonly FieldInfo UnitCostTextF = AccessTools.Field(typeof(CreatorCpu), "unitCostText");
        private static readonly FieldInfo ProjectCostTextF = AccessTools.Field(typeof(CreatorCpu), "projectCostText");
        private static readonly FieldInfo ProjectTimeTextF = AccessTools.Field(typeof(CreatorCpu), "projectTimeText");
        private static readonly FieldInfo ConclusionDateTextF = AccessTools.Field(typeof(CreatorCpu), "conclusionDateText");
        private static readonly FieldInfo YieldRateTextF = AccessTools.Field(typeof(CreatorCpu), "yieldRateText");
        private static readonly FieldInfo MemMipsTextF = AccessTools.Field(typeof(CreatorCpu), "memoryButtonMipsText");
        private static readonly FieldInfo SliderValuesF = AccessTools.Field(typeof(SliderUI), "values");

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "Initialize"), postfix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(Initialize_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "UpdateCurrentHardwares"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(UpdateCurrentHardwares_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "UpdateUI"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(UpdateUI_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "DieSize"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(DieSize_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "UpdateCoreCount"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(UpdateCoreCount_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "AutomateCache"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(AutomateCache_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "Memory"), postfix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(Memory_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "ConsumptionAndTemperature"), postfix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(ConsumptionAndTemperature_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "FailureRate"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(FailureRate_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "UpdateInfoTexts"), postfix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(UpdateInfoTexts_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "HandleCreateButton"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(HandleCreateButton_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "CreateCpu"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(CreateCpu_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpuConfirmationWindow), "Open"), prefix: new HarmonyMethod(typeof(VariantCreatorPatch), nameof(ConfirmationWindow_Open_Prefix)));
        }

        public static void StartNewVariantFlow()
        {
            var baseCpus = Player.Instance?.GetBaseCpus();
            if (baseCpus == null || baseCpus.Count == 0) return;

            Cpu picked = null;
            for (int i = baseCpus.Count - 1; i >= 0; i--)
            {
                if (baseCpus[i] != null && !baseCpus[i].IsRetired) { picked = baseCpus[i]; break; }
            }
            SelectedBaseCpu = picked ?? baseCpus[baseCpus.Count - 1];
            HasConfirmedCpuSelection = false;
            IsVariantMode = true;
            IsHighBinSelected = false;
            _pendingOpenVariant = true;
            _needsInitialSliderSync = true;

            CreatorManager.Instance.OpenCreatorWindowOfType(CreatorWindow.Type.Cpu);
            CpuSelectorWindow.Open(isSwitchingExisting: false);
        }

        public static void SelectBaseCpuAndRefresh(Cpu cpu)
        {
            if (cpu == null) return;
            SelectedBaseCpu = cpu;
            HasConfirmedCpuSelection = true;
            IsVariantMode = true;
            _needsInitialSliderSync = true;

            if (_activeCreator != null)
            {
                UpdateCurrentHwM?.Invoke(_activeCreator, null);
                UpdateUiM?.Invoke(_activeCreator, new object[] { true });
                UpdateCoreCountM?.Invoke(_activeCreator, null);
                UpdateNumbersM?.Invoke(_activeCreator, null);
            }
        }

        public static void CancelAndCloseCreator()
        {
            IsVariantMode = IsHighBinSelected = HasConfirmedCpuSelection = _pendingOpenVariant = false;
            SelectedBaseCpu = null;
            CreatorManager.Instance?.CloseWindowOfType(CreatorWindow.Type.Cpu);
        }

        public static void ForceExitOnDisable()
        {
            bool wasVariant = IsVariantMode || _needsNormalResetOnNextUpdate;
            IsVariantMode = IsHighBinSelected = HasConfirmedCpuSelection = _pendingOpenVariant = false;
            SelectedBaseCpu = null;
            if (wasVariant && _activeCreator != null)
            {
                PrepareNormalModeReset(_activeCreator);
                ApplyLayoutMode(_activeCreator, false);
            }
        }

        private static void Initialize_Postfix(CreatorCpu __instance)
        {
            _activeCreator = __instance;
            _widgetsBuilt = IsHighBinSelected = _slidersGeometrySaved = false;
            _packageSlot = _lithoSlot = _archSlot = _coreDropdownSlot = _dieDropdownSlot = _isolatedRow2Container = _cpuSelectSlot = _variantTypeSlot = null;
            _variantDieCountSlider = _variantCoresSlider = null;

            _cpuWindow = CreatorManager.Instance.GetWindowOfType(CreatorWindow.Type.Cpu);
            if (_cpuWindow == null) return;

            _cpuWindow.OnOpen += () =>
            {
                if (_pendingOpenVariant)
                {
                    _pendingOpenVariant = false;
                    IsVariantMode = _needsInitialSliderSync = true;
                    IsHighBinSelected = false;
                }
                else
                {
                    IsVariantMode = IsHighBinSelected = HasConfirmedCpuSelection = false;
                    SelectedBaseCpu = null;
                }
            };

            _cpuWindow.OnClose += () =>
            {
                CpuSelectorWindow.CloseIfOpen();
                bool wasVariant = IsVariantMode || _needsNormalResetOnNextUpdate;
                IsVariantMode = IsHighBinSelected = HasConfirmedCpuSelection = false;
                SelectedBaseCpu = null;
                if (wasVariant)
                {
                    PrepareNormalModeReset(__instance);
                    ApplyLayoutMode(__instance, false);
                }
            };
        }
    }
}
