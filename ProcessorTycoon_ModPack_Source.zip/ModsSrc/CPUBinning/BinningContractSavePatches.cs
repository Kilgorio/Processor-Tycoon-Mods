using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.ContractSystem.Automation;
using ProcessorTycoon.ContractSystem.UI;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Production.Math;
using ProcessorTycoon.Save;
using ProcessorTycoon.UI;
using UnityEngine;

namespace CPUBinning
{
    public static class BinningContractSavePatches
    {
        private static readonly FieldInfo ContractSellerCpusF = AccessTools.Field(typeof(ContractSeller), "cpus");
        private static readonly FieldInfo ContractWinCurrentContractF = AccessTools.Field(typeof(ContractWindow), "currentContract");
        private static readonly FieldInfo ContractWinLinesTextF = AccessTools.Field(typeof(ContractWindow), "contractProductionLinesText");
        private static readonly FieldInfo ContractWinCpuFailedF = AccessTools.Field(typeof(ContractWindow), "cpuFailedAtAnyRequirement");
        private static readonly MethodInfo ContractWinUpdateProbM = AccessTools.Method(typeof(ContractWindow), "UpdateProbabilityText");
        private static readonly MethodInfo ContractWinUpdateButtonsM = AccessTools.Method(typeof(ContractWindow), "UpdateSendOfferButtons");

        private static readonly List<(Cpu cpu, int baseId)> DeferredBaseLinks = new List<(Cpu, int)>();
        private static readonly Dictionary<int, int> AutoOfferReservedMonthly = new Dictionary<int, int>();
        private static SaveHandler _hookedSaveHandler;
        private static string _pendingLoadSaveName;
        private static bool _inAutoSendOffers;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(ProductionMath), nameof(ProductionMath.RequiredProductionLines)),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ProductionMath_RequiredProductionLines_Prefix)) { priority = Priority.High });
            harmony.Patch(AccessTools.Method(typeof(Contract), nameof(Contract.FailsAtAnyRequirement)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(Contract_FailsAtAnyRequirement_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(Contract), "ChooseCpu"),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(Contract_ChooseCpu_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Contract), nameof(Contract.AddOffer)),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(Contract_AddOffer_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(Contract_AddOffer_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ContractAutomation), "SendOffers"),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractAutomation_SendOffers_Prefix)),
                finalizer: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractAutomation_SendOffers_Finalizer)));
            harmony.Patch(AccessTools.Method(typeof(ContractWindow), "UpdateCurrentCpu"),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractWindow_UpdateCurrentCpu_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ContractSeller), "SellContracts"),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractSeller_SellContracts_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractSeller_SellContracts_Postfix)),
                finalizer: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(ContractSeller_SellContracts_Finalizer)));

            harmony.Patch(AccessTools.Method(typeof(DataConverter), nameof(DataConverter.SaveObjectToCpu)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(DataConverter_SaveObjectToCpu_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Save)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(SaveHandler_Save_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Load)),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(SaveHandler_Load_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(SaveHandler_Load_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(Player), nameof(Player.InitializeAsNewGame)),
                prefix: new HarmonyMethod(typeof(BinningContractSavePatches), nameof(Player_NewGame_Prefix)));
        }

        public static void UnsubscribeSaveEvents()
        {
            if (_hookedSaveHandler == null) return;
            _hookedSaveHandler.DuringLoad -= OnDuringLoad;
            _hookedSaveHandler.OnLoaded -= OnSaveLoaded;
            _hookedSaveHandler = null;
        }

        private static bool ProductionMath_RequiredProductionLines_Prefix(Cpu cpu, ref int __result)
        {
            if (cpu?.Base == null) return true;
            __result = 0;
            return false;
        }

        private static void Contract_FailsAtAnyRequirement_Postfix(Contract __instance, Cpu cpu, ref bool __result)
        {
            if (__result || cpu?.Base == null || __instance == null) return;
            int extra = _inAutoSendOffers && AutoOfferReservedMonthly.TryGetValue(cpu.SaveID, out int r) ? r : 0;
            if (!BinningMath.CanBinnedCpuSupplyContract(cpu, __instance, extra)) __result = true;
        }

        private static void Contract_ChooseCpu_Prefix(Contract __instance)
        {
            if (__instance?.OffersIDs == null || CpuDataProvider.Instance == null || Player.Instance == null) return;
            for (int i = __instance.OffersIDs.Count - 1; i >= 0; i--)
            {
                Cpu cpu = CpuDataProvider.Instance.GetCpu(__instance.OffersIDs[i]);
                if (cpu?.Base == null || cpu.Company == null) continue;
                bool canAutoReject = (cpu.Company.IsPlayer && Player.Instance.AutomateRejection) || !cpu.Company.IsPlayer;
                if (canAutoReject && !BinningMath.CanBinnedCpuSupplyContract(cpu, __instance))
                    __instance.OffersIDs.RemoveAt(i);
            }
        }

        private static void Contract_AddOffer_Prefix(Contract __instance, int cpuID, out bool __state) =>
            __state = _inAutoSendOffers && __instance?.OffersIDs != null && __instance.OffersIDs.Contains(cpuID);

        private static void Contract_AddOffer_Postfix(Contract __instance, int cpuID, bool __state)
        {
            if (!_inAutoSendOffers || __state || __instance?.OffersIDs == null || !__instance.OffersIDs.Contains(cpuID)) return;
            Cpu cpu = CpuDataProvider.Instance?.GetCpu(cpuID);
            if (cpu?.Base != null)
                AutoOfferReservedMonthly[cpuID] = (AutoOfferReservedMonthly.TryGetValue(cpuID, out int cur) ? cur : 0) + Math.Max(0, __instance.Units);
        }

        private static void ContractAutomation_SendOffers_Prefix() { _inAutoSendOffers = true; AutoOfferReservedMonthly.Clear(); }
        private static void ContractAutomation_SendOffers_Finalizer() { _inAutoSendOffers = false; AutoOfferReservedMonthly.Clear(); }

        private static void ContractWindow_UpdateCurrentCpu_Postfix(ContractWindow __instance, Cpu cpu)
        {
            if (__instance == null || cpu == null || !(ContractWinCurrentContractF?.GetValue(__instance) is Contract contract)) return;
            var linesText = ContractWinLinesTextF?.GetValue(__instance) as InfoText;
            if (cpu.Base == null) { linesText?.UpdateColor(false); return; }

            int freeIncoming = Mathf.Max(0, Mathf.RoundToInt(BinningMath.GetVariantMonthlyIncomingSupply(cpu, contract)) - BinningMath.GetActiveContractsMonthlyDemand(cpu, contract));
            int availStock = BinningMath.GetVariantAvailableUnits(cpu);
            bool canSupply = BinningMath.CanBinnedCpuSupplyContract(cpu, contract);
            string capStr = freeIncoming > 0 ? StringFormatter.FloatToIntString(freeIncoming, "", true) + "/m"
                : (availStock > 0 ? StringFormatter.FloatToIntString(availStock, "", true) + " stock" : "0/m");

            if (linesText != null)
            {
                linesText.Text = canSupply ? $"Binned ({capStr})" : $"Low Supply ({capStr})";
                if (canSupply) linesText.UpdateColor(false);
                else linesText.SetVariableColor(Colors.Instance.DynamicNegativeColor(), true);
            }
            if (!canSupply)
            {
                ContractWinCpuFailedF?.SetValue(__instance, true);
                ContractWinUpdateProbM?.Invoke(__instance, null);
                ContractWinUpdateButtonsM?.Invoke(__instance, null);
            }
        }

        private static void ContractSeller_SellContracts_Prefix(ContractSeller __instance, out List<(Cpu cpu, int tempStock)> __state)
        {
            __state = null;
            if (!(ContractSellerCpusF?.GetValue(__instance) is List<Cpu> cpus)) return;
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu?.Base == null || cpu.TodayDemandByContracts <= 0) continue;
                int avail = BinningMath.GetVariantAvailableUnits(cpu);
                if (avail > 0)
                {
                    (__state ??= new List<(Cpu, int)>()).Add((cpu, avail));
                    cpu.Market.Stock = avail;
                }
            }
        }

        private static void ContractSeller_SellContracts_Postfix(List<(Cpu cpu, int tempStock)> __state)
        {
            if (__state == null) return;
            for (int i = 0; i < __state.Count; i++)
            {
                var item = __state[i];
                var cpu = item.cpu;
                if (cpu?.Market == null) continue;
                int delivered = item.tempStock - cpu.Market.Stock;
                cpu.Market.Stock = 0;
                if (delivered > 0)
                {
                    BinningMath.ConsumeVariantStock(cpu, delivered);
                    BinningProductionPatches.ChargeVariantAssemblyExpense(cpu, delivered);
                }
            }
            __state.Clear();
        }

        private static void ContractSeller_SellContracts_Finalizer(List<(Cpu cpu, int tempStock)> __state, Exception __exception)
        {
            if (__exception == null || __state == null) return;
            for (int i = 0; i < __state.Count; i++)
                if (__state[i].cpu?.Market != null) __state[i].cpu.Market.Stock = 0;
        }

        private static void DataConverter_SaveObjectToCpu_Postfix(SaveObject.Cpu saveCpu, Cpu __result)
        {
            if (__result != null && saveCpu != null && saveCpu.BaseID >= 0 && __result.Base == null)
                DeferredBaseLinks.Add((__result, saveCpu.BaseID));
        }

        private static void SaveHandler_Save_Postfix(string saveName) =>
            BinningMath.SaveHighBinPoolsForSaveFile(saveName, DataFinder.FindAllCpus());

        private static void ResetRuntimeOnly()
        {
            BinningMath.ClearRuntimeState();
            AutoOfferReservedMonthly.Clear();
            BinningMarketAiPatches.InMarketSell = _inAutoSendOffers = false;
        }

        private static void Player_NewGame_Prefix()
        {
            ResetRuntimeOnly();
            DeferredBaseLinks.Clear();
        }

        private static void SaveHandler_Load_Prefix()
        {
            DeferredBaseLinks.Clear();
        }

        private static void SaveHandler_Load_Postfix(SaveHandler __instance, string fileName)
        {
            _pendingLoadSaveName = fileName;
            if (__instance == null) return;
            UnsubscribeSaveEvents();
            _hookedSaveHandler = __instance;
            __instance.DuringLoad += OnDuringLoad;
            __instance.OnLoaded += OnSaveLoaded;
        }

        private static void OnDuringLoad()
        {
            ResetRuntimeOnly();
            for (int i = 0; i < DeferredBaseLinks.Count; i++)
            {
                var entry = DeferredBaseLinks[i];
                if (entry.cpu != null && entry.cpu.Base == null)
                {
                    entry.cpu.Base = DataFinder.FindCpu(entry.baseId);
                    if (entry.cpu.Base != null) entry.cpu.Company?.Owner?.GetBaseCpus()?.Remove(entry.cpu);
                }
            }
            DeferredBaseLinks.Clear();
        }

        private static void OnSaveLoaded() =>
            BinningMath.LoadHighBinPoolsForSaveFile(_pendingLoadSaveName, DataFinder.FindAllCpus());
    }
}
