using System;
using System.Globalization;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.Hardware.Math;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.Save;
using ProcessorTycoon.TimeSystem;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;

namespace CPUBinning
{
    public static partial class VariantCreatorPatch
    {
        private static bool UpdateCurrentHardwares_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            _activeCreator = __instance;

            CurrentArchF.SetValue(__instance, SelectedBaseCpu.Architecture);
            CurrentPkgF.SetValue(__instance, SelectedBaseCpu.Package);
            CurrentLithoF.SetValue(__instance, SelectedBaseCpu.ProcessNode);
            CurrentMemF.SetValue(__instance, SelectedBaseCpu.Memory);

            var mfr = SelectedBaseCpu.Manufacturer ?? Player.Instance.Company;
            NodeMfrF.SetValue(__instance, mfr);
            NodeYieldF.SetValue(__instance, mfr.CurrentNodeYield(SelectedBaseCpu.ProcessNode));
            MarkupF.SetValue(__instance, 1f);
            WaferSizeF.SetValue(__instance, mfr.CurrentWaferSize);
            return false;
        }

        private static bool DieSize_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            var b = SelectedBaseCpu;
            DieSizeF.SetValue(__instance, b.DieSize);
            DieCountF.SetValue(__instance, Math.Max(1, b.DieCount));
            TransistorsF.SetValue(__instance, b.Transistors);
            DiesPerWaferF.SetValue(__instance, 1f);
            HighestDiesF.SetValue(__instance, 1f);
            return false;
        }

        private static bool UpdateCoreCount_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            DieCountF.SetValue(__instance, Math.Max(1, SelectedBaseCpu.DieCount));
            if (_variantCoresSlider != null)
            {
                int cores = Mathf.Max(1, Mathf.RoundToInt(_variantCoresSlider.Value));
                CoreCountF.SetValue(__instance, cores);
                _variantCoresSlider.Text = cores == 1 ? "1 Core" : $"{cores} Cores";
            }
            return false;
        }

        private static bool AutomateCache_Prefix() => !IsVariantMode;

        private static void Memory_Postfix(CreatorCpu __instance)
        {
            if (IsVariantMode && SelectedBaseCpu != null && SelectedBaseCpu.L3Cache <= 0 && L3SliderF.GetValue(__instance) is SliderUI l3Slider)
                l3Slider.Text = "0 KB";
        }

        private static void ConsumptionAndTemperature_Postfix(CreatorCpu __instance)
        {
            if (!IsVariantMode || !IsHighBinSelected || SelectedBaseCpu == null) return;
            float cons = (float)ConsF.GetValue(__instance) * 0.88f;
            ConsF.SetValue(__instance, cons);
            if (SelectedBaseCpu.Package != null)
                TempF.SetValue(__instance, CpuMath.Temperature(cons, SelectedBaseCpu.Package, Math.Max(1, SelectedBaseCpu.DieCount)));
        }

        private static bool FailureRate_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            float freq = (float)FreqF.GetValue(__instance);
            float binningYield = IsHighBinSelected
                ? BinningMath.CalculateHighBinYield(SelectedBaseCpu, freq)
                : BinningMath.CalculateBinningYield(SelectedBaseCpu, Mathf.Max(1, (int)CoreCountF.GetValue(__instance)), freq,
                    (int)L1F.GetValue(__instance), (int)L2F.GetValue(__instance), (int)L3F.GetValue(__instance), (bool)SmtF.GetValue(__instance));
            FailRateF.SetValue(__instance, 1f - binningYield);
            return false;
        }

        private static void UpdateInfoTexts_Postfix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return;
            var b = SelectedBaseCpu;
            float binningYield = Mathf.Clamp01(1f - (float)FailRateF.GetValue(__instance));

            var costInfo = ProjectCostTextF.GetValue(__instance) as InfoText;
            var timeInfo = ProjectTimeTextF.GetValue(__instance) as InfoText;
            var dateInfo = ConclusionDateTextF.GetValue(__instance) as InfoText;
            var unitCostText = UnitCostTextF.GetValue(__instance) as InfoText;
            if (dateInfo != null && dateInfo.gameObject.activeSelf) dateInfo.gameObject.SetActive(false);

            if (IsHighBinSelected)
            {
                int stock = b.Market != null ? b.Market.Stock : 0;
                int monthlyProd = Mathf.Max(0, b.ProducedLastDay * 30);
                int initPool = Mathf.FloorToInt(stock * binningYield);
                int monthlyHigh = Mathf.RoundToInt(monthlyProd * binningYield);
                bool viable = binningYield > 0f && (!b.IsRetired || initPool > 0);

                if (costInfo != null)
                {
                    costInfo.Title = "Base Supply";
                    costInfo.Text = (stock > 0 && monthlyProd > 0)
                        ? $"{StringFormatter.FloatToIntString(stock, "", true)} (+{StringFormatter.FloatToIntString(monthlyProd, "", true)}/m)"
                        : (monthlyProd > 0 ? $"{StringFormatter.FloatToIntString(monthlyProd, "", true)}/m" : stock.ToString("N0", CultureInfo.InvariantCulture));
                }
                if (timeInfo != null)
                {
                    timeInfo.Title = "High Bin Supply";
                    timeInfo.Text = binningYield <= 0f ? "0" :
                        (initPool > 0 && monthlyHigh > 0) ? $"{StringFormatter.FloatToIntString(initPool, "", true)} (+{StringFormatter.FloatToIntString(monthlyHigh, "", true)}/m)" :
                        monthlyHigh > 0 ? $"{StringFormatter.FloatToIntString(monthlyHigh, "", true)}/m" :
                        initPool > 0 ? initPool.ToString("N0", CultureInfo.InvariantCulture) :
                        $"{StringFormatter.FloatToPercentageString(binningYield)} of output";
                }
                if (unitCostText != null)
                    unitCostText.Text = viable ? StringFormatter.FloatToMoney(BinningMath.CalculateHighBinDisplayUnitCost(b, b.Package)) : "Not Enough Units";
            }
            else
            {
                int usableUnits = Mathf.FloorToInt(b.FailedStock * binningYield);
                if (costInfo != null) { costInfo.Title = "Defective Units"; costInfo.Text = b.FailedStock.ToString("N0", CultureInfo.InvariantCulture); }
                if (timeInfo != null) { timeInfo.Title = "Usable Units"; timeInfo.Text = usableUnits.ToString("N0", CultureInfo.InvariantCulture); }
                if (unitCostText != null)
                {
                    unitCostText.Text = usableUnits <= 0 ? "Not Enough Units"
                        : StringFormatter.FloatToMoney(BinningMath.CalculateVariantAssemblyCost(
                            b, CurrentPkgF.GetValue(__instance) as IPackage, CurrentMemF.GetValue(__instance) as Memory,
                            CurrentLithoF.GetValue(__instance) as ProcessNode, (int)L1F.GetValue(__instance), (int)L2F.GetValue(__instance), (int)L3F.GetValue(__instance)));
                }
            }
        }

        private static bool HandleCreateButton_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            var createBtn = CreateBtnF.GetValue(__instance) as ButtonUI;
            if (createBtn == null) return false;

            var nameInput = NameInputF.GetValue(__instance) as TMP_InputField;
            bool hasName = nameInput != null && !string.IsNullOrWhiteSpace(nameInput.text);
            float yield = Mathf.Clamp01(1f - (float)FailRateF.GetValue(__instance));
            bool hasUnits = IsHighBinSelected
                ? (yield > 0f && (!SelectedBaseCpu.IsRetired || (SelectedBaseCpu.Market != null && Mathf.FloorToInt(SelectedBaseCpu.Market.Stock * yield) > 0)))
                : Mathf.FloorToInt(SelectedBaseCpu.FailedStock * yield) > 0;

            createBtn.Interactable = hasName && hasUnits;
            return false;
        }

        private static bool ConfirmationWindow_Open_Prefix(Action onConfirm)
        {
            if (!IsVariantMode) return true;
            onConfirm?.Invoke();
            return false;
        }

        private static bool CreateCpu_Prefix(CreatorCpu __instance)
        {
            if (!IsVariantMode || SelectedBaseCpu == null) return true;
            try
            {
                var b = SelectedBaseCpu;
                var nameInput = NameInputF.GetValue(__instance) as TMP_InputField;
                string cpuName = nameInput != null ? nameInput.text.Trim() : $"{b.Name} Variant";

                int cores = Mathf.Max(1, (int)CoreCountF.GetValue(__instance));
                int dies = Math.Max(1, (int)DieCountF.GetValue(__instance));
                float freq = (float)FreqF.GetValue(__instance);
                int l1 = (int)L1F.GetValue(__instance), l2 = (int)L2F.GetValue(__instance), l3 = (int)L3F.GetValue(__instance);
                bool smt = (bool)SmtF.GetValue(__instance);
                float cons = (float)ConsF.GetValue(__instance), temp = (float)TempF.GetValue(__instance);
                float ipc = (float)IpcF.GetValue(__instance), ips = (float)IpsF.GetValue(__instance);
                float failureRate = (float)FailRateF.GetValue(__instance);

                float unitCost = IsHighBinSelected
                    ? BinningMath.CalculateHighBinDisplayUnitCost(b, b.Package)
                    : BinningMath.CalculateVariantAssemblyCost(b, b.Package, b.Memory, b.ProcessNode, l1, l2, l3);

                Cpu variant = new Cpu
                {
                    SaveID = SaveIDHandler.Instance.NewID(), Name = cpuName, Base = b, Company = Player.Instance.Company,
                    OutsourcedID = -1, DieSize = b.DieSize, DieCount = dies, Transistors = b.Transistors,
                    PowerConsumption = cons, ThermalEfficiency = b.ThermalEfficiency, Temperature = temp,
                    Frequency = freq, FrequencyTechnology = b.FrequencyTechnology, CoreCount = cores, Smt = smt,
                    L1Cache = l1, L2Cache = l2, L3Cache = l3, Ipc = ipc, Ips = ips, UnitCost = unitCost, FailureRate = failureRate,
                    Architecture = b.Architecture, Package = b.Package, ProcessNode = b.ProcessNode, Memory = b.Memory,
                    Year = DateController.Instance.CurrentDate.Year, Month = DateController.Instance.CurrentDate.Month,
                    Market = new CpuBase.MarketData(), Strategy = new CpuBase.AIStrategy()
                };

                if (IsHighBinSelected) BinningMath.InitializeHighBinOnRelease(variant);
                ProjectCompletedHandler.Instance.AddCpu(variant);

                IsVariantMode = IsHighBinSelected = HasConfirmedCpuSelection = false;
                SelectedBaseCpu = null;
                PrepareNormalModeReset(__instance);
                ApplyLayoutMode(__instance, false);
                return false;
            }
            catch (Exception ex)
            {
                BinningPlugin.Log.LogError($"Error creating CPU variant: {ex}");
                return false;
            }
        }
    }
}
