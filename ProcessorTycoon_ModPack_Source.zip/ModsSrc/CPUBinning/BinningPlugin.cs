using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace CPUBinning
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class BinningPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.proctycoon.cpubinning";
        public const string PluginName = "CPU Binning & Variants";
        public const string PluginVersion = "2.0.0";

        internal static ManualLogSource Log;
        private static Harmony _harmony;
        private static bool _patchesApplied;

        public static ConfigEntry<bool> ModEnabled { get; private set; }
        public static ConfigEntry<float> HighBinBonusScale { get; private set; }
        public static ConfigEntry<float> LowBinYieldRecoveryScale { get; private set; }
        public static ConfigEntry<bool> EnableAiBinning { get; private set; }

        public static bool IsEnabled => ModEnabled == null || ModEnabled.Value;

        private void Awake()
        {
            Log = Logger;
            _harmony = new Harmony(PluginGuid);

            ModEnabled = Config.Bind("1. General", "Enabled", true,
                "Enable CPU Silicon Binning & Chiplet Variants mod.");
            HighBinBonusScale = Config.Bind("2. Balance", "HighBinClockIpcScale", 1.0f,
                new ConfigDescription("Multiplier for High-Bin (XT/KS) frequency headroom & selection yield.",
                    new AcceptableValueRange<float>(0.25f, 2.5f)));
            LowBinYieldRecoveryScale = Config.Bind("2. Balance", "LowBinYieldRecoveryScale", 1.0f,
                new ConfigDescription("Multiplier for defective silicon yield recovery on Low-Bin (SE) variants.",
                    new AcceptableValueRange<float>(0.25f, 2.0f)));
            EnableAiBinning = Config.Bind("3. AI", "EnableAiBinning", true,
                "Allow AI companies to create Salvage (SE) and Flagship (XT) binned CPU variants.");

            ModEnabled.SettingChanged += (_, _) => ApplyEnabledState(ModEnabled.Value);

            if (ModEnabled.Value)
                ApplyEnabledState(true);
            else
                Log.LogInfo($"{PluginName} v{PluginVersion} loaded (disabled by config).");
        }

        private void OnDestroy()
        {
            BinningContractSavePatches.UnsubscribeSaveEvents();
            VariantCreatorPatch.ForceExitOnDisable();
            CpuSelectorWindow.CloseIfOpen();
            if (_patchesApplied && _harmony != null)
            {
                _harmony.UnpatchSelf();
                _patchesApplied = false;
            }
        }

        public static void ApplyEnabledState(bool enable)
        {
            try
            {
                if (enable && !_patchesApplied)
                {
                    CreateHardwareHook.ApplyPatches(_harmony);
                    CpuSelectorWindow.ApplyPatches(_harmony);
                    VariantCreatorPatch.ApplyPatches(_harmony);
                    BinningProductionPatches.ApplyPatches(_harmony);
                    BinningMarketAiPatches.ApplyPatches(_harmony);
                    BinningContractSavePatches.ApplyPatches(_harmony);
                    _patchesApplied = true;
                    CreateHardwareHook.SetButtonVisible(true);
                    Log.LogInfo($"{PluginName} v{PluginVersion} enabled cleanly.");
                }
                else if (!enable && _patchesApplied)
                {
                    BinningContractSavePatches.UnsubscribeSaveEvents();
                    VariantCreatorPatch.ForceExitOnDisable();
                    CpuSelectorWindow.CloseIfOpen();
                    CreateHardwareHook.SetButtonVisible(false);
                    _harmony.UnpatchSelf();
                    _patchesApplied = false;
                    Log.LogInfo($"{PluginName} v{PluginVersion} disabled live.");
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed toggling {PluginName}: {ex}");
            }
        }
    }
}
