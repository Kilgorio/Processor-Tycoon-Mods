using System;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Math;
using ProcessorTycoon.MarketSystem.UI;
using ProcessorTycoon.Production;
using ProcessorTycoon.Production.UI;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;

namespace CPUBinning
{
    public static class BinningProductionPatches
    {
        private static readonly FieldInfo ProductionUiCpuF = AccessTools.Field(typeof(ProductionUI), "cpu");
        private static readonly FieldInfo ProductionUiSliderF = AccessTools.Field(typeof(ProductionUI), "productionLinesSlider");
        private static readonly FieldInfo ProductionUiProdTextF = AccessTools.Field(typeof(ProductionUI), "productionText");
        private static readonly FieldInfo ProductionUiDemandTextF = AccessTools.Field(typeof(ProductionUI), "demandText");
        private static readonly FieldInfo ProductionUiStockTextF = AccessTools.Field(typeof(ProductionUI), "stockText");
        private static readonly FieldInfo ProductionUiBalanceTextF = AccessTools.Field(typeof(ProductionUI), "balanceText");
        private static readonly FieldInfo ProductionUiInfoTextF = AccessTools.Field(typeof(ProductionUI), "additionalCpuInfoText");

        private static readonly FieldInfo ReleasePriceInputF = AccessTools.Field(typeof(ProjectReleaseWindow), "priceInput");
        private static readonly MethodInfo ReleaseValidatePriceM = AccessTools.Method(typeof(ProjectReleaseWindow), "ValidatePrice");
        private static readonly FieldInfo SalesUiPrefabF = AccessTools.Field(typeof(CpuSalesUIInstantiator), "cpuSalesUIPrefab");
        private static readonly FieldInfo SalesUiVarPrefabF = AccessTools.Field(typeof(CpuSalesUIInstantiator), "cpuSalesUIPrefabVariant");

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(Cpu), nameof(Cpu.UnitsFromFailedStock)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Cpu_UnitsFromFailedStock_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Factory), nameof(Factory.ProduceWafers)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Factory_ProduceWafers_Prefix)),
                postfix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Factory_ProduceWafers_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(Cpu), nameof(Cpu.TriggerRetirement)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Cpu_TriggerRetirement_Prefix)));

            harmony.Patch(AccessTools.PropertyGetter(typeof(Cpu), nameof(Cpu.RealUnitCost)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Cpu_RealUnitCost_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Cpu), nameof(Cpu.RealUnitCostWithNewPrice)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(Cpu_RealUnitCostWithNewPrice_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CpuMath), nameof(CpuMath.LowestUnitCost)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(CpuMath_LowestUnitCost_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(CpuUnitCostUpdater), nameof(CpuUnitCostUpdater.UpdateUnitCost)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(CpuUnitCostUpdater_UpdateUnitCost_Prefix)));

            harmony.Patch(AccessTools.Method(typeof(ProjectReleaseWindow), nameof(ProjectReleaseWindow.Open)),
                postfix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(ProjectReleaseWindow_Open_Postfix)));

            harmony.Patch(AccessTools.Method(typeof(ProductionUI), nameof(ProductionUI.Initialize)),
                postfix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(ProductionUI_Initialize_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ProductionUI), nameof(ProductionUI.UpdateAdditionalInformation)),
                postfix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(ProductionUI_UpdateAdditionalInformation_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ProductionUI), nameof(ProductionUI.UpdateProductionLines)),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(ProductionUI_UpdateProductionLines_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ProductionUI), "UpdateTexts"),
                prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(ProductionUI_UpdateTexts_Prefix)));

            var salesAwake = AccessTools.Method(typeof(CpuSalesUIInstantiator), "Awake");
            if (salesAwake != null)
                harmony.Patch(salesAwake, postfix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(CpuSalesUIInstantiator_SyncPrefab_Postfix)));
            var salesInst = AccessTools.Method(typeof(CpuSalesUIInstantiator), nameof(CpuSalesUIInstantiator.InstantiateCpuUI));
            if (salesInst != null)
                harmony.Patch(salesInst, prefix: new HarmonyMethod(typeof(BinningProductionPatches), nameof(CpuSalesUIInstantiator_SyncPrefab_Postfix)));
        }

        internal static void ChargeVariantAssemblyExpense(Cpu cpu, int unitsSold)
        {
            if (cpu?.Base == null || unitsSold <= 0) return;
            float perUnit = BinningMath.IsHighBin(cpu)
                ? BinningMath.CalculateHighBinValidationFee(cpu.Package, cpu.Base)
                : BinningMath.CalculateVariantAssemblyCost(cpu.Base, cpu.Package, cpu.Memory, cpu.ProcessNode, cpu.L1Cache, cpu.L2Cache, cpu.L3Cache);
            float totalCost = perUnit * unitsSold;
            cpu.Company?.SpendMoney(totalCost, ExpenseOrigin.Factories);
            if (cpu.Market?.Cost != null && cpu.Market.Cost.Count > 0)
                cpu.Market.Cost[cpu.Market.Cost.Count - 1] += totalCost;
        }

        private static void CpuSalesUIInstantiator_SyncPrefab_Postfix(CpuSalesUIInstantiator __instance)
        {
            if (__instance == null || SalesUiPrefabF == null || SalesUiVarPrefabF == null) return;
            var stdPrefab = SalesUiPrefabF.GetValue(__instance);
            if (stdPrefab != null && SalesUiVarPrefabF.GetValue(__instance) != stdPrefab)
                SalesUiVarPrefabF.SetValue(__instance, stdPrefab);
        }

        private static bool Cpu_UnitsFromFailedStock_Prefix(Cpu __instance, int demand, ref int __result)
        {
            if (__instance?.Base == null) return true;
            int allowedDemand = BinningMarketAiPatches.InMarketSell
                ? Mathf.Min(demand, BinningMath.GetVariantMarketAvailableUnits(__instance))
                : demand;
            __result = allowedDemand > 0 ? BinningMath.ConsumeVariantStock(__instance, allowedDemand) : 0;
            return false;
        }

        private static void Factory_ProduceWafers_Prefix(Cpu cpu, bool isForContracts, out int __state) =>
            __state = (!isForContracts && cpu?.Market != null) ? cpu.Market.Stock : -1;

        private static void Factory_ProduceWafers_Postfix(Cpu cpu, bool isForContracts, int __state)
        {
            if (__state >= 0 && !isForContracts && cpu != null && cpu.Base == null && cpu.Market != null && cpu.Market.Stock > __state)
                BinningMath.DistributeDailyProductionToHighBins(cpu, cpu.Market.Stock - __state);
        }

        private static void Cpu_TriggerRetirement_Prefix(Cpu __instance)
        {
            if (__instance == null || !BinningMath.IsHighBin(__instance)) return;
            int rem = BinningMath.PopHighBinPoolOnRetire(__instance);
            if (rem <= 0) return;
            if (__instance.Base != null && !__instance.Base.IsRetired && __instance.Base.Market != null) __instance.Base.Market.Stock += rem;
            else if (__instance.Market != null) __instance.Market.Stock += rem;
        }

        private static bool Cpu_RealUnitCost_Prefix(Cpu __instance, ref float __result)
        {
            if (__instance?.Base == null) return true;
            __result = BinningMath.GetVariantBaseUnitCost(__instance) + __instance.Royalties();
            return false;
        }

        private static bool Cpu_RealUnitCostWithNewPrice_Prefix(Cpu __instance, float newPrice, ref float __result)
        {
            if (__instance?.Base == null) return true;
            __result = BinningMath.GetVariantBaseUnitCost(__instance) + __instance.Royalties(newPrice);
            return false;
        }

        private static bool CpuMath_LowestUnitCost_Prefix(Cpu cpu, ref float __result)
        {
            if (cpu?.Base == null) return true;
            __result = BinningMath.GetVariantBaseUnitCost(cpu);
            return false;
        }

        private static bool CpuUnitCostUpdater_UpdateUnitCost_Prefix(Cpu cpu)
        {
            if (cpu?.Base == null) return true;
            cpu.UnitCost = BinningMath.GetVariantBaseUnitCost(cpu);
            return false;
        }

        private static void ProjectReleaseWindow_Open_Postfix(ProjectReleaseWindow __instance, Cpu cpu)
        {
            if (cpu?.Base == null || cpu.Base.Price <= 0f) return;
            if (ReleasePriceInputF?.GetValue(__instance) is TMP_InputField priceInput)
            {
                int suggested = BinningMath.IsHighBin(cpu)
                    ? Mathf.RoundToInt(Mathf.Max(cpu.UnitCost * 1.4f, cpu.Base.Price * 1.25f))
                    : Mathf.RoundToInt(Mathf.Max(cpu.UnitCost * 2f, cpu.Base.Price * 0.65f));
                priceInput.text = Mathf.Clamp(suggested, 1, 9999).ToString();
                ReleaseValidatePriceM?.Invoke(__instance, null);
            }
        }

        private static void ProductionUI_Initialize_Postfix(ProductionUI __instance, Cpu cpu)
        {
            if (cpu == null) return;
            var prodText = ProductionUiProdTextF?.GetValue(__instance) as InfoText;
            var stockText = ProductionUiStockTextF?.GetValue(__instance) as InfoText;
            if (cpu.Base != null)
            {
                if (prodText != null) prodText.Title = "Conversion Rate:";
                if (stockText != null) stockText.Title = "Available Units:";
                ProductionUI_UpdateProductionLines_Prefix(__instance);
            }
            else
            {
                if (prodText != null) prodText.Title = "Production:";
                if (stockText != null) stockText.Title = "Stock:";
            }
        }

        private static void ProductionUI_UpdateAdditionalInformation_Postfix(ProductionUI __instance)
        {
            var cpu = ProductionUiCpuF?.GetValue(__instance) as Cpu;
            var infoTxt = ProductionUiInfoTextF?.GetValue(__instance) as TMP_Text;
            if (cpu?.Base == null || infoTxt == null) return;

            float percentage = MathHelper.ReversePercentageScale(cpu.FailureRate);
            string dieStr = cpu.DieCount > 1 ? $"{cpu.DieCount} dies" : "1 die";
            infoTxt.text = $"FY: {StringFormatter.FloatToPercentageString(percentage)}, {dieStr}, {cpu.Base.Name}{(BinningMath.IsHighBin(cpu) ? " [High Bin]" : "")}";
        }

        private static bool ProductionUI_UpdateProductionLines_Prefix(ProductionUI __instance)
        {
            var cpu = ProductionUiCpuF?.GetValue(__instance) as Cpu;
            if (cpu?.Base == null) return true;
            cpu.CurrentProductionLines = cpu.CurrentContractedProductionLines = 0;
            if (ProductionUiSliderF?.GetValue(__instance) is SliderUI slider)
            {
                slider.Interactable = false;
                slider.Value = 0f;
                slider.Text = "n/a";
            }
            return false;
        }

        private static bool ProductionUI_UpdateTexts_Prefix(ProductionUI __instance)
        {
            var cpu = ProductionUiCpuF?.GetValue(__instance) as Cpu;
            if (cpu?.Base == null) return true;

            int avail = BinningMath.GetVariantAvailableUnits(cpu);
            float conversionPerMonth = (cpu.SoldLastDay + cpu.SoldLastDayByContracts) * 30f;
            float demandPerMonth = (cpu.SoldLastDay + cpu.MissedSalesLastDay + cpu.TodayDemandByContracts + cpu.MissedSalesLastDayByContracts) * 30f;
            float dailyBalance = (conversionPerMonth - demandPerMonth) / 30f;

            if (ProductionUiProdTextF?.GetValue(__instance) is InfoText prodText)
            {
                prodText.Title = "Conversion Rate:";
                prodText.Text = StringFormatter.FloatToIntString(conversionPerMonth, "", true) + "/m";
            }
            if (ProductionUiDemandTextF?.GetValue(__instance) is InfoText demandText)
                demandText.Text = StringFormatter.FloatToIntString(demandPerMonth, "", true) + "/m";
            if (ProductionUiStockTextF?.GetValue(__instance) is InfoText stockText)
            {
                stockText.Title = "Available Units:";
                stockText.Text = avail > 0 ? StringFormatter.FloatToIntString(avail, "", true) : "Out of Stock!";
            }
            if (ProductionUiBalanceTextF?.GetValue(__instance) is InfoText balanceText)
            {
                balanceText.Text = StringFormatter.FloatToIntString(dailyBalance, "", true) + "/d";
                balanceText.SetVariableColor(dailyBalance >= 0f ? Colors.Instance.DynamicPositiveColor() : Colors.Instance.DynamicNegativeColor(), true);
            }
            return false;
        }
    }
}
