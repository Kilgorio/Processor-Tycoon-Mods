using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon.Menu;
using ProcessorTycoon.TimeSystem;
using ProcessorTycoon.UI;
using UnityEngine;
using UnityEngine.UI;

namespace PTModMenu
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTModMenuPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.modmenu";
        public const string PluginName = "Processor Tycoon Mod Menu";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log { get; private set; }
        private static Harmony _harmony;

        public static ConfigEntry<KeyCode> ToggleKey { get; private set; }
        public static ConfigEntry<bool> ShowInMainMenu { get; private set; }
        public static ConfigEntry<bool> ShowInPauseMenu { get; private set; }
        public static ConfigEntry<string> DisabledModGuids { get; private set; }

        private static readonly FieldInfo PauseContinueBtnF = AccessTools.Field(typeof(PauseMenu), "continueButton");
        private static readonly HashSet<string> DisabledGuidSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static GameObject _mainMenuModsBtn;
        private static GameObject _pauseMenuModsBtn;
        private static bool _appliedSavedDisables;

        private void Awake()
        {
            Log = Logger;
            _harmony = new Harmony(PluginGuid);

            ToggleKey = Config.Bind("1. General", "ToggleKey", KeyCode.F10,
                "Hotkey to open or close the Mod Menu anywhere.");
            ShowInMainMenu = Config.Bind("1. General", "ShowInMainMenu", true,
                "Show a 'Mods' button on the Main Menu.");
            ShowInPauseMenu = Config.Bind("1. General", "ShowInPauseMenu", true,
                "Show a 'Mods' button in the In-Game Pause Menu.");
            DisabledModGuids = Config.Bind("2. State", "DisabledModGuids", "",
                "Internal list of disabled third-party plugin GUIDs.");

            LoadDisabledGuidSet();

            ToggleKey.SettingChanged += (_, _) => ModMenuWindow.RefreshHotkeyHint();
            ShowInMainMenu.SettingChanged += (_, _) =>
            {
                if (_mainMenuModsBtn != null) _mainMenuModsBtn.SetActive(ShowInMainMenu.Value);
            };
            ShowInPauseMenu.SettingChanged += (_, _) =>
            {
                if (_pauseMenuModsBtn != null) _pauseMenuModsBtn.SetActive(ShowInPauseMenu.Value);
            };

            _harmony.Patch(AccessTools.Method(typeof(MenuQuitButton), "Start"),
                postfix: new HarmonyMethod(typeof(PTModMenuPlugin), nameof(MenuQuitButton_Start_Postfix)));
            _harmony.Patch(AccessTools.Method(typeof(PauseMenu), "Start"),
                postfix: new HarmonyMethod(typeof(PTModMenuPlugin), nameof(PauseMenu_Start_Postfix)));

            Log.LogInfo($"{PluginName} v{PluginVersion} loaded cleanly (Hotkey: {ToggleKey.Value}).");
        }

        private void Start()
        {
            if (_appliedSavedDisables) return;
            _appliedSavedDisables = true;
            ApplySavedDisabledMods();
        }

        private void Update()
        {
            ModMenuWindow.TickDeferredSaves();

            if (ToggleKey != null && ToggleKey.Value != KeyCode.None && Input.GetKeyDown(ToggleKey.Value))
                ModMenuWindow.Toggle();
            else if (ModMenuWindow.IsOpen && Input.GetKeyDown(KeyCode.Escape))
                ModMenuWindow.Close();
        }

        private void OnDestroy()
        {
            ModMenuWindow.FlushPendingSaves();
            _harmony?.UnpatchSelf();
        }

        internal static bool IsGuidMarkedDisabled(string guid) =>
            !string.IsNullOrEmpty(guid) && DisabledGuidSet.Contains(guid);

        internal static void SetGuidMarkedDisabled(string guid, bool disabled)
        {
            if (string.IsNullOrEmpty(guid)) return;
            if (disabled) DisabledGuidSet.Add(guid);
            else DisabledGuidSet.Remove(guid);
            if (DisabledModGuids != null)
            {
                DisabledModGuids.Value = string.Join(",", DisabledGuidSet);
                DisabledModGuids.ConfigFile.Save();
            }
        }

        private static void LoadDisabledGuidSet()
        {
            DisabledGuidSet.Clear();
            string raw = DisabledModGuids?.Value ?? "";
            foreach (var part in raw.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string trimmed = part.Trim();
                if (!string.IsNullOrEmpty(trimmed) && !string.Equals(trimmed, PluginGuid, StringComparison.OrdinalIgnoreCase))
                    DisabledGuidSet.Add(trimmed);
            }
        }

        private static void ApplySavedDisabledMods()
        {
            if (DisabledGuidSet.Count == 0) return;
            foreach (var kv in Chainloader.PluginInfos)
            {
                if (!DisabledGuidSet.Contains(kv.Key)) continue;
                try
                {
                    Harmony.UnpatchID(kv.Key);
                    if (kv.Value?.Instance != null) kv.Value.Instance.enabled = false;
                    Log.LogInfo($"Auto-disabled plugin '{kv.Value?.Metadata?.Name ?? kv.Key}' from previous Mod Menu state.");
                }
                catch (Exception ex)
                {
                    Log.LogWarning($"Could not auto-disable {kv.Key}: {ex.Message}");
                }
            }
        }

        private static void MenuQuitButton_Start_Postfix(MenuQuitButton __instance)
        {
            if (__instance == null || DateController.Instance != null) return;
            try
            {
                var btn = InjectModsButton(
                    anchorGo: __instance.gameObject,
                    panelRoot: __instance.transform.parent,
                    placeAfter: false,
                    stripQuitComponent: true,
                    onClick: ModMenuWindow.Toggle);
                if (btn != null)
                {
                    _mainMenuModsBtn = btn;
                    btn.SetActive(ShowInMainMenu?.Value ?? true);
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed injecting Main Menu Mods button: {ex}");
            }
        }

        private static void PauseMenu_Start_Postfix(PauseMenu __instance)
        {
            if (__instance == null) return;
            try
            {
                var continueBtn = PauseContinueBtnF?.GetValue(__instance) as ButtonUI;
                if (continueBtn == null) return;
                var btn = InjectModsButton(
                    anchorGo: continueBtn.gameObject,
                    panelRoot: __instance.transform,
                    placeAfter: true,
                    stripQuitComponent: false,
                    onClick: ModMenuWindow.Open);
                if (btn != null)
                {
                    _pauseMenuModsBtn = btn;
                    btn.SetActive(ShowInPauseMenu?.Value ?? true);
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed injecting Pause Menu Mods button: {ex}");
            }
        }

        private static GameObject InjectModsButton(GameObject anchorGo, Transform panelRoot, bool placeAfter, bool stripQuitComponent, Action onClick)
        {
            if (anchorGo == null || anchorGo.transform.parent == null) return null;
            Transform parent = anchorGo.transform.parent;
            var existing = parent.Find("Btn_ModsMenu");
            if (existing != null) return existing.gameObject;

            var cloneGo = UnityEngine.Object.Instantiate(anchorGo, parent, false);
            cloneGo.name = "Btn_ModsMenu";
            if (stripQuitComponent)
            {
                var mqb = cloneGo.GetComponent<MenuQuitButton>();
                if (mqb != null) UnityEngine.Object.DestroyImmediate(mqb);
            }

            cloneGo.SetActive(true);
            var cloneBtn = cloneGo.GetComponent<ButtonUI>();
            if (cloneBtn != null)
            {
                cloneBtn.ResetOnClick();
                cloneBtn.Text = "Mods";
                cloneBtn.OnClick += onClick;
            }

            AdjustButtonLayout(panelRoot, anchorGo.transform as RectTransform, cloneGo.transform as RectTransform, parent, placeAfter);
            return cloneGo;
        }

        private static void AdjustButtonLayout(Transform panelRoot, RectTransform anchorRt, RectTransform cloneRt, Transform parent, bool placeAfter)
        {
            if (anchorRt == null || cloneRt == null || parent == null) return;

            var vLayout = parent.GetComponent<VerticalLayoutGroup>();
            var layout = parent.GetComponent<LayoutGroup>();
            bool hasLayoutGroup = layout != null;

            float strideY = anchorRt.rect.height > 1f
                ? anchorRt.rect.height + (vLayout != null ? vLayout.spacing : 8f)
                : 46f;

            if (hasLayoutGroup)
            {
                int targetIdx = anchorRt.GetSiblingIndex() + (placeAfter ? 1 : 0);
                cloneRt.SetSiblingIndex(Mathf.Clamp(targetIdx, 0, parent.childCount - 1));
            }
            else
            {
                float bestDiff = float.MaxValue;
                foreach (Transform child in parent)
                {
                    if (child == anchorRt || child == cloneRt || !(child is RectTransform rt)) continue;
                    float diff = Mathf.Abs(anchorRt.anchoredPosition.y - rt.anchoredPosition.y);
                    if (diff > 5f && diff < bestDiff) bestDiff = diff;
                }
                if (bestDiff < 200f) strideY = bestDiff;

                if (placeAfter)
                {
                    float cutY = anchorRt.anchoredPosition.y - 1f;
                    foreach (Transform child in parent)
                    {
                        if (child != anchorRt && child != cloneRt && child is RectTransform rt && rt.anchoredPosition.y < cutY)
                            rt.anchoredPosition -= new Vector2(0f, strideY);
                    }
                    cloneRt.anchoredPosition = anchorRt.anchoredPosition - new Vector2(0f, strideY);
                    cloneRt.SetSiblingIndex(anchorRt.GetSiblingIndex() + 1);
                }
                else
                {
                    cloneRt.anchoredPosition = anchorRt.anchoredPosition;
                    float cutY = anchorRt.anchoredPosition.y + 1f;
                    foreach (Transform child in parent)
                    {
                        if (child != cloneRt && child is RectTransform rt && rt.anchoredPosition.y < cutY)
                            rt.anchoredPosition -= new Vector2(0f, strideY);
                    }
                    cloneRt.SetSiblingIndex(anchorRt.GetSiblingIndex());
                }
            }

            if (panelRoot == null) return;

            Transform cur = parent;
            while (cur != null)
            {
                var rt = cur as RectTransform;
                var fitter = cur.GetComponent<ContentSizeFitter>();
                bool autoFitsVert = fitter != null && fitter.verticalFit == ContentSizeFitter.FitMode.PreferredSize;
                bool isVertStretched = rt != null && !Mathf.Approximately(rt.anchorMin.y, rt.anchorMax.y);
                if (rt != null && !autoFitsVert && !isVertStretched)
                {
                    rt.sizeDelta += new Vector2(0f, strideY);
                    if (!hasLayoutGroup && Mathf.Approximately(rt.pivot.y, 0.5f) && cur == parent)
                    {
                        foreach (Transform child in parent)
                            if (child is RectTransform crt) crt.anchoredPosition += new Vector2(0f, strideY * 0.5f);
                    }
                }
                if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
                if (cur == panelRoot) break;
                cur = cur.parent;
            }
        }
    }
}
