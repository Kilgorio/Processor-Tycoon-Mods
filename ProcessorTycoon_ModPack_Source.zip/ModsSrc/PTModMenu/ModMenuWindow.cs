using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using BepInEx.Configuration;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModMenu
{
    public static class ModMenuWindow
    {
        private static GameObject _canvasGo;
        private static Transform _modListContent;
        private static Transform _settingsContent;
        private static TMP_Text _hotkeyHintTxt;
        private static TMP_Text _detailHeaderTitle;
        private static TMP_Text _detailHeaderSub;
        private static Button _detailToggleBtn;
        private static TMP_Text _detailToggleTxt;
        private static Button _resetDefaultsBtn;
        private static TMP_Text _footerStatusTxt;

        private static readonly List<ModItem> DiscoveredMods = new List<ModItem>();
        private static readonly Dictionary<string, (Button cardBtn, Image bg, TMP_Text badgeTxt, Image badgeBg)> ModCards
            = new Dictionary<string, (Button, Image, TMP_Text, Image)>();
        private static readonly HashSet<ConfigFile> DirtyConfigs = new HashSet<ConfigFile>();
        private static float _nextConfigSaveTime;
        private static string _selectedKey;

        public static bool IsOpen => _canvasGo != null && _canvasGo.activeSelf;

        public static void Toggle()
        {
            if (IsOpen) Close();
            else Open();
        }

        public static void Open()
        {
            try
            {
                if (_canvasGo == null) BuildWindow();
                _canvasGo.SetActive(true);
                RefreshHotkeyHint();
                RefreshAll();
            }
            catch (Exception ex)
            {
                PTModMenuPlugin.Log.LogError($"Failed opening Mod Menu: {ex}");
            }
        }

        public static void Close()
        {
            FlushPendingSaves();
            if (_canvasGo != null) _canvasGo.SetActive(false);
        }

        public static void RefreshHotkeyHint()
        {
            if (_hotkeyHintTxt != null)
                _hotkeyHintTxt.text = $"Hotkey: {PTModMenuPlugin.ToggleKey?.Value}";
        }

        public static void TickDeferredSaves()
        {
            if (DirtyConfigs.Count > 0 && Time.unscaledTime >= _nextConfigSaveTime)
                FlushPendingSaves();
        }

        public static void FlushPendingSaves()
        {
            if (DirtyConfigs.Count == 0) return;
            foreach (var cfg in DirtyConfigs)
            {
                try { cfg?.Save(); }
                catch (Exception ex) { PTModMenuPlugin.Log?.LogWarning($"Failed saving config: {ex.Message}"); }
            }
            DirtyConfigs.Clear();
        }

        private static void MarkConfigDirty(ConfigFile cfg)
        {
            if (cfg == null) return;
            DirtyConfigs.Add(cfg);
            _nextConfigSaveTime = Time.unscaledTime + 0.40f;
        }

        private static void BuildWindow()
        {
            _canvasGo = new GameObject("PTModMenu_OverlayCanvas");
            UnityEngine.Object.DontDestroyOnLoad(_canvasGo);

            var canvas = _canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 500;

            var scaler = _canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;
            _canvasGo.AddComponent<GraphicRaycaster>();

            var dimGo = ModMenuUiFactory.CreatePanel("Backdrop", _canvasGo.transform, new Color(0f, 0f, 0f, 0.62f), false);
            ModMenuUiFactory.StretchFull(dimGo.GetComponent<RectTransform>());
            var dimBtn = dimGo.AddComponent<Button>();
            dimBtn.transition = Selectable.Transition.None;
            dimBtn.onClick.AddListener(Close);

            var panelGo = ModMenuUiFactory.CreatePanel("Window", _canvasGo.transform, ModMenuUiFactory.PanelBg, true);
            var wRt = panelGo.GetComponent<RectTransform>();
            wRt.anchorMin = wRt.anchorMax = wRt.pivot = new Vector2(0.5f, 0.5f);
            wRt.sizeDelta = new Vector2(1120f, 700f);
            var outline = panelGo.AddComponent<Outline>();
            outline.effectColor = ModMenuUiFactory.BorderCol;
            outline.effectDistance = new Vector2(1.5f, -1.5f);

            var header = ModMenuUiFactory.CreatePanel("Header", panelGo.transform, ModMenuUiFactory.HeaderBg, true);
            var hRt = header.GetComponent<RectTransform>();
            hRt.anchorMin = new Vector2(0f, 1f);
            hRt.anchorMax = new Vector2(1f, 1f);
            hRt.pivot = new Vector2(0.5f, 1f);
            hRt.anchoredPosition = new Vector2(0f, -8f);
            hRt.sizeDelta = new Vector2(-16f, 50f);

            var titleTxt = ModMenuUiFactory.CreateText("Title", header.transform, "Installed Mods & Configuration", 20f, TextAlignmentOptions.Left, ModMenuUiFactory.TextPrimary, FontStyles.Bold);
            ModMenuUiFactory.StretchFull(titleTxt.GetComponent<RectTransform>(), 16f, 0f, -200f, 0f);

            _hotkeyHintTxt = ModMenuUiFactory.CreateText("Hint", header.transform, $"Hotkey: {PTModMenuPlugin.ToggleKey?.Value}", 14f, TextAlignmentOptions.Right, ModMenuUiFactory.TextMuted);
            ModMenuUiFactory.StretchFull(_hotkeyHintTxt.GetComponent<RectTransform>(), 0f, 0f, -56f, 0f);

            var closeBtn = ModMenuUiFactory.CreateButton("CloseBtn", header.transform, "X", ModMenuUiFactory.AccentRed, 15f, Close);
            var cRt = closeBtn.GetComponent<RectTransform>();
            cRt.anchorMin = cRt.anchorMax = cRt.pivot = new Vector2(1f, 0.5f);
            cRt.anchoredPosition = new Vector2(-10f, 0f);
            cRt.sizeDelta = new Vector2(34f, 34f);

            var leftBg = ModMenuUiFactory.CreatePanel("LeftPane", panelGo.transform, ModMenuUiFactory.HeaderBg, true);
            ModMenuUiFactory.SetAnchors(leftBg.GetComponent<RectTransform>(), 0f, 0f, 0.34f, 1f, 10f, 38f, -5f, -66f);

            var listLbl = ModMenuUiFactory.CreateText("ModsHeader", leftBg.transform, "PLUGINS", 13f, TextAlignmentOptions.Left, ModMenuUiFactory.TextMuted, FontStyles.Bold);
            var llRt = listLbl.GetComponent<RectTransform>();
            llRt.anchorMin = new Vector2(0f, 1f);
            llRt.anchorMax = new Vector2(1f, 1f);
            llRt.pivot = new Vector2(0.5f, 1f);
            llRt.anchoredPosition = new Vector2(0f, -8f);
            llRt.sizeDelta = new Vector2(-20f, 22f);

            _modListContent = ModMenuUiFactory.CreateScrollView("ModListScroll", leftBg.transform, 8f);
            ModMenuUiFactory.StretchFull(_modListContent.parent.parent.GetComponent<RectTransform>(), 6f, 6f, -6f, -34f);

            var rightBg = ModMenuUiFactory.CreatePanel("RightPane", panelGo.transform, ModMenuUiFactory.HeaderBg, true);
            ModMenuUiFactory.SetAnchors(rightBg.GetComponent<RectTransform>(), 0.34f, 0f, 1f, 1f, 5f, 38f, -10f, -66f);

            var detTop = ModMenuUiFactory.CreatePanel("InspectorHeader", rightBg.transform, ModMenuUiFactory.CardBg, true);
            var dtRt = detTop.GetComponent<RectTransform>();
            dtRt.anchorMin = new Vector2(0f, 1f);
            dtRt.anchorMax = new Vector2(1f, 1f);
            dtRt.pivot = new Vector2(0.5f, 1f);
            dtRt.anchoredPosition = new Vector2(0f, -8f);
            dtRt.sizeDelta = new Vector2(-16f, 68f);

            _detailHeaderTitle = ModMenuUiFactory.CreateText("ModTitle", detTop.transform, "Select a Mod", 18f, TextAlignmentOptions.Left, ModMenuUiFactory.TextPrimary, FontStyles.Bold);
            ModMenuUiFactory.SetAnchors(_detailHeaderTitle.GetComponent<RectTransform>(), 0f, 0.45f, 0.54f, 1f, 14f, 0f, -6f, -6f);

            _detailHeaderSub = ModMenuUiFactory.CreateText("ModSub", detTop.transform, "", 12.5f, TextAlignmentOptions.Left, ModMenuUiFactory.TextMuted);
            ModMenuUiFactory.SetAnchors(_detailHeaderSub.GetComponent<RectTransform>(), 0f, 0f, 0.54f, 0.48f, 14f, 6f, -6f, 0f);

            _detailToggleBtn = ModMenuUiFactory.CreateButton("ToggleModBtn", detTop.transform, "Enabled", ModMenuUiFactory.AccentGreen, 13.5f, OnToggleSelectedMod);
            ModMenuUiFactory.SetAnchors(_detailToggleBtn.GetComponent<RectTransform>(), 0.55f, 0.18f, 0.78f, 0.82f);
            _detailToggleTxt = _detailToggleBtn.GetComponentInChildren<TMP_Text>();

            _resetDefaultsBtn = ModMenuUiFactory.CreateButton("ResetBtn", detTop.transform, "Reset Defaults", ModMenuUiFactory.CardBg, 13.5f, OnResetSelectedDefaults);
            ModMenuUiFactory.SetAnchors(_resetDefaultsBtn.GetComponent<RectTransform>(), 0.80f, 0.18f, 0.98f, 0.82f);
            _resetDefaultsBtn.GetComponent<Image>().color = ModMenuUiFactory.IsDark ? new Color(0.28f, 0.30f, 0.34f, 1f) : new Color(0.68f, 0.71f, 0.76f, 1f);

            _settingsContent = ModMenuUiFactory.CreateScrollView("SettingsScroll", rightBg.transform, 8f);
            ModMenuUiFactory.StretchFull(_settingsContent.parent.parent.GetComponent<RectTransform>(), 6f, 6f, -6f, -84f);

            _footerStatusTxt = ModMenuUiFactory.CreateText("Footer", panelGo.transform,
                "Changes save automatically. Disable/Enable takes effect live on supported mods; third-party DLL toggles apply on next launch.",
                12.5f, TextAlignmentOptions.Left, ModMenuUiFactory.TextMuted);
            var fRt = _footerStatusTxt.GetComponent<RectTransform>();
            fRt.anchorMin = new Vector2(0f, 0f);
            fRt.anchorMax = new Vector2(1f, 0f);
            fRt.pivot = new Vector2(0.5f, 0f);
            fRt.anchoredPosition = new Vector2(0f, 8f);
            fRt.sizeDelta = new Vector2(-24f, 24f);

            _canvasGo.SetActive(false);
        }

        private static void RefreshAll()
        {
            DiscoveredMods.Clear();
            DiscoveredMods.AddRange(ModDiscoveryService.DiscoverMods());
            BuildModCards();
            if (string.IsNullOrEmpty(_selectedKey) || FindSelectedMod() == null)
                _selectedKey = DiscoveredMods.Count > 0 ? DiscoveredMods[0].StableKey : null;
            SelectMod(_selectedKey);
        }

        private static ModItem FindSelectedMod()
        {
            for (int i = 0; i < DiscoveredMods.Count; i++)
                if (DiscoveredMods[i].StableKey == _selectedKey) return DiscoveredMods[i];
            return null;
        }

        private static void BuildModCards()
        {
            ModMenuUiFactory.ClearChildren(_modListContent);
            ModCards.Clear();

            foreach (var mod in DiscoveredMods)
            {
                string key = mod.StableKey;
                var cardGo = ModMenuUiFactory.CreatePanel($"ModCard_{mod.Name}", _modListContent, ModMenuUiFactory.CardBg, true);
                ModMenuUiFactory.SetFixedRowHeight(cardGo, 64f);

                var cardBtn = cardGo.AddComponent<Button>();
                cardBtn.onClick.AddListener(() => SelectMod(key));

                var titleTxt = ModMenuUiFactory.CreateText("Title", cardGo.transform, mod.Name, 15f, TextAlignmentOptions.Left, ModMenuUiFactory.TextPrimary, FontStyles.Bold);
                titleTxt.textWrappingMode = TextWrappingModes.NoWrap;
                titleTxt.overflowMode = TextOverflowModes.Ellipsis;
                ModMenuUiFactory.SetAnchors(titleTxt.GetComponent<RectTransform>(), 0f, 0.45f, 0.74f, 1f, 12f, 0f, -6f, -6f);

                string sub = mod.LoadedPlugin != null ? $"v{mod.Version}" : "Disabled on disk";
                var subTxt = ModMenuUiFactory.CreateText("Ver", cardGo.transform, sub, 12.5f, TextAlignmentOptions.Left, ModMenuUiFactory.TextMuted);
                ModMenuUiFactory.SetAnchors(subTxt.GetComponent<RectTransform>(), 0f, 0f, 0.74f, 0.48f, 12f, 6f, -6f, 0f);

                var badgeGo = ModMenuUiFactory.CreatePanel("Badge", cardGo.transform, ModMenuUiFactory.AccentGreen, true);
                ModMenuUiFactory.SetAnchors(badgeGo.GetComponent<RectTransform>(), 0.76f, 0.22f, 0.96f, 0.78f);
                var badgeTxt = ModMenuUiFactory.CreateText("BLabel", badgeGo.transform, "ON", 12.5f, TextAlignmentOptions.Center, Color.white, FontStyles.Bold);
                ModMenuUiFactory.StretchFull(badgeTxt.GetComponent<RectTransform>());

                if (!mod.IsSelf)
                {
                    var badgeBtn = badgeGo.AddComponent<Button>();
                    badgeBtn.onClick.AddListener(() => { SelectMod(key); ApplyModToggle(mod); });
                }

                ModCards[key] = (cardBtn, cardGo.GetComponent<Image>(), badgeTxt, badgeGo.GetComponent<Image>());
                UpdateModCardVisual(mod);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(_modListContent as RectTransform);
        }

        private static void UpdateModCardVisual(ModItem mod)
        {
            if (!ModCards.TryGetValue(mod.StableKey, out var ui)) return;

            bool isSelected = mod.StableKey == _selectedKey;
            ui.bg.color = isSelected ? ModMenuUiFactory.CardSelBg : ModMenuUiFactory.CardBg;

            if (mod.IsSelf)
            {
                ui.badgeBg.color = ModMenuUiFactory.AccentBlue;
                ui.badgeTxt.text = "CORE";
            }
            else if (mod.RequiresRestart)
            {
                ui.badgeBg.color = ModMenuUiFactory.AccentAmber;
                ui.badgeTxt.text = "RESTART";
            }
            else if (mod.IsEnabled)
            {
                ui.badgeBg.color = ModMenuUiFactory.AccentGreen;
                ui.badgeTxt.text = "ON";
            }
            else
            {
                ui.badgeBg.color = ModMenuUiFactory.AccentRed;
                ui.badgeTxt.text = "OFF";
            }
        }

        private static void SelectMod(string key)
        {
            _selectedKey = key;
            for (int i = 0; i < DiscoveredMods.Count; i++) UpdateModCardVisual(DiscoveredMods[i]);

            var mod = FindSelectedMod();
            if (mod == null) return;

            _detailHeaderTitle.text = mod.Name;
            string dllFile = !string.IsNullOrEmpty(mod.DllPath) ? Path.GetFileName(mod.DllPath) : "";
            _detailHeaderSub.text = !string.IsNullOrEmpty(mod.Guid) ? $"{mod.Guid}  ·  v{mod.Version}  ({dllFile})" : mod.DllPath;

            RefreshDetailHeaderButtons(mod);
            BuildSettingsList(mod);
        }

        private static void RefreshDetailHeaderButtons(ModItem mod)
        {
            if (mod.IsSelf)
            {
                _detailToggleBtn.interactable = false;
                _detailToggleBtn.GetComponent<Image>().color = ModMenuUiFactory.AccentBlue;
                _detailToggleTxt.text = "Always Active";
            }
            else
            {
                _detailToggleBtn.interactable = true;
                if (mod.RequiresRestart)
                {
                    _detailToggleBtn.GetComponent<Image>().color = ModMenuUiFactory.AccentAmber;
                    _detailToggleTxt.text = "Restart Required";
                }
                else if (mod.IsEnabled)
                {
                    _detailToggleBtn.GetComponent<Image>().color = ModMenuUiFactory.AccentGreen;
                    _detailToggleTxt.text = "Enabled";
                }
                else
                {
                    _detailToggleBtn.GetComponent<Image>().color = ModMenuUiFactory.AccentRed;
                    _detailToggleTxt.text = "Disabled";
                }
            }

            bool hasConfig = mod.LoadedPlugin?.Instance?.Config != null &&
                             ModDiscoveryService.GetEditableEntries(mod.LoadedPlugin.Instance.Config, mod.IsSelf).Count > 0;
            _resetDefaultsBtn.interactable = hasConfig;
        }

        private static void OnToggleSelectedMod() => ApplyModToggle(FindSelectedMod());

        private static void ApplyModToggle(ModItem mod)
        {
            if (mod == null || mod.IsSelf) return;
            bool changed = ModDiscoveryService.ToggleModState(mod, DiscoveredMods, out string statusMessage);
            if (!string.IsNullOrEmpty(statusMessage)) _footerStatusTxt.text = statusMessage;
            if (!changed) return;

            UpdateModCardVisual(mod);
            RefreshDetailHeaderButtons(mod);
            BuildSettingsList(mod);
        }

        private static void OnResetSelectedDefaults()
        {
            var mod = FindSelectedMod();
            var cfg = mod?.LoadedPlugin?.Instance?.Config;
            if (cfg == null) return;

            foreach (var entry in ModDiscoveryService.GetEditableEntries(cfg, mod.IsSelf))
                entry.BoxedValue = entry.DefaultValue;
            DirtyConfigs.Remove(cfg);
            cfg.Save();

            if (mod.EnabledConfig != null)
            {
                mod.IsEnabled = mod.EnabledConfig.Value;
                ModDiscoveryService.SetRestartPending(mod, false);
            }
            UpdateModCardVisual(mod);
            RefreshDetailHeaderButtons(mod);
            BuildSettingsList(mod);
            _footerStatusTxt.text = $"Reset {mod.Name} settings to defaults.";
        }

        private static void BuildSettingsList(ModItem mod)
        {
            ModMenuUiFactory.ClearChildren(_settingsContent);
            var cfg = mod.LoadedPlugin?.Instance?.Config;
            var entries = ModDiscoveryService.GetEditableEntries(cfg, mod.IsSelf);

            if (entries.Count == 0)
            {
                string msg = mod.LoadedPlugin == null
                    ? "This plugin is currently disabled on disk.\nEnable it and restart the game to load its settings."
                    : "This plugin does not expose any BepInEx ConfigFile settings.";
                var emptyGo = ModMenuUiFactory.CreatePanel("EmptyNote", _settingsContent, ModMenuUiFactory.CardBg, true);
                ModMenuUiFactory.SetFixedRowHeight(emptyGo, 80f);
                var txt = ModMenuUiFactory.CreateText("Txt", emptyGo.transform, msg, 14.5f, TextAlignmentOptions.Center, ModMenuUiFactory.TextMuted);
                ModMenuUiFactory.StretchFull(txt.GetComponent<RectTransform>(), 16f, 8f, -16f, -8f);
                LayoutRebuilder.ForceRebuildLayoutImmediate(_settingsContent as RectTransform);
                return;
            }

            foreach (var group in entries.GroupBy(e => e.Definition.Section ?? "General"))
            {
                var secGo = new GameObject($"Sec_{group.Key}", typeof(RectTransform));
                secGo.transform.SetParent(_settingsContent, false);
                ModMenuUiFactory.SetFixedRowHeight(secGo, 32f);
                var secTxt = ModMenuUiFactory.CreateText("Lbl", secGo.transform, group.Key.ToUpperInvariant(), 13f, TextAlignmentOptions.BottomLeft, ModMenuUiFactory.AccentBlue, FontStyles.Bold);
                ModMenuUiFactory.StretchFull(secTxt.GetComponent<RectTransform>(), 8f, 3f, -8f, 0f);

                foreach (var entry in group)
                    BuildSettingRow(cfg, mod, entry);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(_settingsContent as RectTransform);
        }

        private static void BuildSettingRow(ConfigFile cfg, ModItem mod, ConfigEntryBase entry)
        {
            var row = ModMenuUiFactory.CreatePanel($"Setting_{entry.Definition.Key}", _settingsContent, ModMenuUiFactory.CardBg, true);
            string desc = entry.Description?.Description ?? "";
            bool hasDesc = !string.IsNullOrEmpty(desc);
            ModMenuUiFactory.SetFixedRowHeight(row, hasDesc ? 68f : 54f);

            var title = ModMenuUiFactory.CreateText("Key", row.transform, entry.Definition.Key, 15f, TextAlignmentOptions.Left, ModMenuUiFactory.TextPrimary, FontStyles.Bold);
            title.textWrappingMode = TextWrappingModes.NoWrap;
            title.overflowMode = TextOverflowModes.Ellipsis;
            ModMenuUiFactory.SetAnchors(title.GetComponent<RectTransform>(), 0f, hasDesc ? 0.48f : 0f, 0.52f, 1f, 14f, 2f, -8f, -4f);

            if (hasDesc)
            {
                var sub = ModMenuUiFactory.CreateText("Desc", row.transform, desc, 12.5f, TextAlignmentOptions.TopLeft, ModMenuUiFactory.TextMuted);
                sub.overflowMode = TextOverflowModes.Ellipsis;
                ModMenuUiFactory.SetAnchors(sub.GetComponent<RectTransform>(), 0f, 0f, 0.52f, 0.50f, 14f, 4f, -8f, 0f);
            }

            Type st = entry.SettingType;
            if (st == typeof(bool))
            {
                bool cur = entry.BoxedValue is bool b && b;
                var btn = ModMenuUiFactory.CreateButton("BoolBtn", row.transform, cur ? "ON" : "OFF", cur ? ModMenuUiFactory.AccentGreen : ModMenuUiFactory.AccentRed, 14f, null);
                ModMenuUiFactory.SetAnchors(btn.GetComponent<RectTransform>(), 0.80f, 0.20f, 0.97f, 0.80f);
                var lbl = btn.GetComponentInChildren<TMP_Text>();
                var bg = btn.GetComponent<Image>();
                btn.onClick.AddListener(() =>
                {
                    bool next = !(entry.BoxedValue is bool c && c);
                    if (!next && entry == mod.EnabledConfig)
                    {
                        var deps = ModDiscoveryService.FindEnabledDependents(mod, DiscoveredMods);
                        if (deps.Count > 0)
                        {
                            _footerStatusTxt.text = $"Cannot disable {mod.Name}: required by {string.Join(", ", deps)}.";
                            return;
                        }
                    }
                    entry.BoxedValue = next;
                    cfg.Save();
                    lbl.text = next ? "ON" : "OFF";
                    bg.color = next ? ModMenuUiFactory.AccentGreen : ModMenuUiFactory.AccentRed;
                    if (entry == mod.EnabledConfig)
                    {
                        mod.IsEnabled = next;
                        ModDiscoveryService.SetRestartPending(mod, false);
                        UpdateModCardVisual(mod);
                        RefreshDetailHeaderButtons(mod);
                    }
                });
            }
            else if (st == typeof(float) || st == typeof(int) || st == typeof(double))
            {
                bool isInt = st == typeof(int);
                float min = 0f, max = 10f;
                if (entry.Description?.AcceptableValues is AcceptableValueRange<float> fr) { min = fr.MinValue; max = fr.MaxValue; }
                else if (entry.Description?.AcceptableValues is AcceptableValueRange<double> dr) { min = (float)dr.MinValue; max = (float)dr.MaxValue; }
                else if (entry.Description?.AcceptableValues is AcceptableValueRange<int> ir) { min = ir.MinValue; max = ir.MaxValue; }
                else
                {
                    float dv = SafeToFloat(entry.DefaultValue, 1f);
                    float cv = SafeToFloat(entry.BoxedValue, dv);
                    float span = Mathf.Max(10f, Mathf.Abs(dv) * 4f, Mathf.Abs(cv) * 2f);
                    min = (dv >= 0f && cv >= 0f) ? 0f : -span;
                    max = span;
                }

                float curVal = SafeToFloat(entry.BoxedValue, min);
                var valTxt = ModMenuUiFactory.CreateText("Val", row.transform, FormatNum(curVal, isInt), 14f, TextAlignmentOptions.Right, ModMenuUiFactory.TextPrimary, FontStyles.Bold);
                ModMenuUiFactory.SetAnchors(valTxt.GetComponent<RectTransform>(), 0.53f, 0.15f, 0.63f, 0.85f, 0f, 0f, -6f, 0f);

                float step = isInt ? 1f : Mathf.Max(0.01f, Mathf.Round((max - min) * 2f) / 100f);
                var slider = ModMenuUiFactory.CreateSlider("Slider", row.transform, min, max, isInt);
                ModMenuUiFactory.SetAnchors(slider.GetComponent<RectTransform>(), 0.64f, 0.25f, 0.86f, 0.75f);
                slider.SetValueWithoutNotify(Mathf.Clamp(curVal, min, max));

                void CommitNumeric(float raw, bool immediateSave)
                {
                    float clamped = Mathf.Clamp(isInt ? Mathf.Round(raw) : (float)Math.Round(raw, 2), min, max);
                    if (isInt) entry.BoxedValue = Mathf.RoundToInt(clamped);
                    else if (st == typeof(double)) entry.BoxedValue = Math.Round(clamped, 2);
                    else entry.BoxedValue = clamped;

                    if (immediateSave) cfg.Save();
                    else MarkConfigDirty(cfg);

                    valTxt.text = FormatNum(clamped, isInt);
                    slider.SetValueWithoutNotify(clamped);
                }

                slider.onValueChanged.AddListener(v => CommitNumeric(v, false));

                var minusBtn = ModMenuUiFactory.CreateButton("Minus", row.transform, "-", ModMenuUiFactory.BorderCol, 16f, () => CommitNumeric(SafeToFloat(entry.BoxedValue, min) - step, true));
                ModMenuUiFactory.SetAnchors(minusBtn.GetComponent<RectTransform>(), 0.875f, 0.20f, 0.92f, 0.80f);
                var plusBtn = ModMenuUiFactory.CreateButton("Plus", row.transform, "+", ModMenuUiFactory.BorderCol, 16f, () => CommitNumeric(SafeToFloat(entry.BoxedValue, min) + step, true));
                ModMenuUiFactory.SetAnchors(plusBtn.GetComponent<RectTransform>(), 0.93f, 0.20f, 0.975f, 0.80f);
            }
            else if (st.IsEnum)
            {
                Array vals = Enum.GetValues(st);
                int idx = Math.Max(0, Array.IndexOf(vals, entry.BoxedValue));

                var prevBtn = ModMenuUiFactory.CreateButton("Prev", row.transform, "<", ModMenuUiFactory.BorderCol, 14f, null);
                ModMenuUiFactory.SetAnchors(prevBtn.GetComponent<RectTransform>(), 0.55f, 0.20f, 0.605f, 0.80f);

                var valBtn = ModMenuUiFactory.CreateButton("EnumVal", row.transform, entry.BoxedValue?.ToString() ?? "", ModMenuUiFactory.AccentBlue, 13.5f, null);
                ModMenuUiFactory.SetAnchors(valBtn.GetComponent<RectTransform>(), 0.615f, 0.20f, 0.91f, 0.80f);
                var valLbl = valBtn.GetComponentInChildren<TMP_Text>();

                var nextBtn = ModMenuUiFactory.CreateButton("Next", row.transform, ">", ModMenuUiFactory.BorderCol, 14f, null);
                ModMenuUiFactory.SetAnchors(nextBtn.GetComponent<RectTransform>(), 0.92f, 0.20f, 0.975f, 0.80f);

                void StepEnum(int dir)
                {
                    if (vals.Length == 0) return;
                    idx = (idx + dir + vals.Length) % vals.Length;
                    object picked = vals.GetValue(idx);
                    entry.BoxedValue = picked;
                    cfg.Save();
                    valLbl.text = picked.ToString();
                }

                prevBtn.onClick.AddListener(() => StepEnum(-1));
                valBtn.onClick.AddListener(() => StepEnum(1));
                nextBtn.onClick.AddListener(() => StepEnum(1));
            }
            else
            {
                var input = ModMenuUiFactory.CreateInput("StrInput", row.transform, entry.BoxedValue?.ToString() ?? "", 14f);
                ModMenuUiFactory.SetAnchors(input.GetComponent<RectTransform>(), 0.55f, 0.18f, 0.975f, 0.82f);
                input.SetTextWithoutNotify(entry.BoxedValue?.ToString() ?? "");
                input.onEndEdit.AddListener(txt =>
                {
                    try
                    {
                        entry.SetSerializedValue(txt);
                        cfg.Save();
                    }
                    catch (Exception ex)
                    {
                        PTModMenuPlugin.Log.LogWarning($"Invalid value '{txt}' for {entry.Definition.Key}: {ex.Message}");
                        input.SetTextWithoutNotify(entry.BoxedValue?.ToString() ?? "");
                    }
                });
            }
        }

        private static float SafeToFloat(object v, float fallback)
        {
            try { return v != null ? Convert.ToSingle(v, CultureInfo.InvariantCulture) : fallback; }
            catch { return fallback; }
        }

        private static string FormatNum(float v, bool isInt) =>
            isInt ? Mathf.RoundToInt(v).ToString(CultureInfo.InvariantCulture) : v.ToString("0.##", CultureInfo.InvariantCulture);
    }
}
