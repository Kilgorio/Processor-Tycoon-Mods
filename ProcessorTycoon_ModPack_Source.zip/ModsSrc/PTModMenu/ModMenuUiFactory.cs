using System;
using ProcessorTycoon.UI.Themes;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PTModMenu
{
    internal static class ModMenuUiFactory
    {
        private static TMP_FontAsset _cachedFont;
        private static Sprite _cachedSprite;

        public static bool IsDark => ThemeManager.Instance == null || ThemeManager.Instance.CurrentThemeIsDark;
        public static Color PanelBg => IsDark ? new Color(0.135f, 0.143f, 0.157f, 0.99f) : new Color(0.94f, 0.95f, 0.97f, 0.99f);
        public static Color HeaderBg => IsDark ? new Color(0.105f, 0.112f, 0.125f, 1f) : new Color(0.84f, 0.86f, 0.90f, 1f);
        public static Color CardBg => IsDark ? new Color(0.185f, 0.195f, 0.212f, 1f) : new Color(0.88f, 0.90f, 0.93f, 1f);
        public static Color CardSelBg => IsDark ? new Color(0.19f, 0.30f, 0.44f, 1f) : new Color(0.75f, 0.84f, 0.95f, 1f);
        public static Color InputBg => IsDark ? new Color(0.10f, 0.11f, 0.12f, 1f) : Color.white;
        public static Color BorderCol => IsDark ? new Color(0.28f, 0.30f, 0.34f, 1f) : new Color(0.68f, 0.72f, 0.78f, 1f);
        public static Color TextPrimary => IsDark ? new Color(0.93f, 0.94f, 0.96f, 1f) : new Color(0.10f, 0.12f, 0.15f, 1f);
        public static Color TextMuted => IsDark ? new Color(0.62f, 0.65f, 0.70f, 1f) : new Color(0.38f, 0.42f, 0.48f, 1f);
        public static Color AccentBlue => new Color(0.22f, 0.52f, 0.82f, 1f);
        public static Color AccentGreen => new Color(0.20f, 0.64f, 0.37f, 1f);
        public static Color AccentRed => new Color(0.75f, 0.25f, 0.27f, 1f);
        public static Color AccentAmber => new Color(0.82f, 0.56f, 0.18f, 1f);

        public static void ClearChildren(Transform t)
        {
            if (t == null) return;
            for (int i = t.childCount - 1; i >= 0; i--)
                UnityEngine.Object.Destroy(t.GetChild(i).gameObject);
        }

        public static TMP_FontAsset GetFont()
        {
            if (_cachedFont != null) return _cachedFont;
            foreach (var t in UnityEngine.Object.FindObjectsByType<TMP_Text>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                if (t != null && t.font != null) return _cachedFont = t.font;
            return TMP_Settings.defaultFontAsset;
        }

        public static Sprite GetRoundedSprite()
        {
            if (_cachedSprite != null) return _cachedSprite;
            const int s = 32;
            const float r = 6f;
            var tex = new Texture2D(s, s, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear,
                hideFlags = HideFlags.HideAndDontSave
            };
            var px = new Color32[s * s];
            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float dx = Math.Max(0f, Math.Max(r - x - 0.5f, x + 0.5f - (s - r)));
                    float dy = Math.Max(0f, Math.Max(r - y - 0.5f, y + 0.5f - (s - r)));
                    byte a = (byte)Mathf.RoundToInt(Mathf.Clamp01(r - Mathf.Sqrt(dx * dx + dy * dy) + 0.5f) * 255f);
                    px[y * s + x] = new Color32(255, 255, 255, a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            _cachedSprite = Sprite.Create(tex, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(8, 8, 8, 8));
            _cachedSprite.hideFlags = HideFlags.HideAndDontSave;
            return _cachedSprite;
        }

        public static void SetFixedRowHeight(GameObject go, float height)
        {
            var rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(0f, height);
            var le = go.AddComponent<LayoutElement>();
            le.minHeight = height;
            le.preferredHeight = height;
        }

        public static void StretchFull(RectTransform rt, float left = 0f, float bottom = 0f, float right = 0f, float top = 0f)
        {
            if (rt == null) return;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(right, top);
        }

        public static void SetAnchors(RectTransform rt, float minX, float minY, float maxX, float maxY, float left = 0f, float bottom = 0f, float right = 0f, float top = 0f)
        {
            if (rt == null) return;
            rt.anchorMin = new Vector2(minX, minY);
            rt.anchorMax = new Vector2(maxX, maxY);
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(right, top);
        }

        public static GameObject CreatePanel(string name, Transform parent, Color col, bool rounded)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.color = col;
            if (rounded) { img.sprite = GetRoundedSprite(); img.type = Image.Type.Sliced; }
            return go;
        }

        public static TMP_Text CreateText(string name, Transform parent, string text, float size, TextAlignmentOptions align, Color col, FontStyles style = FontStyles.Normal)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            var tmp = go.GetComponent<TextMeshProUGUI>();
            var f = GetFont();
            if (f != null) tmp.font = f;
            tmp.text = text;
            tmp.fontSize = size;
            tmp.alignment = align;
            tmp.color = col;
            tmp.fontStyle = style;
            tmp.textWrappingMode = TextWrappingModes.Normal;
            tmp.raycastTarget = false;
            return tmp;
        }

        public static Button CreateButton(string name, Transform parent, string label, Color col, float fontSize, Action onClick)
        {
            var go = CreatePanel(name, parent, col, true);
            var btn = go.AddComponent<Button>();
            var cb = btn.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1.14f, 1.14f, 1.14f, 1f);
            cb.pressedColor = new Color(0.84f, 0.84f, 0.84f, 1f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.6f);
            btn.colors = cb;

            var txt = CreateText("Label", go.transform, label, fontSize, TextAlignmentOptions.Center, Color.white, FontStyles.Bold);
            txt.textWrappingMode = TextWrappingModes.NoWrap;
            txt.overflowMode = TextOverflowModes.Ellipsis;
            StretchFull(txt.GetComponent<RectTransform>(), 4f, 1f, -4f, -1f);
            if (onClick != null) btn.onClick.AddListener(() => onClick());
            return btn;
        }

        public static Slider CreateSlider(string name, Transform parent, float min, float max, bool wholeNumbers)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Slider));
            go.transform.SetParent(parent, false);
            var slider = go.GetComponent<Slider>();
            slider.minValue = min;
            slider.maxValue = max;
            slider.wholeNumbers = wholeNumbers;

            var bg = CreatePanel("Background", go.transform, InputBg, true);
            var bgRt = bg.GetComponent<RectTransform>();
            bgRt.anchorMin = new Vector2(0f, 0.5f);
            bgRt.anchorMax = new Vector2(1f, 0.5f);
            bgRt.sizeDelta = new Vector2(0f, 6f);

            var fillArea = new GameObject("Fill Area", typeof(RectTransform));
            fillArea.transform.SetParent(go.transform, false);
            var faRt = fillArea.GetComponent<RectTransform>();
            faRt.anchorMin = new Vector2(0f, 0.5f);
            faRt.anchorMax = new Vector2(1f, 0.5f);
            faRt.sizeDelta = new Vector2(0f, 6f);

            var fill = CreatePanel("Fill", fillArea.transform, AccentBlue, true);
            var fRt = fill.GetComponent<RectTransform>();
            StretchFull(fRt);
            slider.fillRect = fRt;

            var handleArea = new GameObject("Handle Area", typeof(RectTransform));
            handleArea.transform.SetParent(go.transform, false);
            var haRt = handleArea.GetComponent<RectTransform>();
            haRt.anchorMin = new Vector2(0f, 0.5f);
            haRt.anchorMax = new Vector2(1f, 0.5f);
            haRt.pivot = new Vector2(0.5f, 0.5f);
            haRt.anchoredPosition = Vector2.zero;
            haRt.sizeDelta = new Vector2(-16f, 0f);

            var handle = CreatePanel("Handle", handleArea.transform, Color.white, true);
            var hRt = handle.GetComponent<RectTransform>();
            hRt.anchorMin = new Vector2(0.5f, 0.5f);
            hRt.anchorMax = new Vector2(0.5f, 0.5f);
            hRt.pivot = new Vector2(0.5f, 0.5f);
            hRt.sizeDelta = new Vector2(16f, 16f);
            slider.handleRect = hRt;
            slider.targetGraphic = handle.GetComponent<Image>();
            return slider;
        }

        public static TMP_InputField CreateInput(string name, Transform parent, string text, float fontSize)
        {
            var go = CreatePanel(name, parent, InputBg, true);
            go.SetActive(false);
            var ol = go.AddComponent<Outline>();
            ol.effectColor = BorderCol;
            ol.effectDistance = new Vector2(1f, -1f);

            var area = new GameObject("TextArea", typeof(RectTransform), typeof(RectMask2D));
            area.transform.SetParent(go.transform, false);
            var aRt = area.GetComponent<RectTransform>();
            StretchFull(aRt, 8f, 3f, -8f, -3f);

            var t = CreateText("Text", area.transform, text, fontSize, TextAlignmentOptions.Left, TextPrimary);
            StretchFull(t.GetComponent<RectTransform>());
            t.textWrappingMode = TextWrappingModes.NoWrap;

            var inp = go.AddComponent<TMP_InputField>();
            inp.targetGraphic = go.GetComponent<Image>();
            inp.textViewport = aRt;
            inp.textComponent = t;
            inp.fontAsset = GetFont();
            inp.pointSize = fontSize;
            inp.text = text;
            go.SetActive(true);
            return inp;
        }

        public static Transform CreateScrollView(string name, Transform parent, float spacing)
        {
            var scrollGo = new GameObject(name, typeof(RectTransform), typeof(ScrollRect), typeof(Image));
            scrollGo.transform.SetParent(parent, false);
            scrollGo.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.01f);

            var sr = scrollGo.GetComponent<ScrollRect>();
            sr.horizontal = false;
            sr.scrollSensitivity = 36f;
            sr.movementType = ScrollRect.MovementType.Clamped;

            var vp = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D), typeof(Image));
            vp.transform.SetParent(scrollGo.transform, false);
            vp.GetComponent<Image>().color = Color.clear;
            var vpRt = vp.GetComponent<RectTransform>();
            StretchFull(vpRt);
            sr.viewport = vpRt;

            var content = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            content.transform.SetParent(vp.transform, false);
            var cRt = content.GetComponent<RectTransform>();
            cRt.anchorMin = new Vector2(0f, 1f);
            cRt.anchorMax = new Vector2(1f, 1f);
            cRt.pivot = new Vector2(0.5f, 1f);
            cRt.sizeDelta = new Vector2(0f, 0f);
            sr.content = cRt;

            var vlg = content.GetComponent<VerticalLayoutGroup>();
            vlg.spacing = spacing;
            vlg.padding = new RectOffset(4, 4, 4, 10);
            vlg.childControlWidth = true;
            vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;

            var csf = content.GetComponent<ContentSizeFitter>();
            csf.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            return content.transform;
        }
    }
}
