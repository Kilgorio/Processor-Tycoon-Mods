using System;
using System.Collections.Generic;
using System.IO;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using HarmonyLib;

namespace PTModMenu
{
    internal sealed class ModItem
    {
        public string StableKey { get; }
        public string Guid;
        public string Name;
        public string Version;
        public string DllPath;
        public PluginInfo LoadedPlugin;
        public ConfigEntry<bool> EnabledConfig;
        public bool IsSelf;
        public bool RequiresRestart;
        public bool IsEnabled;

        public ModItem(string stableKey)
        {
            StableKey = stableKey;
        }
    }

    internal static class ModDiscoveryService
    {
        private static readonly HashSet<string> RestartPendingKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public static List<ModItem> DiscoverMods()
        {
            var mods = new List<ModItem>();
            var loadedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var pi in Chainloader.PluginInfos.Values)
            {
                if (pi?.Metadata == null) continue;
                string guid = pi.Metadata.GUID;
                string fullLoc = !string.IsNullOrEmpty(pi.Location) ? Path.GetFullPath(pi.Location) : "";
                if (!string.IsNullOrEmpty(fullLoc)) loadedPaths.Add(fullLoc);

                string stableKey = !string.IsNullOrEmpty(guid) ? guid : StripDisabledSuffix(fullLoc);
                var enabledEntry = FindEnabledConfigEntry(pi.Instance?.Config);
                bool isSelf = string.Equals(guid, PTModMenuPlugin.PluginGuid, StringComparison.OrdinalIgnoreCase);
                bool enabled = enabledEntry != null
                    ? enabledEntry.Value
                    : !PTModMenuPlugin.IsGuidMarkedDisabled(guid) && (pi.Instance == null || pi.Instance.enabled) &&
                      (string.IsNullOrEmpty(pi.Location) || !pi.Location.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase));

                mods.Add(new ModItem(stableKey)
                {
                    Guid = guid,
                    Name = pi.Metadata.Name,
                    Version = pi.Metadata.Version?.ToString() ?? "1.0.0",
                    DllPath = fullLoc,
                    LoadedPlugin = pi,
                    EnabledConfig = enabledEntry,
                    IsSelf = isSelf,
                    RequiresRestart = RestartPendingKeys.Contains(stableKey),
                    IsEnabled = enabled
                });
            }

            if (!string.IsNullOrEmpty(Paths.PluginPath) && Directory.Exists(Paths.PluginPath))
            {
                foreach (var file in Directory.GetFiles(Paths.PluginPath, "*.dll.disabled", SearchOption.AllDirectories))
                {
                    string norm = Path.GetFullPath(file);
                    if (norm.IndexOf("\\obj\\", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        norm.IndexOf("\\bin\\", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        norm.IndexOf("\\src", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        norm.IndexOf(".disabled\\", StringComparison.OrdinalIgnoreCase) >= 0)
                        continue;

                    string activeCandidate = StripDisabledSuffix(norm);
                    if (loadedPaths.Contains(norm) || loadedPaths.Contains(activeCandidate)) continue;

                    string stableKey = activeCandidate;
                    bool isPendingRestart = RestartPendingKeys.Contains(stableKey);
                    mods.Add(new ModItem(stableKey)
                    {
                        Guid = "",
                        Name = Path.GetFileNameWithoutExtension(activeCandidate),
                        Version = "Unloaded",
                        DllPath = norm,
                        RequiresRestart = isPendingRestart,
                        IsEnabled = isPendingRestart
                    });
                }
            }

            mods.Sort((a, b) =>
            {
                if (a.IsSelf != b.IsSelf) return a.IsSelf ? -1 : 1;
                return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
            });
            return mods;
        }

        public static ConfigEntry<bool> FindEnabledConfigEntry(ConfigFile cfg)
        {
            if (cfg == null) return null;
            foreach (var key in cfg.Keys)
            {
                if ((string.Equals(key.Key, "Enabled", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(key.Key, "ModEnabled", StringComparison.OrdinalIgnoreCase)) &&
                    cfg[key] is ConfigEntry<bool> boolEntry)
                    return boolEntry;
            }
            return null;
        }

        public static List<ConfigEntryBase> GetEditableEntries(ConfigFile cfg, bool isSelf)
        {
            var list = new List<ConfigEntryBase>();
            if (cfg == null) return list;
            foreach (var def in cfg.Keys)
            {
                if (isSelf && string.Equals(def.Key, "DisabledModGuids", StringComparison.OrdinalIgnoreCase)) continue;
                list.Add(cfg[def]);
            }
            return list;
        }

        public static void SetRestartPending(ModItem mod, bool pending)
        {
            if (mod == null) return;
            mod.RequiresRestart = pending;
            if (pending) RestartPendingKeys.Add(mod.StableKey);
            else RestartPendingKeys.Remove(mod.StableKey);
        }

        public static List<string> FindEnabledDependents(ModItem targetMod, List<ModItem> allMods)
        {
            var dependents = new List<string>();
            if (targetMod == null || string.IsNullOrEmpty(targetMod.Guid)) return dependents;

            foreach (var other in allMods)
            {
                if (other == null || other == targetMod || !other.IsEnabled || other.LoadedPlugin?.Dependencies == null) continue;
                foreach (var dep in other.LoadedPlugin.Dependencies)
                {
                    if (dep == null) continue;
                    if (string.Equals(dep.DependencyGUID, targetMod.Guid, StringComparison.OrdinalIgnoreCase) &&
                        dep.Flags != BepInDependency.DependencyFlags.SoftDependency)
                    {
                        dependents.Add(other.Name);
                        break;
                    }
                }
            }
            return dependents;
        }

        public static bool ToggleModState(ModItem mod, List<ModItem> allMods, out string statusMessage)
        {
            statusMessage = "";
            if (mod == null || mod.IsSelf) return false;
            bool nextState = !mod.IsEnabled;

            if (!nextState)
            {
                var deps = FindEnabledDependents(mod, allMods);
                if (deps.Count > 0)
                {
                    statusMessage = $"Cannot disable {mod.Name}: required by {string.Join(", ", deps)}.";
                    return false;
                }
            }

            if (mod.EnabledConfig != null)
            {
                if (mod.LoadedPlugin?.Instance != null) mod.LoadedPlugin.Instance.enabled = true;
                mod.EnabledConfig.Value = nextState;
                mod.LoadedPlugin?.Instance?.Config?.Save();
                mod.IsEnabled = nextState;
                SetRestartPending(mod, false);
                PTModMenuPlugin.SetGuidMarkedDisabled(mod.Guid, false);
                statusMessage = $"{mod.Name} {(nextState ? "enabled" : "disabled")} live.";
                return true;
            }

            if (mod.LoadedPlugin != null)
            {
                if (!nextState)
                {
                    if (!string.IsNullOrEmpty(mod.Guid)) Harmony.UnpatchID(mod.Guid);
                    if (mod.LoadedPlugin.Instance != null) mod.LoadedPlugin.Instance.enabled = false;
                    PTModMenuPlugin.SetGuidMarkedDisabled(mod.Guid, true);
                    TryRenamePluginDll(mod, toDisabled: true);
                    mod.IsEnabled = false;
                    SetRestartPending(mod, false);
                    statusMessage = $"{mod.Name} disabled live and saved.";
                }
                else
                {
                    if (!TryRenamePluginDll(mod, toDisabled: false))
                    {
                        statusMessage = $"Could not re-enable DLL on disk for {mod.Name}.";
                        return false;
                    }
                    PTModMenuPlugin.SetGuidMarkedDisabled(mod.Guid, false);
                    mod.IsEnabled = true;
                    SetRestartPending(mod, true);
                    statusMessage = $"{mod.Name} marked enabled. Restart the game to re-apply its startup patches.";
                }
                return true;
            }

            if (!TryRenamePluginDll(mod, toDisabled: !nextState))
            {
                statusMessage = $"Could not rename plugin DLL '{Path.GetFileName(mod.DllPath)}'.";
                return false;
            }

            mod.IsEnabled = nextState;
            SetRestartPending(mod, nextState);
            statusMessage = nextState
                ? $"{mod.Name} enabled on disk. Restart the game to load it."
                : $"{mod.Name} disabled on disk.";
            return true;
        }

        private static string StripDisabledSuffix(string path) =>
            !string.IsNullOrEmpty(path) && path.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase)
                ? path.Substring(0, path.Length - ".disabled".Length)
                : (path ?? "");

        public static bool TryRenamePluginDll(ModItem mod, bool toDisabled)
        {
            if (string.IsNullOrEmpty(mod.DllPath)) return true;
            try
            {
                string target = toDisabled
                    ? (mod.DllPath.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase) ? mod.DllPath : mod.DllPath + ".disabled")
                    : StripDisabledSuffix(mod.DllPath);

                if (string.Equals(mod.DllPath, target, StringComparison.OrdinalIgnoreCase)) return true;
                if (!File.Exists(mod.DllPath)) return File.Exists(target);
                if (File.Exists(target)) return false;

                File.Move(mod.DllPath, target);
                mod.DllPath = target;
                return true;
            }
            catch (Exception ex)
            {
                PTModMenuPlugin.Log.LogWarning($"Could not rename plugin DLL '{mod.DllPath}': {ex.Message}");
                return false;
            }
        }
    }
}
