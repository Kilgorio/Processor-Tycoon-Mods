using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.TimeSystem;
using PTModdingAPI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ContractKind = ProcessorTycoon.ContractSystem.ContractType;
using ContractPkgKind = ProcessorTycoon.ContractSystem.PackageType;

namespace PTMotherboardDesigner
{
    public sealed class PlatformDesignSpec
    {
        public string Id;
        public string Name;
        public string ChipsetTechId;
        public int VrmPhases;
        public int MemChannels; // 1, 2, 4, 8
        public float IpcMultiplier;
        public float PowerMultiplier;
        public float FailureMultiplier;
        public float SafeTempBonus;
        public int BomLicenseCost;
    }

    public sealed class ChipsetDef
    {
        public string TechId;
        public string DisplayName;
        public int Year;
        public float BaseIpcMult;
        public float BasePowerMult;
        public float BaseFailMult;
        public int MaxVrmPhases;
        public int BaseBomCost;
        public float BaseProjectCost;
        public int BaseProjectDays;
    }

    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    [BepInDependency(PTModdingApiPlugin.PluginGuid)]
    public class PTMotherboardDesignerPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.motherboarddesigner";
        public const string PluginName = "PT Motherboard & Platform Designer";
        public const string PluginVersion = "2.0.0";

        internal const string TechTabId = "platform";
        internal static ManualLogSource Log;

        public static ConfigEntry<bool> EnableMod;
        public static ConfigEntry<float> ResearchSpeedMult;

        private static readonly List<ChipsetDef> Chipsets = new List<ChipsetDef>
        {
            new ChipsetDef { TechId = "plat_nb_vrm", DisplayName = "Discrete Northbridge & Linear VRM", Year = 1971, BaseIpcMult = 1.01f, BasePowerMult = 0.99f, BaseFailMult = 0.97f, MaxVrmPhases = 3, BaseBomCost = 4, BaseProjectCost = 360_000f, BaseProjectDays = 40 },
            new ChipsetDef { TechId = "plat_pwm_vrm", DisplayName = "Multi-Phase PWM Controller Board", Year = 1986, BaseIpcMult = 1.03f, BasePowerMult = 0.97f, BaseFailMult = 0.93f, MaxVrmPhases = 6, BaseBomCost = 8, BaseProjectCost = 850_000f, BaseProjectDays = 55 },
            new ChipsetDef { TechId = "plat_dual_ch", DisplayName = "Dual-Channel Chipset & Low-ESR Chokes", Year = 2001, BaseIpcMult = 1.06f, BasePowerMult = 0.95f, BaseFailMult = 0.89f, MaxVrmPhases = 10, BaseBomCost = 14, BaseProjectCost = 2_200_000f, BaseProjectDays = 75 },
            new ChipsetDef { TechId = "plat_drmos", DisplayName = "DrMOS High-Phase Digital Platform", Year = 2009, BaseIpcMult = 1.09f, BasePowerMult = 0.92f, BaseFailMult = 0.85f, MaxVrmPhases = 16, BaseBomCost = 22, BaseProjectCost = 4_800_000f, BaseProjectDays = 95 },
            new ChipsetDef { TechId = "plat_hedt_quad", DisplayName = "Workstation Quad-Ch & Point-to-Point", Year = 2014, BaseIpcMult = 1.13f, BasePowerMult = 0.90f, BaseFailMult = 0.81f, MaxVrmPhases = 22, BaseBomCost = 34, BaseProjectCost = 8_200_000f, BaseProjectDays = 115 },
            new ChipsetDef { TechId = "plat_cxl_sps", DisplayName = "24+ Phase SPS & CXL Coherent Platform", Year = 2020, BaseIpcMult = 1.17f, BasePowerMult = 0.87f, BaseFailMult = 0.77f, MaxVrmPhases = 32, BaseBomCost = 48, BaseProjectCost = 13_500_000f, BaseProjectDays = 135 }
        };

        private static readonly DesignCatalog<PlatformDesignSpec> Catalog = new DesignCatalog<PlatformDesignSpec>(p => p.Id);
        private static readonly Dictionary<int, string> SocketBoundPlatformByHwId = new Dictionary<int, string>();
        private static readonly CpuBomTracker BomTracker = new CpuBomTracker();
        private static readonly PersistentDesignProject<PlatformDesignSpec> DesignProject = new PersistentDesignProject<PlatformDesignSpec>("platform_design_proj");
        private static readonly List<ChipsetDef> UnlockedChipsetScratch = new List<ChipsetDef>();
        private static readonly List<int> PruneKeysScratch = new List<int>();
        private static string _cpuSelectedMode = "AUTO";
        private static string _socketSelectedMode = "AUTO";

        private static StudioWindowShell _shell;
        private static TMP_Text _vrmLabel;
        private static Slider _vrmSlider;
        private static Button _ch1Btn, _ch2Btn, _ch4Btn, _ch8Btn;
        private static int _selChipIdx;
        private static int _curVrm = 4;
        private static int _curCh = 1;

        private void Awake()
        {
            Log = Logger;
            EnableMod = Config.Bind("1. General", "Enabled", true, "Enable Motherboard & Platform Designer");
            ResearchSpeedMult = Config.Bind("2. Balance", "Research Speed Multiplier", 1.0f, "Multiplier for Platform R&D speed (0.25 - 3.0)");

            RegisterTechTree();
            RegisterHooks();
            Log.LogInfo($"{PluginName} v{PluginVersion} initialized.");
        }

        private static void RegisterTechTree()
        {
            var tab = new ModTechTabDef
            {
                TabId = TechTabId,
                TabTitle = "Platform",
                Subtitle = "Reference Motherboard chipsets, VRM power stages, and memory/interconnect buses for Desktop & Server CPUs. OEMs adapt reference specs for Computer contracts.",
                ActionButtonLabel = "Open Platform Designer",
                OnActionButtonClick = OpenWindow,
                IsModEnabled = () => EnableMod.Value,
                GetResearchSpeedMultiplier = () => Mathf.Clamp(ResearchSpeedMult?.Value ?? 1f, 0.25f, 3f)
            };

            tab.Branches.Add(new ModTechBranchDef { Id = 0, Name = "Chipset & Memory", AccentColor = UiFactory.AccentBlue });
            tab.Branches.Add(new ModTechBranchDef { Id = 1, Name = "VRM Power Stages", AccentColor = UiFactory.AccentAmber });
            tab.Branches.Add(new ModTechBranchDef { Id = 2, Name = "Platform Fabric", AccentColor = UiFactory.AccentGreen });

            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_nb_vrm", ShortName = "NB Chipset", Name = "Discrete Northbridge & Bus", Branch = 0, Tier = 0, Year = 1971, BaseDays = 85f, MonthlyCost = 55_000f, Description = "Standardizes external memory buffers and clock glue logic.", EffectsSummary = "• Unlocks Northbridge platform\n• Baseline 1-Channel bus" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_pwm_vrm", ShortName = "AGP/PCI Bus", Name = "Multi-Phase PWM Platform", Branch = 0, Tier = 1, Year = 1986, BaseDays = 115f, MonthlyCost = 140_000f, Prereqs = new[] { "plat_nb_vrm" }, Description = "Clean switched-mode motherboard reference bus.", EffectsSummary = "• Unlocks 6-Phase PWM platforms\n• +Desktop contract compatibility" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_dual_ch", ShortName = "Dual-Ch", Name = "Dual-Channel & Low-ESR Board", Branch = 0, Tier = 2, Year = 2001, BaseDays = 145f, MonthlyCost = 360_000f, Prereqs = new[] { "plat_pwm_vrm" }, Description = "Twin-channel memory routing doubling effective memory bandwidth.", EffectsSummary = "• Unlocks 2-Channel boards\n• +6% Multicore IPC" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_quad_ch", ShortName = "Quad-Ch", Name = "Quad-Channel Workstation Routing", Branch = 0, Tier = 3, Year = 2010, BaseDays = 175f, MonthlyCost = 880_000f, Prereqs = new[] { "plat_dual_ch" }, Description = "10-layer matched-impedance trace routing for HEDT & servers.", EffectsSummary = "• Unlocks 4-Channel platforms" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_octa_ch", ShortName = "Octa-Ch", Name = "8-Channel Server Backplane", Branch = 0, Tier = 4, Year = 2017, BaseDays = 215f, MonthlyCost = 2_100_000f, Prereqs = new[] { "plat_quad_ch" }, Description = "High-pin-count server motherboard with 8-channel DDR routing.", EffectsSummary = "• Unlocks 8-Channel Server platforms\n• Strong multi-die IPC scaling" });

            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_solid_cap", ShortName = "Solid Cap", Name = "Low-ESR Polymer Capacitor VRM", Branch = 1, Tier = 1, Year = 1998, BaseDays = 120f, MonthlyCost = 210_000f, Prereqs = new[] { "plat_pwm_vrm" }, Description = "Replaces electrolytic caps for cleaner transient droop recovery.", EffectsSummary = "• VRM Limit raised to 8 phases\n• -4% Failure rate" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_drmos", ShortName = "DrMOS", Name = "DrMOS Integrated Power Stages", Branch = 1, Tier = 2, Year = 2009, BaseDays = 155f, MonthlyCost = 620_000f, Prereqs = new[] { "plat_solid_cap", "plat_dual_ch" }, Description = "Integrated driver+MOSFET stages slashing VRM heat and voltage ripple.", EffectsSummary = "• Unlocks 16-Phase DrMOS platforms\n• -15% Failure rate · -8% Power" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_llc_loop", ShortName = "Digital LLC", Name = "Digital Load-Line Calibration", Branch = 1, Tier = 3, Year = 2013, BaseDays = 175f, MonthlyCost = 1_100_000f, Prereqs = new[] { "plat_drmos" }, Description = "Real-time voltage droop feedback stabilizes boost clocks.", EffectsSummary = "• +2.0°C VRM thermal margin" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_titanium_vrm", ShortName = "24+ SPS", Name = "Titanium 24+ Phase Smart Power", Branch = 1, Tier = 4, Year = 2019, BaseDays = 210f, MonthlyCost = 2_450_000f, Prereqs = new[] { "plat_llc_loop" }, Description = "Ultra-dense smart power stages for 64-core server sockets.", EffectsSummary = "• Unlocks 32-Phase VRM limit" });

            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_fsb_ddr", ShortName = "QDR FSB", Name = "Quad-Pumped System Interconnect", Branch = 2, Tier = 0, Year = 2000, BaseDays = 135f, MonthlyCost = 300_000f, Prereqs = new[] { "plat_pwm_vrm" }, Description = "High-bandwidth front-side interconnect between CPU and Northbridge.", EffectsSummary = "• +2% IPC baseline on desktop boards" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_p2p_link", ShortName = "P2P Link", Name = "Coherent Point-to-Point Bus", Branch = 2, Tier = 1, Year = 2007, BaseDays = 165f, MonthlyCost = 760_000f, Prereqs = new[] { "plat_fsb_ddr", "plat_dual_ch" }, Description = "Eliminates shared FSB bottlenecks across multi-core sockets.", EffectsSummary = "• Needed for Workstation platforms\n• Reduces multi-core latency" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_hedt_quad", ShortName = "HEDT Ref", Name = "Workstation HEDT Reference", Branch = 2, Tier = 2, Year = 2014, BaseDays = 190f, MonthlyCost = 1_500_000f, Prereqs = new[] { "plat_p2p_link", "plat_quad_ch" }, Description = "Validated enterprise workstation reference motherboard specification.", EffectsSummary = "• Unlocks 22-Phase HEDT platforms\n• Boosts Desktop contract power ceilings" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_pcie_gen5", ShortName = "PCIe 5.0", Name = "Redriver & PCIe 5.0 Lanes", Branch = 2, Tier = 3, Year = 2019, BaseDays = 205f, MonthlyCost = 2_200_000f, Prereqs = new[] { "plat_hedt_quad" }, Description = "Low-loss retimed motherboard PCB materials for 32GT/s signaling.", EffectsSummary = "• +3% IPC bonus on modern sockets" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_cxl_sps", ShortName = "CXL Fabric", Name = "CXL 2.0 Coherent Fabric", Branch = 2, Tier = 4, Year = 2020, BaseDays = 230f, MonthlyCost = 3_100_000f, Prereqs = new[] { "plat_pcie_gen5", "plat_octa_ch" }, Description = "Cache-coherent CXL expansion lanes for rack-scale CPUs.", EffectsSummary = "• Unlocks flagship CXL platforms\n• +17% IPC · -23% Failure rate" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "plat_optical_board", ShortName = "Opto-PCB", Name = "Silicon Photonics Backplane", Branch = 2, Tier = 5, Year = 2024, BaseDays = 260f, MonthlyCost = 4_200_000f, Prereqs = new[] { "plat_cxl_sps" }, Description = "Optical waveguide motherboard routing for extreme TDP data centers.", EffectsSummary = "• Bonus -5% power draw across PGA/LGA boards" });

            ModTechRegistry.RegisterTechTab(tab);
        }

        private static void RegisterHooks()
        {
            ModApi.RegisterSaveParticipant("platform_designer", SerializeDesigns, DeserializeDesigns, ResetState);

            ModApi.RegisterHardwareMenuAction(new HardwareMenuButtonDef
            {
                Id = "new_platform",
                Label = "New Reference Platform",
                IsVisible = () => EnableMod.Value,
                OnClick = OpenWindow
            });

            ModApi.RegisterCreatorCpuSlot(new CreatorCpuSlotDef
            {
                SlotId = "platform_slot",
                Label = "Platform",
                IsVisible = () => EnableMod.Value,
                IsInteractable = () => { var p = ModApi.CurrentCreatorPackage; return p != null && p.IsPgaOrLga; },
                GetDisplayText = GetCreatorSlotText,
                GetBadgeColor = GetCreatorSlotColor,
                OnPrev = () => CycleCpuSelection(-1),
                OnNext = () => CycleCpuSelection(1),
                OnOpenStudio = OpenWindow,
                OnClick = OpenWindow
            });

            ModApi.RegisterCreatorSocketSlot(new CreatorCpuSlotDef
            {
                SlotId = "socket_platform_slot",
                Label = "Ref Platform",
                IsVisible = () => EnableMod.Value,
                IsInteractable = () => true,
                GetDisplayText = GetSocketSlotText,
                GetBadgeColor = GetSocketSlotColor,
                OnPrev = () => CycleSocketSelection(-1),
                OnNext = () => CycleSocketSelection(1),
                OnOpenStudio = OpenWindow,
                OnClick = OpenWindow
            });

            ModApi.RegisterSocketCreatedListener(hw =>
            {
                if (EnableMod.Value && hw != null) SocketBoundPlatformByHwId[hw.SaveID] = _socketSelectedMode;
            });

            ModApi.RegisterCreatorPackageChangedListener(pkg =>
            {
                if (EnableMod.Value && pkg is CustomSocket cs && SocketBoundPlatformByHwId.TryGetValue(cs.CustomHardwareID, out var bound))
                    _cpuSelectedMode = bound;
            });

            BomTracker.RegisterHooks(() => EnableMod.Value, () => { var s = GetActiveSpec(); return s != null ? s.BomLicenseCost : 0; });

            ModApi.RegisterPackageSafeTemperatureModifier((pkg, cur) =>
            {
                if (!EnableMod.Value || pkg == null || !pkg.IsPgaOrLga) return cur;
                var spec = GetActiveSpec();
                if (spec == null) return cur;
                var st = ModTechRegistry.GetPlayerState(TechTabId);
                float extra = spec.SafeTempBonus + ((st != null && st.IsUnlocked("plat_llc_loop")) ? 2.0f : 0f);
                return Mathf.Max(cur, Mathf.Min(95f, cur + extra));
            });

            ModApi.RegisterCpuStatModifier((ctx, mods) =>
            {
                if (!EnableMod.Value || ctx?.Package == null || !ctx.Package.IsPgaOrLga) return;
                var spec = GetActiveSpec();
                if (spec == null) return;

                var st = ModTechRegistry.GetPlayerState(TechTabId);
                float coreScale = ctx.CoreCount >= 8 || ctx.DieCount >= 2 ? 1.0f : 0.65f;
                float extraIpc = (spec.IpcMultiplier - 1f) * coreScale;
                if (st != null && st.IsUnlocked("plat_fsb_ddr")) extraIpc += 0.015f;
                if (st != null && st.IsUnlocked("plat_pcie_gen5") && ctx.DieCount >= 2) extraIpc += 0.025f;

                float powMult = spec.PowerMultiplier;
                if (st != null && st.IsUnlocked("plat_optical_board")) powMult *= 0.95f;

                float failMult = spec.FailureMultiplier;
                if (st != null && st.IsUnlocked("plat_solid_cap")) failMult *= 0.96f;

                mods.IpcMultiplier *= (1f + extraIpc);
                mods.PowerMultiplier *= powMult;
                mods.FailureMultiplier *= failMult;
            });

            ModApi.RegisterContractPowerModifier((contract, cpu, curMult) =>
            {
                if (!EnableMod.Value || contract == null) return curMult;
                if (contract.ContractType != ContractKind.Computer || contract.PackageType != (int)ContractPkgKind.PGAAndLGA) return curMult;
                var st = ModTechRegistry.GetPlayerState(TechTabId);
                int count = st?.UnlockedIds.Count ?? 0;
                int yr = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
                float prog = Mathf.Max(Mathf.Clamp01((yr - 1980f) / 42f) * 0.65f, Mathf.Clamp01(count / 12f));
                return curMult * (1f + prog * 0.28f);
            });
        }

        private static void ResetState()
        {
            Catalog.Clear();
            SocketBoundPlatformByHwId.Clear();
            BomTracker.Clear();
            DesignProject.Clear();
            _cpuSelectedMode = "AUTO";
            _socketSelectedMode = "AUTO";
            if (_shell?.OverlayGo != null) _shell.OverlayGo.SetActive(false);
        }

        private static void CycleCpuSelection(int dir)
        {
            _cpuSelectedMode = Catalog.CycleMode(_cpuSelectedMode, dir);
            ModApi.RefreshCreatorCpu();
            if (_shell?.OverlayGo != null && _shell.OverlayGo.activeInHierarchy) RefreshPreview();
        }

        private static void CycleSocketSelection(int dir)
        {
            _socketSelectedMode = Catalog.CycleMode(_socketSelectedMode, dir);
            ModApi.RefreshCreatorSocket();
            if (_shell?.OverlayGo != null && _shell.OverlayGo.activeInHierarchy) RefreshPreview();
        }

        private static PlatformDesignSpec GetActiveSpec() => GetSpecForMode(ref _cpuSelectedMode);

        private static PlatformDesignSpec GetSpecForMode(ref string mode) =>
            Catalog.Resolve(ref mode, TechTabId, st =>
            {
                ChipsetDef best = null;
                for (int i = 0; i < Chipsets.Count; i++)
                    if (st != null && st.IsUnlocked(Chipsets[i].TechId)) best = Chipsets[i];
                if (best == null) return null;
                int maxCh = st.IsUnlocked("plat_octa_ch") ? 8 : st.IsUnlocked("plat_quad_ch") ? 4 : st.IsUnlocked("plat_dual_ch") ? 2 : 1;
                int spIdx = best.DisplayName.IndexOf(' ');
                string shortName = spIdx > 0 ? best.DisplayName.Substring(0, spIdx) : best.DisplayName;
                return ComputeSpec($"Ref {shortName}", best, Math.Min(GetMaxUnlockedVrm(), best.MaxVrmPhases), maxCh);
            });

        private static int GetMaxUnlockedVrm()
        {
            var st = ModTechRegistry.GetPlayerState(TechTabId);
            if (st == null) return 3;
            if (st.IsUnlocked("plat_titanium_vrm")) return 32;
            if (st.IsUnlocked("plat_drmos")) return 18;
            if (st.IsUnlocked("plat_solid_cap")) return 8;
            if (st.IsUnlocked("plat_pwm_vrm")) return 6;
            return 3;
        }

        private static string GetCreatorSlotText()
        {
            var pkg = ModApi.CurrentCreatorPackage;
            if (pkg != null && !pkg.IsPgaOrLga) return "Platform: Embedded / SoC (N/A)";
            var sp = GetActiveSpec();
            if (_cpuSelectedMode == "NONE") return "Platform: Minimal ($0)";
            if (sp == null) return "Platform: Locked (Research)";
            return $"Platform: {(_cpuSelectedMode == "AUTO" ? "Auto" : sp.Name)} ({sp.MemChannels}Ch, {sp.VrmPhases}Ph, +${sp.BomLicenseCost})";
        }

        private static Color GetCreatorSlotColor()
        {
            var pkg = ModApi.CurrentCreatorPackage;
            if (pkg != null && !pkg.IsPgaOrLga) return UiFactory.CardAltBg;
            if (GetActiveSpec() == null) return UiFactory.CardAltBg;
            return _cpuSelectedMode == "AUTO" ? new Color(0.18f, 0.25f, 0.34f, 1f) : new Color(0.22f, 0.32f, 0.18f, 1f);
        }

        private static string GetSocketSlotText()
        {
            var sp = GetSpecForMode(ref _socketSelectedMode);
            if (_socketSelectedMode == "NONE") return "Socket Ref Platform: Minimal";
            if (sp == null) return "Socket Ref Platform: Locked";
            return $"Socket Ref Platform: {(_socketSelectedMode == "AUTO" ? "Auto" : sp.Name)} ({sp.MemChannels}Ch, {sp.VrmPhases}Ph)";
        }

        private static Color GetSocketSlotColor() =>
            GetSpecForMode(ref _socketSelectedMode) == null
                ? UiFactory.CardAltBg
                : (_socketSelectedMode == "AUTO" ? new Color(0.18f, 0.25f, 0.34f, 1f) : new Color(0.22f, 0.32f, 0.18f, 1f));

        private static PlatformDesignSpec ComputeSpec(string name, ChipsetDef chip, int vrmPhases, int channels)
        {
            float chBonus = channels >= 8 ? 0.06f : channels >= 4 ? 0.04f : channels >= 2 ? 0.02f : 0f;
            float vrmRatio = Mathf.Clamp01(vrmPhases / 24f);
            int bom = chip.BaseBomCost + Mathf.RoundToInt(vrmPhases * 0.7f) + (channels >= 8 ? 14 : channels >= 4 ? 7 : channels >= 2 ? 3 : 0);
            return new PlatformDesignSpec
            {
                Name = name, ChipsetTechId = chip.TechId, VrmPhases = vrmPhases, MemChannels = channels,
                IpcMultiplier = chip.BaseIpcMult + chBonus,
                PowerMultiplier = chip.BasePowerMult * (1f - vrmRatio * 0.05f),
                FailureMultiplier = chip.BaseFailMult * (1f - vrmRatio * 0.08f),
                SafeTempBonus = vrmRatio * 3.5f,
                BomLicenseCost = bom
            };
        }

        private static (int days, float cost) EstimateProject(ChipsetDef chip, int vrmPhases, int channels)
        {
            float scale = (0.85f + vrmPhases * 0.025f) * (channels >= 8 ? 1.45f : channels >= 4 ? 1.25f : channels >= 2 ? 1.1f : 1f);
            return (Mathf.Clamp(Mathf.RoundToInt(chip.BaseProjectDays * Mathf.Sqrt(scale)), 30, 190),
                    Mathf.Round(chip.BaseProjectCost * scale / 1000f) * 1000f);
        }

        private static List<ChipsetDef> GetUnlockedChipsets()
        {
            var st = ModTechRegistry.GetPlayerState(TechTabId);
            UnlockedChipsetScratch.Clear();
            for (int i = 0; i < Chipsets.Count; i++)
                if (st != null && st.IsUnlocked(Chipsets[i].TechId)) UnlockedChipsetScratch.Add(Chipsets[i]);
            return UnlockedChipsetScratch;
        }

        public static void OpenWindow()
        {
            UiFactory.EnsureEventSystem();
            if (_shell == null || _shell.OverlayGo == null) BuildWindow();
            _shell.OverlayGo.SetActive(true);
            RefreshUI();
        }

        private static void BuildWindow()
        {
            _shell = StudioWindowShell.Create(
                "PTMotherboardDesigner", 510f, "Reference Motherboard & Chipset Studio", "Platform Catalog (Assign in Socket / CPU)",
                "Reference Board / Chipset Name", "Board Rev 1", "e.g. X570 Pro...",
                "Chipset & Bus Class (Tech-Gated)", "Platform Tech Tree", TechTabId, "Start Platform Project",
                dir => { var u = GetUnlockedChipsets(); if (u.Count > 0) _selChipIdx = (_selChipIdx + dir + u.Count) % u.Count; RefreshUI(); },
                OnBuildPlatformClicked,
                previewMinY: 0.155f, previewMaxY: 0.345f, selectorMinY: 0.65f, selectorMaxY: 0.73f);

            var rp = _shell.RightPane;
            _vrmLabel = UiFactory.CreateText("VrmLbl", rp, "VRM Power Phases: 4", 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary);
            _vrmLabel.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.565f, 0.96f, 0.63f);
            _vrmSlider = UiFactory.CreateSlider("VrmSld", rp, 2f, 32f, 4f, v => { _curVrm = Mathf.RoundToInt(v); RefreshPreview(); }, wholeNumbers: true);
            _vrmSlider.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.505f, 0.96f, 0.565f);

            UiFactory.CreateText("ChLbl", rp, "Memory Channel Topology (Tech-Gated)", 12f, TextAlignmentOptions.MidlineLeft, UiFactory.TextPrimary)
                .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.435f, 0.96f, 0.495f);

            _ch1Btn = UiFactory.CreateButton("Ch1", rp, "Single-Ch", UiFactory.AccentBlue, () => { _curCh = 1; RefreshUI(); }, 11.5f);
            _ch1Btn.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.355f, 0.255f, 0.425f);
            _ch2Btn = UiFactory.CreateButton("Ch2", rp, "Dual-Ch", UiFactory.CardBg, () => { _curCh = 2; RefreshUI(); }, 11.5f);
            _ch2Btn.GetComponent<RectTransform>().SetAnchorStretch(0.275f, 0.355f, 0.49f, 0.425f);
            _ch4Btn = UiFactory.CreateButton("Ch4", rp, "Quad-Ch", UiFactory.CardBg, () => { _curCh = 4; RefreshUI(); }, 11.5f);
            _ch4Btn.GetComponent<RectTransform>().SetAnchorStretch(0.51f, 0.355f, 0.725f, 0.425f);
            _ch8Btn = UiFactory.CreateButton("Ch8", rp, "Octa-Ch", UiFactory.CardBg, () => { _curCh = 8; RefreshUI(); }, 11.5f);
            _ch8Btn.GetComponent<RectTransform>().SetAnchorStretch(0.745f, 0.355f, 0.96f, 0.425f);
        }

        private static void RefreshUI()
        {
            if (_shell?.WindowGo == null) return;
            _shell.RebuildCatalogRows(
                Catalog.Items, "No custom reference boards yet.\nUse Auto or develop one ->",
                p => p.Id, p => p.Name,
                p => $"{p.MemChannels}Ch · {p.VrmPhases}Ph VRM · +${p.BomLicenseCost} Ref",
                p =>
                {
                    Catalog.Items.RemoveAll(x => x.Id == p.Id);
                    if (_cpuSelectedMode == p.Id) _cpuSelectedMode = "AUTO";
                    if (_socketSelectedMode == p.Id) _socketSelectedMode = "AUTO";
                    PruneKeysScratch.Clear();
                    foreach (var kv in SocketBoundPlatformByHwId) if (kv.Value == p.Id) PruneKeysScratch.Add(kv.Key);
                    for (int i = 0; i < PruneKeysScratch.Count; i++) SocketBoundPlatformByHwId[PruneKeysScratch[i]] = "AUTO";

                    RefreshUI();
                    ModApi.RefreshCreatorCpu();
                    ModApi.RefreshCreatorSocket();
                });
            RefreshPreview();
        }

        private static void RefreshPreview()
        {
            if (_shell?.WindowGo == null) return;
            var unlocked = GetUnlockedChipsets();
            var st = ModTechRegistry.GetPlayerState(TechTabId);

            bool has2 = st != null && st.IsUnlocked("plat_dual_ch");
            bool has4 = st != null && st.IsUnlocked("plat_quad_ch");
            bool has8 = st != null && st.IsUnlocked("plat_octa_ch");
            if (_curCh == 8 && !has8) _curCh = has4 ? 4 : has2 ? 2 : 1;
            if (_curCh == 4 && !has4) _curCh = has2 ? 2 : 1;
            if (_curCh == 2 && !has2) _curCh = 1;

            StudioWindowShell.SetSegmentButton(_ch1Btn, _curCh == 1, true);
            StudioWindowShell.SetSegmentButton(_ch2Btn, _curCh == 2, has2);
            StudioWindowShell.SetSegmentButton(_ch4Btn, _curCh == 4, has4);
            StudioWindowShell.SetSegmentButton(_ch8Btn, _curCh == 8, has8);

            if (unlocked.Count == 0)
            {
                _shell.TechLabel.text = "None Unlocked (Research Platform Tech)";
                _shell.PreviewText.text = "Research 'Discrete Northbridge' in Platform tab first.";
                _shell.BuildButton.interactable = false;
                _shell.BuildButtonText.text = "Locked";
                return;
            }

            _selChipIdx = Mathf.Clamp(_selChipIdx, 0, unlocked.Count - 1);
            var chip = unlocked[_selChipIdx];
            _shell.TechLabel.text = $"{chip.DisplayName} ({chip.Year})";

            int maxPhases = Math.Min(GetMaxUnlockedVrm(), chip.MaxVrmPhases);
            _vrmSlider.minValue = 2;
            _vrmSlider.maxValue = Math.Max(2, maxPhases);
            _curVrm = Mathf.Clamp(_curVrm, 2, maxPhases);
            _vrmSlider.SetValueWithoutNotify(_curVrm);
            _vrmLabel.text = $"VRM Power Phases: {_curVrm} (max {maxPhases})";

            var spec = ComputeSpec("Preview", chip, _curVrm, _curCh);
            var proj = EstimateProject(chip, _curVrm, _curCh);

            _shell.PreviewText.text =
                $"<b>IPC Bonus:</b> +{(spec.IpcMultiplier - 1f) * 100f:0.#}%    <b>Power Draw:</b> {(spec.PowerMultiplier - 1f) * 100f:0.#}%    <b>Reliability:</b> -{(1f - spec.FailureMultiplier) * 100f:0.#}% fail\n" +
                $"<b>Ref Bus:</b> {spec.MemChannels}-Ch DDR · {spec.VrmPhases}-Ph VRM     <b>CPU BOM/License:</b> +${spec.BomLicenseCost}\n" +
                $"<b>R&D Project:</b> {UiFactory.FormatMoneyCompact(proj.cost)} over {proj.days} days (daily bank-credit billing)";

            _shell.UpdateBuildState(DesignProject.ProjectId, "Start Platform Project",
                "Assign platforms in Socket Creation (default) or CPU Creation.", "Platform R&D running in Side Window -> Projects.");
        }

        private static void OnBuildPlatformClicked()
        {
            var unlocked = GetUnlockedChipsets();
            if (unlocked.Count == 0 || DesignProject.IsActive) return;
            var chip = unlocked[Mathf.Clamp(_selChipIdx, 0, unlocked.Count - 1)];
            string name = SaveCodec.CleanField(string.IsNullOrWhiteSpace(_shell?.NameInput?.text) ? $"Ref Board #{Catalog.Items.Count + 1}" : _shell.NameInput.text.Trim());
            var spec = ComputeSpec(name, chip, _curVrm, _curCh);
            spec.Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            var proj = EstimateProject(chip, _curVrm, _curCh);
            StartPlatformProject(spec, proj.days, proj.cost, 0f, notifyStart: true);
        }

        private static void StartPlatformProject(PlatformDesignSpec spec, int days, float cost, float initialProgress, bool notifyStart)
        {
            DesignProject.Start(spec, spec.Name, "Platform R&D", days, cost, initialProgress, () =>
            {
                Catalog.Items.Add(spec);
                _cpuSelectedMode = spec.Id;
                _socketSelectedMode = spec.Id;
                ModApi.RefreshCreatorCpu();
                ModApi.RefreshCreatorSocket();
                RefreshUI();
                if (DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating)
                    PopupManager.Instance?.InstantiateGenericNotification($"Platform Ready: {spec.Name}", $"{spec.MemChannels}Ch · {spec.VrmPhases}Ph VRM");
            });

            RefreshPreview();
            if (notifyStart)
                PopupManager.Instance?.InstantiateGenericNotification($"Platform Started: {spec.Name}", $"{days}d · {UiFactory.FormatMoneyCompact(cost)}");
        }

        private static string FormatSpecFields(PlatformDesignSpec d) => string.Join("|", new[]
        {
            d.Id, SaveCodec.CleanField(d.Name), d.ChipsetTechId,
            d.VrmPhases.ToString(CultureInfo.InvariantCulture), d.MemChannels.ToString(CultureInfo.InvariantCulture),
            SaveCodec.FormatFloat(d.IpcMultiplier), SaveCodec.FormatFloat(d.PowerMultiplier),
            SaveCodec.FormatFloat(d.FailureMultiplier), SaveCodec.FormatFloat(d.SafeTempBonus),
            d.BomLicenseCost.ToString(CultureInfo.InvariantCulture)
        });

        private static PlatformDesignSpec ParseSpecFields(string[] p, int s) => new PlatformDesignSpec
        {
            Id = p[s], Name = p[s + 1], ChipsetTechId = p[s + 2],
            VrmPhases = SaveCodec.ParseInt(p[s + 3], 4), MemChannels = SaveCodec.ParseInt(p[s + 4], 1),
            IpcMultiplier = SaveCodec.ParseFloat(p[s + 5], 1.02f), PowerMultiplier = SaveCodec.ParseFloat(p[s + 6], 0.98f),
            FailureMultiplier = SaveCodec.ParseFloat(p[s + 7], 0.95f), SafeTempBonus = SaveCodec.ParseFloat(p[s + 8], 1f),
            BomLicenseCost = SaveCodec.ParseInt(p[s + 9], 6)
        };

        private static string SerializeDesigns()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"CPUMODE|{_cpuSelectedMode}");
            sb.AppendLine($"SOCKMODE|{_socketSelectedMode}");
            DesignProject.WritePendingLine(sb, FormatSpecFields);
            for (int i = 0; i < Catalog.Items.Count; i++) sb.AppendLine($"P|{FormatSpecFields(Catalog.Items[i])}");
            foreach (var kv in SocketBoundPlatformByHwId) sb.AppendLine($"SOCK|{kv.Key.ToString(CultureInfo.InvariantCulture)}|{kv.Value}");
            BomTracker.WriteLines(sb);
            return sb.ToString();
        }

        private static void DeserializeDesigns(string raw)
        {
            ResetState();
            if (string.IsNullOrWhiteSpace(raw)) return;
            foreach (var line in raw.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = line.Split('|');
                if (p[0] == "MODE" && p.Length >= 2) { _cpuSelectedMode = p[1]; _socketSelectedMode = p[1]; }
                else if (p[0] == "CPUMODE" && p.Length >= 2) _cpuSelectedMode = p[1];
                else if (p[0] == "SOCKMODE" && p.Length >= 2) _socketSelectedMode = p[1];
                else if (p[0] == "P" && p.Length >= 11) Catalog.Items.Add(ParseSpecFields(p, 1));
                else if (p[0] == "SOCK" && p.Length >= 3 && int.TryParse(p[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out int hwId))
                    SocketBoundPlatformByHwId[hwId] = p[2];
                else if (!BomTracker.TryReadLine(p))
                    DesignProject.TryReadPendingLine(p, 14, ParseSpecFields, 60, 1_000_000f, (spec, days, cost, prog) => StartPlatformProject(spec, days, cost, prog, false));
            }
        }
    }
}
