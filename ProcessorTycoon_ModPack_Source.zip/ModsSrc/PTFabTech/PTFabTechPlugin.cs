using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using PTModdingAPI;
using UnityEngine;

namespace PTFabTech
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    [BepInDependency(PTModdingApiPlugin.PluginGuid)]
    public class PTFabTechPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.fabtech";
        public const string PluginName = "PT Fab & Packaging Tech";
        public const string PluginVersion = "2.0.0";

        internal const string TechTabId = "fabtech";
        internal static ManualLogSource Log;

        public static ConfigEntry<bool> EnableMod;
        public static ConfigEntry<float> ResearchSpeedMult;
        public static ConfigEntry<float> FabBonusScale;

        private void Awake()
        {
            Log = Logger;
            EnableMod = Config.Bind("1. General", "Enabled", true, "Enable Fab & Multi-Die Packaging Research Tech Tree");
            ResearchSpeedMult = Config.Bind("2. Balance", "Research Speed Multiplier", 1.0f, "Multiplier for Fab R&D research speed (0.25 - 3.0)");
            FabBonusScale = Config.Bind("2. Balance", "Fab Throughput Bonus Scale", 1.0f, "Multiplier on wafer & multi-die bonuses (0.5 - 2.0)");

            RegisterTechTree();
            RegisterFabHooks();
            Log.LogInfo($"{PluginName} v{PluginVersion} initialized.");
        }

        private static void RegisterTechTree()
        {
            var tab = new ModTechTabDef
            {
                TabId = TechTabId,
                TabTitle = "Fab Tech",
                Subtitle = "Research wafer automation, cleanroom planarization, and multi-die interposer packaging. Balances throughput (+15% to +145%) & 8-die 2016+ scaling without breaking vanilla yields.",
                IsModEnabled = () => EnableMod.Value,
                GetResearchSpeedMultiplier = () => Mathf.Clamp(ResearchSpeedMult?.Value ?? 1f, 0.25f, 3f)
            };

            tab.Branches.Add(new ModTechBranchDef { Id = 0, Name = "Litho & Cleanroom", AccentColor = UiFactory.AccentBlue });
            tab.Branches.Add(new ModTechBranchDef { Id = 1, Name = "Multi-Die & Interposer", AccentColor = UiFactory.AccentGreen });

            // Branch 0: Wafer throughput & node learning (balanced, non-OP!)
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_auto_stepper", ShortName = "Stepper", Name = "Automated Wafer Stepper", Branch = 0, Tier = 0, Year = 1982, BaseDays = 115f, MonthlyCost = 180_000f, Description = "Closed-loop optical alignment reduces reticle swap downtime.", EffectsSummary = "• Wafer Output +15%\n• Node Yield +1.5%" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_cmp_scan", ShortName = "CMP Scan", Name = "CMP Planarization & Inspection", Branch = 0, Tier = 1, Year = 1992, BaseDays = 145f, MonthlyCost = 450_000f, Prereqs = new[] { "fab_auto_stepper" }, Description = "Chemical-mechanical planarization flattens sub-micron interconnect layers.", EffectsSummary = "• Cumulative Wafer Output +32%\n• Node Yield +3.0%" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_300_foup", ShortName = "300mm FOUP", Name = "300mm FOUP & Copper Dual-Damascene", Branch = 0, Tier = 2, Year = 2001, BaseDays = 175f, MonthlyCost = 1_150_000f, Prereqs = new[] { "fab_cmp_scan" }, Description = "Overhead hoist cleanroom transport with copper metalization.", EffectsSummary = "• Cumulative Wafer Output +58%\n• Node Yield +4.5%" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_immersion", ShortName = "Immersion", Name = "ArF Immersion & Quad-Patterning", Branch = 0, Tier = 3, Year = 2012, BaseDays = 210f, MonthlyCost = 2_600_000f, Prereqs = new[] { "fab_300_foup" }, Description = "Liquid immersion lenses and pitch-splitting cut sub-22nm defectivity.", EffectsSummary = "• Cumulative Wafer Output +95%\n• Node Yield +6.5%" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_euv_pellicle", ShortName = "EUV HighNA", Name = "EUV Pellicle & Stochastic APC", Branch = 0, Tier = 4, Year = 2019, BaseDays = 245f, MonthlyCost = 5_200_000f, Prereqs = new[] { "fab_immersion" }, Description = "13.5nm EUV masks with advanced process control keep sub-7nm yields healthy.", EffectsSummary = "• Cumulative Wafer Output +145%\n• Node Yield +8.5%" });

            // Branch 1: Multi-Die & Chiplet Packaging (built specifically for 2016+ 8-die 64-core era!)
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_mcm_sub", ShortName = "MCM Sub", Name = "High-Density Organic MCM Substrate", Branch = 1, Tier = 2, Year = 2005, BaseDays = 140f, MonthlyCost = 680_000f, Prereqs = new[] { "fab_cmp_scan" }, Description = "Multi-die organic package substrate for dual & quad-chiplet modules.", EffectsSummary = "• -22% Multi-Die fail rate penalty\n• +10% Output on >=2-Die CPUs" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_interposer", ShortName = "2.5D Interp", Name = "2.5D Silicon Interposer & Microbump", Branch = 1, Tier = 3, Year = 2016, BaseDays = 185f, MonthlyCost = 1_850_000f, Prereqs = new[] { "fab_mcm_sub", "fab_300_foup" }, Description = "CoWoS/EMIB silicon bridges cut assembly defects in 8-die 64-core CPUs.", EffectsSummary = "• -48% Multi-Die fail rate penalty\n• +22% Output on >=2-Die CPUs" });
            tab.Nodes.Add(new ModTechNodeDef { Id = "fab_3d_bond", ShortName = "3D Bond", Name = "Cu-Cu Hybrid 3D Die Bonding", Branch = 1, Tier = 4, Year = 2021, BaseDays = 225f, MonthlyCost = 3_900_000f, Prereqs = new[] { "fab_interposer", "fab_immersion" }, Description = "Sub-micron direct copper hybrid bonding for stacked chiplets.", EffectsSummary = "• -72% Multi-Die fail rate penalty\n• +35% Output on >=2-Die CPUs" });

            ModTechRegistry.RegisterTechTab(tab);
        }

        private static void RegisterFabHooks()
        {
            ModApi.RegisterFabModifier((comp, dieCount, fm) =>
            {
                if (!EnableMod.Value || comp == null) return;
                var st = ModTechRegistry.GetState(TechTabId, comp);
                if (st == null || st.UnlockedIds.Count == 0) return;

                float scale = Mathf.Clamp(FabBonusScale?.Value ?? 1f, 0.5f, 2f);
                float throughputBonus = 0f;
                float yieldBonus = 0f;
                float dieFailRed = 0f;

                if (st.IsUnlocked("fab_euv_pellicle")) { throughputBonus = 1.45f; yieldBonus = 0.085f; }
                else if (st.IsUnlocked("fab_immersion")) { throughputBonus = 0.95f; yieldBonus = 0.065f; }
                else if (st.IsUnlocked("fab_300_foup")) { throughputBonus = 0.58f; yieldBonus = 0.045f; }
                else if (st.IsUnlocked("fab_cmp_scan")) { throughputBonus = 0.32f; yieldBonus = 0.030f; }
                else if (st.IsUnlocked("fab_auto_stepper")) { throughputBonus = 0.15f; yieldBonus = 0.015f; }

                if (dieCount >= 2)
                {
                    if (st.IsUnlocked("fab_3d_bond")) { dieFailRed = 0.72f; throughputBonus += 0.35f; }
                    else if (st.IsUnlocked("fab_interposer")) { dieFailRed = 0.48f; throughputBonus += 0.22f; }
                    else if (st.IsUnlocked("fab_mcm_sub")) { dieFailRed = 0.22f; throughputBonus += 0.10f; }
                }

                fm.ThroughputMultiplier *= (1f + throughputBonus * scale);
                fm.YieldBonus += yieldBonus * scale;
                fm.MultiDieFailureReduction = Mathf.Max(fm.MultiDieFailureReduction, Mathf.Clamp01(dieFailRed * scale));
            });
        }
    }
}
