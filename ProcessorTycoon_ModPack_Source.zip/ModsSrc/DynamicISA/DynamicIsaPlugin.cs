using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.Save;

namespace DynamicISA
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class DynamicIsaPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.dynamicisa";
        public const string PluginName = "Dynamic ISA & Architecture Ecosystem";
        public const string PluginVersion = "1.0.0";

        public static ManualLogSource Log { get; private set; }
        private static Harmony _harmony;
        private static bool _patchesApplied;
        private static string _pendingSaveName;
        private static bool _preRegisteredPendingLoad;
        private static SaveHandler _hookedSaveHandler;

        public static ConfigEntry<bool> ModEnabled { get; private set; }
        public static ConfigEntry<float> ResearchSpeedMult { get; private set; }
        public static ConfigEntry<float> FeatureStatScale { get; private set; }
        public static ConfigEntry<int> MaxCrossLicensePartners { get; private set; }
        public static ConfigEntry<float> BreakPenaltyMult { get; private set; }
        public static ConfigEntry<bool> EnableAiIsaResearch { get; private set; }
        public static ConfigEntry<bool> EnableAiCrossLicensing { get; private set; }

        public static bool IsEnabled => ModEnabled == null || ModEnabled.Value;

        private void Awake()
        {
            Log = Logger;
            _harmony = new Harmony(PluginGuid);

            ModEnabled = Config.Bind("1. General", "Enabled", true,
                "Enable Dynamic ISA & Custom Architecture mod.");
            ResearchSpeedMult = Config.Bind("2. Balance", "ResearchSpeedMultiplier", 1.0f,
                new ConfigDescription("Global multiplier for ISA Tech Tree research speed.",
                    new AcceptableValueRange<float>(0.25f, 3.0f)));
            FeatureStatScale = Config.Bind("2. Balance", "FeatureStatScale", 1.0f,
                new ConfigDescription("Global multiplier for IPC, Power Efficiency, and Clock bonuses granted by ISA features.",
                    new AcceptableValueRange<float>(0.25f, 2.5f)));
            MaxCrossLicensePartners = Config.Bind("3. Contracts", "MaxCrossLicensePartners", 3,
                new ConfigDescription("Maximum co-owners allowed per ISA via Cross-Licensing.",
                    new AcceptableValueRange<int>(1, 8)));
            BreakPenaltyMult = Config.Bind("3. Contracts", "BreakContractPenaltyMult", 1.25f,
                new ConfigDescription("Penalty multiplier on upfront cash when canceling a Cross-License early.",
                    new AcceptableValueRange<float>(0.5f, 3.0f)));
            EnableAiIsaResearch = Config.Bind("4. AI", "EnableAiIsaResearch", true,
                "Allow AI companies to research ISA technologies, evolve 64-bit ISAs, and tune Focus Triangle.");
            EnableAiCrossLicensing = Config.Bind("4. AI", "EnableAiCrossLicensing", true,
                "Allow AI companies to sign Cross-License deals.");

            ModEnabled.SettingChanged += (_, _) => ApplyEnabledState(ModEnabled.Value);
            FeatureStatScale.SettingChanged += (_, _) => IsaState.RefreshAllProfileStats();

            if (ModEnabled.Value)
                ApplyEnabledState(true);
            else
                Log.LogInfo($"{PluginName} v{PluginVersion} loaded (disabled by config).");
        }

        private void OnDestroy()
        {
            UnsubscribeSaveEvents();
            if (_patchesApplied && _harmony != null)
            {
                _harmony.UnpatchSelf();
                _patchesApplied = false;
            }
        }

        public static void ApplyEnabledState(bool enable)
        {
            try
            {
                if (enable && !_patchesApplied)
                {
                    IsaResearchTabUI.ApplyPatches(_harmony);
                    IsaCreatorWindow.ApplyPatches(_harmony);
                    DynamicMarketIsaEngine.ApplyPatches(_harmony);
                    DynamicAiIsaController.ApplyPatches(_harmony);
                    IsaContractIntegration.ApplyPatches(_harmony);

                    _harmony.Patch(AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Save)),
                        postfix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(SaveHandler_Save_Postfix)));
                    _harmony.Patch(AccessTools.Method(typeof(SaveHandler), nameof(SaveHandler.Load)),
                        prefix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(SaveHandler_Load_Prefix)),
                        postfix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(SaveHandler_Load_Postfix)));
                    _harmony.Patch(AccessTools.Method(typeof(DataConverter), nameof(DataConverter.SaveObjectToCpu)),
                        prefix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(DataConverter_SaveObjectToCpu_Prefix)));
                    _harmony.Patch(AccessTools.Method(typeof(DataConverter), nameof(DataConverter.SaveProjectToCpu)),
                        prefix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(DataConverter_SaveProjectToCpu_Prefix)));
                    _harmony.Patch(AccessTools.Method(typeof(Player), nameof(Player.InitializeAsNewGame)),
                        prefix: new HarmonyMethod(typeof(DynamicIsaPlugin), nameof(Player_NewGame_Prefix)));

                    _patchesApplied = true;
                    IsaResearchTabUI.SetUiActive(true);
                    Log.LogInfo($"{PluginName} v{PluginVersion} enabled cleanly.");
                }
                else if (!enable && _patchesApplied)
                {
                    UnsubscribeSaveEvents();
                    _harmony.UnpatchSelf();
                    _patchesApplied = false;
                    IsaResearchTabUI.SetUiActive(false);
                    IsaCreatorWindow.CancelBuildOnDisable();
                    IsaCreatorWindow.Close();
                    IsaContractIntegration.ResetUiState();
                    DynamicAiIsaController.InvalidateAiArchCache();
                    Log.LogInfo($"{PluginName} v{PluginVersion} disabled live.");
                }
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed toggling {PluginName}: {ex}");
            }
        }

        private static void UnsubscribeSaveEvents()
        {
            if (_hookedSaveHandler == null) return;
            _hookedSaveHandler.DuringLoad -= EnsurePreRegistered;
            _hookedSaveHandler.OnLoaded -= OnSaveLoaded;
            _hookedSaveHandler.OnLateLoaded -= OnSaveLateLoaded;
            _hookedSaveHandler = null;
        }

        private static void SaveHandler_Save_Postfix(string saveName) => IsaPersistence.SaveToFile(saveName);

        private static void DataConverter_SaveObjectToCpu_Prefix(SaveObject.Cpu saveCpu)
        {
            EnsurePreRegistered();
            if (!string.IsNullOrEmpty(saveCpu?.Architecture)) IsaState.EnsureFallbackArchitectureExists(saveCpu.Architecture);
        }

        private static void DataConverter_SaveProjectToCpu_Prefix(SaveObject.CpuProject saveCpuProject)
        {
            EnsurePreRegistered();
            if (!string.IsNullOrEmpty(saveCpuProject?.Architecture)) IsaState.EnsureFallbackArchitectureExists(saveCpuProject.Architecture);
        }

        private static void SaveHandler_Load_Prefix(string fileName)
        {
            _pendingSaveName = fileName;
            _preRegisteredPendingLoad = false;
            DynamicMarketIsaEngine.ResetSessionFlags();
            IsaContractIntegration.ResetUiState();
            IsaCreatorWindow.ActiveNativeProject = null;
            IsaCreatorWindow.CurrentPlayerBuild = null;
        }

        private static void SaveHandler_Load_Postfix(SaveHandler __instance, string fileName)
        {
            if (__instance == null || string.IsNullOrEmpty(fileName)) return;
            UnsubscribeSaveEvents();
            _hookedSaveHandler = __instance;
            __instance.DuringLoad += EnsurePreRegistered;
            __instance.OnLoaded += OnSaveLoaded;
            __instance.OnLateLoaded += OnSaveLateLoaded;
        }

        private static void EnsurePreRegistered()
        {
            if (!_preRegisteredPendingLoad && !string.IsNullOrEmpty(_pendingSaveName))
            {
                _preRegisteredPendingLoad = true;
                IsaPersistence.PreRegisterCustomArchitecturesFromFile(_pendingSaveName);
            }
        }

        private static void OnSaveLoaded()
        {
            if (string.IsNullOrEmpty(_pendingSaveName)) return;
            EnsurePreRegistered();
            IsaPersistence.LoadFromFileAfterDeserialize(_pendingSaveName);
        }

        private static void OnSaveLateLoaded()
        {
            if (IsaCreatorWindow.CurrentPlayerBuild != null && Player.Instance?.Company != null)
                IsaCreatorWindow.SpawnNativeSideProject(IsaCreatorWindow.CurrentPlayerBuild, Player.Instance.Company);
        }

        private static void Player_NewGame_Prefix()
        {
            _pendingSaveName = null;
            _preRegisteredPendingLoad = false;
            IsaState.ClearAllRuntimeState();
            DynamicMarketIsaEngine.ResetSessionFlags();
            IsaContractIntegration.ResetUiState();
            IsaCreatorWindow.ActiveNativeProject = null;
            IsaCreatorWindow.CurrentPlayerBuild = null;
        }
    }
}
