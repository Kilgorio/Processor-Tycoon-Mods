using System;
using System.Collections.Generic;
using System.Linq;

namespace DynamicISA
{
    public enum IsaBranch
    {
        ExecutionPipeline = 0,
        AddressingBitWidth = 1,
        SimdVector = 2,
        PowerMobile = 3,
        ServerSecurity = 4
    }

    public enum IsaParadigm
    {
        CISC = 0,
        RISC = 1,
        VLIW = 2
    }

    public class IsaTechNode
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string ShortTag { get; set; }
        public string Description { get; set; }
        public IsaBranch Branch { get; set; }
        public int UnlockYear { get; set; }
        public int Column { get; set; }
        public int Row { get; set; }
        public string[] Dependencies { get; set; } = Array.Empty<string>();

        public float MonthlyCost { get; set; }
        public int ResearchDays { get; set; }
        public float BuildCost { get; set; }
        public int BuildDays { get; set; }

        public float IpcBonus { get; set; }
        public float PowerDelta { get; set; }
        public float ClockBonus { get; set; }

        public float DesktopAppeal { get; set; }
        public float ServerAppeal { get; set; }
        public float MobileAppeal { get; set; }
        public float IndustrialAppeal { get; set; }

        public int BitWidth { get; set; }
        public bool IsBackwardsCompat64 { get; set; }
        public bool IsCleanSheet64 { get; set; }
        public bool RequiresCleanSheet { get; set; }
        public bool UnlocksVliwParadigm { get; set; }
    }

    public static class IsaTechTree
    {
        public static readonly List<IsaTechNode> Nodes = BuildNodes();
        private static readonly Dictionary<string, IsaTechNode> ById = Nodes.ToDictionary(n => n.Id, n => n);

        public static IsaTechNode Get(string id) => !string.IsNullOrEmpty(id) && ById.TryGetValue(id, out var n) ? n : null;

        public static string BranchName(IsaBranch b) => b switch
        {
            IsaBranch.ExecutionPipeline => "Execution & Pipeline",
            IsaBranch.AddressingBitWidth => "Addressing & Bit-Width",
            IsaBranch.SimdVector => "SIMD & Vector / AI",
            IsaBranch.PowerMobile => "Power & Mobile",
            IsaBranch.ServerSecurity => "Server & Security",
            _ => "ISA"
        };

        private static IsaTechNode Node(
            string id, string name, string tag, IsaBranch branch, int year, int col, int row, string[] deps,
            float mCostM, int rDays, float bCostM, int bDays,
            float ipc, float pow, float clk, float desk, float srv, float mob, float ind,
            string desc, int bits = 0, bool compat64 = false, bool clean64 = false, bool reqClean = false, bool vliw = false)
        {
            return new IsaTechNode
            {
                Id = id, Name = name, ShortTag = tag, Branch = branch, UnlockYear = year, Column = col, Row = row,
                Dependencies = deps ?? Array.Empty<string>(),
                MonthlyCost = mCostM * 1_000_000f, ResearchDays = rDays, BuildCost = bCostM * 1_000_000f, BuildDays = bDays,
                IpcBonus = ipc, PowerDelta = pow, ClockBonus = clk,
                DesktopAppeal = desk, ServerAppeal = srv, MobileAppeal = mob, IndustrialAppeal = ind,
                Description = desc, BitWidth = bits,
                IsBackwardsCompat64 = compat64, IsCleanSheet64 = clean64, RequiresCleanSheet = reqClean, UnlocksVliwParadigm = vliw
            };
        }

        private static List<IsaTechNode> BuildNodes() => new List<IsaTechNode>
        {
            // Branch 0: Execution & Pipeline
            Node("isa_microcode", "Microcoded Control", "uCode", IsaBranch.ExecutionPipeline, 1971, 0, 0, null,
                1.2f, 90, 1.5f, 20, 0.02f, 0.02f, 0.00f, 0.03f, 0.02f, 0.00f, 0.04f,
                "Structured microcode sequencer enabling richer instruction decoding."),
            Node("isa_pipelining", "Scalar Pipelining", "Pipe", IsaBranch.ExecutionPipeline, 1978, 1, 0, new[] { "isa_microcode" },
                3.5f, 140, 4.0f, 25, 0.03f, 0.02f, 0.06f, 0.05f, 0.04f, 0.02f, 0.03f,
                "Overlapped fetch-decode-execute stages dramatically raise achievable clock rates."),
            Node("isa_branch_pred", "Dynamic Branch Pred.", "BPU", IsaBranch.ExecutionPipeline, 1991, 3, 0, new[] { "isa_pipelining" },
                14f, 180, 15f, 30, 0.04f, 0.02f, 0.03f, 0.06f, 0.06f, 0.02f, 0.02f,
                "Hardware branch history tables cut pipeline stalls across complex workloads."),
            Node("isa_superscalar", "Superscalar Dual-Issue", "2-Issue", IsaBranch.ExecutionPipeline, 1989, 2, 1, new[] { "isa_pipelining" },
                10f, 180, 12f, 30, 0.05f, 0.04f, 0.01f, 0.06f, 0.06f, 0.01f, 0.02f,
                "Dispatches multiple independent instructions per cycle from a single core."),
            Node("isa_ooo", "Out-of-Order Execution", "OoO", IsaBranch.ExecutionPipeline, 1995, 4, 1, new[] { "isa_superscalar", "isa_branch_pred" },
                32f, 240, 38f, 40, 0.07f, 0.06f, -0.02f, 0.08f, 0.08f, -0.01f, 0.01f,
                "Dynamic register renaming & reorder buffers maximize real-world IPC cleanly."),
            Node("isa_uop_cache", "Macro-Op Fusion & uOp$", "uOp$", IsaBranch.ExecutionPipeline, 2006, 6, 0, new[] { "isa_ooo" },
                90f, 260, 95f, 40, 0.05f, -0.04f, 0.03f, 0.07f, 0.07f, 0.05f, 0.01f,
                "Eliminates CISC/legacy decode penalties with decoded micro-op loop caches."),
            Node("isa_spec_guard", "Speculative Isolation", "SpecSec", IsaBranch.ExecutionPipeline, 2018, 8, 0, new[] { "isa_uop_cache" },
                220f, 260, 180f, 35, 0.02f, 0.01f, 0.01f, 0.04f, 0.12f, 0.04f, 0.03f,
                "Hardware speculation fencing that protects enterprise & cloud tenants."),

            // Branch 1: Addressing, Bit-Width & Paradigm
            Node("isa_16bit", "16-Bit Segmented ISA", "16b", IsaBranch.AddressingBitWidth, 1975, 1, 2, new[] { "isa_microcode" },
                2.2f, 110, 3.0f, 20, 0.02f, 0.01f, 0.01f, 0.07f, 0.02f, 0.00f, 0.05f,
                "Expanded 16-bit general registers & segmented addressing for early PCs.", bits: 16),
            Node("isa_risc_loadstore", "RISC Fixed-Length Encoding", "RISC", IsaBranch.AddressingBitWidth, 1981, 2, 3, new[] { "isa_16bit" },
                6.0f, 160, 8.0f, 25, 0.02f, -0.09f, 0.04f, 0.01f, 0.04f, 0.12f, 0.07f,
                "Uniform 32-bit instructions & load/store discipline cut decode watts sharply.", bits: 32),
            Node("isa_32bit", "32-Bit Flat Protected Mode", "32b", IsaBranch.AddressingBitWidth, 1985, 3, 2, new[] { "isa_16bit" },
                12f, 200, 18f, 30, 0.04f, 0.02f, 0.02f, 0.12f, 0.10f, 0.03f, 0.04f,
                "4 GB linear virtual memory & kernel protection rings powering OS ecosystems.", bits: 32),
            Node("isa_vliw_epic", "EPIC / VLIW Bundling", "EPIC", IsaBranch.AddressingBitWidth, 1994, 4, 3, new[] { "isa_superscalar", "isa_32bit" },
                42f, 260, 65f, 45, 0.08f, 0.05f, -0.06f, -0.04f, 0.08f, -0.06f, 0.03f,
                "Compiler-scheduled wide instruction bundles chasing huge peak throughput; incompatible with legacy decode.", reqClean: true, vliw: true),
            Node("isa_64bit_ext", "64-Bit Extension (x86-64)", "x64", IsaBranch.AddressingBitWidth, 1999, 5, 2, new[] { "isa_32bit" },
                110f, 300, 120f, 45, 0.06f, 0.02f, 0.03f, 0.14f, 0.16f, 0.06f, 0.04f,
                "Doubles register width & adds 64-bit addressing atop existing 32-bit binaries with zero emulation penalty.", bits: 64, compat64: true),
            Node("isa_64bit_clean", "Clean-Sheet 64-Bit Native", "IA64", IsaBranch.AddressingBitWidth, 1997, 5, 3, new[] { "isa_vliw_epic" },
                140f, 330, 180f, 50, 0.10f, -0.02f, 0.00f, 0.02f, 0.18f, 0.03f, 0.06f,
                "Pure 64-bit orthogonal register file discarding legacy baggage for peak server IPC — requires full ecosystem port.", bits: 64, clean64: true, reqClean: true),

            // Branch 2: SIMD, Vector & AI
            Node("isa_fpu", "On-Die Hardware FPU", "x87/FPU", IsaBranch.SimdVector, 1980, 2, 4, new[] { "isa_16bit" },
                5.0f, 150, 7.5f, 25, 0.03f, 0.03f, 0.00f, 0.06f, 0.07f, 0.00f, 0.08f,
                "IEEE-754 floating-point instructions accelerated natively inside the execution core."),
            Node("isa_mmx_simd", "Packed Media SIMD", "MMX", IsaBranch.SimdVector, 1996, 4, 4, new[] { "isa_fpu" },
                24f, 180, 25f, 25, 0.03f, 0.02f, 0.01f, 0.09f, 0.04f, 0.05f, 0.02f,
                "64-bit packed integer SIMD instructions for audio, video, and 3D acceleration."),
            Node("isa_sse_fp", "128-Bit Streaming Vectors", "SSE", IsaBranch.SimdVector, 1999, 5, 4, new[] { "isa_mmx_simd" },
                50f, 210, 45f, 30, 0.04f, 0.03f, 0.01f, 0.10f, 0.07f, 0.05f, 0.03f,
                "Dedicated 128-bit FP vector registers accelerating games, codecs, and scientific compute."),
            Node("isa_avx256", "256-Bit Wide AVX/SVE", "AVX2", IsaBranch.SimdVector, 2011, 7, 4, new[] { "isa_sse_fp" },
                140f, 270, 130f, 35, 0.05f, 0.05f, -0.01f, 0.08f, 0.12f, 0.02f, 0.04f,
                "3-operand fused multiply-add 256-bit vectors for workstation & datacenter dominance."),
            Node("isa_matrix_ai", "512-Bit & Tensor Matrix", "Tensor", IsaBranch.SimdVector, 2017, 8, 4, new[] { "isa_avx256" },
                320f, 320, 260f, 45, 0.06f, 0.07f, 0.00f, 0.06f, 0.15f, 0.08f, 0.05f,
                "Systolic BF16/INT8 matrix opcodes turning general CPUs into AI inference powerhouses."),

            // Branch 3: Power Efficiency & Mobile
            Node("isa_clock_gating", "ISA Clock & Power Gating", "C-State", IsaBranch.PowerMobile, 1991, 3, 5, new[] { "isa_risc_loadstore" },
                9.0f, 150, 12f, 25, 0.01f, -0.08f, 0.01f, 0.03f, 0.04f, 0.14f, 0.06f,
                "Architectural sleep states and idle unit clock gating cut wasted battery power."),
            Node("isa_dvfs", "Dynamic P-State & Turbo", "DVFS", IsaBranch.PowerMobile, 2000, 5, 5, new[] { "isa_clock_gating" },
                36f, 200, 40f, 30, 0.02f, -0.07f, 0.04f, 0.06f, 0.07f, 0.15f, 0.05f,
                "Telemetry-driven per-core voltage/frequency scaling for mobile thrift & desktop turbo boost."),
            Node("isa_big_little", "Heterogeneous P/E Hinting", "big.LTL", IsaBranch.PowerMobile, 2011, 7, 5, new[] { "isa_dvfs" },
                125f, 250, 110f, 35, 0.03f, -0.09f, 0.02f, 0.06f, 0.05f, 0.18f, 0.04f,
                "OS-visible asymmetric core scheduling mixes efficiency & performance cores seamlessly."),
            Node("isa_ulp_npu", "Ultra-Low-Power Edge DSP", "EdgeNPU", IsaBranch.PowerMobile, 2018, 8, 5, new[] { "isa_big_little" },
                240f, 280, 180f, 35, 0.03f, -0.07f, 0.01f, 0.04f, 0.05f, 0.18f, 0.10f,
                "Tightly-coupled neural wake DSP letting mobile & IoT chips crush perf-per-watt."),

            // Branch 4: Server, Virtualization & Interconnect
            Node("isa_hw_virt", "Hardware Virtualization (VT)", "VT-x", IsaBranch.ServerSecurity, 2005, 6, -1, new[] { "isa_32bit" },
                70f, 220, 75f, 30, 0.02f, 0.02f, 0.00f, 0.03f, 0.16f, 0.02f, 0.03f,
                "Trapless hypervisor ring extensions unlocking multi-tenant cloud & server consolidation."),
            Node("isa_aes_enclave", "Hardware AES & Trust Enclave", "AES-NI", IsaBranch.ServerSecurity, 2009, 7, -1, new[] { "isa_hw_virt" },
                115f, 230, 95f, 30, 0.02f, -0.01f, 0.01f, 0.04f, 0.14f, 0.06f, 0.04f,
                "Dedicated crypto pipelines & encrypted VM memory enclaves mandatory for cloud datacenters."),
            Node("isa_chiplet_coherency", "Chiplet Mesh & Cache Coherency", "CCIX", IsaBranch.ServerSecurity, 2016, 8, -1, new[] { "isa_aes_enclave", "isa_64bit_ext" },
                210f, 280, 200f, 40, 0.05f, -0.02f, 0.02f, 0.08f, 0.18f, 0.02f, 0.04f,
                "Inter-die coherent fabric & memory-page extensions scaling high-core server chiplets.")
        };
    }
}
