using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.ProjectSystem;
using ProcessorTycoon.ProjectSystem.UI;
using ProcessorTycoon.TimeSystem;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DynamicISA
{
    public class ActiveIsaBuildProject
    {
        public string ExistingUid { get; set; }
        public string Name { get; set; }
        public IsaParadigm Paradigm { get; set; }
        public float FocusIpc { get; set; }
        public float FocusEff { get; set; }
        public float FocusClk { get; set; }
        public List<string> Features { get; set; } = new List<string>();
        public List<string> CompatibleIds { get; set; } = new List<string>();
        public bool IsProprietary { get; set; }
        public float RoyaltyRate { get; set; }
        public int TotalDays { get; set; }
        public int DaysDone { get; set; }
        public float TotalCost { get; set; }
    }

    public static class IsaCreatorWindow
    {
        public static ActiveIsaBuildProject CurrentPlayerBuild { get; set; }
        public static Project ActiveNativeProject { get; set; }

        private static readonly FieldInfo ProjDailyProgF = AccessTools.Field(typeof(Project), "dailyProgress");
        private static readonly FieldInfo ProjDailyCostF = AccessTools.Field(typeof(Project), "dailyCost");
        private static readonly MethodInfo ProjCalcRemM = AccessTools.Method(typeof(Project), "CalculateRemainingCost");
        private static readonly FieldInfo ProjUiSecTxtF = AccessTools.Field(typeof(ProjectUI), "secondaryText");

        private static GameObject _windowGo;
        private static Button _createArchHookBtn;
        private static bool _isEvolveMode;
        private static string _selectedEvolveUid;
        private static string _livePolicyNotice = "";

        private static Button _tabNewBtn, _tabEvolveBtn;
        private static TMP_Dropdown _evolveTargetDd, _paradigmDd, _compatDd;
        private static GameObject _evolveTargetRow;
        private static RectTransform _leftNameRow, _leftParaRow, _leftCompatRow, _leftLicBox, _leftTriHdr, _leftTriBox, _leftPresets;

        private static TMP_InputField _nameInput;
        private static Toggle _proprietaryToggle;
        private static Slider _royaltySlider;
        private static TMP_Text _royaltyValTxt;

        private static IsaTriangleWidget _triangle;
        private static Transform _featuresContent;
        private static int _activeFilterBranch = -1;
        private static readonly List<Button> FilterButtons = new List<Button>();
        private static TMP_Text _featCountTxt;

        private static readonly List<GameObject> FeatureRows = new List<GameObject>();
        private static readonly HashSet<string> SelectedFeatures = new HashSet<string>();
        private static readonly List<string> EvolveUids = new List<string>();
        private static readonly List<string> CompatUids = new List<string>();

        private static TMP_Text _summaryTitleTxt, _summaryStatsTxt, _projectInfoTxt, _buildBtnTxt;
        private static Button _buildBtn, _cancelBuildBtn;
        private static bool _suppressUiEvents;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(CreateHardwareWindow), "UpdateButtonStates"),
                postfix: new HarmonyMethod(typeof(IsaCreatorWindow), nameof(CreateHardwareWindow_Update_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreateHardwareWindow), "OnEnable"),
                postfix: new HarmonyMethod(typeof(IsaCreatorWindow), nameof(CreateHardwareWindow_Update_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(Project), "TickCost"),
                postfix: new HarmonyMethod(typeof(IsaCreatorWindow), nameof(Project_TickCost_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ProjectUI), nameof(ProjectUI.UpdateUI)),
                postfix: new HarmonyMethod(typeof(IsaCreatorWindow), nameof(ProjectUI_UpdateUI_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(TimerScheduler), nameof(TimerScheduler.Unschedule)),
                prefix: new HarmonyMethod(typeof(IsaCreatorWindow), nameof(TimerScheduler_Unschedule_Prefix)));
        }

        private static (IsaParadigm paradigm, List<string> compatIds, Architecture existingArch, IsaProfile existingProf) GetEffectiveDesignTargets()
        {
            if (_isEvolveMode && EvolveUids.Count > 0)
            {
                var arch = ArchitectureManager.Instance?.GetArchitecture(_selectedEvolveUid);
                if (arch != null)
                {
                    var prof = IsaState.GetOrCreateProfile(arch);
                    return (prof.Paradigm, prof.CompatibleIds ?? new List<string>(), arch, prof);
                }
            }

            IsaParadigm paradigm = (IsaParadigm)Mathf.Clamp(_paradigmDd != null ? _paradigmDd.value : 0, 0, 2);
            var compat = new List<string>();
            if (_compatDd != null && _compatDd.value > 0 && _compatDd.value < CompatUids.Count && !string.IsNullOrEmpty(CompatUids[_compatDd.value]))
                compat.Add(CompatUids[_compatDd.value]);
            return (paradigm, compat, null, null);
        }

        private static void Project_TickCost_Postfix(Project __instance)
        {
            if (__instance == null || __instance != ActiveNativeProject || CurrentPlayerBuild == null) return;
            float dailyCost = ProjDailyCostF?.GetValue(__instance) is float dc ? dc : 0f;
            if (dailyCost > 0f) __instance.Company?.SpendMoney(dailyCost, ExpenseOrigin.Development);
            CurrentPlayerBuild.DaysDone = Mathf.Clamp(Mathf.RoundToInt(__instance.Progress * CurrentPlayerBuild.TotalDays), 0, CurrentPlayerBuild.TotalDays);
            if (_windowGo != null && _windowGo.activeInHierarchy) RefreshPreview();
        }

        private static void ProjectUI_UpdateUI_Postfix(ProjectUI __instance)
        {
            if (__instance?.Project == null || __instance.Project != ActiveNativeProject || CurrentPlayerBuild == null) return;
            if (ProjUiSecTxtF?.GetValue(__instance) is TMP_Text sec)
            {
                string modeTag = string.IsNullOrEmpty(CurrentPlayerBuild.ExistingUid) ? "New ISA" : "ISA Upgrade";
                sec.text = $"{CurrentPlayerBuild.Paradigm} · {modeTag} ({CurrentPlayerBuild.Features.Count} ext.)";
            }
        }

        private static void TimerScheduler_Unschedule_Prefix(ITimer timer)
        {
            if (timer != null && ReferenceEquals(timer, ActiveNativeProject))
            {
                ActiveNativeProject = null;
                CurrentPlayerBuild = null;
                if (_windowGo != null && _windowGo.activeInHierarchy) RefreshPreview();
            }
        }

        private static void CreateHardwareWindow_Update_Postfix(CreateHardwareWindow __instance)
        {
            if (__instance == null) return;
            if (_createArchHookBtn == null)
            {
                foreach (var btn in __instance.GetComponentsInChildren<Button>(true))
                {
                    if (btn == null) continue;
                    string txt = btn.GetComponentInChildren<TMP_Text>(true)?.text ?? "";
                    if (btn.gameObject.name.IndexOf("Arch", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        txt.IndexOf("Architecture", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        txt.IndexOf("Evolve ISA", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        _createArchHookBtn = btn;
                        break;
                    }
                }
            }
            if (_createArchHookBtn == null) return;

            var coreOpen = _createArchHookBtn.GetComponent<CreatorOpenButton>();
            if (coreOpen != null) UnityEngine.Object.Destroy(coreOpen);

            _createArchHookBtn.interactable = Player.Instance?.Company != null && !Player.Instance.Company.IsFoundry;
            var label = _createArchHookBtn.GetComponentInChildren<TMP_Text>(true);
            if (label != null && (label.text.IndexOf("x86", StringComparison.OrdinalIgnoreCase) >= 0 || label.text.IndexOf("Architecture", StringComparison.OrdinalIgnoreCase) >= 0))
                label.text = "New / Evolve ISA";

            var uiBtn = _createArchHookBtn.GetComponent<ButtonUI>();
            if (uiBtn != null) { uiBtn.Interactable = _createArchHookBtn.interactable; uiBtn.ResetOnClick(); }

            _createArchHookBtn.onClick.RemoveAllListeners();
            _createArchHookBtn.onClick.AddListener(Open);
        }

        public static void Open()
        {
            if (!DynamicIsaPlugin.IsEnabled) return;
            try
            {
                if (_windowGo == null) BuildWindow();
                _windowGo.SetActive(true);
                _windowGo.transform.SetAsLastSibling();
                SetMode(false);
                RefreshPreview();
            }
            catch (Exception ex)
            {
                DynamicIsaPlugin.Log?.LogError($"Failed opening ISA Studio: {ex}");
            }
        }

        public static void Close() => _windowGo?.SetActive(false);

        public static void CancelBuildOnDisable()
        {
            if (ActiveNativeProject != null) OnCancelActiveBuildClicked();
            else CurrentPlayerBuild = null;
        }

        private static void BuildWindow()
        {
            var parentCanvas = CreateHardwareWindow.Instance != null
                ? CreateHardwareWindow.Instance.GetComponentInParent<Canvas>()
                : UnityEngine.Object.FindFirstObjectByType<Canvas>();

            _windowGo = IsaUiHelper.CreatePanel("DynamicISA_CreatorWindow", parentCanvas.transform, IsaUiHelper.PanelBg, true);
            var wRt = _windowGo.GetComponent<RectTransform>();
            wRt.anchorMin = wRt.anchorMax = wRt.pivot = new Vector2(0.5f, 0.5f);
            wRt.sizeDelta = new Vector2(960f, 640f);
            wRt.anchoredPosition = Vector2.zero;

            var outline = _windowGo.AddComponent<Outline>();
            outline.effectColor = IsaUiHelper.BorderCol; outline.effectDistance = new Vector2(1.5f, -1.5f);

            var header = IsaUiHelper.CreatePanel("Header", _windowGo.transform, IsaUiHelper.HeaderBg, true);
            header.GetComponent<RectTransform>().SetTopAnchored(0f, 44f, 0f);

            IsaUiHelper.CreateText("Title", header.transform, "ISA Architecture Studio  (Design & Evolve)", 17f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.5f, 1f, 16f, 0f, 0f, 0f);

            _tabNewBtn = IsaUiHelper.CreateButton("TabNew", header.transform, "Create New ISA", IsaUiHelper.AccentBlue, 13f, () => SetMode(false));
            _tabNewBtn.GetComponent<RectTransform>().SetAnchorStretch(0.52f, 0.14f, 0.71f, 0.86f);

            _tabEvolveBtn = IsaUiHelper.CreateButton("TabEvolve", header.transform, "Evolve Owned ISA", IsaUiHelper.CardBg, 13f, () => SetMode(true));
            _tabEvolveBtn.GetComponent<RectTransform>().SetAnchorStretch(0.72f, 0.14f, 0.92f, 0.86f);

            IsaUiHelper.CreateButton("CloseBtn", header.transform, "X", IsaUiHelper.AccentRed, 14f, Close)
                .GetComponent<RectTransform>().SetAnchorStretch(0.945f, 0.16f, 0.99f, 0.84f);

            // LEFT COLUMN
            var leftCol = IsaUiHelper.CreatePanel("LeftCol", _windowGo.transform, IsaUiHelper.CardAltBg, true);
            leftCol.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.37f, 1f, 12f, 12f, -5f, -52f);

            float y = -12f;
            _evolveTargetRow = new GameObject("EvolveRow", typeof(RectTransform));
            _evolveTargetRow.transform.SetParent(leftCol.transform, false);
            _evolveTargetRow.GetComponent<RectTransform>().SetTopAnchored(y, 48f);

            IsaUiHelper.CreateText("EvolveLbl", _evolveTargetRow.transform, "Select ISA to Evolve / Add Features", 12f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted)
                .GetComponent<RectTransform>().SetAnchorStretch(0f, 0.56f, 1f, 1f);

            _evolveTargetDd = IsaUiHelper.CloneNativeDropdown("EvolveTargetDd", _evolveTargetRow.transform);
            _evolveTargetDd.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 0.54f);
            _evolveTargetDd.onValueChanged.AddListener(idx =>
            {
                if (_suppressUiEvents || idx < 0 || idx >= EvolveUids.Count) return;
                _selectedEvolveUid = EvolveUids[idx];
                LoadStateForCurrentMode();
                RebuildFeatureList();
                RefreshPreview();
            });
            _evolveTargetRow.SetActive(false);

            _leftNameRow = AddLabeledControl(leftCol.transform, "Architecture Name", ref y, 48f, parent =>
            {
                _nameInput = IsaUiHelper.CreateInputField("NameInput", parent, "e.g. Zenith-64 or Aura-RISC", 13.5f);
                _nameInput.onValueChanged.AddListener(_ => RefreshPreview());
                return _nameInput.GetComponent<RectTransform>();
            });

            _leftParaRow = AddLabeledControl(leftCol.transform, "Base Paradigm", ref y, 46f, parent =>
            {
                _paradigmDd = IsaUiHelper.CloneNativeDropdown("ParadigmDd", parent);
                _paradigmDd.onValueChanged.AddListener(_ => { if (!_suppressUiEvents) { RebuildFeatureList(); RefreshPreview(); } });
                return _paradigmDd.GetComponent<RectTransform>();
            });

            _leftCompatRow = AddLabeledControl(leftCol.transform, "Backwards Compatibility", ref y, 46f, parent =>
            {
                _compatDd = IsaUiHelper.CloneNativeDropdown("CompatDd", parent);
                _compatDd.onValueChanged.AddListener(_ => { if (!_suppressUiEvents) { RebuildFeatureList(); RefreshPreview(); } });
                return _compatDd.GetComponent<RectTransform>();
            });

            var licBox = new GameObject("LicBox", typeof(RectTransform));
            licBox.transform.SetParent(leftCol.transform, false);
            _leftLicBox = licBox.GetComponent<RectTransform>().SetTopAnchored(y, 64f);

            _proprietaryToggle = IsaUiHelper.CreateCheckbox("PropToggle", licBox.transform, "Proprietary (Cross-License Required)", 12f, _ => OnLicensingPolicyChanged());
            _proprietaryToggle.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.62f, 1f, 1f);

            IsaUiHelper.CreateText("RoyTitle", licBox.transform, "Default Royalty Rate", 12f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted)
                .GetComponent<RectTransform>().SetAnchorStretch(0f, 0.34f, 0.68f, 0.60f);
            _royaltyValTxt = IsaUiHelper.CreateText("RoyVal", licBox.transform, "5%", 12f, TextAlignmentOptions.Right, IsaUiHelper.TextPrimary, FontStyles.Bold);
            _royaltyValTxt.GetComponent<RectTransform>().SetAnchorStretch(0.70f, 0.34f, 0.98f, 0.60f);

            _royaltySlider = IsaUiHelper.CreateSlider("RoyaltySlider", licBox.transform, 0f, 12f, true, v =>
            {
                if (_royaltyValTxt != null) _royaltyValTxt.text = $"{v:0}%";
                OnLicensingPolicyChanged();
            });
            _royaltySlider.value = 5f;
            _royaltySlider.GetComponent<RectTransform>().SetAnchorStretch(0.02f, 0.02f, 0.98f, 0.28f);
            y -= 70f;

            _leftTriHdr = IsaUiHelper.CreateText("TriHdr", leftCol.transform, "Design Focus Triangle (Drag Dot)", 12f, TextAlignmentOptions.Center, IsaUiHelper.TextPrimary, FontStyles.Bold)
                .GetComponent<RectTransform>().SetTopAnchored(y, 18f, -16f);
            y -= 20f;

            _triangle = IsaTriangleWidget.Create(leftCol.transform, new Vector2(265f, 184f));
            _leftTriBox = _triangle.GetComponent<RectTransform>();
            _leftTriBox.anchorMin = _leftTriBox.anchorMax = _leftTriBox.pivot = new Vector2(0.5f, 1f);
            _leftTriBox.anchoredPosition = new Vector2(0f, y);
            _triangle.OnWeightsChanged += (_, _, _) => RefreshPreview();
            y -= 188f;

            var presetRow = new GameObject("Presets", typeof(RectTransform));
            presetRow.transform.SetParent(leftCol.transform, false);
            _leftPresets = presetRow.GetComponent<RectTransform>().SetTopAnchored(y, 24f, -16f);

            AddPresetPill(presetRow.transform, "Bal", 0f, 0.24f, () => _triangle.SetWeights(0.34f, 0.33f, 0.33f));
            AddPresetPill(presetRow.transform, "IPC", 0.25f, 0.49f, () => _triangle.SetWeights(0.75f, 0.12f, 0.13f));
            AddPresetPill(presetRow.transform, "Eff.", 0.50f, 0.74f, () => _triangle.SetWeights(0.15f, 0.75f, 0.10f));
            AddPresetPill(presetRow.transform, "Clock", 0.75f, 1f, () => _triangle.SetWeights(0.15f, 0.10f, 0.75f));

            // MIDDLE COLUMN
            var midCol = IsaUiHelper.CreatePanel("MidCol", _windowGo.transform, IsaUiHelper.CardAltBg, true);
            midCol.GetComponent<RectTransform>().SetAnchorStretch(0.373f, 0f, 0.755f, 1f, 4f, 12f, -4f, -52f);

            IsaUiHelper.CreateText("FeatHdr", midCol.transform, "ISA Extension Matrix", 13.5f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold)
                .GetComponent<RectTransform>().SetAnchorStretch(0.025f, 0.935f, 0.56f, 0.99f);

            _featCountTxt = IsaUiHelper.CreateText("FeatCnt", midCol.transform, "", 11.5f, TextAlignmentOptions.Right, IsaUiHelper.TextMuted);
            _featCountTxt.GetComponent<RectTransform>().SetAnchorStretch(0.56f, 0.935f, 0.975f, 0.99f);

            var filterBar = new GameObject("FilterBar", typeof(RectTransform));
            filterBar.transform.SetParent(midCol.transform, false);
            filterBar.GetComponent<RectTransform>().SetAnchorStretch(0.02f, 0.875f, 0.98f, 0.932f);

            FilterButtons.Clear();
            string[] tabNames = { "All", "Pipe", "Bit", "SIMD", "Power", "Srv" };
            int[] tabBranches = { -1, 0, 1, 2, 3, 4 };
            float w = 1f / tabNames.Length;
            for (int i = 0; i < tabNames.Length; i++)
            {
                int br = tabBranches[i];
                var b = IsaUiHelper.CreateButton($"Flt_{tabNames[i]}", filterBar.transform, tabNames[i], br == _activeFilterBranch ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg, 11f, () =>
                {
                    _activeFilterBranch = br;
                    UpdateFilterButtonsVisual();
                    RebuildFeatureList();
                });
                b.GetComponent<RectTransform>().SetAnchorStretch(i * w, 0.05f, (i + 1) * w, 0.95f, 2f, 0f, -2f, 0f);
                FilterButtons.Add(b);
            }

            var scrollGo = IsaUiHelper.CreatePanel("FeatScroll", midCol.transform, IsaUiHelper.PanelBg, true);
            scrollGo.AddComponent<RectMask2D>();
            var sRt = scrollGo.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.02f, 1f, 0.87f, 8f, 4f, -8f, -2f);

            var contentGo = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            contentGo.transform.SetParent(scrollGo.transform, false);
            var ctRt = contentGo.GetComponent<RectTransform>().SetAnchorStretch(0f, 1f, 1f, 1f, 4f, 0f, -4f, 0f);
            ctRt.pivot = new Vector2(0.5f, 1f);

            var vlg = contentGo.GetComponent<VerticalLayoutGroup>();
            vlg.spacing = 4f; vlg.padding = new RectOffset(4, 4, 5, 5);
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;
            contentGo.GetComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            var sr = scrollGo.AddComponent<ScrollRect>();
            sr.viewport = sRt; sr.content = ctRt; sr.horizontal = false; sr.scrollSensitivity = 28f;
            _featuresContent = ctRt;

            // RIGHT COLUMN
            var rightCol = IsaUiHelper.CreatePanel("RightCol", _windowGo.transform, IsaUiHelper.CardAltBg, true);
            rightCol.GetComponent<RectTransform>().SetAnchorStretch(0.758f, 0f, 1f, 1f, 4f, 12f, -12f, -52f);

            leftCol.transform.SetAsLastSibling();

            _summaryTitleTxt = IsaUiHelper.CreateText("SumTitle", rightCol.transform, "Architecture Summary", 15f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextPrimary, FontStyles.Bold);
            _summaryTitleTxt.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.89f, 0.94f, 0.97f);

            _summaryStatsTxt = IsaUiHelper.CreateText("SumStats", rightCol.transform, "", 12.5f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextPrimary);
            _summaryStatsTxt.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.30f, 0.94f, 0.89f);

            _projectInfoTxt = IsaUiHelper.CreateText("ProjInfo", rightCol.transform, "", 12f, TextAlignmentOptions.BottomLeft, IsaUiHelper.TextMuted);
            _projectInfoTxt.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.14f, 0.94f, 0.30f);

            _buildBtn = IsaUiHelper.CreateButton("BuildIsaBtn", rightCol.transform, "Develop ISA", IsaUiHelper.AccentBlue, 13.5f, OnBuildClicked);
            _buildBtn.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.025f, 0.94f, 0.115f);
            _buildBtnTxt = _buildBtn.GetComponentInChildren<TMP_Text>();

            _cancelBuildBtn = IsaUiHelper.CreateButton("CancelIsaBuildBtn", rightCol.transform, "Cancel", IsaUiHelper.AccentRed, 12f, OnCancelActiveBuildClicked);
            _cancelBuildBtn.GetComponent<RectTransform>().SetAnchorStretch(0.68f, 0.025f, 0.94f, 0.115f);
            _cancelBuildBtn.gameObject.SetActive(false);

            _windowGo.SetActive(false);
        }

        private static RectTransform AddLabeledControl(Transform parent, string label, ref float y, float height, Func<Transform, RectTransform> makeControl)
        {
            var holder = new GameObject($"Grp_{label}", typeof(RectTransform));
            holder.transform.SetParent(parent, false);
            var rt = holder.GetComponent<RectTransform>().SetTopAnchored(y, height);
            IsaUiHelper.CreateText("Lbl", holder.transform, label, 12f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted)
                .GetComponent<RectTransform>().SetAnchorStretch(0f, 0.56f, 1f, 1f);
            makeControl(holder.transform).SetAnchorStretch(0f, 0f, 1f, 0.54f);
            y -= height + 4f;
            return rt;
        }

        private static void RepositionLeftColumn(bool evolve)
        {
            float y = -8f;
            if (_evolveTargetRow != null) { _evolveTargetRow.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, y); if (evolve) y -= 52f; }
            if (_leftNameRow != null) { _leftNameRow.anchoredPosition = new Vector2(0f, y); y -= 52f; }
            if (_leftParaRow != null) { _leftParaRow.anchoredPosition = new Vector2(0f, y); y -= 50f; }
            if (_leftCompatRow != null) { _leftCompatRow.anchoredPosition = new Vector2(0f, y); y -= 50f; }
            if (_leftLicBox != null) { _leftLicBox.anchoredPosition = new Vector2(0f, y); y -= 70f; }
            if (_leftTriHdr != null) { _leftTriHdr.anchoredPosition = new Vector2(0f, y); y -= 20f; }
            if (_leftTriBox != null) { _leftTriBox.anchoredPosition = new Vector2(0f, y); y -= 188f; }
            if (_leftPresets != null) _leftPresets.anchoredPosition = new Vector2(0f, y);
        }

        private static void AddPresetPill(Transform parent, string txt, float xMin, float xMax, Action onClick)
        {
            IsaUiHelper.CreateButton($"Pre_{txt}", parent, txt, IsaUiHelper.CardBg, 11.5f, onClick)
                .GetComponent<RectTransform>().SetAnchorStretch(xMin, 0f, xMax, 1f, 2f, 0f, -2f, 0f);
        }

        private static void SetMode(bool evolve)
        {
            _isEvolveMode = evolve;
            _livePolicyNotice = "";
            _evolveTargetRow?.SetActive(evolve);
            RepositionLeftColumn(evolve);
            if (_tabNewBtn != null) _tabNewBtn.GetComponent<Image>().color = !evolve ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg;
            if (_tabEvolveBtn != null) _tabEvolveBtn.GetComponent<Image>().color = evolve ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg;

            PopulateDropdowns();
            LoadStateForCurrentMode();
            RebuildFeatureList();
            RefreshPreview();
        }

        private static void PopulateDropdowns()
        {
            _suppressUiEvents = true;
            try
            {
                var comp = Player.Instance?.Company;
                var st = IsaState.GetCompanyResearch(comp);

                var pOpts = new List<string> { "CISC (Variable-Length)", "RISC (Load/Store)" };
                if ((st != null && st.IsUnlocked("isa_vliw_epic")) || _isEvolveMode)
                    pOpts.Add("VLIW / EPIC (Clean-Sheet 64)");
                IsaUiHelper.SetDropdownOptions(_paradigmDd, pOpts, 0);

                CompatUids.Clear();
                var cOpts = new List<string> { "None (Clean-Sheet ISA)" };
                CompatUids.Add("");
                if (ArchitectureManager.Instance != null && comp != null)
                {
                    foreach (var arch in ArchitectureManager.Instance.GetAvailableArchitectures())
                    {
                        if (arch != null && IsaState.CanCompanyUseArchitecture(comp, arch, out _))
                        {
                            cOpts.Add($"Extend: {arch.Name}");
                            CompatUids.Add(arch.UniqueID);
                        }
                    }
                }
                IsaUiHelper.SetDropdownOptions(_compatDd, cOpts, 0);

                EvolveUids.Clear();
                var eOpts = new List<string>();
                if (ArchitectureManager.Instance != null && comp != null)
                {
                    foreach (var arch in ArchitectureManager.Instance.GetAvailableArchitectures())
                    {
                        if (arch?.OwnerIDs != null && arch.OwnerIDs.Contains(comp.UniqueID))
                        {
                            eOpts.Add($"{arch.Name} (v{IsaState.GetOrCreateProfile(arch).Revision}.0)");
                            EvolveUids.Add(arch.UniqueID);
                        }
                    }
                }
                if (eOpts.Count == 0) eOpts.Add("No Owned ISAs Yet");
                if (EvolveUids.Count > 0 && (string.IsNullOrEmpty(_selectedEvolveUid) || !EvolveUids.Contains(_selectedEvolveUid)))
                    _selectedEvolveUid = EvolveUids[0];

                IsaUiHelper.SetDropdownOptions(_evolveTargetDd, eOpts, Mathf.Max(0, EvolveUids.IndexOf(_selectedEvolveUid)));
            }
            finally { _suppressUiEvents = false; }
        }

        private static void LoadStateForCurrentMode()
        {
            _suppressUiEvents = true;
            try
            {
                SelectedFeatures.Clear();
                if (_isEvolveMode && EvolveUids.Count > 0)
                {
                    var arch = ArchitectureManager.Instance?.GetArchitecture(_selectedEvolveUid);
                    var prof = arch != null ? IsaState.GetOrCreateProfile(arch) : null;
                    if (arch != null && prof != null)
                    {
                        _nameInput.text = arch.Name;
                        _nameInput.interactable = prof.IsCustomCreated;
                        _paradigmDd.SetValueWithoutNotify(Mathf.Clamp((int)prof.Paradigm, 0, _paradigmDd.options.Count - 1));
                        _paradigmDd.RefreshShownValue();
                        _paradigmDd.interactable = false;

                        int compatIdx = prof.CompatibleIds.Count > 0 ? Mathf.Max(0, CompatUids.IndexOf(prof.CompatibleIds[0])) : 0;
                        _compatDd.SetValueWithoutNotify(compatIdx);
                        _compatDd.RefreshShownValue();
                        _compatDd.interactable = false;

                        _proprietaryToggle.isOn = prof.IsProprietary;
                        _royaltySlider.value = Mathf.Round(prof.BaseRoyalty * 100f);
                        _triangle.SetWeights(prof.FocusIpc, prof.FocusEfficiency, prof.FocusClock, false);
                        SelectedFeatures.UnionWith(prof.Features);
                        return;
                    }
                }

                _nameInput.interactable = true; _nameInput.text = "";
                _paradigmDd.interactable = _compatDd.interactable = true;
                _paradigmDd.SetValueWithoutNotify(0); _paradigmDd.RefreshShownValue();
                _compatDd.SetValueWithoutNotify(0); _compatDd.RefreshShownValue();
                _proprietaryToggle.isOn = true; _royaltySlider.value = 5f;
                _triangle.SetWeights(0.34f, 0.33f, 0.33f, false);

                var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
                if (st != null && st.IsUnlocked("isa_microcode")) SelectedFeatures.Add("isa_microcode");
            }
            finally { _suppressUiEvents = false; }
        }

        private static void UpdateFilterButtonsVisual()
        {
            int[] tabBranches = { -1, 0, 1, 2, 3, 4 };
            for (int i = 0; i < FilterButtons.Count && i < tabBranches.Length; i++)
                if (FilterButtons[i]?.GetComponent<Image>() is Image img)
                    img.color = tabBranches[i] == _activeFilterBranch ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg;
        }

        private static void UpdateFeatureCountHeader()
        {
            if (_featCountTxt == null) return;
            var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
            int unlockedCount = 0;
            if (st != null)
            {
                for (int i = 0; i < IsaTechTree.Nodes.Count; i++)
                    if (st.IsUnlocked(IsaTechTree.Nodes[i].Id)) unlockedCount++;
            }
            _featCountTxt.text = $"{SelectedFeatures.Count} Selected · {unlockedCount}/{IsaTechTree.Nodes.Count} Researched";
        }

        private static Color GetTileBackground(bool alreadyInTarget, bool selected, bool canToggle)
        {
            if (alreadyInTarget)
                return IsaUiHelper.IsDark ? new Color(0.16f, 0.25f, 0.20f, 1f) : new Color(0.76f, 0.88f, 0.80f, 1f);
            if (selected)
                return IsaUiHelper.IsDark ? new Color(0.18f, 0.25f, 0.34f, 1f) : new Color(0.76f, 0.84f, 0.94f, 1f);
            if (canToggle) return IsaUiHelper.CardBg;
            return IsaUiHelper.IsDark ? new Color(0.155f, 0.160f, 0.172f, 0.85f) : new Color(0.83f, 0.85f, 0.88f, 0.85f);
        }

        private static void RebuildFeatureList()
        {
            for (int i = 0; i < FeatureRows.Count; i++)
                if (FeatureRows[i] != null) UnityEngine.Object.Destroy(FeatureRows[i]);
            FeatureRows.Clear();

            var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
            var target = GetEffectiveDesignTargets();
            var existingFeatures = target.existingProf?.Features;
            var previewProfile = new IsaProfile
            {
                Paradigm = target.paradigm,
                CompatibleIds = target.compatIds,
                IsCustomCreated = target.existingProf == null || target.existingProf.IsCustomCreated,
                Features = SelectedFeatures
            };

            var branchNodes = new List<IsaTechNode>();
            foreach (IsaBranch branch in Enum.GetValues(typeof(IsaBranch)))
            {
                if (_activeFilterBranch != -1 && (int)branch != _activeFilterBranch) continue;
                branchNodes.Clear();
                for (int nIdx = 0; nIdx < IsaTechTree.Nodes.Count; nIdx++)
                    if (IsaTechTree.Nodes[nIdx].Branch == branch) branchNodes.Add(IsaTechTree.Nodes[nIdx]);

                var hdrTxt = IsaUiHelper.CreateText($"BranchHdr_{branch}", _featuresContent, $"<b>{IsaTechTree.BranchName(branch)}</b>", 11f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted);
                hdrTxt.gameObject.AddComponent<LayoutElement>().preferredHeight = 18f;
                FeatureRows.Add(hdrTxt.gameObject);

                for (int i = 0; i < branchNodes.Count; i += 2)
                {
                    var pairRow = new GameObject($"Row_{branch}_{i}", typeof(RectTransform));
                    pairRow.transform.SetParent(_featuresContent, false);
                    pairRow.AddComponent<LayoutElement>().preferredHeight = 52f;
                    FeatureRows.Add(pairRow);

                    for (int col = 0; col < 2 && (i + col) < branchNodes.Count; col++)
                    {
                        var n = branchNodes[i + col];
                        bool unlocked = st != null && st.IsUnlocked(n.Id);
                        bool alreadyInTarget = existingFeatures != null && existingFeatures.Contains(n.Id);
                        string conflictMsg = IsaState.GetFeatureBlockReason(target.existingArch, target.existingProf ?? previewProfile, n);
                        if (conflictMsg != null && !alreadyInTarget) SelectedFeatures.Remove(n.Id);

                        bool isOn = alreadyInTarget || SelectedFeatures.Contains(n.Id);
                        bool canToggle = !alreadyInTarget && unlocked && conflictMsg == null;

                        var tile = IsaUiHelper.CreatePanel($"Tile_{n.Id}", pairRow.transform, GetTileBackground(alreadyInTarget, isOn, canToggle), true);
                        var tileImg = tile.GetComponent<Image>();
                        tile.GetComponent<RectTransform>().SetAnchorStretch(col == 0 ? 0f : 0.506f, 0f, col == 0 ? 0.494f : 1f, 1f);

                        string costTag = IsaUiHelper.FormatMoneyCompact(n.BuildCost);
                        string badge = alreadyInTarget ? "INC" : conflictMsg != null ? "N/A" : !unlocked ? $"'{n.UnlockYear % 100:00}" : (isOn ? $"ON {costTag}" : costTag);
                        Color badgeCol = alreadyInTarget ? IsaUiHelper.AccentGreen : conflictMsg != null ? IsaUiHelper.AccentAmber :
                                         !unlocked ? new Color(0.75f, 0.42f, 0.42f, 1f) : (isOn ? IsaUiHelper.AccentBlue : IsaUiHelper.TextMuted);
                        var bTxt = IsaUiHelper.CreateText("Badge", tile.transform, badge, 9.2f, TextAlignmentOptions.TopRight, badgeCol, FontStyles.Bold);
                        bTxt.GetComponent<RectTransform>().SetAnchorStretch(0.70f, 0.44f, 0.96f, 0.94f);
                        bTxt.raycastTarget = false;

                        var tgl = IsaUiHelper.CreateCheckbox("Chk", tile.transform, n.Name, 10.5f, checkOn =>
                        {
                            if (checkOn) SelectedFeatures.Add(n.Id);
                            else SelectedFeatures.Remove(n.Id);
                            if (tileImg != null) tileImg.color = GetTileBackground(false, checkOn, true);
                            if (bTxt != null)
                            {
                                bTxt.text = checkOn ? $"ON {costTag}" : costTag;
                                bTxt.color = checkOn ? IsaUiHelper.AccentBlue : IsaUiHelper.TextMuted;
                            }
                            UpdateFeatureCountHeader();
                            RefreshPreview();
                        });
                        tgl.GetComponent<RectTransform>().SetAnchorStretch(0.02f, 0.42f, 0.72f, 0.96f);
                        var chkTxt = tgl.GetComponentInChildren<TMP_Text>();
                        if (chkTxt != null)
                        {
                            chkTxt.textWrappingMode = TextWrappingModes.Normal;
                            chkTxt.overflowMode = TextOverflowModes.Ellipsis;
                            chkTxt.color = canToggle || isOn ? IsaUiHelper.TextPrimary : IsaUiHelper.TextMuted;
                        }
                        tgl.SetIsOnWithoutNotify(isOn);
                        tgl.interactable = canToggle;

                        string subLine;
                        Color subCol = IsaUiHelper.TextMuted;
                        if (conflictMsg != null && !alreadyInTarget)
                        {
                            subLine = conflictMsg;
                            subCol = IsaUiHelper.AccentAmber;
                        }
                        else if (!unlocked && !alreadyInTarget)
                        {
                            string reqs = n.Dependencies?.Length > 0 ? string.Join(",", n.Dependencies.Select(d => IsaTechTree.Get(d)?.ShortTag ?? d)) : "None";
                            subLine = $"Unlock {n.UnlockYear} · Req: {reqs}";
                            subCol = new Color(0.78f, 0.50f, 0.50f, 1f);
                        }
                        else
                        {
                            subLine = $"IPC {n.IpcBonus:+0%;-0%;0%} · Pow {n.PowerDelta:+0%;-0%;0%} · Clk {n.ClockBonus:+0%;-0%;0%}";
                        }

                        var subTxt = IsaUiHelper.CreateText("Sub", tile.transform, subLine, 9.2f, TextAlignmentOptions.Left, subCol);
                        subTxt.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.04f, 0.96f, 0.40f);
                        subTxt.textWrappingMode = TextWrappingModes.NoWrap;
                        subTxt.overflowMode = TextOverflowModes.Ellipsis;
                        subTxt.raycastTarget = false;
                    }
                }
            }
            UpdateFeatureCountHeader();
        }

        private static (float cost, int days, int addedCount) ComputeBuildEffort()
        {
            var target = GetEffectiveDesignTargets();
            var existingFeatures = target.existingProf?.Features;
            float cost = _isEvolveMode ? 3_000_000f : 8_000_000f;
            float rawDays = _isEvolveMode ? 22f : 40f;
            int addedCount = 0;

            foreach (var fid in SelectedFeatures)
            {
                if (existingFeatures != null && existingFeatures.Contains(fid)) continue;
                addedCount++;
                var node = IsaTechTree.Get(fid);
                if (node == null) continue;
                cost += node.BuildCost;
                rawDays += node.BuildDays * 0.45f;
            }

            if (_isEvolveMode && addedCount == 0) return (1_000_000f, 10, 0);
            if (!_isEvolveMode && target.compatIds.Count == 0) { cost *= 1.30f; rawDays *= 1.15f; }
            return (cost, Mathf.Clamp(Mathf.RoundToInt(rawDays), 10, 150), addedCount);
        }

        private static void OnLicensingPolicyChanged()
        {
            if (_suppressUiEvents) return;
            if (_isEvolveMode && EvolveUids.Count > 0)
            {
                var arch = ArchitectureManager.Instance?.GetArchitecture(_selectedEvolveUid);
                var prof = arch != null ? IsaState.GetOrCreateProfile(arch) : null;
                if (arch != null && prof != null)
                {
                    prof.IsProprietary = _proprietaryToggle != null && _proprietaryToggle.isOn;
                    prof.BaseRoyalty = Mathf.Clamp((_royaltySlider != null ? _royaltySlider.value : 5f) / 100f, 0f, 0.25f);
                    arch.Royalties = prof.BaseRoyalty;
                    DynamicMarketIsaEngine.InvalidateAiArchCache();
                    _livePolicyNotice = prof.IsProprietary
                        ? $"Policy live: Proprietary ({prof.BaseRoyalty * 100f:0}% roy.)"
                        : $"Policy live: Open Domain ({prof.BaseRoyalty * 100f:0}% roy.)";
                }
            }
            RefreshPreview();
        }

        private static void RefreshPreview()
        {
            if (_summaryStatsTxt == null || _triangle == null) return;

            var target = GetEffectiveDesignTargets();
            bool hasCompat = target.compatIds.Count > 0;
            float baseIpc = target.existingProf?.VanillaBaseIpc ?? 1f;
            float basePow = target.existingProf?.VanillaBasePower ?? 1f;
            int rev = target.existingProf != null ? target.existingProf.Revision + 1 : 1;
            string compatName = hasCompat
                ? (ArchitectureManager.Instance?.GetArchitecture(target.compatIds[0])?.Name ?? target.compatIds[0]) : "None (Clean-Sheet)";

            var stats = IsaState.CalculateStats(target.paradigm, _triangle.WeightIpc, _triangle.WeightEff, _triangle.WeightClk, SelectedFeatures, hasCompat, baseIpc, basePow);
            var previewProfile = new IsaProfile
            {
                Paradigm = target.paradigm, FocusIpc = _triangle.WeightIpc, FocusEfficiency = _triangle.WeightEff, FocusClock = _triangle.WeightClk,
                Features = SelectedFeatures, CompatibleIds = target.compatIds
            };
            int yr = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
            var app = IsaState.CalculateSegmentAppeals(previewProfile, yr);
            var effort = ComputeBuildEffort();

            _summaryTitleTxt.text = _isEvolveMode ? $"ISA Revision v{rev}.0" : "New ISA Design";
            _summaryStatsTxt.text =
                $"<b>Paradigm:</b> {target.paradigm}\n<b>Legacy Compat:</b> {compatName}\n<b>Bit-Width:</b> {previewProfile.MaxBitWidth}-Bit\n<b>Features Selected:</b> {SelectedFeatures.Count}\n\n" +
                $"<b>Silicon Multipliers:</b>\n• IPC Scale: <b>{stats.ipc:0.00}x</b>\n• Power Draw: <b>{stats.power:0.00}x</b>\n• Max Clock: <b>{stats.clock:0.00}x</b>\n\n" +
                $"<b>Segment Fitness:</b>\n• Desktop: {app.desk:0.00}x\n• Server:  {app.srv:0.00}x\n• Mobile:  {app.mob:0.00}x\n• Industr: {app.ind:0.00}x";

            if (CurrentPlayerBuild != null)
            {
                int rem = Mathf.Max(0, CurrentPlayerBuild.TotalDays - CurrentPlayerBuild.DaysDone);
                _projectInfoTxt.text = $"<b>Active Build:</b> {CurrentPlayerBuild.Name}\nProgress: {CurrentPlayerBuild.DaysDone}/{CurrentPlayerBuild.TotalDays}d ({rem}d left)";
                _buildBtn.interactable = false;
                _buildBtn.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.025f, 0.65f, 0.115f);
                _buildBtnTxt.text = "In Progress...";
                _cancelBuildBtn?.gameObject.SetActive(true);
            }
            else
            {
                float monthly = effort.cost / Math.Max(1, effort.days) * 30f;
                string policyLine = !string.IsNullOrEmpty(_livePolicyNotice) ? $"\n<color=#5CE08C>{_livePolicyNotice}</color>" : "";
                _projectInfoTxt.text = $"<b>Dev Cost:</b> {IsaUiHelper.FormatMoneyShort(effort.cost)} ({IsaUiHelper.FormatMoneyShort(monthly)}/m)\n<b>Duration:</b> {effort.days} days{policyLine}";
                _buildBtn.interactable = !string.IsNullOrWhiteSpace(_nameInput.text) && (!_isEvolveMode || EvolveUids.Count > 0);
                _buildBtn.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.025f, 0.94f, 0.115f);
                _buildBtnTxt.text = _isEvolveMode ? $"Release v{rev}.0" : "Build New ISA";
                _cancelBuildBtn?.gameObject.SetActive(false);
            }
        }

        private static void OnCancelActiveBuildClicked()
        {
            var proj = ActiveNativeProject;
            if (proj != null)
            {
                TimerScheduler.Instance?.Unschedule(proj);
                foreach (var pui in UnityEngine.Object.FindObjectsByType<ProjectUI>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                    if (pui != null && pui.Project == proj) ProjectUIInstantiator.Instance?.DestroyProjectUI(pui);
            }
            ActiveNativeProject = null;
            CurrentPlayerBuild = null;
            if (_windowGo != null && _windowGo.activeInHierarchy) RefreshPreview();
        }

        private static void OnBuildClicked()
        {
            if (CurrentPlayerBuild != null || Player.Instance?.Company == null) return;
            string name = _nameInput.text.Trim();
            if (string.IsNullOrEmpty(name)) return;

            var effort = ComputeBuildEffort();
            var target = GetEffectiveDesignTargets();

            CurrentPlayerBuild = new ActiveIsaBuildProject
            {
                ExistingUid = target.existingArch != null ? target.existingArch.UniqueID : "",
                Name = name, Paradigm = target.paradigm,
                FocusIpc = _triangle.WeightIpc, FocusEff = _triangle.WeightEff, FocusClk = _triangle.WeightClk,
                Features = new List<string>(SelectedFeatures), CompatibleIds = new List<string>(target.compatIds),
                IsProprietary = _proprietaryToggle.isOn, RoyaltyRate = _royaltySlider.value / 100f,
                TotalDays = effort.days, DaysDone = 0, TotalCost = effort.cost
            };

            SpawnNativeSideProject(CurrentPlayerBuild, Player.Instance.Company);
            PopupManager.Instance?.InstantiateGenericNotification($"ISA Started: {name}", $"{effort.days}d · {IsaUiHelper.FormatMoneyShort(effort.cost)}");
            Close();
        }

        public static void SpawnNativeSideProject(ActiveIsaBuildProject build, ICompany company)
        {
            if (build == null || company == null || TimerScheduler.Instance == null || ActiveNativeProject != null) return;

            float startProgress = build.TotalDays > 0 ? Mathf.Clamp01((float)build.DaysDone / build.TotalDays) : 0f;
            var project = new Project();
            project.Initialize(build.Name, Math.Max(1, build.TotalDays), build.TotalCost, () => CompleteActiveBuild(project), company, progress: startProgress);

            ProjDailyProgF?.SetValue(project, 1f / Math.Max(1, build.TotalDays));
            ProjCalcRemM?.Invoke(project, null);
            ActiveNativeProject = project;

            TimerScheduler.Instance.Schedule(project);
            ProjectUIInstantiator.Instance?.InstantiateProjectUI(project);
        }

        private static void CompleteActiveBuild(Project project)
        {
            var b = CurrentPlayerBuild;
            ActiveNativeProject = null;
            CurrentPlayerBuild = null;
            if (project != null) TimerScheduler.Instance?.Unschedule(project);
            if (b == null || Player.Instance?.Company == null) return;

            bool isUpdate = !string.IsNullOrEmpty(b.ExistingUid);
            var arch = IsaState.CreateOrUpdateCustomArchitecture(
                b.ExistingUid, b.Name, b.Paradigm, Player.Instance.Company,
                b.FocusIpc, b.FocusEff, b.FocusClk, b.Features, b.CompatibleIds,
                b.IsProprietary, b.RoyaltyRate, triggerEventPopup: !isUpdate);

            if (isUpdate && arch != null && DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating)
            {
                PopupManager.Instance?.InstantiateGenericNotification(
                    $"ISA Updated: {arch.Name}",
                    $"Revision v{IsaState.GetOrCreateProfile(arch).Revision}.0 live");
            }
            if (_windowGo != null && _windowGo.activeInHierarchy) RefreshPreview();
        }
    }
}
