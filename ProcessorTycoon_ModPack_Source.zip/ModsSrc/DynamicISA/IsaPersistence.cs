using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using BepInEx;
using ProcessorTycoon;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace DynamicISA
{
    public static class IsaPersistence
    {
        private static string SaveDir
        {
            get
            {
                string cfg = Paths.ConfigPath;
                if (string.IsNullOrEmpty(cfg))
                {
                    string root = Paths.BepInExRootPath;
                    cfg = !string.IsNullOrEmpty(root) ? Path.Combine(root, "config") : Application.persistentDataPath;
                }
                return Path.Combine(cfg, "DynamicISA_Saves");
            }
        }

        public static string NormalizeSaveName(string saveName)
        {
            string s = (saveName ?? "").Trim();
            if (s.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)) s = s.Substring(0, s.Length - 4);
            else if (s.EndsWith(".json", StringComparison.OrdinalIgnoreCase)) s = s.Substring(0, s.Length - 5);

            if (string.IsNullOrWhiteSpace(s))
            {
                if (DateController.Instance != null)
                {
                    var d = DateController.Instance.CurrentDate;
                    s = $"{d.Year}_{d.Month}_{d.Day}";
                }
                else s = "default";
            }
            return s;
        }

        private static string GetSaveFilePath(string saveName)
        {
            Directory.CreateDirectory(SaveDir);
            string norm = NormalizeSaveName(saveName);
            char[] invalid = Path.GetInvalidFileNameChars();
            string safe = new string(norm.Select(c => Array.IndexOf(invalid, c) >= 0 ? '_' : c).ToArray());
            return Path.Combine(SaveDir, $"{safe}.json");
        }

        private static string F(float v) => v.ToString("R", CultureInfo.InvariantCulture);
        private static float PF(string s, float def = 0f) => float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out float v) ? v : def;
        private static int PI(string s, int def = 0) => int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int v) ? v : def;
        private static string Clean(string s) => (s ?? "").Replace("|", "/").Replace("\n", " ").Replace("\r", "");

        private static List<string> SplitCsvList(string csv)
        {
            if (string.IsNullOrEmpty(csv)) return new List<string>();
            var list = new List<string>();
            foreach (var item in csv.Split(','))
                if (!string.IsNullOrEmpty(item)) list.Add(item);
            return list;
        }

        public static void SaveToFile(string saveName)
        {
            try
            {
                if (string.IsNullOrEmpty(saveName)) return;
                var lines = new List<string> { "#DynamicISA_v2" };

                var archs = ArchitectureManager.Instance != null ? ArchitectureManager.Instance.Architectures : null;
                if (archs != null)
                {
                    foreach (var arch in archs)
                    {
                        if (arch == null) continue;
                        var p = IsaState.GetOrCreateProfile(arch);
                        string pops = arch.MarketData?.Popularities != null ? string.Join(",", arch.MarketData.Popularities.Select(F)) : "";
                        string owners = arch.OwnerIDs != null ? string.Join(",", arch.OwnerIDs) : "";
                        lines.Add(string.Join("|", "P", Clean(p.UniqueID), Clean(arch.Name), (int)p.Paradigm, Clean(p.CreatorCompanyID),
                            p.CreatedYear, p.CreatedMonth, p.Revision, F(p.FocusIpc), F(p.FocusEfficiency), F(p.FocusClock),
                            p.IsProprietary ? 1 : 0, p.IsCustomCreated ? 1 : 0, F(p.BaseRoyalty),
                            $"{arch.DarkModeColor.r},{arch.DarkModeColor.g},{arch.DarkModeColor.b}",
                            F(p.VanillaBaseIpc), F(p.VanillaBasePower),
                            string.Join(",", p.Features), string.Join(",", p.CompatibleIds), owners, pops));
                    }
                }
                else
                {
                    foreach (var p in IsaState.Profiles.Values)
                    {
                        lines.Add(string.Join("|", "P", Clean(p.UniqueID), Clean(p.Name), (int)p.Paradigm, Clean(p.CreatorCompanyID),
                            p.CreatedYear, p.CreatedMonth, p.Revision, F(p.FocusIpc), F(p.FocusEfficiency), F(p.FocusClock),
                            p.IsProprietary ? 1 : 0, p.IsCustomCreated ? 1 : 0, F(p.BaseRoyalty),
                            $"{p.DarkColor.r},{p.DarkColor.g},{p.DarkColor.b}",
                            F(p.VanillaBaseIpc), F(p.VanillaBasePower),
                            string.Join(",", p.Features), string.Join(",", p.CompatibleIds), "", ""));
                    }
                }

                foreach (var r in IsaState.CompanyResearch.Values)
                {
                    string prog = string.Join(",", r.Progress.Select(kv => $"{kv.Key}:{F(kv.Value)}"));
                    lines.Add(string.Join("|", "R", Clean(r.CompanyID), Clean(r.ActiveTechId), F(r.Funding),
                        string.Join(",", r.UnlockedFeatures), prog));
                }

                foreach (var m in IsaState.ContractMeta)
                {
                    lines.Add(string.Join("|", "C", m.ContractType, m.ProviderID, m.ClientID, Clean(m.ArchitectureID),
                        F(m.RoyaltyRate), F(m.UpfrontFee), m.StartYear, m.StartMonth, string.Join(",", m.ContributedFeatures)));
                }

                if (IsaCreatorWindow.CurrentPlayerBuild != null)
                {
                    var b = IsaCreatorWindow.CurrentPlayerBuild;
                    lines.Add(string.Join("|", "B", Clean(b.ExistingUid), Clean(b.Name), (int)b.Paradigm,
                        F(b.FocusIpc), F(b.FocusEff), F(b.FocusClk), b.IsProprietary ? 1 : 0, F(b.RoyaltyRate),
                        b.TotalDays, b.DaysDone, F(b.TotalCost), string.Join(",", b.Features), string.Join(",", b.CompatibleIds)));
                }

                string path = GetSaveFilePath(saveName);
                File.WriteAllLines(path, lines);
                DynamicIsaPlugin.Log?.LogInfo($"Saved DynamicISA state ({lines.Count - 1} records) to {Path.GetFileName(path)}.");
            }
            catch (Exception ex)
            {
                DynamicIsaPlugin.Log?.LogWarning($"Failed saving DynamicISA state: {ex.Message}");
            }
        }

        public static void PreRegisterCustomArchitecturesFromFile(string saveName)
        {
            try
            {
                IsaState.ClearAllRuntimeState();
                string path = GetSaveFilePath(saveName);
                if (!File.Exists(path) || ArchitectureManager.Instance == null) return;

                foreach (var line in File.ReadAllLines(path))
                {
                    if (string.IsNullOrWhiteSpace(line) || !line.StartsWith("P|", StringComparison.Ordinal)) continue;
                    var s = line.Split('|');
                    if (s.Length < 21) continue;
                    string uid = s[1];
                    bool isCustom = PI(s[12]) == 1;
                    if (!isCustom || string.IsNullOrEmpty(uid) || ArchitectureManager.Instance.GetArchitecture(uid) != null) continue;

                    var paradigm = (IsaParadigm)PI(s[3]);
                    var darkCol = ParseDarkColor(s[14]);
                    var lightCol = DeriveLightColor(darkCol);
                    var owners = SplitCsvList(s[19]);
                    List<float> pops = null;
                    if (!string.IsNullOrEmpty(s[20]))
                    {
                        var raw = s[20].Split(',');
                        if (raw.Length == MarketHelper.SegmentCount)
                        {
                            pops = new List<float>(raw.Length);
                            for (int i = 0; i < raw.Length; i++) pops.Add(PF(raw[i], 0.01f));
                        }
                    }

                    IsaState.SpawnArchitectureObject(
                        ArchitectureManager.Instance, uid, s[2], paradigm,
                        new Date(PI(s[5], 1971), PI(s[6], 1)),
                        owners, darkCol, lightCol, PF(s[13], 0.05f), pops);
                }
            }
            catch (Exception ex)
            {
                DynamicIsaPlugin.Log?.LogWarning($"PreRegister custom ISAs failed: {ex.Message}");
            }
        }

        public static void LoadFromFileAfterDeserialize(string saveName)
        {
            try
            {
                string path = GetSaveFilePath(saveName);
                if (File.Exists(path))
                {
                    IsaState.CompanyResearch.Clear();
                    IsaState.ContractMeta.Clear();

                    foreach (var line in File.ReadAllLines(path))
                    {
                        if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#", StringComparison.Ordinal)) continue;
                        var s = line.Split('|');
                        if (s.Length < 2) continue;

                        if (s[0] == "P" && s.Length >= 21) LoadProfileRow(s);
                        else if (s[0] == "R" && s.Length >= 6) LoadResearchRow(s);
                        else if (s[0] == "C" && s.Length >= 10) LoadContractRow(s);
                        else if (s[0] == "B" && s.Length >= 14 && PI(s[9]) > 0) LoadBuildRow(s);
                    }
                    DynamicIsaPlugin.Log?.LogInfo($"Loaded DynamicISA state ({IsaState.Profiles.Count} profiles, {IsaState.CompanyResearch.Count} labs).");
                }
            }
            catch (Exception ex)
            {
                DynamicIsaPlugin.Log?.LogWarning($"Failed loading DynamicISA state: {ex.Message}");
            }
            finally
            {
                IsaState.SanitizeLoadedProfiles();
            }
        }

        private static void LoadProfileRow(string[] s)
        {
            string uid = s[1];
            if (string.IsNullOrEmpty(uid)) return;
            var darkCol = ParseDarkColor(s[14]);
            var lightCol = DeriveLightColor(darkCol);

            var prof = new IsaProfile
            {
                UniqueID = uid, Name = s[2], Paradigm = (IsaParadigm)PI(s[3]), CreatorCompanyID = s[4],
                CreatedYear = PI(s[5], 1971), CreatedMonth = PI(s[6], 1), Revision = Math.Max(1, PI(s[7], 1)),
                FocusIpc = PF(s[8], 0.34f), FocusEfficiency = PF(s[9], 0.33f), FocusClock = PF(s[10], 0.33f),
                IsProprietary = PI(s[11]) == 1, IsCustomCreated = PI(s[12]) == 1, BaseRoyalty = PF(s[13], 0.05f),
                DarkColor = darkCol, LightColor = lightCol,
                VanillaBaseIpc = PF(s[15], 1f), VanillaBasePower = PF(s[16], 1f),
                Features = new HashSet<string>(SplitCsvList(s[17])),
                CompatibleIds = SplitCsvList(s[18])
            };
            IsaState.Profiles[uid] = prof;

            var arch = ArchitectureManager.Instance != null ? ArchitectureManager.Instance.GetArchitecture(uid) : null;
            if (arch == null) return;

            if (!string.IsNullOrEmpty(prof.Name)) arch.Name = prof.Name;
            if (!string.IsNullOrEmpty(s[19]))
                arch.OwnerIDs = SplitCsvList(s[19]);
            else if (arch.OwnerIDs == null)
                arch.OwnerIDs = new List<string>();

            if (!string.IsNullOrEmpty(s[20]) && arch.MarketData != null)
            {
                var raw = s[20].Split(',');
                if (raw.Length == MarketHelper.SegmentCount)
                {
                    var pops = new List<float>(raw.Length);
                    for (int i = 0; i < raw.Length; i++) pops.Add(PF(raw[i], 0.01f));
                    arch.MarketData.Popularities = pops;
                }
            }
        }

        private static void LoadResearchRow(string[] s)
        {
            var cr = new CompanyIsaResearchState
            {
                CompanyID = s[1], ActiveTechId = s[2], Funding = PF(s[3], 1f),
                UnlockedFeatures = new HashSet<string>(SplitCsvList(s[4]))
            };
            if (!string.IsNullOrEmpty(s[5]))
            {
                foreach (var kv in s[5].Split(','))
                {
                    var p = kv.Split(':');
                    if (p.Length == 2) cr.Progress[p[0]] = PF(p[1]);
                }
            }
            IsaState.CompanyResearch[cr.CompanyID] = cr;
        }

        private static void LoadContractRow(string[] s)
        {
            IsaState.ContractMeta.Add(new IsaContractMetadata
            {
                ContractType = PI(s[1]), ProviderID = PI(s[2]), ClientID = PI(s[3]), ArchitectureID = s[4],
                RoyaltyRate = PF(s[5]), UpfrontFee = PF(s[6]), StartYear = PI(s[7]), StartMonth = PI(s[8]),
                ContributedFeatures = SplitCsvList(s[9])
            });
        }

        private static void LoadBuildRow(string[] s)
        {
            IsaCreatorWindow.CurrentPlayerBuild = new ActiveIsaBuildProject
            {
                ExistingUid = s[1], Name = s[2], Paradigm = (IsaParadigm)PI(s[3]),
                FocusIpc = PF(s[4], 0.34f), FocusEff = PF(s[5], 0.33f), FocusClk = PF(s[6], 0.33f),
                IsProprietary = PI(s[7]) == 1, RoyaltyRate = PF(s[8], 0.05f),
                TotalDays = PI(s[9]), DaysDone = PI(s[10]), TotalCost = PF(s[11]),
                Features = SplitCsvList(s[12]), CompatibleIds = SplitCsvList(s[13])
            };
        }

        private static Color32 ParseDarkColor(string csv)
        {
            var rgb = (csv ?? "").Split(',');
            return rgb.Length >= 3
                ? new Color32((byte)Mathf.Clamp(PI(rgb[0], 180), 0, 255), (byte)Mathf.Clamp(PI(rgb[1], 180), 0, 255), (byte)Mathf.Clamp(PI(rgb[2], 180), 0, 255), 255)
                : new Color32(180, 180, 180, 255);
        }

        private static Color32 DeriveLightColor(Color32 darkCol)
        {
            Color.RGBToHSV(darkCol, out float h, out float s, out float v);
            return Color.HSVToRGB(h, Mathf.Min(1f, s * 1.1f), Mathf.Clamp(v * 0.78f, 0.25f, 0.75f));
        }
    }
}
