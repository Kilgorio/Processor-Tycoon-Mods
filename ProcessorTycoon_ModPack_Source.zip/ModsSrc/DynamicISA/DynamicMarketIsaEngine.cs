using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.ContractSystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.MarketSystem.UI;
using ProcessorTycoon.TimeSystem;
using ProcessorTycoon.UI;
using UnityEngine;

namespace DynamicISA
{
    public static class DynamicMarketIsaEngine
    {
        private static readonly FieldInfo MarketCpusF = AccessTools.Field(typeof(Market), "cpus");
        private static readonly FieldInfo MarketAvailArchF = AccessTools.Field(typeof(Market), "availableArchitectures");
        private static readonly FieldInfo MarketPopsF = AccessTools.Field(typeof(Market), "populations");
        private static readonly FieldInfo PopDataF = AccessTools.Field(AccessTools.Inner(typeof(Market), "Population"), "populationData");

        private static readonly FieldInfo CreatorArchF = AccessTools.Field(typeof(CreatorCpu), "currentArchitecture");
        private static readonly FieldInfo CreatorMaxFreqF = AccessTools.Field(typeof(CreatorCpu), "maxFrequency");
        private static readonly FieldInfo CreatorFreqSliderF = AccessTools.Field(typeof(CreatorCpu), "frequencySlider");
        private static readonly FieldInfo CreatorOcToggleF = AccessTools.Field(typeof(CreatorCpu), "overclockToggle");
        private static readonly FieldInfo CreatorHasInitF = AccessTools.Field(typeof(CreatorCpu), "hasInitialized");
        private static readonly FieldInfo CreatorProjCostInfoF = AccessTools.Field(typeof(CreatorCpu), "projectCostText");

        private static readonly FieldInfo HwSelectorOptsF = AccessTools.Field(typeof(HardwareSelectorWindow), "selectorOptions");
        private static readonly FieldInfo ContractReqArchF = AccessTools.Field(typeof(Contract), "requestedArchitecture");

        private static readonly MarketType[] AllMarkets = { MarketType.Desktop, MarketType.Server, MarketType.Mobile, MarketType.Industrial };
        private static readonly Dictionary<string, float> ReachPowerRatio = new Dictionary<string, float>();
        private static readonly HashSet<string> ActiveArchInMarket = new HashSet<string>();
        private static readonly Dictionary<Architecture, float> ReachScores = new Dictionary<Architecture, float>();
        private static readonly HashSet<Architecture> TempActiveArchs = new HashSet<Architecture>();
        private static readonly List<(Architecture arch, float weight)> TempContractCandidates = new List<(Architecture, float)>();
        private static readonly List<string> TempOwnerNames = new List<string>(3);

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(Architecture), nameof(Architecture.GetDescriptions)),
                postfix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Architecture_GetDescriptions_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(CreatorCpu), "UpdateUI"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(CreatorCpu_UpdateUI_Prefix)),
                postfix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(CreatorCpu_UpdateUI_Postfix)));

            harmony.Patch(AccessTools.Method(typeof(Market), "CalculateRatings"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_CalculateRatings_Prefix)),
                postfix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_CalculateRatings_Postfix)),
                finalizer: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_CalculateRatings_Finalizer)));
            harmony.Patch(AccessTools.Method(typeof(Market), nameof(Market.CpuBelongsToMarket)),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_CpuBelongsToMarket_Prefix)),
                finalizer: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_CpuBelongsToMarket_Finalizer)));
            harmony.Patch(AccessTools.Method(typeof(Market), "UpdateArchitectureMarketReach"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_UpdateArchitectureMarketReach_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "ArchitectureMarketReach", new[] { typeof(Architecture), typeof(MarketType), typeof(bool) }),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_ArchitectureMarketReach_Market_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "ArchitectureMarketReach", new[] { typeof(Architecture), typeof(Segment), typeof(bool) }),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_ArchitectureMarketReach_Segment_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "ArchitectureMarketReachPercentage"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_ArchitectureMarketReachPercentage_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "ArchitecturePreferredMarkets"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_ArchitecturePreferredMarkets_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "NonAllocatedMarketReach", new[] { typeof(Segment) }),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_NonAllocatedSegment_Prefix)));

            harmony.Patch(AccessTools.Method(typeof(Cpu), nameof(Cpu.Royalties)),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Cpu_Royalties_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Market), "SellCpuToPopulation"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_SellCpuToPopulation_Prefix)),
                finalizer: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Market_SellCpuToPopulation_Finalizer)));

            harmony.Patch(AccessTools.Method(typeof(MarketShareWindow), "UpdateArchitectures"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(MarketShareWindow_UpdateArchitectures_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(HardwareSelectorWindow), "FilterObsoleteArchitectures"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(HardwareSelectorWindow_FilterObsoleteArchitectures_Prefix)));

            harmony.Patch(AccessTools.Method(typeof(Contract), "UpdateArchitecture"),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Contract_UpdateArchitecture_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(Contract), nameof(Contract.IsRequestedArchitecture)),
                prefix: new HarmonyMethod(typeof(DynamicMarketIsaEngine), nameof(Contract_IsRequestedArchitecture_Prefix)));
        }

        public static void InvalidateAiArchCache() => DynamicAiIsaController.InvalidateAiArchCache();
        public static void ResetSessionFlags() => DynamicAiIsaController.ResetSessionFlags();

        private static int CurrentYear => DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;

        internal static MarketType GetSegmentMarket(Segment seg) =>
            MarketHelper.SegmentBelongsToMarket(seg, MarketType.Server) ? MarketType.Server :
            MarketHelper.SegmentBelongsToMarket(seg, MarketType.Mobile) ? MarketType.Mobile :
            MarketHelper.SegmentBelongsToMarket(seg, MarketType.Desktop) ? MarketType.Desktop : MarketType.Industrial;

        internal static float GetAppeal(IsaProfile prof, MarketType mt, int year)
        {
            var a = IsaState.CalculateSegmentAppeals(prof, year);
            return mt switch { MarketType.Desktop => a.desk, MarketType.Server => a.srv, MarketType.Mobile => a.mob, _ => a.ind };
        }

        public static bool IsArchitectureAllowedInMarket(Architecture arch, MarketType marketType, int segmentIdx, int year)
        {
            if (arch == null) return false;
            var prof = IsaState.GetOrCreateProfile(arch);
            if (year < 1986 && !prof.IsCustomCreated)
            {
                float pop = (arch.MarketData != null && segmentIdx >= 0 && segmentIdx < arch.MarketData.Popularities.Count) ? arch.MarketData.Popularities[segmentIdx] : 0f;
                if (marketType == MarketType.Desktop || marketType == MarketType.Server) return arch.Type == IsaType.CISC || pop >= 0.04f;
                if (marketType == MarketType.Mobile) return arch.Type == IsaType.RISC || pop >= 0.04f;
            }
            return true;
        }

        private static float GetSegmentCpuRatingModifier(Architecture arch, MarketType marketType, int segmentIdx, int year)
        {
            var prof = IsaState.GetOrCreateProfile(arch);
            float segAppeal = GetAppeal(prof, marketType, year);
            float pop = (arch.MarketData != null && segmentIdx >= 0 && segmentIdx < arch.MarketData.Popularities.Count) ? arch.MarketData.Popularities[segmentIdx] : 0.05f;

            float eco = 1f;
            if (prof.CompatibleIds.Count == 0 && year >= 1985 && marketType != MarketType.Industrial && !arch.IsARM)
                eco = pop < 0.18f ? Mathf.Lerp(0.58f, 0.96f, pop / 0.18f) : Mathf.Lerp(0.96f, 1.15f, Mathf.Clamp01((pop - 0.18f) / 0.35f));
            else if (prof.CompatibleIds.Count > 0)
                eco = 1.06f;

            return Mathf.Clamp(Mathf.Lerp(1f, segAppeal, 0.55f) * eco, 0.25f, 2.5f);
        }

        private static void Market_CalculateRatings_Prefix(object population, out (PopulationData data, bool addedCisc, bool addedRisc) __state)
        {
            __state = (null, false, false);
            var pd = population != null ? PopDataF?.GetValue(population) as PopulationData : null;
            if (pd?.PreferredIsas == null) return;

            bool allowMixed = CurrentYear >= 1986;
            if (!allowMixed)
            {
                foreach (var p in IsaState.Profiles.Values)
                    if (p.IsCustomCreated) { allowMixed = true; break; }
            }
            if (!allowMixed) return;

            bool addCisc = !pd.PreferredIsas.Contains(IsaType.CISC);
            bool addRisc = !pd.PreferredIsas.Contains(IsaType.RISC);
            if (!addCisc && !addRisc) return;

            __state = (pd, addCisc, addRisc);
            if (addCisc) pd.PreferredIsas.Add(IsaType.CISC);
            if (addRisc) pd.PreferredIsas.Add(IsaType.RISC);
        }

        private static void Market_CalculateRatings_Postfix(Market __instance, object population, int populationIndex)
        {
            var cpus = MarketCpusF?.GetValue(__instance) as List<Cpu>;
            var pd = population != null ? PopDataF?.GetValue(population) as PopulationData : null;
            if (cpus == null || pd == null) return;

            int year = CurrentYear;
            for (int i = 0; i < cpus.Count; i++)
            {
                var cpu = cpus[i];
                if (cpu?.Architecture == null || cpu.Ratings.Overall <= 0f) continue;
                var r = cpu.Ratings;
                r.Overall = IsArchitectureAllowedInMarket(cpu.Architecture, pd.MarketType, populationIndex, year)
                    ? r.Overall * GetSegmentCpuRatingModifier(cpu.Architecture, pd.MarketType, populationIndex, year)
                    : 0f;
                cpu.Ratings = r;
            }
        }

        private static void Market_CalculateRatings_Finalizer((PopulationData data, bool addedCisc, bool addedRisc) __state)
        {
            if (__state.data?.PreferredIsas == null) return;
            if (__state.addedRisc) __state.data.PreferredIsas.Remove(IsaType.RISC);
            if (__state.addedCisc) __state.data.PreferredIsas.Remove(IsaType.CISC);
        }

        private static bool ShouldAllowMixedIsa()
        {
            if (CurrentYear >= 1986) return true;
            foreach (var p in IsaState.Profiles.Values)
                if (p.IsCustomCreated) return true;
            return false;
        }

        private static void Market_CpuBelongsToMarket_Prefix(Market __instance, Cpu cpu, MarketType marketType,
            out List<(PopulationData data, bool addedCisc, bool addedRisc)> __state)
        {
            __state = null;
            if (__instance == null || cpu?.Architecture == null || !ShouldAllowMixedIsa()) return;
            var pops = MarketPopsF?.GetValue(__instance) as System.Collections.IList;
            if (pops == null || pops.Count == 0) return;

            int year = CurrentYear;
            if (!IsArchitectureAllowedInMarket(cpu.Architecture, marketType, -1, year)) return;

            for (int i = 0; i < pops.Count; i++)
            {
                var pd = PopDataF?.GetValue(pops[i]) as PopulationData;
                if (pd?.PreferredIsas == null || pd.MarketType != marketType) continue;
                bool addCisc = !pd.PreferredIsas.Contains(IsaType.CISC);
                bool addRisc = !pd.PreferredIsas.Contains(IsaType.RISC);
                if (!addCisc && !addRisc) continue;
                if (addCisc) pd.PreferredIsas.Add(IsaType.CISC);
                if (addRisc) pd.PreferredIsas.Add(IsaType.RISC);
                __state ??= new List<(PopulationData, bool, bool)>(3);
                __state.Add((pd, addCisc, addRisc));
            }
        }

        private static void Market_CpuBelongsToMarket_Finalizer(List<(PopulationData data, bool addedCisc, bool addedRisc)> __state)
        {
            if (__state == null) return;
            for (int i = 0; i < __state.Count; i++)
            {
                var s = __state[i];
                if (s.data?.PreferredIsas == null) continue;
                if (s.addedRisc) s.data.PreferredIsas.Remove(IsaType.RISC);
                if (s.addedCisc) s.data.PreferredIsas.Remove(IsaType.CISC);
            }
        }

        private static bool HasLivingOwnerOrOpen(Architecture arch)
        {
            if (arch == null) return false;
            if (arch.IsARM || arch.OwnerIDs == null || arch.OwnerIDs.Count == 0) return true;
            var cdp = CompanyDataProvider.Instance;
            if (cdp == null) return true;
            for (int i = 0; i < arch.OwnerIDs.Count; i++)
            {
                var c = cdp.GetCompany(arch.OwnerIDs[i]);
                if (c != null && !c.IsBankrupt) return true;
            }
            return false;
        }

        private static bool Market_UpdateArchitectureMarketReach_Prefix(Market __instance)
        {
            var avail = ArchitectureManager.Instance != null
                ? ArchitectureManager.Instance.GetAvailableArchitectures(MarketAvailArchF?.GetValue(__instance) as List<Architecture>)
                : MarketAvailArchF?.GetValue(__instance) as List<Architecture>;
            if (avail != null) MarketAvailArchF?.SetValue(__instance, avail);
            if (avail == null || avail.Count == 0) return true;

            var cpus = MarketCpusF?.GetValue(__instance) as List<Cpu>;
            int year = CurrentYear;
            MarketType lastPopulatedMarket = (MarketType)(-1);

            for (int seg = 0; seg < MarketHelper.SegmentCount; seg++)
            {
                int segSize = __instance.GetSegmentSize(seg);
                if (segSize <= 0) continue;
                MarketType mType = GetSegmentMarket((Segment)seg);

                if (mType != lastPopulatedMarket)
                {
                    lastPopulatedMarket = mType;
                    ReachPowerRatio.Clear();
                    ActiveArchInMarket.Clear();
                    if (cpus != null)
                    {
                        for (int i = 0; i < cpus.Count; i++)
                        {
                            var c = cpus[i];
                            if (c == null || c.IsRetired || !c.SellOnMarket || c.Architecture == null || string.IsNullOrEmpty(c.Architecture.UniqueID)) continue;
                            if (c.Company != null && c.Company.IsBankrupt) continue;
                            if (!__instance.CpuBelongsToMarket(c, mType)) continue;
                            string uid = c.Architecture.UniqueID;
                            ActiveArchInMarket.Add(uid);
                            float metric = (c.Ips / Math.Max(5f, c.Price)) * 100f + (c.Ips / Math.Max(0.25f, c.PowerConsumption)) * 2.5f;
                            if (!ReachPowerRatio.TryGetValue(uid, out float curMax) || metric > curMax)
                                ReachPowerRatio[uid] = metric;
                        }
                    }
                }

                ReachScores.Clear();
                float totalScore = 0f;
                int activeSelling = 0;

                for (int i = 0; i < avail.Count; i++)
                {
                    var arch = avail[i];
                    if (arch == null || arch.MarketData?.Popularities == null || seg >= arch.MarketData.Popularities.Count ||
                        !IsArchitectureAllowedInMarket(arch, mType, seg, year))
                    {
                        if (arch != null) ReachScores[arch] = 0f;
                        continue;
                    }

                    int sold = arch.MarketData.SoldLastDay != null && seg < arch.MarketData.SoldLastDay.Count ? arch.MarketData.SoldLastDay[seg] : 0;
                    bool hasActive = !string.IsNullOrEmpty(arch.UniqueID) && ActiveArchInMarket.Contains(arch.UniqueID);
                    if (sold > 0) activeSelling++;

                    // Dead / bankrupt ISAs or ISAs with no CPUs selling in this market should not pull share away from active ISAs.
                    if (sold == 0 && !hasActive)
                    {
                        ReachScores[arch] = 0f;
                        continue;
                    }

                    float salesShare = Mathf.Clamp01(sold / Mathf.Max(1f, segSize / 30f));
                    var prof = IsaState.GetOrCreateProfile(arch);
                    float appeal = GetAppeal(prof, mType, year);
                    float sq = !string.IsNullOrEmpty(arch.UniqueID) && ReachPowerRatio.TryGetValue(arch.UniqueID, out float v) ? v : 0f;
                    float compatBoost = prof.CompatibleIds.Count > 0 ? 1.30f : (arch.MarketData.Popularities[seg] >= 0.18f ? 1.10f : 0.65f);

                    float score = (salesShare * 4.0f + Mathf.Min(2.5f, sq * 0.08f)) * appeal * compatBoost + arch.MarketData.Popularities[seg] * 0.5f * appeal;
                    ReachScores[arch] = score;
                    totalScore += score;
                }

                if (totalScore <= 0.0001f || activeSelling == 0) continue;

                float allocTotal = 0f;
                for (int i = 0; i < avail.Count; i++)
                {
                    var arch = avail[i];
                    if (arch?.MarketData?.Popularities == null || seg >= arch.MarketData.Popularities.Count) continue;
                    float cur = arch.MarketData.Popularities[seg];
                    int sold = arch.MarketData.SoldLastDay != null && seg < arch.MarketData.SoldLastDay.Count ? arch.MarketData.SoldLastDay[seg] : 0;
                    bool hasActive = !string.IsNullOrEmpty(arch.UniqueID) && ActiveArchInMarket.Contains(arch.UniqueID);
                    float next;

                    if (sold == 0 && !hasActive)
                    {
                        bool living = HasLivingOwnerOrOpen(arch);
                        next = living
                            ? Mathf.Max(0f, cur * 0.992f - 0.001f)
                            : Mathf.Max(0f, cur * 0.980f - 0.0025f);
                        if (next < 0.0005f) next = 0f;
                    }
                    else
                    {
                        next = Mathf.Lerp(cur, Mathf.Clamp((ReachScores[arch] / totalScore) * 0.985f, 0.001f, 0.98f), 0.0045f);
                        var prof = IsaState.GetOrCreateProfile(arch);
                        if (sold == 0 && cur > 0.005f) next = Mathf.Max(0.001f, cur - 0.0004f);
                        else if (prof.CompatibleIds.Count == 0 && cur < 0.18f && !arch.IsARM && mType != MarketType.Industrial && next > cur)
                            next = cur + (next - cur) * 0.60f;
                    }

                    arch.MarketData.Popularities[seg] = next;
                    allocTotal += next;
                }

                if (allocTotal > 1f)
                {
                    for (int i = 0; i < avail.Count; i++)
                    {
                        var arch = avail[i];
                        if (arch?.MarketData?.Popularities != null && seg < arch.MarketData.Popularities.Count)
                            arch.MarketData.Popularities[seg] /= allocTotal;
                    }
                }
            }

            for (int i = 0; i < avail.Count; i++) avail[i]?.MarketData?.ClampPopularities();
            return false;
        }

        private static bool Market_ArchitectureMarketReach_Market_Prefix(Market __instance, Architecture architecture, MarketType marketType, bool combineCompatible, ref float __result)
        {
            if (architecture?.MarketData == null) return true;
            int year = CurrentYear;
            float num = 0f;
            for (int seg = 0; seg < MarketHelper.SegmentCount; seg++)
                if (MarketHelper.SegmentBelongsToMarket((Segment)seg, marketType) && IsArchitectureAllowedInMarket(architecture, marketType, seg, year))
                    num += __instance.GetSegmentSize(seg) * architecture.MarketData.GetPopularity(seg, combineCompatible);
            __result = Mathf.RoundToInt(num);
            return false;
        }

        private static bool Market_ArchitectureMarketReach_Segment_Prefix(Market __instance, Architecture architecture, Segment segment, bool combineCompatible, ref float __result)
        {
            if (architecture?.MarketData == null) return true;
            int seg = (int)segment;
            __result = IsArchitectureAllowedInMarket(architecture, GetSegmentMarket(segment), seg, CurrentYear)
                ? Mathf.RoundToInt(__instance.GetSegmentSize(seg) * architecture.MarketData.GetPopularity(seg, combineCompatible)) : 0f;
            return false;
        }

        private static bool Market_ArchitectureMarketReachPercentage_Prefix(Market __instance, Architecture architecture, MarketType marketType, bool combineCompatible, ref float __result)
        {
            if (architecture?.MarketData == null) return true;
            int year = CurrentYear;
            float weighted = 0f, total = 0f;
            for (int seg = 0; seg < MarketHelper.SegmentCount; seg++)
            {
                if (!MarketHelper.SegmentBelongsToMarket((Segment)seg, marketType) || !IsArchitectureAllowedInMarket(architecture, marketType, seg, year)) continue;
                float sz = __instance.GetSegmentSize(seg);
                weighted += sz * architecture.MarketData.GetPopularity(seg, combineCompatible);
                total += sz;
            }
            __result = total > 0f ? weighted / total : 0f;
            return false;
        }

        private static bool Market_ArchitecturePreferredMarkets_Prefix(Market __instance, Architecture architecture, ref List<MarketType> __result)
        {
            var list = new List<MarketType>(4);
            if (architecture != null)
            {
                int year = CurrentYear;
                foreach (MarketType mt in AllMarkets)
                {
                    if (__instance.GetMarketSize(mt) <= 0) continue;
                    for (int seg = 0; seg < MarketHelper.SegmentCount; seg++)
                    {
                        if (MarketHelper.SegmentBelongsToMarket((Segment)seg, mt) && IsArchitectureAllowedInMarket(architecture, mt, seg, year) &&
                            (__instance.ArchitectureMarketReach(architecture, mt, false) >= __instance.GetMarketSize(mt) * 0.01f || year >= 1986))
                        {
                            list.Add(mt);
                            break;
                        }
                    }
                }
            }
            __result = list;
            return false;
        }

        private static bool Market_NonAllocatedSegment_Prefix(Market __instance, Segment segment, ref int __result)
        {
            var avail = MarketAvailArchF?.GetValue(__instance) as List<Architecture>;
            if (avail == null) return true;
            int seg = (int)segment, year = CurrentYear;
            MarketType mt = GetSegmentMarket(segment);
            float sum = 0f;
            for (int i = 0; i < avail.Count; i++)
            {
                var a = avail[i];
                if (a?.MarketData != null && IsArchitectureAllowedInMarket(a, mt, seg, year))
                    sum += a.MarketData.GetPopularity(seg, false);
            }
            __result = Mathf.RoundToInt(__instance.GetSegmentSize(seg) * (1f - Mathf.Clamp01(sum)));
            return false;
        }

        private static void Architecture_GetDescriptions_Postfix(Architecture __instance, ICompany company, ref List<string> __result)
        {
            if (__instance == null || __result == null || __result.Count < 8) return;
            var prof = IsaState.GetOrCreateProfile(__instance);
            IsaState.CanCompanyUseArchitecture(company ?? Player.Instance?.Company, __instance, out string licStatus, out _);

            if (!string.IsNullOrEmpty(__result[1]))
                __result[1] = __result[1].Replace("Desktop", "Desk").Replace("Server", "Srv").Replace("Mobile", "Mob").Replace("Industrial", "Ind");

            if (__instance.OwnerIDs != null && __instance.OwnerIDs.Count > 3 && !__instance.IsARM)
            {
                TempOwnerNames.Clear();
                for (int i = 0; i < 3; i++)
                {
                    string oid = __instance.OwnerIDs[i];
                    TempOwnerNames.Add(CompanyDataProvider.Instance?.GetCompany(oid)?.Name ?? oid);
                }
                __result[2] = $"Owners: {string.Join(", ", TempOwnerNames)} (+{__instance.OwnerIDs.Count - 3})";
            }

            string roy = __result[3] ?? "";
            if (roy.Contains("<color=") && !roy.Contains("</color>")) roy += "</color>";
            __result[3] = $"{roy} · {prof.Paradigm} {prof.MaxBitWidth}b ({licStatus}) · Clk {IsaState.GetClockMultiplier(__instance):0.00}x";

            string compat = prof.CompatibleIds != null && prof.CompatibleIds.Count > 0
                ? (ArchitectureManager.Instance?.GetArchitecture(prof.CompatibleIds[0])?.Name ?? prof.CompatibleIds[0]) : "None";
            if (compat.Length > 10) compat = compat.Substring(0, 10);
            __result[4] = $"Compat: {compat} · IPC {__instance.IpcMultiplier:0.00}x";

            float reach = 0f;
            if (Market.Instance != null)
            {
                var prefMkts = Market.Instance.ArchitecturePreferredMarkets(__instance);
                if (prefMkts != null)
                    for (int i = 0; i < prefMkts.Count; i++)
                        reach += Market.Instance.ArchitectureMarketReach(__instance, prefMkts[i]);
            }
            __result[5] = $"Reach: {StringFormatter.FloatToIntString(reach, "", true) ?? "0"}/m · Pow {__instance.PowerConsumptionMultiplier:0.00}x";
            if (__result.Count > 8) __result[8] = "";
        }

        private static bool HardwareSelectorWindow_FilterObsoleteArchitectures_Prefix(HardwareSelectorWindow __instance)
        {
            if (__instance == null) return true;
            var opts = HwSelectorOptsF?.GetValue(__instance) as List<HardwareSelectorOption>;
            if (opts == null || opts.Count == 0) return false;

            int year = CurrentYear;
            string playerId = Player.Instance?.Company?.UniqueID;
            for (int i = 0; i < opts.Count; i++)
            {
                var opt = opts[i];
                var arch = opt != null ? opt.HardwareOption as Architecture : null;
                if (arch == null) continue;

                var prof = IsaState.GetOrCreateProfile(arch);
                bool owned = arch.OwnerIDs != null && !string.IsNullOrEmpty(playerId) && arch.OwnerIDs.Contains(playerId);
                bool hide = false;
                if (year >= 1986 && !prof.IsCustomCreated && !owned && !arch.IsARM && (arch.UniqueID == "CISC" || arch.UniqueID == "RISC"))
                {
                    bool hasShare = false;
                    if (Market.Instance != null)
                    {
                        for (int m = 0; m < AllMarkets.Length; m++)
                            if (Market.Instance.ArchitectureMarketReachPercentage(arch, AllMarkets[m], false) >= 0.005f) { hasShare = true; break; }
                    }
                    hide = !hasShare;
                }
                opt.gameObject.SetActive(!hide);
            }
            return false;
        }

        private static void CreatorCpu_UpdateUI_Prefix(CreatorCpu __instance, out float __state)
        {
            var freqSlider = __instance != null ? CreatorFreqSliderF?.GetValue(__instance) as SliderUI : null;
            __state = (freqSlider?.Slider != null && freqSlider.Slider.maxValue > freqSlider.Slider.minValue)
                ? freqSlider.Value01 : 0.5f;
        }

        private static void CreatorCpu_UpdateUI_Postfix(CreatorCpu __instance, float __state, bool __runOriginal)
        {
            if (!__runOriginal || __instance == null || CreatorArchF == null) return;
            var costInfo = CreatorProjCostInfoF?.GetValue(__instance) as InfoText;
            if (costInfo?.Title != null && costInfo.Title.IndexOf("Defective", StringComparison.OrdinalIgnoreCase) >= 0) return;

            var arch = CreatorArchF.GetValue(__instance) as Architecture;
            if (arch == null) return;
            float clkMult = IsaState.GetClockMultiplier(arch);
            if (Mathf.Abs(clkMult - 1f) < 0.005f) return;

            float scaledMax = Mathf.Clamp((float)CreatorMaxFreqF.GetValue(__instance) * clkMult, 5f, 100000000f);
            CreatorMaxFreqF.SetValue(__instance, scaledMax);

            var oc = CreatorOcToggleF?.GetValue(__instance) as ToggleUI;
            float num = (oc != null && oc.IsOn) ? scaledMax * 1.5f : scaledMax;
            var freqSlider = CreatorFreqSliderF?.GetValue(__instance) as SliderUI;
            if (freqSlider != null)
            {
                freqSlider.Setup(5f, num / 20f, num);
                if (CreatorHasInitF != null && !(bool)CreatorHasInitF.GetValue(__instance)) freqSlider.SetValueToAverage();
                else freqSlider.Slider.value = Mathf.Round(Mathf.Lerp(freqSlider.Slider.minValue, freqSlider.Slider.maxValue, __state));
            }
        }

        private static bool Cpu_Royalties_Prefix(Cpu __instance, float price, ref float __result)
        {
            if (__instance == null) return true;
            if (__instance.Architecture == null || __instance.Company == null)
            {
                __result = 0f;
                return false;
            }
            if (price <= 0f) price = __instance.Price;
            IsaState.CanCompanyUseArchitecture(__instance.Company, __instance.Architecture, out float rate);
            __result = (__instance.IsOutsourced ? 0.05f * price : 0f) + rate * price;
            return false;
        }

        private static void Market_SellCpuToPopulation_Prefix(Cpu cpu, out (Architecture arch, float orig) __state)
        {
            __state = (null, 0f);
            if (cpu?.Architecture != null && cpu.Company != null &&
                IsaState.CanCompanyUseArchitecture(cpu.Company, cpu.Architecture, out float eff) &&
                !Mathf.Approximately(eff, cpu.Architecture.Royalties))
            {
                __state = (cpu.Architecture, cpu.Architecture.Royalties);
                cpu.Architecture.Royalties = eff;
            }
        }

        private static void Market_SellCpuToPopulation_Finalizer((Architecture arch, float orig) __state)
        {
            if (__state.arch != null) __state.arch.Royalties = __state.orig;
        }

        private static bool Contract_UpdateArchitecture_Prefix(Contract __instance, ContractData contractData)
        {
            if (__instance == null || ArchitectureManager.Instance == null) return true;

            if (!string.IsNullOrEmpty(__instance.ArchitectureID))
            {
                var existing = ArchitectureManager.Instance.GetArchitecture(__instance.ArchitectureID);
                if (existing != null)
                {
                    ContractReqArchF?.SetValue(__instance, existing);
                    return false;
                }
            }

            Segment targetSeg = contractData.Type switch
            {
                ContractType.Calculator => Segment.Industrial,
                ContractType.Phone => Segment.MobileMid,
                _ => Segment.DesktopMid
            };
            IsaType fallbackIsa = (contractData.Type == ContractType.Calculator || contractData.Type == ContractType.Phone)
                ? IsaType.RISC : IsaType.CISC;
            MarketType mt = GetSegmentMarket(targetSeg);
            int year = CurrentYear;

            TempActiveArchs.Clear();
            var allCpus = CpuDataProvider.Instance?.GetAllCpus();
            if (allCpus != null)
            {
                for (int i = 0; i < allCpus.Count; i++)
                {
                    var cpu = allCpus[i];
                    if (cpu != null && !cpu.IsRetired && cpu.Architecture != null) TempActiveArchs.Add(cpu.Architecture);
                }
            }

            var avail = ArchitectureManager.Instance.GetAvailableArchitectures();
            TempContractCandidates.Clear();
            float totalNonPropWeight = 0f;

            if (avail != null)
            {
                for (int i = 0; i < avail.Count; i++)
                {
                    var arch = avail[i];
                    if (arch == null || !IsArchitectureAllowedInMarket(arch, mt, (int)targetSeg, year)) continue;
                    bool isActive = TempActiveArchs.Contains(arch);
                    bool matchesSide = (fallbackIsa == IsaType.RISC && arch.Type == IsaType.RISC) ||
                                       (fallbackIsa == IsaType.CISC && (arch.Type == IsaType.CISC || (arch.Type == IsaType.RISC && isActive)));
                    if (!matchesSide && !isActive) continue;

                    float pop = arch.MarketData != null ? arch.MarketData.GetPopularity((int)targetSeg, false) : 0.05f;
                    float w = Mathf.Max(0.02f, pop) * (isActive ? 1.5f : 0.25f);
                    var prof = IsaState.GetOrCreateProfile(arch);
                    bool singleOwnerProp = prof != null && prof.IsProprietary && arch.OwnerIDs != null && arch.OwnerIDs.Count <= 1;
                    if (!singleOwnerProp) totalNonPropWeight += w;
                    TempContractCandidates.Add((arch, w));
                }
            }

            Architecture chosen = null;
            if (TempContractCandidates.Count > 0)
            {
                float maxSinglePropW = totalNonPropWeight > 0f ? totalNonPropWeight * 0.80f : 10f;
                float sumW = 0f;
                for (int i = 0; i < TempContractCandidates.Count; i++)
                {
                    var arch = TempContractCandidates[i].arch;
                    var prof = IsaState.GetOrCreateProfile(arch);
                    bool singleOwnerProp = prof != null && prof.IsProprietary && arch.OwnerIDs != null && arch.OwnerIDs.Count <= 1;
                    float cappedW = singleOwnerProp ? Mathf.Min(TempContractCandidates[i].weight, maxSinglePropW) : TempContractCandidates[i].weight;
                    TempContractCandidates[i] = (arch, cappedW);
                    sumW += cappedW;
                }

                float roll = UnityEngine.Random.Range(0f, Mathf.Max(0.0001f, sumW));
                float acc = 0f;
                for (int i = 0; i < TempContractCandidates.Count; i++)
                {
                    acc += TempContractCandidates[i].weight;
                    if (roll <= acc) { chosen = TempContractCandidates[i].arch; break; }
                }
                chosen ??= TempContractCandidates[0].arch;
            }

            chosen ??= ArchitectureManager.Instance.GetMostRecentArchitectureOfType(fallbackIsa)
                       ?? ArchitectureManager.Instance.GetMostRecentArchitectureOfType(IsaType.CISC);
            if (chosen != null)
            {
                ContractReqArchF?.SetValue(__instance, chosen);
                __instance.ArchitectureID = chosen.UniqueID;
            }
            return false;
        }

        private static bool Contract_IsRequestedArchitecture_Prefix(Contract __instance, Cpu cpu, ref bool __result)
        {
            var req = ContractReqArchF?.GetValue(__instance) as Architecture;
            if (cpu?.Architecture == null || req == null) return true;
            __result = cpu.Architecture == req ||
                       (cpu.Architecture.CompatibleArchitectures != null && cpu.Architecture.CompatibleArchitectures.Contains(req));
            return false;
        }

        private static void MarketShareWindow_UpdateArchitectures_Prefix()
        {
            if (ArchitectureManager.Instance?.Architectures == null) return;
            foreach (var arch in ArchitectureManager.Instance.Architectures)
            {
                if (arch == null) continue;
                IsaState.GetOrCreateProfile(arch);
                if (arch.DarkModeColor.a == 0)
                {
                    IsaState.GenerateDistinctColors(arch.UniqueID, out var dc, out var lc);
                    arch.DarkModeColor = dc; arch.LightModeColor = lc;
                }
            }
        }
    }
}
