using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.CompanySystem.Business;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.Hardware.Creation;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.TimeSystem;
using ProcessorTycoon.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DynamicISA
{
    public static class IsaContractIntegration
    {
        private static readonly FieldInfo NegTypeDdF = AccessTools.Field(typeof(ContractNegotiationWindow), "contractTypeDropdown");
        private static readonly FieldInfo NegDurDdF = AccessTools.Field(typeof(ContractNegotiationWindow), "durationDropdown");
        private static readonly FieldInfo NegExclTglF = AccessTools.Field(typeof(ContractNegotiationWindow), "exclusivityDealToggle");
        private static readonly FieldInfo NegRenewTglF = AccessTools.Field(typeof(ContractNegotiationWindow), "renewContractToggle");
        private static readonly FieldInfo NegCapSliderF = AccessTools.Field(typeof(ContractNegotiationWindow), "productionCapacitySlider");
        private static readonly FieldInfo NegMarkupSliderF = AccessTools.Field(typeof(ContractNegotiationWindow), "markupPriceSlider");
        private static readonly FieldInfo NegSignBtnF = AccessTools.Field(typeof(ContractNegotiationWindow), "signContractButton");
        private static readonly FieldInfo NegProvOblF = AccessTools.Field(typeof(ContractNegotiationWindow), "providerObligationsText");
        private static readonly FieldInfo NegCliOblF = AccessTools.Field(typeof(ContractNegotiationWindow), "clientObligationsText");
        private static readonly FieldInfo NegAcceptTxtF = AccessTools.Field(typeof(ContractNegotiationWindow), "acceptanceText");
        private static readonly FieldInfo NegScoreTextsF = AccessTools.Field(typeof(ContractNegotiationWindow), "scoreTexts");
        private static readonly FieldInfo NegProviderF = AccessTools.Field(typeof(ContractNegotiationWindow), "currentProvider");
        private static readonly FieldInfo NegClientF = AccessTools.Field(typeof(ContractNegotiationWindow), "currentClient");
        private static readonly FieldInfo NegScoreF = AccessTools.Field(typeof(ContractNegotiationWindow), "acceptanceScore");

        private static readonly MethodInfo NegUpdateOblM = AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateObligationTexts");
        private static readonly MethodInfo NegUpdateSignBtnM = AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateSignButton");
        private static readonly MethodInfo NegUpdateScoresM = AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateScores");

        private static readonly FieldInfo BmContractsF = AccessTools.Field(typeof(BusinessContractManager), "contracts");
        private static readonly FieldInfo UiContractF = AccessTools.Field(typeof(BusinessContractUI), "contract");
        private static readonly FieldInfo UiProdTextF = AccessTools.Field(typeof(BusinessContractUI), "productionCapacityText");
        private static readonly FieldInfo UiMarkupTextF = AccessTools.Field(typeof(BusinessContractUI), "markupPriceText");
        private static readonly FieldInfo UiRoyaltyTextF = AccessTools.Field(typeof(BusinessContractUI), "royaltyText");
        private static readonly FieldInfo UiTermTextF = AccessTools.Field(typeof(BusinessContractUI), "terminationDateText");

        private static readonly FieldInfo HwSelectBtnF = AccessTools.Field(typeof(HardwareSelectorWindow), "selectButton");
        private static readonly FieldInfo HwSelectorOptsF = AccessTools.Field(typeof(HardwareSelectorWindow), "selectorOptions");

        private static ContractNegotiationWindow _activeNegWindow;
        private static DropdownUI _hookedTypeDd;
        private static TMP_Text _durationLabelTxt;
        private static GameObject _inlineIsaRowGo;
        private static TMP_Dropdown _targetIsaDd;

        private static GameObject _isaDrawerGo;
        private static TMP_Text _isaDrawerSubtitle;
        private static Transform _contribContent;
        private static readonly List<GameObject> ContribRows = new List<GameObject>();
        private static readonly List<string> CandidateArchUids = new List<string>();
        private static readonly HashSet<string> SelectedContribFeatures = new HashSet<string>();
        private static string _selectedIsaUid = "";
        private static int _lastContractTypeMode = -1;

        private static HardwareSelectorWindow _lastHwWin;
        private static Architecture _lastHwArch;
        private static int _lastHwCheckFrame = -999;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "Start"),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_Start_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "Open"),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_Open_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "OpenWithContractRenewal"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_OpenRenewal_Prefix)),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_OpenRenewal_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "Close"),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_Close_Postfix)));

            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateValues"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_UpdateValues_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateObligationTexts"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_UpdateObligations_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateScores"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_UpdateScores_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "UpdateSignButton"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_UpdateSignButton_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ContractNegotiationWindow), "SignContract"),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(Neg_SignContract_Prefix)));

            harmony.Patch(AccessTools.Method(typeof(BusinessContract), nameof(BusinessContract.ContractType)),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContract_Type_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(BusinessContract), nameof(BusinessContract.LinesPercentage)),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContract_LinesPct_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(BusinessContract), nameof(BusinessContract.IsExclusive)),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContract_IsExclusive_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(BusinessContract), nameof(BusinessContract.BreakingContractFines)),
                prefix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContract_BreakingFines_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(BusinessContractManager), nameof(BusinessContractManager.BreakContract)),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContractManager_BreakContract_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(BusinessContractUI), nameof(BusinessContractUI.UpdateTexts)),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(BusinessContractUI_UpdateTexts_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(HardwareSelectorWindow), "Update"),
                postfix: new HarmonyMethod(typeof(IsaContractIntegration), nameof(HardwareSelectorWindow_Update_Postfix)));
        }

        public static void ResetUiState()
        {
            _activeNegWindow = null;
            _hookedTypeDd = null;
            _selectedIsaUid = "";
            _lastContractTypeMode = -1;
            SelectedContribFeatures.Clear();
            CandidateArchUids.Clear();
            for (int i = 0; i < ContribRows.Count; i++)
                if (ContribRows[i] != null) UnityEngine.Object.Destroy(ContribRows[i]);
            ContribRows.Clear();
            _lastHwWin = null;
            _lastHwArch = null;
            _lastHwCheckFrame = -999;
            if (_isaDrawerGo != null) _isaDrawerGo.SetActive(false);
            if (_inlineIsaRowGo != null) _inlineIsaRowGo.SetActive(false);
        }

        private static bool IsCrossLicenseMode(ContractNegotiationWindow win) =>
            win != null && (NegTypeDdF?.GetValue(win) as DropdownUI)?.Value == 1;

        private static void RefreshNegWindow(ContractNegotiationWindow win)
        {
            if (win == null) return;
            NegUpdateOblM?.Invoke(win, null);
            NegUpdateSignBtnM?.Invoke(win, new object[] { true });
        }

        private static bool TryGetCrossLicenseState(
            ContractNegotiationWindow win, out ICompany prov, out ICompany cli,
            out Architecture arch, out IsaProfile prof, out int maxOwners, out string invalidReason)
        {
            prov = NegProviderF?.GetValue(win) as ICompany;
            cli = NegClientF?.GetValue(win) as ICompany;
            arch = ArchitectureManager.Instance?.GetArchitecture(_selectedIsaUid);
            prof = arch != null ? IsaState.GetOrCreateProfile(arch) : null;
            maxOwners = IsaState.GetMaxCrossLicenseOwners(prof);

            if (prov == null || cli == null || arch?.OwnerIDs == null || !arch.OwnerIDs.Contains(prov.UniqueID))
            {
                invalidReason = $"{prov?.Name ?? "Provider"} owns no ISA";
                return false;
            }
            if (!arch.OwnerIDs.Contains(cli.UniqueID) && arch.OwnerIDs.Count >= maxOwners)
            {
                invalidReason = $"Max {maxOwners} Co-Owners Reached";
                return false;
            }
            invalidReason = null;
            return true;
        }

        private static void Neg_Start_Postfix(ContractNegotiationWindow __instance)
        {
            _activeNegWindow = __instance;
            var dd = NegTypeDdF?.GetValue(__instance) as DropdownUI;
            if (dd != null && _hookedTypeDd != dd)
            {
                _hookedTypeDd = dd;
                dd.UpdateOptions(new List<string> { "Foundry Services", "Cross-License" }, false);
                dd.SetSelected(0);
                dd.OnValueChanged += () => OnContractTypeChanged(_activeNegWindow);
            }
            BuildInlineTargetAndDrawer(__instance);
        }

        private static void Neg_Open_Postfix(ContractNegotiationWindow __instance)
        {
            _activeNegWindow = __instance;
            BuildInlineTargetAndDrawer(__instance);
            var dd = NegTypeDdF?.GetValue(__instance) as DropdownUI;
            if (dd != null) dd.Interactable = true;
            OnContractTypeChanged(__instance);
        }

        private static void Neg_OpenRenewal_Prefix(ContractNegotiationWindow __instance)
        {
            if (__instance == null) return;
            _activeNegWindow = __instance;
            BuildInlineTargetAndDrawer(__instance);
            var dd = NegTypeDdF?.GetValue(__instance) as DropdownUI;
            if (dd != null) { if (dd.Value != 0) dd.SetSelected(0); dd.Interactable = false; }
            OnContractTypeChanged(__instance);
        }

        private static void Neg_OpenRenewal_Postfix(ContractNegotiationWindow __instance)
        {
            var dd = __instance != null ? NegTypeDdF?.GetValue(__instance) as DropdownUI : null;
            if (dd != null) { if (dd.Value != 0) dd.SetSelected(0); dd.Interactable = false; }
            if (_inlineIsaRowGo != null) _inlineIsaRowGo.SetActive(false);
            if (_isaDrawerGo != null) _isaDrawerGo.SetActive(false);
        }

        private static void Neg_Close_Postfix()
        {
            if (_isaDrawerGo != null) _isaDrawerGo.SetActive(false);
        }

        private static void OnContractTypeChanged(ContractNegotiationWindow win)
        {
            if (win == null) return;
            bool isCross = IsCrossLicenseMode(win);

            (NegDurDdF?.GetValue(win) as DropdownUI)?.gameObject.SetActive(!isCross);
            if (_durationLabelTxt != null) _durationLabelTxt.gameObject.SetActive(!isCross);
            (NegExclTglF?.GetValue(win) as ToggleUI)?.gameObject.SetActive(!isCross);
            (NegRenewTglF?.GetValue(win) as ToggleUI)?.gameObject.SetActive(!isCross);

            if (_inlineIsaRowGo != null)
            {
                _inlineIsaRowGo.SetActive(isCross);
                if (isCross) _inlineIsaRowGo.transform.SetAsLastSibling();
            }
            if (_isaDrawerGo != null)
            {
                _isaDrawerGo.SetActive(isCross);
                if (isCross) _isaDrawerGo.transform.SetAsLastSibling();
            }

            var capSlider = NegCapSliderF?.GetValue(win) as SliderUI;
            var feeSlider = NegMarkupSliderF?.GetValue(win) as SliderUI;
            int mode = isCross ? 1 : 0;

            if (!isCross && _lastContractTypeMode != 0)
            {
                if (capSlider != null) { capSlider.Setup(true, 1f, 25f); capSlider.Value = 10f; capSlider.Title = "Production Capacity"; }
                if (feeSlider != null) { feeSlider.Setup(true, 25f, 125f); feeSlider.Value = 100f; feeSlider.Title = "Markup"; }
            }
            else if (isCross)
            {
                if (_lastContractTypeMode != 1)
                {
                    if (capSlider != null) { capSlider.Setup(true, 0f, 6f); capSlider.Value = 0f; capSlider.Title = "Mutual Royalty"; }
                    if (feeSlider != null) { feeSlider.Setup(true, 0f, 60f); feeSlider.Value = 10f; feeSlider.Title = "Equalization Fee"; }
                }
                RefreshTargetIsaDropdown(win);
            }

            _lastContractTypeMode = mode;
            RefreshNegWindow(win);
        }

        private static void BuildInlineTargetAndDrawer(ContractNegotiationWindow win)
        {
            var durDd = NegDurDdF?.GetValue(win) as DropdownUI;
            if (_inlineIsaRowGo == null && durDd != null)
            {
                Transform leftParent = durDd.transform.parent;
                _durationLabelTxt = null;
                foreach (var t in leftParent.GetComponentsInChildren<TMP_Text>(true))
                {
                    if (t != null && string.Equals(t.text.Trim(), "Duration", StringComparison.OrdinalIgnoreCase))
                    {
                        _durationLabelTxt = t;
                        break;
                    }
                }

                _inlineIsaRowGo = new GameObject("DynamicISA_InlineTargetRow", typeof(RectTransform));
                _inlineIsaRowGo.transform.SetParent(leftParent, false);
                _inlineIsaRowGo.transform.SetSiblingIndex(durDd.transform.GetSiblingIndex() + 1);
                var le = _inlineIsaRowGo.AddComponent<LayoutElement>();
                le.preferredHeight = 56f; le.minHeight = 52f;

                var durRt = durDd.GetComponent<RectTransform>();
                var rRt = _inlineIsaRowGo.GetComponent<RectTransform>();
                if (leftParent.GetComponent<VerticalLayoutGroup>() != null)
                {
                    rRt.SetTopAnchored(0f, 56f, 0f);
                }
                else
                {
                    rRt.anchorMin = new Vector2(0f, durRt.anchorMin.y);
                    rRt.anchorMax = new Vector2(1f, durRt.anchorMax.y);
                    rRt.pivot = new Vector2(0.5f, durRt.pivot.y);
                    rRt.anchoredPosition = new Vector2(0f, durRt.anchoredPosition.y - 14f);
                    rRt.sizeDelta = new Vector2(-24f, 42f);
                }

                var lbl = IsaUiHelper.CreateText("IsaLbl", _inlineIsaRowGo.transform, "Target ISA", 12.5f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold);
                lbl.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.56f, 1f, 1f);

                _targetIsaDd = IsaUiHelper.CloneNativeDropdown("TargetIsaDd", _inlineIsaRowGo.transform);
                _targetIsaDd.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 0.54f);
                _targetIsaDd.onValueChanged.AddListener(idx =>
                {
                    if (idx < 0 || idx >= CandidateArchUids.Count) return;
                    _selectedIsaUid = CandidateArchUids[idx];
                    SelectedContribFeatures.Clear();
                    RebuildFeatureContributionList(NegProviderF?.GetValue(_activeNegWindow) as ICompany);
                    RefreshNegWindow(_activeNegWindow);
                });
                _inlineIsaRowGo.SetActive(false);
            }

            if (_isaDrawerGo == null)
            {
                _isaDrawerGo = IsaUiHelper.CreatePanel("DynamicISA_CrossFeatureDrawer", win.transform, IsaUiHelper.PanelBg, true);
                var rt = _isaDrawerGo.GetComponent<RectTransform>();
                rt.anchorMin = new Vector2(0f, 0f); rt.anchorMax = new Vector2(0f, 1f);
                rt.pivot = new Vector2(1f, 0.5f); rt.anchoredPosition = new Vector2(-8f, 0f);
                rt.sizeDelta = new Vector2(290f, 0f);

                var outline = _isaDrawerGo.AddComponent<Outline>();
                outline.effectColor = IsaUiHelper.BorderCol; outline.effectDistance = new Vector2(1.5f, -1.5f);

                var hdr = IsaUiHelper.CreatePanel("Hdr", _isaDrawerGo.transform, IsaUiHelper.HeaderBg, true);
                hdr.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.91f, 1f, 1f);
                IsaUiHelper.CreateText("HTxt", hdr.transform, "Contribute ISA Features", 14f, TextAlignmentOptions.Center, IsaUiHelper.TextPrimary, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0f, 0.96f, 1f);

                _isaDrawerSubtitle = IsaUiHelper.CreateText("Sub", _isaDrawerGo.transform, "", 12f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextMuted);
                _isaDrawerSubtitle.GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.72f, 0.95f, 0.89f);

                IsaUiHelper.CreateText("ContribLbl", _isaDrawerGo.transform, "Merge Your Unlocked Techs into ISA:", 12f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0.05f, 0.66f, 0.95f, 0.72f);

                var scroll = IsaUiHelper.CreatePanel("ContribScroll", _isaDrawerGo.transform, IsaUiHelper.CardAltBg, true);
                scroll.AddComponent<RectMask2D>();
                var sRt = scroll.GetComponent<RectTransform>().SetAnchorStretch(0.04f, 0.03f, 0.96f, 0.655f);

                var content = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
                content.transform.SetParent(scroll.transform, false);
                var ctRt = content.GetComponent<RectTransform>().SetTopAnchored(0f, 0f, 0f);

                var vlg = content.GetComponent<VerticalLayoutGroup>();
                vlg.spacing = 4f; vlg.padding = new RectOffset(6, 6, 6, 6);
                vlg.childControlWidth = true; vlg.childControlHeight = false; vlg.childForceExpandWidth = true;
                content.GetComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;

                var sr = scroll.AddComponent<ScrollRect>();
                sr.viewport = sRt; sr.content = ctRt; sr.horizontal = false; sr.scrollSensitivity = 24f;
                _contribContent = ctRt;
                _isaDrawerGo.SetActive(false);
            }
        }

        private static void RefreshTargetIsaDropdown(ContractNegotiationWindow win)
        {
            if (_targetIsaDd == null || ArchitectureManager.Instance == null) return;
            var provider = NegProviderF?.GetValue(win) as ICompany;
            var client = NegClientF?.GetValue(win) as ICompany;

            CandidateArchUids.Clear();
            var opts = new List<string>();
            var avail = ArchitectureManager.Instance.GetAvailableArchitectures();
            if (avail != null)
            {
                for (int i = 0; i < avail.Count; i++)
                {
                    var arch = avail[i];
                    if (arch?.OwnerIDs == null || provider == null || !arch.OwnerIDs.Contains(provider.UniqueID)) continue;
                    bool ownedByCli = client != null && arch.OwnerIDs.Contains(client.UniqueID);
                    CandidateArchUids.Add(arch.UniqueID);
                    opts.Add($"{arch.Name} ({(ownedByCli ? "Co-Owned" : provider.Name)})");
                }
            }

            if (opts.Count == 0)
            {
                opts.Add($"{provider?.Name ?? "Provider"} owns no ISA");
                _selectedIsaUid = "";
            }
            else if (string.IsNullOrEmpty(_selectedIsaUid) || !CandidateArchUids.Contains(_selectedIsaUid))
            {
                _selectedIsaUid = CandidateArchUids[0];
            }

            IsaUiHelper.SetDropdownOptions(_targetIsaDd, opts, Mathf.Max(0, CandidateArchUids.IndexOf(_selectedIsaUid)));
            SelectedContribFeatures.Clear();
            RebuildFeatureContributionList(provider);
        }

        private static void RebuildFeatureContributionList(ICompany provider = null)
        {
            for (int i = 0; i < ContribRows.Count; i++)
                if (ContribRows[i] != null) UnityEngine.Object.Destroy(ContribRows[i]);
            ContribRows.Clear();

            var arch = ArchitectureManager.Instance?.GetArchitecture(_selectedIsaUid);
            var playerSt = IsaState.GetCompanyResearch(Player.Instance?.Company);
            if (arch == null)
            {
                if (_isaDrawerSubtitle != null)
                    _isaDrawerSubtitle.text = $"{provider?.Name ?? "Provider"} does not own a private ISA to license.\nClick <b>Swap (<->)</b> to offer one of your own ISAs, or negotiate with an ISA owner (Inlet / EMD).";
                return;
            }

            var prof = IsaState.GetOrCreateProfile(arch);
            if (_isaDrawerSubtitle != null)
            {
                string owners = "Public Domain";
                if (arch.OwnerIDs != null && arch.OwnerIDs.Count > 0)
                {
                    var names = new List<string>(arch.OwnerIDs.Count);
                    for (int i = 0; i < arch.OwnerIDs.Count; i++)
                    {
                        string oid = arch.OwnerIDs[i];
                        names.Add(CompanyDataProvider.Instance?.GetCompany(oid)?.Name ?? oid);
                    }
                    owners = string.Join(", ", names);
                }
                _isaDrawerSubtitle.text = $"<b>{arch.Name}</b> v{prof.Revision}.0 ({prof.Paradigm} {prof.MaxBitWidth}b)\nOwners: {owners}\nFocus: IPC {Mathf.RoundToInt(prof.FocusIpc * 100)}% / Eff {Mathf.RoundToInt(prof.FocusEfficiency * 100)}% / Clk {Mathf.RoundToInt(prof.FocusClock * 100)}%";
            }

            int added = 0;
            for (int i = 0; i < IsaTechTree.Nodes.Count; i++)
            {
                var n = IsaTechTree.Nodes[i];
                if (prof.HasFeature(n.Id) || playerSt == null || !playerSt.IsUnlocked(n.Id)) continue;
                if (IsaState.IsFeatureBlockedForArchitecture(arch, prof, n)) continue;

                added++;
                var row = IsaUiHelper.CreatePanel($"Contrib_{n.Id}", _contribContent, IsaUiHelper.CardBg, true);
                row.AddComponent<LayoutElement>().preferredHeight = 32f;

                var chk = IsaUiHelper.CreateCheckbox("Chk", row.transform, $"{n.ShortTag}: {n.Name}", 11.5f, isOn =>
                {
                    if (isOn) SelectedContribFeatures.Add(n.Id);
                    else SelectedContribFeatures.Remove(n.Id);
                    RefreshNegWindow(_activeNegWindow);
                });
                chk.GetComponent<RectTransform>().SetAnchorStretch(0.02f, 0.05f, 0.98f, 0.95f);
                chk.SetIsOnWithoutNotify(SelectedContribFeatures.Contains(n.Id));
                ContribRows.Add(row);
            }

            if (added == 0)
            {
                var info = IsaUiHelper.CreateText("NoneNote", _contribContent, "No additional unlocked ISA technologies available to inject right now (you can still negotiate cross-license co-ownership).", 11.5f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextMuted);
                info.gameObject.AddComponent<LayoutElement>().preferredHeight = 65f;
                ContribRows.Add(info.gameObject);
            }
        }

        private static bool Neg_UpdateValues_Prefix(ContractNegotiationWindow __instance)
        {
            if (!IsCrossLicenseMode(__instance)) return true;
            var capSlider = NegCapSliderF?.GetValue(__instance) as SliderUI;
            var feeSlider = NegMarkupSliderF?.GetValue(__instance) as SliderUI;
            if (capSlider != null) capSlider.Text = capSlider.Value == 0 ? "0% (Mutual)" : $"{capSlider.Value:0}%";
            if (feeSlider != null)
            {
                float feeDollars = feeSlider.Value * 5_000_000f;
                feeSlider.Text = feeDollars <= 0f ? "$0" : IsaUiHelper.FormatMoneyShort(feeDollars);
            }
            return false;
        }

        private static bool Neg_UpdateObligations_Prefix(ContractNegotiationWindow __instance)
        {
            if (!IsCrossLicenseMode(__instance)) return true;
            Neg_UpdateValues_Prefix(__instance);
            NegUpdateScoresM?.Invoke(__instance, null);

            var prov = NegProviderF?.GetValue(__instance) as ICompany;
            var cli = NegClientF?.GetValue(__instance) as ICompany;
            var capSlider = NegCapSliderF?.GetValue(__instance) as SliderUI;
            var feeSlider = NegMarkupSliderF?.GetValue(__instance) as SliderUI;
            var provObl = NegProvOblF?.GetValue(__instance) as TMP_Text;
            var cliObl = NegCliOblF?.GetValue(__instance) as TMP_Text;

            string archName = ArchitectureManager.Instance?.GetArchitecture(_selectedIsaUid)?.Name ?? "None Selected";
            float royaltyPct = capSlider != null ? capSlider.Value : 0f;
            float upfront = feeSlider != null ? feeSlider.Value * 5_000_000f : 0f;

            if (provObl != null)
                provObl.text = $"1. Grants permanent mutual <b>Co-Ownership</b> & design rights over <b>{archName}</b>.\n\n2. Merges <b>{SelectedContribFeatures.Count}</b> new ISA extensions directly into {archName}.";
            if (cliObl != null)
                cliObl.text = $"1. Pays {IsaUiHelper.FormatMoneyShort(upfront)} equalization fee & <b>{royaltyPct:0}%</b> ongoing licensing share.\n\n2. Shares future extensions cleanly so both {prov?.Name ?? "Provider"} and {cli?.Name ?? "Client"} compete on the same ecosystem.";
            return false;
        }

        private static bool Neg_UpdateScores_Prefix(ContractNegotiationWindow __instance)
        {
            if (!IsCrossLicenseMode(__instance)) return true;

            var scoreTexts = NegScoreTextsF?.GetValue(__instance) as List<TMP_Text>;
            var acceptTxt = NegAcceptTxtF?.GetValue(__instance) as TMP_Text;

            if (!TryGetCrossLicenseState(__instance, out var prov, out var cli, out var arch, out var prof, out _, out string invalidReason))
            {
                NegScoreF?.SetValue(__instance, -999);
                if (acceptTxt != null) acceptTxt.text = $"{invalidReason} (-999)";
                return false;
            }

            var capSlider = NegCapSliderF?.GetValue(__instance) as SliderUI;
            var feeSlider = NegMarkupSliderF?.GetValue(__instance) as SliderUI;
            int royaltyPct = capSlider != null ? Mathf.RoundToInt(capSlider.Value) : 0;
            float upfront = feeSlider != null ? feeSlider.Value * 5_000_000f : 0f;

            bool playerIsProvider = prov.IsPlayer;
            ICompany aiSide = playerIsProvider ? cli : prov;
            bool alreadyCoOwner = arch.OwnerIDs.Contains(cli.UniqueID);

            int featScore = 0;
            foreach (var fid in SelectedContribFeatures)
            {
                if (fid == "isa_64bit_ext" || fid == "isa_64bit_clean") featScore += 22;
                else if (fid == "isa_hw_virt" || fid == "isa_ooo" || fid == "isa_avx256") featScore += 14;
                else featScore += 9;
            }
            featScore = Math.Min(45, featScore);

            int sMoney, sReach, sRivalry = (Player.Instance != null && Player.Instance.DifficultyLevel == 5) || aiSide.IsFoundry ? -1000 : -6;
            if (playerIsProvider)
            {
                sMoney = (upfront > Mathf.Max(0f, aiSide.MoneyAmount * 0.25f) || (alreadyCoOwner && upfront > 0f))
                    ? -99
                    : Mathf.Clamp((1 - royaltyPct) * 4 - Mathf.RoundToInt(upfront / 4_000_000f), -80, 8);

                float maxReach = 0f;
                if (Market.Instance != null)
                {
                    maxReach = Math.Max(Market.Instance.ArchitectureMarketReachPercentage(arch, MarketType.Desktop, true),
                        Math.Max(Market.Instance.ArchitectureMarketReachPercentage(arch, MarketType.Server, true),
                            Market.Instance.ArchitectureMarketReachPercentage(arch, MarketType.Mobile, true)));
                }

                bool aiNeedsDesktopSrv = false;
                var aiCpus = aiSide.Owner?.GetCpus();
                if (aiCpus != null)
                {
                    for (int i = 0; i < aiCpus.Count; i++)
                    {
                        var c = aiCpus[i];
                        if (c != null && !c.IsRetired && c.Strategy != null &&
                            (MarketHelper.IsDesktop(c.Strategy.TargetMarket) || MarketHelper.IsServer(c.Strategy.TargetMarket)))
                        {
                            aiNeedsDesktopSrv = true;
                            break;
                        }
                    }
                }
                int mismatchPenalty = (!aiNeedsDesktopSrv && prof.Paradigm != IsaParadigm.RISC) ? 22 : 0;
                sReach = Mathf.Clamp(Mathf.RoundToInt(maxReach * 30f) + Math.Min(8, prof.Features.Count) - 16 - mismatchPenalty, -30, 18);
            }
            else
            {
                sMoney = Mathf.Clamp((royaltyPct - 1) * 5 + Mathf.RoundToInt(upfront / 20_000_000f), -15, 30);
                float totMkt = Market.Instance != null ? Math.Max(1f, (Market.Instance.DesktopSize + Market.Instance.ServerSize) / 30f) : 1f;
                float soldDay = 0f;
                var pCpus = Player.Instance?.GetCpus();
                if (pCpus != null)
                    for (int i = 0; i < pCpus.Count; i++)
                        if (pCpus[i] != null) soldDay += pCpus[i].SoldLastDay;
                float playerShare = Market.Instance != null ? Mathf.Clamp01(soldDay / totMkt) : 0f;
                sReach = Mathf.Clamp(Mathf.RoundToInt(playerShare * 45f) - 12, -12, 20);
            }

            if (!playerIsProvider && SelectedContribFeatures.Count == 0 && sRivalry > -500) sRivalry -= 18;

            int sum = sMoney + featScore + sReach + sRivalry;
            NegScoreF?.SetValue(__instance, sum);

            SetCustomScoreLine(scoreTexts, 0, sMoney, "Financial Terms", "Unfavorable Terms");
            SetCustomScoreLine(scoreTexts, 1, featScore, "Contributed Features", "No Tech Brought");
            SetCustomScoreLine(scoreTexts, 2, sReach, "ISA Market Ecosystem", "Weak ISA Leverage");
            SetCustomScoreLine(scoreTexts, 3, sRivalry, "Strategic Alignment", "Rivalry Concern");
            if (scoreTexts != null)
                for (int i = 4; i < scoreTexts.Count; i++) scoreTexts[i]?.gameObject.SetActive(false);

            if (acceptTxt != null)
                acceptTxt.text = sum > 0 ? $"They will accept (+{sum})" : $"They will not accept ({sum})";
            return false;
        }

        private static void SetCustomScoreLine(List<TMP_Text> lines, int idx, int val, string posTxt, string negTxt)
        {
            if (lines == null || idx >= lines.Count || lines[idx] == null) return;
            lines[idx].gameObject.SetActive(val != 0 || idx == 0);
            string col = val >= 0 ? Colors.Instance.DynamicPositiveHex() : Colors.Instance.DynamicNegativeHex();
            lines[idx].text = $"<color={col}>{(val >= 0 ? posTxt : negTxt)}: {(val >= 0 ? $"+{val}" : $"{val}")}</color>";
        }

        private static bool Neg_UpdateSignButton_Prefix(ContractNegotiationWindow __instance, bool updateText)
        {
            if (!IsCrossLicenseMode(__instance)) return true;

            var prov = NegProviderF?.GetValue(__instance) as ICompany;
            var cli = NegClientF?.GetValue(__instance) as ICompany;
            var signBtn = NegSignBtnF?.GetValue(__instance) as ButtonUI;
            int score = NegScoreF?.GetValue(__instance) is int s ? s : -999;

            var arch = ArchitectureManager.Instance?.GetArchitecture(_selectedIsaUid);
            var profBtn = arch != null ? IsaState.GetOrCreateProfile(arch) : null;
            int maxOwners = IsaState.GetMaxCrossLicenseOwners(profBtn);
            bool hasArch = prov != null && cli != null && arch?.OwnerIDs != null && !prov.IsBankrupt && !cli.IsBankrupt && arch.OwnerIDs.Contains(prov.UniqueID);
            bool alreadySameCross = hasArch && SelectedContribFeatures.Count == 0 && arch.OwnerIDs.Contains(cli.UniqueID);
            bool tooManyOwners = hasArch && !arch.OwnerIDs.Contains(cli.UniqueID) && arch.OwnerIDs.Count >= maxOwners;

            if (signBtn != null)
            {
                if (updateText)
                    signBtn.Text = !hasArch ? "No Private ISA" : (tooManyOwners ? $"Max {maxOwners} Co-Owners" : (alreadySameCross ? "Already Co-Owners (Add Tech)" : "Sign Cross-License"));
                signBtn.Interactable = hasArch && !tooManyOwners && score > 0 && !alreadySameCross;
            }
            return false;
        }

        private static bool Neg_SignContract_Prefix(ContractNegotiationWindow __instance)
        {
            if (!IsCrossLicenseMode(__instance)) return true;
            if (!TryGetCrossLicenseState(__instance, out var prov, out var cli, out var arch, out var prof, out _, out _))
                return false;

            var validContribs = new List<string>();
            foreach (var fid in SelectedContribFeatures)
            {
                if (!prof.HasFeature(fid) && !IsaState.IsFeatureBlockedForArchitecture(arch, prof, IsaTechTree.Get(fid)))
                    validContribs.Add(fid);
            }

            bool alreadyCoOwner = arch.OwnerIDs.Contains(cli.UniqueID);
            if (alreadyCoOwner && validContribs.Count == 0) return false;

            var signBtn = NegSignBtnF?.GetValue(__instance) as ButtonUI;
            if (signBtn != null) signBtn.Interactable = false;

            var capSlider = NegCapSliderF?.GetValue(__instance) as SliderUI;
            var feeSlider = NegMarkupSliderF?.GetValue(__instance) as SliderUI;
            int royaltyPct = capSlider != null ? Mathf.RoundToInt(capSlider.Value) : 0;
            float royaltyRate = royaltyPct / 100f;
            float upfront = feeSlider != null ? feeSlider.Value * 5_000_000f : 0f;

            if (upfront > 0f)
            {
                cli.SpendMoney(upfront, ExpenseOrigin.Royalties);
                prov.EarnMoney(upfront, RevenueOrigin.Contracts);
            }

            if (!alreadyCoOwner) arch.OwnerIDs.Add(cli.UniqueID);
            foreach (var fid in validContribs) IsaState.ApplyFeatureToArchitecture(arch, fid);

            if (validContribs.Count > 0)
            {
                ICompany partner = prov.IsPlayer ? cli : prov;
                var partnerSt = IsaState.GetCompanyResearch(partner);
                if (partnerSt != null)
                {
                    foreach (var pf in partnerSt.UnlockedFeatures)
                    {
                        if (prof.HasFeature(pf)) continue;
                        var node = IsaTechTree.Get(pf);
                        if (node != null && !IsaState.IsFeatureBlockedForArchitecture(arch, prof, node))
                        {
                            IsaState.ApplyFeatureToArchitecture(arch, pf);
                            break;
                        }
                    }
                }
            }

            if (arch.UniqueID == "x86-64" && arch.Name == "EMD64" && arch.OwnerIDs.Contains("INT") && arch.OwnerIDs.Contains("EMD"))
                arch.Name = prof.Name = "x86-64";

            DateTime cur = DateController.Instance != null ? DateController.Instance.CurrentDate : DateTime.Now;
            IsaContractMetadata existingMeta = null;
            for (int i = 0; i < IsaState.ContractMeta.Count; i++)
            {
                var m = IsaState.ContractMeta[i];
                if (m.ArchitectureID == arch.UniqueID &&
                    ((m.ProviderID == prov.SaveID && m.ClientID == cli.SaveID) || (m.ProviderID == cli.SaveID && m.ClientID == prov.SaveID)))
                {
                    existingMeta = m;
                    break;
                }
            }

            if (existingMeta != null)
            {
                existingMeta.RoyaltyRate = royaltyRate;
                existingMeta.UpfrontFee += upfront;
                foreach (var f in validContribs)
                    if (!existingMeta.ContributedFeatures.Contains(f)) existingMeta.ContributedFeatures.Add(f);
            }
            else
            {
                IsaState.ContractMeta.Add(new IsaContractMetadata
                {
                    ContractType = IsaState.ContractIdCrossLicense, ProviderID = prov.SaveID, ClientID = cli.SaveID,
                    ArchitectureID = arch.UniqueID, RoyaltyRate = royaltyRate, UpfrontFee = upfront,
                    StartYear = cur.Year, StartMonth = cur.Month, ContributedFeatures = validContribs
                });
            }

            BusinessContract existingBc = null;
            var allContracts = BusinessContractManager.Instance?.GetContracts();
            if (allContracts != null)
            {
                int archHash = arch.UniqueID.GetHashCode();
                for (int i = 0; i < allContracts.Count; i++)
                {
                    var c = allContracts[i];
                    if (!IsaState.IsIsaContract(c)) continue;
                    if (((c.ProviderID == prov.SaveID && c.ClientID == cli.SaveID) || (c.ProviderID == cli.SaveID && c.ClientID == prov.SaveID)) &&
                        (c.ContractValues == null || c.ContractValues.Count < 4 || c.ContractValues[3] == archHash))
                    {
                        existingBc = c;
                        break;
                    }
                }
            }

            if (existingBc != null)
            {
                int totalMerged = existingMeta != null ? existingMeta.ContributedFeatures.Count : validContribs.Count;
                float totalUpfront = existingMeta != null ? existingMeta.UpfrontFee : upfront;
                existingBc.ContractValues = new List<int> { royaltyPct, Mathf.RoundToInt(totalUpfront / 1_000_000f), totalMerged, arch.UniqueID.GetHashCode() };
                existingBc.MonetaryValues = new List<float> { royaltyRate, totalUpfront };
            }
            else
            {
                var bc = new BusinessContract();
                bc.Initialize(prov, cli);
                bc.ContractID = IsaState.ContractIdCrossLicense;
                bc.ContractValues = new List<int> { royaltyPct, Mathf.RoundToInt(upfront / 1_000_000f), validContribs.Count, arch.UniqueID.GetHashCode() };
                bc.MonetaryValues = new List<float> { royaltyRate, upfront };
                bc.Conditions = new List<bool> { false };
                bc.RenewalEnabled = false;
                bc.StartDate = new Date(cur.Year, cur.Month);
                bc.TerminationDate = new Date(9999, 12);
                BusinessContractManager.Instance?.AddContract(bc);
            }

            SelectedContribFeatures.Clear();
            PopupManager.Instance?.InstantiateGenericNotification($"Cross-Licensed: {arch.Name}", $"Co-Owner with {(prov.IsPlayer ? cli.Name : prov.Name)}");
            __instance.Close();
            return false;
        }

        public static void DeduplicateCrossLicenseContracts()
        {
            var mgr = BusinessContractManager.Instance;
            var list = mgr != null ? BmContractsF?.GetValue(mgr) as List<BusinessContract> : null;
            if (list != null)
            {
                var seen = new HashSet<string>();
                for (int i = list.Count - 1; i >= 0; i--)
                {
                    var c = list[i];
                    if (!IsaState.IsIsaContract(c)) continue;
                    int p1 = Math.Min(c.ProviderID, c.ClientID), p2 = Math.Max(c.ProviderID, c.ClientID);
                    int h = c.ContractValues != null && c.ContractValues.Count >= 4 ? c.ContractValues[3] : 0;
                    if (!seen.Add($"{p1}_{p2}_{h}")) list.RemoveAt(i);
                }
            }

            var seenMeta = new Dictionary<string, IsaContractMetadata>();
            for (int i = IsaState.ContractMeta.Count - 1; i >= 0; i--)
            {
                var m = IsaState.ContractMeta[i];
                if (m == null) continue;
                int p1 = Math.Min(m.ProviderID, m.ClientID), p2 = Math.Max(m.ProviderID, m.ClientID);
                string key = $"{p1}_{p2}_{m.ArchitectureID}";
                if (seenMeta.TryGetValue(key, out var first))
                {
                    foreach (var f in m.ContributedFeatures)
                        if (!first.ContributedFeatures.Contains(f)) first.ContributedFeatures.Add(f);
                    IsaState.ContractMeta.RemoveAt(i);
                }
                else seenMeta[key] = m;
            }
        }

        private static bool BusinessContract_Type_Prefix(BusinessContract __instance, ref string __result)
        {
            if (!IsaState.IsIsaContract(__instance)) return true;
            __result = "ISA Cross-License";
            return false;
        }

        private static bool BusinessContract_LinesPct_Prefix(BusinessContract __instance, ref float __result)
        {
            if (!IsaState.IsIsaContract(__instance)) return true;
            __result = 0f;
            return false;
        }

        private static bool BusinessContract_IsExclusive_Prefix(BusinessContract __instance, ref bool __result)
        {
            if (!IsaState.IsIsaContract(__instance)) return true;
            __result = __instance.Conditions != null && __instance.Conditions.Count > 0 && __instance.Conditions[0];
            return false;
        }

        private static bool BusinessContract_BreakingFines_Prefix(BusinessContract __instance, ref float __result)
        {
            if (!IsaState.IsIsaContract(__instance)) return true;
            float penaltyMult = DynamicIsaPlugin.BreakPenaltyMult?.Value ?? 1.25f;
            float upfront = __instance.MonetaryValues != null && __instance.MonetaryValues.Count > 1 ? __instance.MonetaryValues[1] : 25_000_000f;
            __result = Mathf.Max(50_000_000f * (penaltyMult / 1.25f), upfront * penaltyMult);
            return false;
        }

        private static void BusinessContractManager_BreakContract_Postfix(BusinessContract contract)
        {
            if (!IsaState.IsIsaContract(contract)) return;
            var meta = IsaState.FindMetaForContract(contract);
            var arch = meta != null ? ArchitectureManager.Instance?.GetArchitecture(meta.ArchitectureID) : null;
            if (arch?.OwnerIDs != null && contract.Client != null)
            {
                var prof = IsaState.GetOrCreateProfile(arch);
                if (prof.CreatorCompanyID != contract.Client.UniqueID && arch.OwnerIDs.Count > 1)
                    arch.OwnerIDs.Remove(contract.Client.UniqueID);
            }
            if (meta != null) IsaState.ContractMeta.Remove(meta);
        }

        private static void BusinessContractUI_UpdateTexts_Postfix(BusinessContractUI __instance)
        {
            var c = __instance != null ? UiContractF?.GetValue(__instance) as BusinessContract : null;
            if (!IsaState.IsIsaContract(c)) return;

            var meta = IsaState.FindMetaForContract(c);
            string archName = meta != null ? (ArchitectureManager.Instance?.GetArchitecture(meta.ArchitectureID)?.Name ?? meta.ArchitectureID) : "ISA";

            if (UiProdTextF?.GetValue(__instance) is InfoText prodTxt) { prodTxt.Title = "Architecture:"; prodTxt.Text = archName; }
            if (UiMarkupTextF?.GetValue(__instance) is InfoText mkTxt) { mkTxt.Title = "Features Merged:"; mkTxt.Text = $"{meta?.ContributedFeatures?.Count ?? 0} ext."; }
            if (UiRoyaltyTextF?.GetValue(__instance) is InfoText royTxt) royTxt.Text = $"{IsaState.GetContractRoyalty(c) * 100f:0.#}%";
            if (UiTermTextF?.GetValue(__instance) is InfoText termTxt && c.TerminationDate != null && c.TerminationDate.Year >= 9000)
                termTxt.Text = "Permanent";
        }

        private static void HardwareSelectorWindow_Update_Postfix(HardwareSelectorWindow __instance)
        {
            if (__instance == null || __instance.Hardware != HardwareType.Architecture || Player.Instance?.Company == null) return;
            var optUis = HwSelectorOptsF?.GetValue(__instance) as List<HardwareSelectorOption>;
            var selectBtn = HwSelectBtnF?.GetValue(__instance) as ButtonUI;
            if (selectBtn == null || optUis == null) return;

            var activeBtn = SelectableButtonsHandler.Instance?.CurrentButtonWithID(__instance.UniqueID);
            if (activeBtn == null) return;

            Architecture selectedArch = null;
            for (int i = 0; i < optUis.Count; i++)
            {
                var o = optUis[i];
                if (o != null && o.Button == activeBtn) { selectedArch = o.HardwareOption as Architecture; break; }
            }
            if (selectedArch == null) return;

            if (_lastHwWin == __instance && _lastHwArch == selectedArch && Time.frameCount - _lastHwCheckFrame < 12) return;
            _lastHwWin = __instance;
            _lastHwArch = selectedArch;
            _lastHwCheckFrame = Time.frameCount;

            bool allowed = IsaState.CanCompanyUseArchitecture(Player.Instance.Company, selectedArch, out _);
            selectBtn.Interactable = allowed;
            selectBtn.Text = allowed ? "Select" : "Needs Cross-License";
        }
    }
}
