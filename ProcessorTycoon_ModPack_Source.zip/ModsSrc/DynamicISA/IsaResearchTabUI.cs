using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.PopupSystem;
using ProcessorTycoon.ResearchSystem;
using ProcessorTycoon.ResearchSystem.Math;
using ProcessorTycoon.TimeSystem;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DynamicISA
{
    public class IsaTreeViewportDrag : MonoBehaviour, IDragHandler, IScrollHandler
    {
        public RectTransform ContentRect;
        public float MinScale = 0.45f;
        public float MaxScale = 1.45f;
        private Canvas _canvas;

        public void OnDrag(PointerEventData e)
        {
            if (ContentRect == null) return;
            if (_canvas == null) _canvas = GetComponentInParent<Canvas>();
            float canvasScale = _canvas != null && _canvas.scaleFactor > 0.05f ? _canvas.scaleFactor : 1f;
            float zoomScale = Mathf.Max(0.25f, ContentRect.localScale.x);
            ContentRect.anchoredPosition += e.delta / (canvasScale * zoomScale);
        }

        public void OnScroll(PointerEventData e)
        {
            if (ContentRect == null) return;
            float s = Mathf.Clamp(ContentRect.localScale.x + e.scrollDelta.y * 0.08f, MinScale, MaxScale);
            ContentRect.localScale = new Vector3(s, s, 1f);
        }
    }

    public static class IsaResearchTabUI
    {
        private sealed class NodeWidget
        {
            public IsaTechNode Node;
            public Image Bg;
            public TMP_Text StatusTxt;
            public RectTransform ProgFillRt;
            public Image ProgImg;
        }

        private readonly struct DepLine
        {
            public readonly string FromId;
            public readonly string ToId;
            public readonly Image Img;

            public DepLine(string fromId, string toId, Image img)
            {
                FromId = fromId;
                ToId = toId;
                Img = img;
            }
        }

        private static readonly FieldInfo CpuTabF = AccessTools.Field(typeof(ResearchTreeWindow), "cpuTab");
        private static readonly FieldInfo CurrentResearchUiF = AccessTools.Field(typeof(ResearchTreeWindow), "currentResearchUI");
        private static readonly FieldInfo CompanyResearchSectorF = AccessTools.Field(typeof(ResearchSector), "company");

        private static ResearchTreeWindow _window;
        private static GameObject _cpuTab, _isaPanel, _tabBarGo;
        private static Button _cpuTabBtn, _isaTabBtn, _stopBtn, _detailResearchBtn;
        private static bool _showingIsaTab;

        private static RectTransform _treeContent, _activeBarFill;
        private static readonly List<NodeWidget> NodeWidgets = new List<NodeWidget>();
        private static readonly List<DepLine> DepLines = new List<DepLine>();

        private static TMP_Text _activeTitleTxt, _activeInfoTxt, _fundingPctTxt, _detailTitleTxt, _detailBodyTxt, _detailBtnTxt;
        private static Slider _fundingSlider;
        private static string _selectedNodeId;
        private static readonly int[] FundingStepsPct =
        {
            10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95,
            100,
            125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 475, 500
        };

        private static int FundingToStepIndex(float funding)
        {
            int targetPct = Mathf.RoundToInt(funding * 100f);
            int bestIdx = 18, bestDiff = int.MaxValue;
            for (int i = 0; i < FundingStepsPct.Length; i++)
            {
                int d = Math.Abs(FundingStepsPct[i] - targetPct);
                if (d < bestDiff) { bestDiff = d; bestIdx = i; }
            }
            return bestIdx;
        }

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(ResearchTreeWindow), "InitializeUI"),
                postfix: new HarmonyMethod(typeof(IsaResearchTabUI), nameof(ResearchTreeWindow_InitializeUI_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ResearchTreeWindow), nameof(ResearchTreeWindow.ForceUIUpdate)),
                postfix: new HarmonyMethod(typeof(IsaResearchTabUI), nameof(ResearchTreeWindow_OnEnable_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ResearchSector), nameof(ResearchSector.Update)),
                postfix: new HarmonyMethod(typeof(IsaResearchTabUI), nameof(ResearchSector_Update_Postfix)));
        }

        private static void ResearchTreeWindow_InitializeUI_Postfix(ResearchTreeWindow __instance)
        {
            try
            {
                _window = __instance;
                _cpuTab = CpuTabF?.GetValue(__instance) as GameObject;
                if (_cpuTab == null) return;
                BuildTabBarAndIsaPanel(__instance);
            }
            catch (Exception ex)
            {
                DynamicIsaPlugin.Log?.LogError($"Failed building ISA Research Tab UI: {ex}");
            }
        }

        private static void ResearchTreeWindow_OnEnable_Postfix()
        {
            if (_isaPanel != null && _showingIsaTab) RefreshTreeUi();
        }

        private static void BuildTabBarAndIsaPanel(ResearchTreeWindow win)
        {
            if (_isaPanel != null) return;

            _isaPanel = IsaUiHelper.CreatePanel("DynamicISA_IsaTabPanel", win.transform, IsaUiHelper.PanelBg, false);
            _isaPanel.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 4f, 4f, -4f, -38f);

            _tabBarGo = IsaUiHelper.CreatePanel("DynamicISA_ResearchTabBar", win.transform, IsaUiHelper.HeaderBg, true);
            var tbRt = _tabBarGo.GetComponent<RectTransform>();
            tbRt.anchorMin = tbRt.anchorMax = tbRt.pivot = new Vector2(0f, 1f);
            tbRt.anchoredPosition = new Vector2(210f, -6f);
            tbRt.sizeDelta = new Vector2(236f, 32f);

            _cpuTabBtn = IsaUiHelper.CreateButton("CpuTreeTabBtn", _tabBarGo.transform, "CPU Tech", IsaUiHelper.AccentBlue, 13f, () => SwitchTab(false));
            _cpuTabBtn.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.5f, 1f, 3f, 3f, -2f, -3f);

            _isaTabBtn = IsaUiHelper.CreateButton("IsaTreeTabBtn", _tabBarGo.transform, "ISA Tree", IsaUiHelper.CardBg, 13f, () => SwitchTab(true));
            _isaTabBtn.GetComponent<RectTransform>().SetAnchorStretch(0.5f, 0f, 1f, 1f, 2f, 3f, -3f, -3f);

            var topBar = IsaUiHelper.CreatePanel("IsaActiveBar", _isaPanel.transform, IsaUiHelper.HeaderBg, true);
            topBar.GetComponent<RectTransform>().SetTopAnchored(-6f, 64f, -24f);

            _activeTitleTxt = IsaUiHelper.CreateText("ActiveTitle", topBar.transform, "ISA Lab Idle — Select a technology below", 15f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold);
            _activeTitleTxt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.5f, 0.45f, 1f, 14f, 0f, -6f, -4f);

            _activeInfoTxt = IsaUiHelper.CreateText("ActiveInfo", topBar.transform, "Independent Architecture R&D Queue", 12.5f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted);
            _activeInfoTxt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.45f, 0.52f, 14f, 6f, -6f, 0f);

            var pbBg = IsaUiHelper.CreatePanel("ProgBg", topBar.transform, new Color(0.08f, 0.09f, 0.11f, 1f), true);
            pbBg.GetComponent<RectTransform>().SetAnchorStretch(0.46f, 0.36f, 0.68f, 0.68f);

            _activeBarFill = IsaUiHelper.CreatePanel("ProgFill", pbBg.transform, IsaUiHelper.AccentBlue, true)
                .GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0f, 1f);

            IsaUiHelper.CreateText("FundLbl", topBar.transform, "ISA Funding", 12f, TextAlignmentOptions.Right, IsaUiHelper.TextMuted)
                .GetComponent<RectTransform>().SetAnchorStretch(0.69f, 0.55f, 0.84f, 0.95f);

            _fundingPctTxt = IsaUiHelper.CreateText("FundPct", topBar.transform, "100%", 12.5f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold);
            _fundingPctTxt.GetComponent<RectTransform>().SetAnchorStretch(0.85f, 0.55f, 0.91f, 0.95f, 4f, 0f, 0f, 0f);

            _fundingSlider = IsaUiHelper.CreateSlider("FundSlider", topBar.transform, 0f, FundingStepsPct.Length - 1, true, v =>
            {
                var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
                if (st != null)
                {
                    int idx = Mathf.Clamp(Mathf.RoundToInt(v), 0, FundingStepsPct.Length - 1);
                    st.Funding = FundingStepsPct[idx] / 100f;
                    RefreshHeaderBar();
                }
            });
            _fundingSlider.SetValueWithoutNotify(18f);
            _fundingSlider.GetComponent<RectTransform>().SetAnchorStretch(0.69f, 0.14f, 0.90f, 0.50f);

            _stopBtn = IsaUiHelper.CreateButton("StopIsaResearchBtn", topBar.transform, "Stop", IsaUiHelper.AccentRed, 12.5f, () =>
            {
                var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
                if (st != null) { st.ActiveTechId = ""; RefreshTreeUi(); }
            });
            _stopBtn.GetComponent<RectTransform>().SetAnchorStretch(0.92f, 0.22f, 0.99f, 0.78f);

            var viewport = IsaUiHelper.CreatePanel("IsaTreeViewport", _isaPanel.transform, IsaUiHelper.IsDark ? new Color(0.11f, 0.12f, 0.135f, 1f) : new Color(0.90f, 0.91f, 0.94f, 1f), true);
            viewport.AddComponent<RectMask2D>();
            viewport.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.75f, 1f, 12f, 12f, -6f, -78f);

            var contentGo = new GameObject("TreeCanvas", typeof(RectTransform));
            contentGo.transform.SetParent(viewport.transform, false);
            _treeContent = contentGo.GetComponent<RectTransform>();
            _treeContent.anchorMin = _treeContent.anchorMax = _treeContent.pivot = new Vector2(0.5f, 0.5f);
            _treeContent.sizeDelta = new Vector2(2100f, 1050f);
            _treeContent.anchoredPosition = new Vector2(45f, 12f);
            _treeContent.localScale = new Vector3(0.56f, 0.56f, 1f);
            viewport.AddComponent<IsaTreeViewportDrag>().ContentRect = _treeContent;

            var sidePanel = IsaUiHelper.CreatePanel("IsaNodeInspector", _isaPanel.transform, IsaUiHelper.CardBg, true);
            sidePanel.GetComponent<RectTransform>().SetAnchorStretch(0.755f, 0f, 1f, 1f, 6f, 12f, -12f, -78f);

            _detailTitleTxt = IsaUiHelper.CreateText("DetailTitle", sidePanel.transform, "Select ISA Tech", 16f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextPrimary, FontStyles.Bold);
            _detailTitleTxt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.84f, 1f, 1f, 14f, 4f, -14f, -12f);

            _detailBodyTxt = IsaUiHelper.CreateText("DetailBody", sidePanel.transform, "Click any node on the ISA Tech Tree (drag to pan, scroll to zoom) to inspect its capabilities, unlocks, and segment bonuses.", 13f, TextAlignmentOptions.TopLeft, IsaUiHelper.TextPrimary);
            _detailBodyTxt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.14f, 1f, 0.84f, 14f, 6f, -14f, -4f);

            _detailResearchBtn = IsaUiHelper.CreateButton("DetailResearchBtn", sidePanel.transform, "Research Tech", IsaUiHelper.AccentBlue, 14f, OnStartSelectedResearchClicked);
            _detailResearchBtn.GetComponent<RectTransform>().SetAnchorStretch(0.06f, 0.025f, 0.94f, 0.115f);
            _detailBtnTxt = _detailResearchBtn.GetComponentInChildren<TMP_Text>();
            _detailResearchBtn.interactable = false;

            BuildTreeNodesAndLines();
            _isaPanel.SetActive(false);
            SwitchTab(false);
        }

        private static void BuildTreeNodesAndLines()
        {
            NodeWidgets.Clear();
            DepLines.Clear();
            const float colSpacing = 212f, rowSpacing = 122f, startX = -740f, startY = 230f;
            Vector2 GetNodePos(IsaTechNode n) => new Vector2(startX + n.Column * colSpacing, startY - n.Row * rowSpacing);

            string[] lanes = { "SERVER & SECURITY", "EXECUTION CORE", "SUPERSCALAR / OoO", "BIT-WIDTH (x86)", "RISC & VLIW / IA64", "SIMD & AI VECTORS", "POWER & MOBILE" };
            for (int r = -1; r <= 5; r++)
            {
                var lt = IsaUiHelper.CreateText($"Lane_{r}", _treeContent, lanes[r + 1], 11f, TextAlignmentOptions.Right, IsaUiHelper.TextMuted, FontStyles.Bold);
                var lrt = lt.GetComponent<RectTransform>();
                lrt.sizeDelta = new Vector2(145f, 36f);
                lrt.anchoredPosition = new Vector2(startX - 185f, startY - r * rowSpacing);
            }

            var linesContainer = new GameObject("Lines", typeof(RectTransform));
            linesContainer.transform.SetParent(_treeContent, false);
            linesContainer.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            foreach (var node in IsaTechTree.Nodes)
            {
                if (node.Dependencies == null) continue;
                Vector2 to = GetNodePos(node) - new Vector2(96f, 0f);
                foreach (var depId in node.Dependencies)
                {
                    var dep = IsaTechTree.Get(depId);
                    if (dep == null) continue;
                    Vector2 from = GetNodePos(dep) + new Vector2(96f, 0f);
                    Vector2 delta = to - from;

                    var lineGo = new GameObject($"Line_{depId}_{node.Id}", typeof(RectTransform), typeof(Image));
                    lineGo.transform.SetParent(linesContainer.transform, false);
                    var img = lineGo.GetComponent<Image>();
                    img.color = IsaUiHelper.BorderCol;
                    var rt = lineGo.GetComponent<RectTransform>();
                    rt.sizeDelta = new Vector2(delta.magnitude, 3f);
                    rt.anchoredPosition = (from + to) * 0.5f;
                    rt.localEulerAngles = new Vector3(0f, 0f, Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg);
                    DepLines.Add(new DepLine(depId, node.Id, img));
                }
            }

            foreach (var node in IsaTechTree.Nodes)
            {
                var card = IsaUiHelper.CreatePanel($"Node_{node.Id}", _treeContent, IsaUiHelper.CardBg, true);
                var rt = card.GetComponent<RectTransform>();
                rt.sizeDelta = new Vector2(192f, 84f);
                rt.anchoredPosition = GetNodePos(node);

                var outline = card.AddComponent<Outline>();
                outline.effectColor = IsaUiHelper.BorderCol; outline.effectDistance = new Vector2(1f, -1f);

                string capturedId = node.Id;
                card.AddComponent<Button>().onClick.AddListener(() => { _selectedNodeId = capturedId; RefreshTreeUi(); });

                IsaUiHelper.CreateText("Year", card.transform, $"{node.UnlockYear} · {node.ShortTag}", 11f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0f, 0.72f, 1f, 0.96f, 8f, 0f, -8f, -2f);

                IsaUiHelper.CreateText("Name", card.transform, node.Name, 12.5f, TextAlignmentOptions.Left, IsaUiHelper.TextPrimary, FontStyles.Bold)
                    .GetComponent<RectTransform>().SetAnchorStretch(0f, 0.34f, 1f, 0.74f, 8f, 0f, -8f, 0f);

                var status = IsaUiHelper.CreateText("Status", card.transform, $"{IsaUiHelper.FormatMoneyShort(node.MonthlyCost)}/m", 11f, TextAlignmentOptions.Left, IsaUiHelper.TextMuted);
                status.GetComponent<RectTransform>().SetAnchorStretch(0f, 0.12f, 1f, 0.35f, 8f, 0f, -8f, 0f);

                var pbBg = IsaUiHelper.CreatePanel("PB", card.transform, new Color(0f, 0f, 0f, 0.25f), false);
                pbBg.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 0.08f);

                var pbFill = IsaUiHelper.CreatePanel("PBF", pbBg.transform, IsaUiHelper.AccentBlue, false);
                var pbRt = pbFill.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0f, 1f);

                NodeWidgets.Add(new NodeWidget
                {
                    Node = node,
                    Bg = card.GetComponent<Image>(),
                    StatusTxt = status,
                    ProgFillRt = pbRt,
                    ProgImg = pbFill.GetComponent<Image>()
                });
            }

            _selectedNodeId = IsaTechTree.Nodes[0].Id;
        }

        internal static void SetUiActive(bool active)
        {
            if (!active)
            {
                if (_showingIsaTab) SwitchTab(false);
                if (_isaPanel != null) _isaPanel.SetActive(false);
            }
            if (_tabBarGo != null) _tabBarGo.SetActive(active);
        }

        private static void SwitchTab(bool showIsa)
        {
            _showingIsaTab = showIsa;
            _cpuTab?.SetActive(!showIsa);
            _isaPanel?.SetActive(showIsa);
            if (_cpuTabBtn != null) _cpuTabBtn.GetComponent<Image>().color = !showIsa ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg;
            if (_isaTabBtn != null) _isaTabBtn.GetComponent<Image>().color = showIsa ? IsaUiHelper.AccentBlue : IsaUiHelper.CardBg;

            var curUi = _window != null ? CurrentResearchUiF?.GetValue(_window) as CurrentResearchUI : null;
            var cg = curUi != null ? curUi.GetComponent<CanvasGroup>() : null;
            if (cg != null)
            {
                bool hasCpuResearch = Player.Instance?.Company?.ResearchSector?.CurrentResearch() != null;
                cg.alpha = !showIsa && hasCpuResearch ? 1f : 0f;
                cg.blocksRaycasts = !showIsa && hasCpuResearch;
            }

            if (_isaPanel != null && showIsa)
            {
                _isaPanel.transform.SetAsLastSibling();
                _tabBarGo?.transform.SetAsLastSibling();
                RefreshTreeUi();
            }
        }

        private static void OnStartSelectedResearchClicked()
        {
            var node = IsaTechTree.Get(_selectedNodeId);
            var st = IsaState.GetCompanyResearch(Player.Instance?.Company);
            if (node == null || st == null || st.IsUnlocked(node.Id) || !st.AreDependenciesMet(node)) return;
            st.ActiveTechId = node.Id;
            RefreshTreeUi();
        }

        public static void RefreshTreeUi()
        {
            if (_isaPanel == null || Player.Instance?.Company == null) return;
            var st = IsaState.GetCompanyResearch(Player.Instance.Company);
            if (st == null) return;

            RefreshHeaderBar();
            int year = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;

            for (int i = 0; i < NodeWidgets.Count; i++)
            {
                var w = NodeWidgets[i];
                var node = w.Node;
                bool unlocked = st.IsUnlocked(node.Id), active = st.ActiveTechId == node.Id, depsOk = st.AreDependenciesMet(node);
                float prog = st.GetProgress(node.Id);

                Color cardCol = active ? new Color(0.18f, 0.36f, 0.56f, 1f) :
                                unlocked ? new Color(0.16f, 0.34f, 0.24f, 1f) :
                                depsOk ? IsaUiHelper.CardBg : new Color(IsaUiHelper.CardBg.r * 0.72f, IsaUiHelper.CardBg.g * 0.72f, IsaUiHelper.CardBg.b * 0.72f, 0.75f);
                if (_selectedNodeId == node.Id) cardCol = Color.Lerp(cardCol, Color.white, 0.14f);
                if (w.Bg != null) w.Bg.color = cardCol;

                if (w.StatusTxt != null)
                {
                    if (unlocked) { w.StatusTxt.text = "UNLOCKED"; w.StatusTxt.color = new Color(0.45f, 0.90f, 0.58f, 1f); }
                    else if (active)
                    {
                        int remDays = RemainingDays(node, prog, st.Funding, Player.Instance.Company, year);
                        w.StatusTxt.text = $"ACTIVE · {Mathf.RoundToInt(prog * 100f)}% ({remDays}d)";
                        w.StatusTxt.color = new Color(0.48f, 0.82f, 1f, 1f);
                    }
                    else
                    {
                        w.StatusTxt.text = !depsOk ? "LOCKED (Prereq)" : $"{IsaUiHelper.FormatMoneyShort(node.MonthlyCost)}/m · {node.ResearchDays}d";
                        w.StatusTxt.color = IsaUiHelper.TextMuted;
                    }
                }

                if (w.ProgFillRt != null) w.ProgFillRt.anchorMax = new Vector2(prog, 1f);
                if (w.ProgImg != null) w.ProgImg.color = unlocked ? IsaUiHelper.AccentGreen : IsaUiHelper.AccentBlue;
            }

            for (int i = 0; i < DepLines.Count; i++)
            {
                var line = DepLines[i];
                if (line.Img == null) continue;
                bool fromOk = st.IsUnlocked(line.FromId);
                line.Img.color = (fromOk && st.IsUnlocked(line.ToId)) ? IsaUiHelper.AccentGreen :
                                 (fromOk ? IsaUiHelper.AccentBlue : IsaUiHelper.BorderCol);
            }

            UpdateInspectorPanel(st);
        }

        private static void RefreshHeaderBar()
        {
            if (_activeTitleTxt == null || Player.Instance?.Company == null) return;
            var st = IsaState.GetCompanyResearch(Player.Instance.Company);
            if (st == null) return;

            _fundingSlider?.SetValueWithoutNotify(FundingToStepIndex(st.Funding));
            if (_fundingPctTxt != null) _fundingPctTxt.text = $"{Mathf.RoundToInt(st.Funding * 100f)}%";

            var active = IsaTechTree.Get(st.ActiveTechId);
            if (active == null)
            {
                _activeTitleTxt.text = "ISA Lab Idle — Select an ISA Feature Node";
                _activeInfoTxt.text = $"Unlocked Features: {st.UnlockedFeatures.Count}/{IsaTechTree.Nodes.Count} (Runs alongside CPU research)";
                if (_activeBarFill != null) _activeBarFill.anchorMax = new Vector2(0f, 1f);
                if (_stopBtn != null) _stopBtn.interactable = false;
            }
            else
            {
                float prog = st.GetProgress(active.Id);
                int year = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
                int rem = RemainingDays(active, prog, st.Funding, Player.Instance.Company, year);
                float speed = EffectiveSpeedMultiplier(active, st.Funding, Player.Instance.Company, year);
                _activeTitleTxt.text = $"Researching: {active.Name} ({active.UnlockYear})";
                _activeInfoTxt.text = $"Cost: {IsaUiHelper.FormatMoneyShort(active.MonthlyCost * st.Funding)}/m · Speed: {Mathf.RoundToInt(speed * 100f)}% · Left: {rem}d";
                if (_activeBarFill != null) _activeBarFill.anchorMax = new Vector2(prog, 1f);
                if (_stopBtn != null) _stopBtn.interactable = true;
            }
        }

        private static void UpdateInspectorPanel(CompanyIsaResearchState st)
        {
            var node = IsaTechTree.Get(_selectedNodeId);
            if (node == null || _detailTitleTxt == null) return;

            _detailTitleTxt.text = $"{node.Name} ({node.UnlockYear})";
            string deps = node.Dependencies != null && node.Dependencies.Length > 0
                ? string.Join(", ", Array.ConvertAll(node.Dependencies, id => IsaTechTree.Get(id)?.Name ?? id)) : "None";

            string flags = (node.IsBackwardsCompat64 ? "\n• Keeps 100% legacy x86 binary compatibility" : "") +
                           (node.IsCleanSheet64 ? "\n• Clean-sheet 64b (requires new software ecosystem)" : "") +
                           (node.UnlocksVliwParadigm ? "\n• Unlocks VLIW / EPIC ISA Paradigm" : "") +
                           (node.BitWidth > 0 ? $"\n• Architecture Width: {node.BitWidth}-Bit" : "");

            _detailBodyTxt.text =
                $"{node.Description}\n\n<b>Prerequisites:</b> {deps}\n" +
                $"<b>Research:</b> {IsaUiHelper.FormatMoneyShort(node.MonthlyCost)}/m · {node.ResearchDays} days\n" +
                $"<b>Build Cost on ISA:</b> {IsaUiHelper.FormatMoneyShort(node.BuildCost)} · +{node.BuildDays}d\n\n" +
                $"<b>Silicon Effects when Enabled:</b>\n• IPC: {FormatSignedPct(node.IpcBonus)}\n• Power Draw: {FormatSignedPct(node.PowerDelta)}\n• Clock Ceiling: {FormatSignedPct(node.ClockBonus)}\n\n" +
                $"<b>Market Appeal:</b> Desk {FormatSignedPct(node.DesktopAppeal)}, Srv {FormatSignedPct(node.ServerAppeal)}, Mob {FormatSignedPct(node.MobileAppeal)}, Ind {FormatSignedPct(node.IndustrialAppeal)}{flags}";

            bool unlocked = st.IsUnlocked(node.Id), active = st.ActiveTechId == node.Id, depsOk = st.AreDependenciesMet(node);
            _detailBtnTxt.text = unlocked ? "Researched" : (active ? "Researching Now" : (!depsOk ? "Requires Prerequisite" : "Start ISA Research"));
            _detailResearchBtn.interactable = !unlocked && !active && depsOk;
            _detailResearchBtn.GetComponent<Image>().color = unlocked ? IsaUiHelper.AccentGreen : (active ? IsaUiHelper.AccentAmber : (!depsOk ? IsaUiHelper.BorderCol : IsaUiHelper.AccentBlue));
        }

        private static string FormatSignedPct(float v) => $"{Mathf.RoundToInt(v * 100f):+0;-0;+0}%";

        private static float EffectiveSpeedMultiplier(IsaTechNode node, float funding, ICompany comp, int year)
        {
            float baseSpeed = ResearchMath.ResearchSpeed(Mathf.Max(0.1f, funding), comp) * (DynamicIsaPlugin.ResearchSpeedMult?.Value ?? 1f);
            float yearsEarly = Mathf.Max(0f, node.UnlockYear - year);
            float earlyPenalty = yearsEarly > 0f ? Mathf.Pow(1.75f, yearsEarly) : 1f;
            return Mathf.Clamp(baseSpeed / earlyPenalty, 0.01f, 12f);
        }

        private static int RemainingDays(IsaTechNode node, float curProgress, float funding, ICompany comp, int year)
        {
            float perDay = EffectiveSpeedMultiplier(node, funding, comp, year) / Math.Max(1f, node.ResearchDays);
            return Mathf.CeilToInt(Math.Max(0f, 1f - curProgress) / Math.Max(0.0001f, perDay));
        }

        private static void ResearchSector_Update_Postfix(ResearchSector __instance, bool statesOnly)
        {
            if (statesOnly || (GameManager.Instance != null && GameManager.Instance.IsLoading)) return;
            var company = CompanyResearchSectorF?.GetValue(__instance) as ICompany;
            if (company == null || company.IsBankrupt) return;
            if (!company.IsPlayer && !(DynamicIsaPlugin.EnableAiIsaResearch?.Value ?? true)) return;

            var st = IsaState.GetCompanyResearch(company);
            if (st == null) return;
            int year = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;

            if (!company.IsPlayer && string.IsNullOrEmpty(st.ActiveTechId))
                PickNextAiIsaTech(company, st, year);

            if (string.IsNullOrEmpty(st.ActiveTechId)) return;
            var node = IsaTechTree.Get(st.ActiveTechId);
            if (node == null || st.IsUnlocked(node.Id)) { st.ActiveTechId = ""; return; }

            if (!company.IsPlayer)
            {
                if (company.MoneyAmount <= 0f) return;
                int diff = Player.Instance != null ? Player.Instance.DifficultyLevel : 2;
                float maxFund = diff switch { 0 => 0.85f, 1 => 1.1f, 2 => 1.45f, 3 => 1.9f, _ => 2.5f };
                if (CompanyHelper.IsInlet(company) || CompanyHelper.IsEMD(company)) maxFund *= 1.15f;
                st.Funding = company.MoneyAmount < node.MonthlyCost * 4f ? 0.35f :
                             (company.MoneyAmount < node.MonthlyCost * 12f ? Mathf.Min(1f, maxFund) : maxFund);
            }

            float dailyCost = node.MonthlyCost * st.Funding / 30f;
            if (dailyCost > 0f) company.SpendMoney(dailyCost, ExpenseOrigin.Research);

            float cur = st.GetProgress(node.Id) + EffectiveSpeedMultiplier(node, st.Funding, company, year) / Math.Max(1f, node.ResearchDays);
            if (cur >= 1f)
            {
                st.Progress[node.Id] = 1f;
                st.UnlockedFeatures.Add(node.Id);
                st.ActiveTechId = "";
                if (company.IsPlayer && DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating &&
                    (GameManager.Instance == null || !GameManager.Instance.IsLoading))
                    PopupManager.Instance?.InstantiateGenericNotification($"ISA Unlocked: {node.ShortTag}", node.Name);
                else if (!company.IsPlayer)
                    DynamicAiIsaController.OnAiUnlockedIsaFeature(company, node);
            }
            else st.Progress[node.Id] = cur;

            if (company.IsPlayer && _showingIsaTab && _isaPanel != null && _isaPanel.activeInHierarchy)
                RefreshTreeUi();
        }

        private static void PickNextAiIsaTech(ICompany company, CompanyIsaResearchState st, int year)
        {
            if (company.IsFoundry || company.MoneyAmount <= 0f) return;
            IsaTechNode best = null;
            float bestScore = -999f;

            for (int i = 0; i < IsaTechTree.Nodes.Count; i++)
            {
                var n = IsaTechTree.Nodes[i];
                if (st.IsUnlocked(n.Id) || !st.AreDependenciesMet(n) || year < n.UnlockYear - 3) continue;
                float score = 10f - Math.Max(0, n.UnlockYear - year) * 3f;

                if (CompanyHelper.IsInlet(company))
                {
                    if (n.Id == "isa_vliw_epic" || n.Id == "isa_64bit_clean") score += 25f;
                    if (n.Id == "isa_hw_virt" || n.Id == "isa_ooo" || n.Branch == IsaBranch.SimdVector) score += 10f;
                }
                else if (CompanyHelper.IsEMD(company) && (n.Id == "isa_64bit_ext" || n.Id == "isa_mmx_simd" || n.Id == "isa_sse_fp" || n.Branch == IsaBranch.ExecutionPipeline))
                    score += 22f;
                else if (n.Branch == IsaBranch.PowerMobile || n.Id == "isa_risc_loadstore" || n.Branch == IsaBranch.ExecutionPipeline)
                    score += 10f;

                if (n.MonthlyCost * 6f > Math.Max(1f, company.MoneyAmount)) score -= 12f;
                if (score > bestScore) { bestScore = score; best = n; }
            }

            if (best != null) { st.ActiveTechId = best.Id; st.Funding = 1f; }
        }
    }
}
