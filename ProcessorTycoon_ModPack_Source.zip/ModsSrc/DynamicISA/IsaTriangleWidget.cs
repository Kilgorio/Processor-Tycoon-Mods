using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DynamicISA
{
    public class IsaTriangleWidget : MonoBehaviour, IPointerDownHandler, IDragHandler
    {
        private static readonly Vector2 VTopIpc = new Vector2(0.50f, 0.87f);
        private static readonly Vector2 VLeftEff = new Vector2(0.11f, 0.14f);
        private static readonly Vector2 VRightClk = new Vector2(0.89f, 0.14f);

        private RectTransform _plotRect;
        private RectTransform _handleRect;
        private TMP_Text _topLabel, _leftLabel, _rightLabel;
        private Texture2D _triTex;

        public float WeightIpc { get; private set; } = 0.34f;
        public float WeightEff { get; private set; } = 0.33f;
        public float WeightClk { get; private set; } = 0.33f;

        public event Action<float, float, float> OnWeightsChanged;

        public static IsaTriangleWidget Create(Transform parent, Vector2 anchoredSize)
        {
            var root = new GameObject("IsaFocusTriangle", typeof(RectTransform));
            root.transform.SetParent(parent, false);
            root.GetComponent<RectTransform>().sizeDelta = anchoredSize;
            var widget = root.AddComponent<IsaTriangleWidget>();
            widget.BuildUi();
            return widget;
        }

        private void OnDestroy()
        {
            if (_triTex != null)
            {
                Destroy(_triTex);
                _triTex = null;
            }
        }

        private void BuildUi()
        {
            var plotGo = new GameObject("TrianglePlot", typeof(RectTransform), typeof(RawImage));
            plotGo.transform.SetParent(transform, false);
            _plotRect = plotGo.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            _triTex = GenerateTriangleTexture(256, 232);
            plotGo.GetComponent<RawImage>().texture = _triTex;

            var ringGo = IsaUiHelper.CreatePanel("HandleRing", _plotRect, Color.white, true);
            _handleRect = ringGo.GetComponent<RectTransform>();
            _handleRect.anchorMin = _handleRect.anchorMax = Vector2.zero;
            _handleRect.pivot = new Vector2(0.5f, 0.5f);
            _handleRect.sizeDelta = new Vector2(18f, 18f);

            var innerGo = IsaUiHelper.CreatePanel("InnerDot", ringGo.transform, new Color(0.10f, 0.12f, 0.16f, 1f), true);
            innerGo.GetComponent<RectTransform>().SetAnchorStretch(0.24f, 0.24f, 0.76f, 0.76f);

            _topLabel = IsaUiHelper.CreateText("TopIpc", transform, "IPC 34%", 12.5f, TextAlignmentOptions.Center, new Color(0.45f, 0.80f, 1f, 1f), FontStyles.Bold);
            _topLabel.GetComponent<RectTransform>().SetTopAnchored(-2f, 22f, 0f);

            _leftLabel = IsaUiHelper.CreateText("LeftEff", transform, "Eff. 33%", 12f, TextAlignmentOptions.Left, new Color(0.45f, 0.90f, 0.58f, 1f), FontStyles.Bold);
            _leftLabel.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 0.5f, 0f, 4f, 2f, 0f, 24f);

            _rightLabel = IsaUiHelper.CreateText("RightClk", transform, "Clock 33%", 12f, TextAlignmentOptions.Right, new Color(1f, 0.74f, 0.34f, 1f), FontStyles.Bold);
            _rightLabel.GetComponent<RectTransform>().SetAnchorStretch(0.5f, 0f, 1f, 0f, 0f, 2f, -4f, 24f);

            SetWeights(0.34f, 0.33f, 0.33f, false);
        }

        public void SetWeights(float ipc, float eff, float clk, bool notify = true)
        {
            float sum = Mathf.Max(0.001f, ipc + eff + clk);
            WeightIpc = Mathf.Clamp01(ipc / sum);
            WeightEff = Mathf.Clamp01(eff / sum);
            WeightClk = Mathf.Clamp01(1f - WeightIpc - WeightEff);
            UpdateHandleVisual();
            if (notify) OnWeightsChanged?.Invoke(WeightIpc, WeightEff, WeightClk);
        }

        private void UpdateHandleVisual()
        {
            if (_plotRect == null || _handleRect == null) return;
            Vector2 pNorm = VTopIpc * WeightIpc + VLeftEff * WeightEff + VRightClk * WeightClk;
            Rect r = _plotRect.rect;
            _handleRect.anchoredPosition = new Vector2(pNorm.x * r.width, pNorm.y * r.height);
            if (_topLabel != null) _topLabel.text = $"IPC  {Mathf.RoundToInt(WeightIpc * 100f)}%";
            if (_leftLabel != null) _leftLabel.text = $"Eff. {Mathf.RoundToInt(WeightEff * 100f)}%";
            if (_rightLabel != null) _rightLabel.text = $"Clock {Mathf.RoundToInt(WeightClk * 100f)}%";
        }

        private void OnRectTransformDimensionsChange() => UpdateHandleVisual();
        public void OnPointerDown(PointerEventData e) => UpdateFromPointer(e);
        public void OnDrag(PointerEventData e) => UpdateFromPointer(e);

        private void UpdateFromPointer(PointerEventData eventData)
        {
            if (_plotRect == null || !RectTransformUtility.ScreenPointToLocalPointInRectangle(_plotRect, eventData.position, eventData.pressEventCamera, out Vector2 local))
                return;
            Rect r = _plotRect.rect;
            if (r.width <= 1f || r.height <= 1f) return;
            Barycentric(new Vector2((local.x - r.xMin) / r.width, (local.y - r.yMin) / r.height), VTopIpc, VLeftEff, VRightClk, out float u, out float v, out float w);
            u = Mathf.Max(0f, u); v = Mathf.Max(0f, v); w = Mathf.Max(0f, w);
            SetWeights(u, v, w, true);
        }

        private static void Barycentric(Vector2 p, Vector2 a, Vector2 b, Vector2 c, out float u, out float v, out float w)
        {
            Vector2 v0 = b - a, v1 = c - a, v2 = p - a;
            float d00 = Vector2.Dot(v0, v0), d01 = Vector2.Dot(v0, v1), d11 = Vector2.Dot(v1, v1);
            float d20 = Vector2.Dot(v2, v0), d21 = Vector2.Dot(v2, v1);
            float denom = d00 * d11 - d01 * d01;
            if (Mathf.Abs(denom) < 1e-6f) { u = 0.34f; v = 0.33f; w = 0.33f; return; }
            v = (d11 * d20 - d01 * d21) / denom;
            w = (d00 * d21 - d01 * d20) / denom;
            u = 1f - v - w;
        }

        private static Texture2D GenerateTriangleTexture(int width, int height)
        {
            var tex = new Texture2D(width, height, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp,
                hideFlags = HideFlags.HideAndDontSave
            };
            Color ipcCol = new Color(0.24f, 0.62f, 0.96f, 0.85f), effCol = new Color(0.22f, 0.78f, 0.44f, 0.85f), clkCol = new Color(0.95f, 0.60f, 0.20f, 0.85f);
            Color gridCol = new Color(1f, 1f, 1f, 0.16f), edgeCol = new Color(0.85f, 0.88f, 0.92f, 0.80f);
            Color32 clear = new Color32(0, 0, 0, 0);
            var px = new Color32[width * height];

            for (int y = 0; y < height; y++)
            {
                float ny = (y + 0.5f) / height;
                int rowOffset = y * width;
                for (int x = 0; x < width; x++)
                {
                    Barycentric(new Vector2((x + 0.5f) / width, ny), VTopIpc, VLeftEff, VRightClk, out float u, out float v, out float w);
                    float minB = Mathf.Min(u, Mathf.Min(v, w));
                    if (minB < -0.014f) { px[rowOffset + x] = clear; continue; }
                    if (minB < 0f)
                    {
                        px[rowOffset + x] = new Color(edgeCol.r, edgeCol.g, edgeCol.b, edgeCol.a * Mathf.Clamp01(1f + minB / 0.014f));
                        continue;
                    }

                    Color c = ipcCol * u + effCol * v + clkCol * w;
                    c.a = 0.42f;
                    if (minB < 0.015f) c = Color.Lerp(edgeCol, c, minB / 0.015f);
                    else
                    {
                        for (int s = 1; s <= 4; s++)
                        {
                            float t = s * 0.2f;
                            if (Mathf.Abs(u - t) < 0.0055f || Mathf.Abs(v - t) < 0.0055f || Mathf.Abs(w - t) < 0.0055f)
                            {
                                c = Color.Lerp(c, gridCol, 0.65f);
                                break;
                            }
                        }
                    }
                    px[rowOffset + x] = c;
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }
    }
}
