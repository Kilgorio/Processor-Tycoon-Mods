using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.AISystem;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace DynamicISA
{
    public static class DynamicAiIsaController
    {
        private static readonly FieldInfo AiCompF = AccessTools.Field(typeof(AIBehaviourCreation), "company");
        private static readonly FieldInfo AiFreqValsF = AccessTools.Field(typeof(AIBehaviourCreation), "frequencyValues");
        private static readonly Dictionary<(string companyId, Segment seg), (int monthKey, Architecture arch)> AiArchCache
            = new Dictionary<(string, Segment), (int, Architecture)>();
        private static readonly List<string> TempContribFeatures = new List<string>();

        private static bool _hasEnsuredItaniumBattle;
        private static int _lastAiEvolutionYear = -1;

        public static void ApplyPatches(Harmony harmony)
        {
            harmony.Patch(AccessTools.Method(typeof(ArchitectureManager), "InitializeArchitectureIDs"),
                postfix: new HarmonyMethod(typeof(DynamicAiIsaController), nameof(ArchitectureManager_Init_Postfix)));
            harmony.Patch(AccessTools.Method(typeof(ArchitectureManager), "HandleArchitectureReleases"),
                prefix: new HarmonyMethod(typeof(DynamicAiIsaController), nameof(ArchitectureManager_Releases_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(ArchitectureManager), "HandlePlayerInCrossLicensingAgreement"),
                prefix: new HarmonyMethod(typeof(DynamicAiIsaController), nameof(ArchitectureManager_CrossLicense_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourCreation), "SelectArchitecture"),
                prefix: new HarmonyMethod(typeof(DynamicAiIsaController), nameof(AI_SelectArchitecture_Prefix)));
            harmony.Patch(AccessTools.Method(typeof(AIBehaviourCreation), "UpdateFrequencyValues"),
                postfix: new HarmonyMethod(typeof(DynamicAiIsaController), nameof(AI_UpdateFrequencyValues_Postfix)));
        }

        public static void InvalidateAiArchCache() => AiArchCache.Clear();

        public static void ResetSessionFlags()
        {
            _hasEnsuredItaniumBattle = false;
            _lastAiEvolutionYear = -1;
            AiArchCache.Clear();
        }

        private static int CurrentYear => DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;

        private static void ArchitectureManager_Init_Postfix(ArchitectureManager __instance)
        {
            if (__instance?.Architectures == null) return;
            foreach (var arch in __instance.Architectures)
                if (arch != null) IsaState.GetOrCreateProfile(arch);
        }

        private static bool ArchitectureManager_Releases_Prefix(ArchitectureManager __instance)
        {
            if (GameManager.Instance != null && GameManager.Instance.IsLoading) return false;
            EnsureBattleArchitecturesConfigured(__instance);
            if (DateController.Instance == null || __instance?.Architectures == null) return false;

            DateTime curDate = DateController.Instance.CurrentDate;
            if (_lastAiEvolutionYear != curDate.Year)
            {
                _lastAiEvolutionYear = curDate.Year;
                RunAnnualAiIsaStrategy(curDate.Year);
            }

            foreach (var arch in __instance.Architectures)
            {
                if (arch?.ReleaseDate == null || curDate.Year != arch.ReleaseDate.Year || curDate.Month != arch.ReleaseDate.Month || curDate.Day != 1)
                    continue;

                if (arch.UniqueID == "x86-64" && !arch.Name.Contains("Inlet"))
                {
                    if (arch.OwnerIDs.Contains("EMD") && !arch.OwnerIDs.Contains("INT")) arch.Name = "EMD64";
                    else if (arch.OwnerIDs.Contains("INT") && arch.OwnerIDs.Contains("EMD")) arch.Name = "x86-64";
                    var p = IsaState.GetOrCreateProfile(arch);
                    if (!p.CompatibleIds.Contains("x86")) p.CompatibleIds.Add("x86");
                    IsaState.SyncProfileToArchitecture(arch, p);
                }

                SeedReleasePopularity(__instance, arch);
                if (!DateController.Instance.IsFastFowardSimulating)
                    UnityEngine.Object.FindFirstObjectByType<ArchitectureEventWindow>()?.HandleRelease(arch);
            }
            return false;
        }

        private static bool ArchitectureManager_CrossLicense_Prefix(ArchitectureManager __instance)
        {
            if (__instance == null || DateController.Instance == null || DateController.Instance.IsFastFowardSimulating) return false;
            if (GameManager.Instance != null && GameManager.Instance.IsLoading) return false;
            if (Market.Instance == null || Player.Instance == null) return false;

            var x64 = __instance.GetArchitecture("x86-64");
            if (x64 == null || x64.OwnerIDs == null || x64.OwnerIDs.Count == 0 || x64.OwnerIDs.Contains("PLAYER")) return false;
            if (x64.ReleaseDate != null && DateController.Instance.CurrentDate <= new DateTime(x64.ReleaseDate.Year, x64.ReleaseDate.Month, 1)) return false;

            float soldDesktop = 0f;
            var playerCpus = Player.Instance.GetCpus();
            if (playerCpus != null)
            {
                for (int i = 0; i < playerCpus.Count; i++)
                    if (playerCpus[i] != null) soldDesktop += playerCpus[i].SoldLastDayToDesktop;
            }
            float desktopShare = Market.Instance.DesktopSize > 0 ? soldDesktop / (Market.Instance.DesktopSize / 30f) : 0f;
            if (desktopShare >= 0.40f)
            {
                UnityEngine.Object.FindFirstObjectByType<ArchitectureEventWindow>()?.HandleCrossLicesingAgreement(x64);
                x64.OwnerIDs.Add("PLAYER");
            }
            return false;
        }

        private static void EnsureBattleArchitecturesConfigured(ArchitectureManager mgr)
        {
            if (mgr == null || _hasEnsuredItaniumBattle) return;
            _hasEnsuredItaniumBattle = true;

            int curYear = CurrentYear;
            var x64 = mgr.GetArchitecture("x86-64");
            var x86 = mgr.GetArchitecture("x86");
            var ia64 = mgr.GetArchitecture("IA-64");
            var emd64 = mgr.GetArchitecture("EMD64");

            if (x64 != null && x64.Name.Contains("Inlet"))
            {
                var pInlet = IsaState.GetOrCreateProfile(x64);
                pInlet.Name = x64.Name;
                if (!pInlet.IsCustomCreated && pInlet.Paradigm != IsaParadigm.VLIW)
                {
                    pInlet.Paradigm = IsaParadigm.VLIW;
                    pInlet.FocusIpc = 0.56f; pInlet.FocusEfficiency = 0.22f; pInlet.FocusClock = 0.22f;
                    pInlet.CompatibleIds.Clear();
                    pInlet.Features.Remove("isa_64bit_ext");
                    pInlet.Features.Add("isa_vliw_epic");
                    pInlet.Features.Add("isa_64bit_clean");
                    pInlet.IsProprietary = true;
                    IsaState.SyncProfileToArchitecture(x64, pInlet);
                }

                var emdComp = CompanyDataProvider.Instance?.GetCompany("EMD");
                if (emd64 == null && emdComp != null && !emdComp.IsBankrupt && curYear >= 2003)
                {
                    SpawnBuiltInChallenger(mgr, "EMD64", "EMD64", IsaParadigm.CISC, new Date(2003, 4),
                        new List<string> { "EMD" }, new List<string> { "x86" }, 0.34f, 0.33f, 0.33f, false, 0.05f,
                        IsaState.BaselineX64Features);
                }
                return;
            }

            if (x64 != null)
            {
                var prof64 = IsaState.GetOrCreateProfile(x64);
                if (x86 != null && !prof64.CompatibleIds.Contains("x86")) prof64.CompatibleIds.Add("x86");
                if (x64.OwnerIDs.Contains("INT") && x64.OwnerIDs.Contains("EMD"))
                {
                    x64.OwnerIDs.Remove("INT");
                    x64.Name = prof64.Name = "EMD64";
                }
                if (x64.ReleaseDate != null && x64.ReleaseDate.Year < 2003) x64.ReleaseDate = new Date(2003, 4);
                IsaState.SyncProfileToArchitecture(x64, prof64);
            }

            bool hasInlet64 = false;
            for (int i = 0; i < mgr.Architectures.Count; i++)
            {
                var a = mgr.Architectures[i];
                if (a != null && a.Name != null && a.Name.Contains("Inlet 64")) { hasInlet64 = true; break; }
            }

            if (ia64 == null && !hasInlet64)
            {
                SpawnBuiltInChallenger(mgr, "IA-64", "Inlet 64 (IA-64)", IsaParadigm.VLIW, new Date(2001, 5),
                    new List<string> { "INT" }, new List<string>(), 0.56f, 0.22f, 0.22f, true, 0.06f,
                    new[] { "isa_microcode", "isa_pipelining", "isa_superscalar", "isa_vliw_epic", "isa_64bit_clean", "isa_fpu" });
            }
        }

        private static void SpawnBuiltInChallenger(
            ArchitectureManager mgr, string uid, string name, IsaParadigm paradigm, Date relDate,
            List<string> owners, List<string> compatIds, float wIpc, float wEff, float wClk,
            bool proprietary, float royalty, string[] features)
        {
            IsaState.GenerateDistinctColors(uid, out var dCol, out var lCol);
            var arch = IsaState.SpawnArchitectureObject(mgr, uid, name, paradigm, relDate, owners, dCol, lCol, royalty, null);
            var prof = new IsaProfile
            {
                UniqueID = uid, Name = name, Paradigm = paradigm, CreatorCompanyID = owners.Count > 0 ? owners[0] : "",
                CreatedYear = relDate.Year, CreatedMonth = relDate.Month, Revision = 1,
                FocusIpc = wIpc, FocusEfficiency = wEff, FocusClock = wClk,
                Features = new HashSet<string>(features), CompatibleIds = compatIds,
                IsProprietary = proprietary, BaseRoyalty = royalty, DarkColor = dCol, LightColor = lCol, IsCustomCreated = true
            };
            IsaState.Profiles[uid] = prof;
            IsaState.SyncProfileToArchitecture(arch, prof);
        }

        private static void SeedReleasePopularity(ArchitectureManager mgr, Architecture released)
        {
            var prof = IsaState.GetOrCreateProfile(released);
            bool compat = prof.CompatibleIds.Count > 0;
            bool isArm64 = released.UniqueID == "ARM64";
            bool isX64 = released.UniqueID == "x86-64" || released.UniqueID == "EMD64";
            var avail = mgr.GetAvailableArchitectures();

            for (int i = 0; i < MarketHelper.SegmentCount; i++)
            {
                Segment seg = (Segment)i;
                bool isMob = MarketHelper.IsMobile(seg);
                float initial = isArm64 ? (isMob ? 0.38f : 0.08f) :
                                isX64 ? (isMob || seg == Segment.Industrial ? 0f : 0.16f) :
                                (released.UniqueID == "IA-64" && MarketHelper.IsServer(seg)) ? 0.08f :
                                (compat ? 0.12f : 0.03f);
                if (initial <= 0f) continue;

                if (released.MarketData?.Popularities != null && i < released.MarketData.Popularities.Count)
                    released.MarketData.Popularities[i] = Mathf.Max(released.MarketData.Popularities[i], initial);

                if (avail != null)
                {
                    for (int j = 0; j < avail.Count; j++)
                    {
                        var other = avail[j];
                        if (other != null && other != released && other.MarketData?.Popularities != null && i < other.MarketData.Popularities.Count)
                            other.MarketData.Popularities[i] = Mathf.Max(0.005f, other.MarketData.Popularities[i] - initial * 0.25f);
                    }
                }
            }
            released.MarketData?.ClampPopularities();
        }

        private static void RunAnnualAiIsaStrategy(int year)
        {
            IsaState.EvolveArmEcosystem(year);
            if (!(DynamicIsaPlugin.EnableAiIsaResearch?.Value ?? true)) return;
            var aiCompanies = DataFinder.FindAllAICompanies();
            if (aiCompanies == null || ArchitectureManager.Instance == null) return;

            var x64 = ArchitectureManager.Instance.GetArchitecture("x86-64");
            var ia64 = ArchitectureManager.Instance.GetArchitecture("IA-64");
            var avail = ArchitectureManager.Instance.GetAvailableArchitectures();

            foreach (var comp in aiCompanies)
            {
                if (comp == null || comp.IsBankrupt || comp.IsFoundry) continue;
                var st = IsaState.GetCompanyResearch(comp);
                if (st == null) continue;

                bool ownsAny = false;
                bool isMobileFocus = false, isServerFocus = false;
                var cpus = comp.Owner?.GetCpus();
                if (cpus != null)
                {
                    for (int i = 0; i < cpus.Count; i++)
                    {
                        var c = cpus[i];
                        if (c == null || c.IsRetired || c.Strategy == null) continue;
                        if (MarketHelper.IsMobile(c.Strategy.TargetMarket)) isMobileFocus = true;
                        if (MarketHelper.IsServer(c.Strategy.TargetMarket)) isServerFocus = true;
                    }
                }

                if (avail != null)
                {
                    foreach (var arch in avail)
                    {
                        if (arch?.OwnerIDs == null || !arch.OwnerIDs.Contains(comp.UniqueID)) continue;
                        ownsAny = true;
                        var prof = IsaState.GetOrCreateProfile(arch);
                        bool added = false;
                        foreach (var fid in st.UnlockedFeatures)
                        {
                            var node = IsaTechTree.Get(fid);
                            if (node != null && node.UnlockYear <= year && !IsaState.IsFeatureBlockedForArchitecture(arch, prof, node) && prof.Features.Add(fid))
                                added = true;
                        }
                        if (added && (prof.IsCustomCreated || arch.UniqueID == "x86-64"))
                        {
                            prof.Revision++;
                            float tIpc = isServerFocus ? 0.46f : (isMobileFocus ? 0.28f : 0.40f);
                            float tEff = isMobileFocus ? 0.50f : (isServerFocus ? 0.26f : 0.24f);
                            prof.FocusIpc = Mathf.Lerp(prof.FocusIpc, tIpc, 0.35f);
                            prof.FocusEfficiency = Mathf.Lerp(prof.FocusEfficiency, tEff, 0.35f);
                            prof.FocusClock = Mathf.Max(0.05f, 1f - prof.FocusIpc - prof.FocusEfficiency);
                        }
                        IsaState.SyncProfileToArchitecture(arch, prof);
                    }
                }

                var target64 = (x64 != null && !x64.Name.Contains("Inlet")) ? x64 : ArchitectureManager.Instance.GetArchitecture("EMD64");
                var inletNative64 = ia64 ?? (x64 != null && x64.Name.Contains("Inlet") ? x64 : null);
                if (CompanyHelper.IsInlet(comp) && year >= 2004 && target64 != null && inletNative64 != null && !target64.OwnerIDs.Contains("INT") && Market.Instance?.ServerSize > 0)
                {
                    float srvSz = Mathf.Max(1f, Market.Instance.ServerSize);
                    float ia64Srv = Market.Instance.ArchitectureMarketReach(inletNative64, MarketType.Server, false) / srvSz;
                    float x64Srv = Market.Instance.ArchitectureMarketReach(target64, MarketType.Server, false) / srvSz;
                    if (ia64Srv < 0.22f && x64Srv > ia64Srv * 1.15f)
                    {
                        target64.OwnerIDs.Add("INT");
                        var tp = IsaState.GetOrCreateProfile(target64);
                        if (target64.Name == "EMD64" && target64.OwnerIDs.Contains("EMD"))
                            target64.Name = tp.Name = "x86-64";
                        IsaState.SyncProfileToArchitecture(target64, tp);
                    }
                }
                else if ((DynamicIsaPlugin.EnableAiCrossLicensing?.Value ?? true) && !ownsAny && comp.MoneyAmount > 350_000_000f &&
                         target64 != null && target64.ReleaseDate != null && year >= target64.ReleaseDate.Year &&
                         !target64.OwnerIDs.Contains(comp.UniqueID))
                {
                    var p64 = IsaState.GetOrCreateProfile(target64);
                    int maxOwners = IsaState.GetMaxCrossLicenseOwners(p64);
                    TempContribFeatures.Clear();
                    foreach (var fid in st.UnlockedFeatures)
                    {
                        if (!p64.Features.Contains(fid) && IsaTechTree.Get(fid) is IsaTechNode n && !IsaState.IsFeatureBlockedForArchitecture(target64, p64, n))
                            TempContribFeatures.Add(fid);
                    }
                    if (TempContribFeatures.Count >= 2 && target64.OwnerIDs.Count < maxOwners && target64.OwnerIDs.Count > 0)
                    {
                        const float fee = 75_000_000f;
                        comp.SpendMoney(fee, ExpenseOrigin.Development);
                        foreach (var oid in target64.OwnerIDs)
                            CompanyDataProvider.Instance?.GetCompany(oid)?.EarnMoney(fee / target64.OwnerIDs.Count, RevenueOrigin.Royalties);
                        target64.OwnerIDs.Add(comp.UniqueID);
                        foreach (var fid in TempContribFeatures) p64.Features.Add(fid);
                        IsaState.SyncProfileToArchitecture(target64, p64);
                    }
                }
            }
        }

        public static void OnAiUnlockedIsaFeature(ICompany company, IsaTechNode node)
        {
            if (company == null || node == null || ArchitectureManager.Instance == null) return;
            foreach (var arch in ArchitectureManager.Instance.GetAvailableArchitectures())
            {
                if (arch?.OwnerIDs == null || !arch.OwnerIDs.Contains(company.UniqueID)) continue;
                var p = IsaState.GetOrCreateProfile(arch);
                if (!IsaState.IsFeatureBlockedForArchitecture(arch, p, node) && p.Features.Add(node.Id))
                    IsaState.SyncProfileToArchitecture(arch, p);
            }
        }

        private static Architecture ChooseBestAiArchitecture(AIBehaviourCreation instance)
        {
            var comp = AiCompF?.GetValue(instance) as AICompany;
            if (comp == null || ArchitectureManager.Instance == null) return null;

            Segment seg = instance.MarketFocus;
            int monthKey = DateController.Instance != null
                ? DateController.Instance.CurrentDate.Year * 12 + DateController.Instance.CurrentDate.Month : 0;
            var cacheKey = (comp.UniqueID ?? "", seg);
            if (AiArchCache.TryGetValue(cacheKey, out var cached) && cached.monthKey == monthKey && cached.arch != null)
                return cached.arch;

            var avail = ArchitectureManager.Instance.GetAvailableArchitectures();
            if (avail == null || avail.Count == 0) return null;

            int year = CurrentYear;
            MarketType mt = DynamicMarketIsaEngine.GetSegmentMarket(seg);

            float bestOpenIpc = 1f;
            for (int i = 0; i < avail.Count; i++)
            {
                var a = avail[i];
                if (a != null && !(IsaState.GetOrCreateProfile(a)?.IsProprietary ?? false) && a.IpcMultiplier > bestOpenIpc)
                    bestOpenIpc = a.IpcMultiplier;
            }

            Architecture best = null;
            float bestScore = -9999f;
            for (int i = 0; i < avail.Count; i++)
            {
                var arch = avail[i];
                if (arch == null || !IsaState.CanCompanyUseArchitecture(comp, arch, out float royalty) ||
                    !DynamicMarketIsaEngine.IsArchitectureAllowedInMarket(arch, mt, (int)seg, year))
                    continue;

                var prof = IsaState.GetOrCreateProfile(arch);
                float appeal = DynamicMarketIsaEngine.GetAppeal(prof, mt, year);
                float reach = Market.Instance != null
                    ? Market.Instance.ArchitectureMarketReach(arch, seg, true) / Mathf.Max(1f, Market.Instance.GetSegmentSize((int)seg)) : 0.1f;
                float ownerBonus = (arch.OwnerIDs != null && arch.OwnerIDs.Contains(comp.UniqueID)) ? 1.8f : 0f;
                float openBonus = !prof.IsProprietary
                    ? ((arch.IpcMultiplier - 1f) * 3.5f + prof.Features.Count * 0.08f + (2f - arch.PowerConsumptionMultiplier) * 1.2f)
                    : 0f;
                float score = reach * 4.5f + appeal * 1.6f + ownerBonus + openBonus - royalty * 4.0f + prof.Features.Count * 0.04f;

                if (mt == MarketType.Mobile)
                {
                    if (prof.Paradigm == IsaParadigm.RISC || arch.IsARM || arch.UniqueID == "ARM64") score += 3.5f;
                    if (arch.UniqueID == "ARM64" && year >= 2011) score += 2.0f;
                    if (prof.Paradigm == IsaParadigm.CISC) score -= 2.8f;
                }
                if (CompanyHelper.IsInlet(comp) && arch.UniqueID == "IA-64" && year <= 2005 && (mt == MarketType.Server || seg == Segment.DesktopHigh || seg == Segment.ServerHigh))
                    score += 4.5f;
                if (CompanyHelper.IsEMD(comp) && arch.UniqueID == "x86-64" && mt != MarketType.Mobile)
                    score += bestOpenIpc > arch.IpcMultiplier * 1.08f ? 1.2f : 3.5f;

                if (score > bestScore) { bestScore = score; best = arch; }
            }

            if (best != null) AiArchCache[cacheKey] = (monthKey, best);
            return best;
        }

        private static bool AI_SelectArchitecture_Prefix(AIBehaviourCreation __instance, ref Architecture __result)
        {
            var best = ChooseBestAiArchitecture(__instance);
            if (best == null) return true;
            __result = best;
            return false;
        }

        private static void AI_UpdateFrequencyValues_Postfix(AIBehaviourCreation __instance, ref float __result)
        {
            var vals = AiFreqValsF?.GetValue(__instance) as List<float>;
            var arch = ChooseBestAiArchitecture(__instance);
            if (vals == null || vals.Count == 0 || arch == null) return;

            float clkMult = IsaState.GetClockMultiplier(arch);
            if (Mathf.Abs(clkMult - 1f) < 0.01f) return;
            for (int i = 0; i < vals.Count; i++) vals[i] *= clkMult;
            __result *= clkMult;
        }
    }
}
