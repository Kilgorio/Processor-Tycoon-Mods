using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using ProcessorTycoon;
using ProcessorTycoon.CompanySystem;
using ProcessorTycoon.CompanySystem.Business;
using ProcessorTycoon.Hardware;
using ProcessorTycoon.MarketSystem;
using ProcessorTycoon.TimeSystem;
using UnityEngine;

namespace DynamicISA
{
    public class IsaProfile
    {
        public string UniqueID { get; set; }
        public string Name { get; set; }
        public IsaParadigm Paradigm { get; set; } = IsaParadigm.CISC;
        public string CreatorCompanyID { get; set; } = "";
        public int CreatedYear { get; set; } = 1971;
        public int CreatedMonth { get; set; } = 1;
        public int Revision { get; set; } = 1;

        public float FocusIpc { get; set; } = 0.34f;
        public float FocusEfficiency { get; set; } = 0.33f;
        public float FocusClock { get; set; } = 0.33f;

        public HashSet<string> Features { get; set; } = new HashSet<string>();
        public List<string> CompatibleIds { get; set; } = new List<string>();

        public bool IsProprietary { get; set; }
        public bool IsCustomCreated { get; set; }
        public float BaseRoyalty { get; set; } = 0.05f;
        public Color32 DarkColor { get; set; }
        public Color32 LightColor { get; set; }
        public float VanillaBaseIpc { get; set; } = 1f;
        public float VanillaBasePower { get; set; } = 1f;
        public float CachedClockMult { get; set; } = 1f;
        internal int CachedAppealsYear = -1;
        internal (float desk, float srv, float mob, float ind) CachedAppeals = (1f, 1f, 1f, 1f);

        public void NormalizeWeights()
        {
            float sum = Mathf.Max(0.001f, FocusIpc + FocusEfficiency + FocusClock);
            FocusIpc = Mathf.Clamp01(FocusIpc / sum);
            FocusEfficiency = Mathf.Clamp01(FocusEfficiency / sum);
            FocusClock = Mathf.Clamp01(1f - FocusIpc - FocusEfficiency);
        }

        public bool HasFeature(string id) => Features.Contains(id);

        public int MaxBitWidth
        {
            get
            {
                int max = 8;
                foreach (var f in Features)
                {
                    var n = IsaTechTree.Get(f);
                    if (n != null && n.BitWidth > max) max = n.BitWidth;
                }
                return max;
            }
        }

        public bool IsCleanSheet64 =>
            Features.Contains("isa_64bit_clean") ||
            (Paradigm == IsaParadigm.VLIW && MaxBitWidth >= 64 && CompatibleIds.Count == 0);
    }

    public class CompanyIsaResearchState
    {
        public string CompanyID { get; set; }
        public HashSet<string> UnlockedFeatures { get; set; } = new HashSet<string>();
        public string ActiveTechId { get; set; } = "";
        public float Funding { get; set; } = 1f;
        public Dictionary<string, float> Progress { get; set; } = new Dictionary<string, float>();

        public bool IsUnlocked(string techId) => UnlockedFeatures.Contains(techId);

        public bool AreDependenciesMet(IsaTechNode node)
        {
            if (node == null) return false;
            var deps = node.Dependencies;
            if (deps == null || deps.Length == 0) return true;
            for (int i = 0; i < deps.Length; i++)
                if (!UnlockedFeatures.Contains(deps[i])) return false;
            return true;
        }

        public float GetProgress(string techId) =>
            UnlockedFeatures.Contains(techId) ? 1f : (Progress.TryGetValue(techId, out float p) ? Mathf.Clamp01(p) : 0f);
    }

    public class IsaContractMetadata
    {
        public int ContractType { get; set; }
        public int ProviderID { get; set; }
        public int ClientID { get; set; }
        public string ArchitectureID { get; set; }
        public float RoyaltyRate { get; set; }
        public float UpfrontFee { get; set; }
        public int StartYear { get; set; }
        public int StartMonth { get; set; }
        public List<string> ContributedFeatures { get; set; } = new List<string>();
    }

    public static class IsaState
    {
        public const int ContractIdLicense = 1;
        public const int ContractIdCrossLicense = 2;

        private static readonly FieldInfo MarketAvailArchF = AccessTools.Field(typeof(Market), "availableArchitectures");

        public static readonly Dictionary<string, IsaProfile> Profiles = new Dictionary<string, IsaProfile>();
        public static readonly Dictionary<string, CompanyIsaResearchState> CompanyResearch = new Dictionary<string, CompanyIsaResearchState>();
        public static readonly List<IsaContractMetadata> ContractMeta = new List<IsaContractMetadata>();

        internal static readonly string[] BaselineArm32Features = { "isa_microcode", "isa_pipelining", "isa_risc_loadstore", "isa_32bit" };
        internal static readonly string[] BaselineArm64Features =
        {
            "isa_microcode", "isa_pipelining", "isa_risc_loadstore", "isa_16bit", "isa_32bit", "isa_64bit_ext",
            "isa_fpu", "isa_branch_pred", "isa_superscalar", "isa_ooo", "isa_mmx_simd", "isa_sse_fp",
            "isa_clock_gating", "isa_dvfs", "isa_hw_virt", "isa_aes_enclave", "isa_big_little"
        };
        internal static readonly string[] BaselineX64Features =
        {
            "isa_microcode", "isa_pipelining", "isa_16bit", "isa_32bit", "isa_fpu",
            "isa_branch_pred", "isa_superscalar", "isa_ooo", "isa_mmx_simd", "isa_sse_fp", "isa_64bit_ext"
        };

        public static bool IsIsaContract(BusinessContract c) =>
            c != null && (c.ContractID == ContractIdLicense || c.ContractID == ContractIdCrossLicense);

        public static int GetMaxCrossLicenseOwners(IsaProfile prof)
        {
            int cfgMax = DynamicIsaPlugin.MaxCrossLicensePartners?.Value ?? 3;
            return prof != null && !prof.IsProprietary ? Math.Max(8, cfgMax) : cfgMax;
        }

        public static string GetFeatureBlockReason(Architecture arch, IsaProfile prof, IsaTechNode node)
        {
            if (node == null) return "Invalid Node";
            IsaParadigm paradigm = prof?.Paradigm ?? IsaParadigm.CISC;
            bool hasCompat = prof != null && prof.CompatibleIds != null && prof.CompatibleIds.Count > 0;
            bool isCleanSheet64 = prof != null && prof.IsCleanSheet64;
            bool isVanillaFixed = arch != null && prof != null && !prof.IsCustomCreated &&
                (arch.UniqueID == "x86" || arch.UniqueID == "CISC" || arch.UniqueID == "RISC");
            bool isVanillaArm = arch != null && prof != null && !prof.IsCustomCreated && arch.UniqueID == "ARM";

            if ((node.RequiresCleanSheet || node.IsCleanSheet64) && hasCompat) return "Requires Compat: None";
            if (node.IsBackwardsCompat64 && (!hasCompat || arch?.UniqueID == "IA-64" || isCleanSheet64 || paradigm == IsaParadigm.VLIW))
                return "Requires Legacy Compat";
            if (node.Id == "isa_risc_loadstore" && paradigm != IsaParadigm.RISC) return "Requires RISC Paradigm";
            if (node.Id == "isa_vliw_epic" && paradigm != IsaParadigm.VLIW) return "Requires VLIW Paradigm";
            if (isVanillaFixed && (node.BitWidth >= 64 || node.UnlockYear >= 2002 || node.IsCleanSheet64 || node.IsBackwardsCompat64 || node.UnlocksVliwParadigm))
                return "Fixed Legacy Vanilla ISA";
            if (isVanillaArm && (node.BitWidth >= 64 || node.IsCleanSheet64 || node.IsBackwardsCompat64))
                return "Requires 64-Bit ARM64 ISA";
            return null;
        }

        public static bool IsFeatureBlockedForArchitecture(Architecture arch, IsaProfile prof, IsaTechNode node) =>
            arch == null || prof == null || GetFeatureBlockReason(arch, prof, node) != null;

        private static (float ipc, float pow) GetTrueVanillaBaseline(string uid, IsaParadigm paradigm) =>
            uid switch
            {
                "CISC" => (0.90f, 1.00f),
                "RISC" => (0.85f, 0.65f),
                "ARM" => (0.90f, 0.58f),
                "ARM64" => (0.98f, 0.60f),
                _ => paradigm == IsaParadigm.RISC ? (0.94f, 0.68f) : (1.00f, 1.00f)
            };

        public static void SanitizeLoadedProfiles()
        {
            if (ArchitectureManager.Instance == null) return;
            foreach (var arch in ArchitectureManager.Instance.Architectures)
            {
                if (arch == null || !Profiles.TryGetValue(arch.UniqueID, out var prof)) continue;
                var vb = GetTrueVanillaBaseline(arch.UniqueID, prof.Paradigm);
                prof.VanillaBaseIpc = vb.ipc;
                prof.VanillaBasePower = vb.pow;
                prof.Features.RemoveWhere(fid =>
                {
                    var node = IsaTechTree.Get(fid);
                    return node != null && IsFeatureBlockedForArchitecture(arch, prof, node);
                });
                SyncProfileToArchitecture(arch, prof);
            }
            int yr = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
            EvolveArmEcosystem(yr, restoreMobileShareIfCrushed: true);
            IsaContractIntegration.DeduplicateCrossLicenseContracts();
        }

        public static void EvolveArmEcosystem(int year, bool restoreMobileShareIfCrushed = false)
        {
            var mgr = ArchitectureManager.Instance;
            if (mgr == null) return;

            var arm = mgr.GetArchitecture("ARM");
            if (arm != null)
            {
                var pArm = GetOrCreateProfile(arm);
                pArm.Paradigm = IsaParadigm.RISC;
                pArm.FocusIpc = 0.30f; pArm.FocusEfficiency = 0.48f; pArm.FocusClock = 0.22f;
                pArm.Features.UnionWith(BaselineArm32Features);
                foreach (var n in IsaTechTree.Nodes)
                    if (n.UnlockYear <= year && n.BitWidth < 64 && !n.UnlocksVliwParadigm && !IsFeatureBlockedForArchitecture(arm, pArm, n))
                        pArm.Features.Add(n.Id);
                pArm.Revision = Mathf.Clamp(1 + (year - 1985) / 4, 1, 8);
                SyncProfileToArchitecture(arm, pArm);
            }

            var arm64 = mgr.GetArchitecture("ARM64");
            if (arm64 == null && year >= 2011)
            {
                var pops = new List<float>(MarketHelper.SegmentCount);
                for (int i = 0; i < MarketHelper.SegmentCount; i++) pops.Add(0.02f);
                arm64 = SpawnArchitectureObject(
                    mgr, "ARM64", "ARM64", IsaParadigm.RISC, new Date(2011, 10),
                    new List<string>(), new Color32(106, 168, 97, 255), new Color32(82, 140, 74, 255),
                    0.01f, pops);
            }

            if (arm64 != null)
            {
                var p64 = GetOrCreateProfile(arm64);
                p64.Paradigm = IsaParadigm.RISC;
                p64.FocusIpc = 0.34f; p64.FocusEfficiency = 0.44f; p64.FocusClock = 0.22f;
                if (!p64.CompatibleIds.Contains("ARM")) p64.CompatibleIds.Add("ARM");
                p64.Features.UnionWith(BaselineArm64Features);
                foreach (var n in IsaTechTree.Nodes)
                    if (n.UnlockYear <= Math.Max(2011, year) && !n.UnlocksVliwParadigm && !IsFeatureBlockedForArchitecture(arm64, p64, n))
                        p64.Features.Add(n.Id);
                p64.Revision = Mathf.Clamp(1 + Math.Max(0, year - 2011) / 3, 1, 9);
                SyncProfileToArchitecture(arm64, p64);
            }

            if (restoreMobileShareIfCrushed && year >= 1994)
            {
                var targetArm = (year >= 2012 && arm64 != null) ? arm64 : arm;
                if (targetArm?.MarketData?.Popularities != null && targetArm.MarketData.Popularities.Count >= 7)
                {
                    float mobShare = (targetArm.MarketData.Popularities[4] + targetArm.MarketData.Popularities[5] + targetArm.MarketData.Popularities[6]) / 3f;
                    if (mobShare < 0.05f)
                    {
                        var avail = mgr.GetAvailableArchitectures();
                        for (int s = 4; s <= 6; s++)
                        {
                            targetArm.MarketData.Popularities[s] = 0.55f;
                            if (arm != null && targetArm == arm64 && s < arm.MarketData.Popularities.Count)
                                arm.MarketData.Popularities[s] = Mathf.Max(0.12f, arm.MarketData.Popularities[s]);
                            foreach (var other in avail)
                                if (other != null && !other.IsARM && other.UniqueID != "ARM64" && s < other.MarketData.Popularities.Count)
                                    other.MarketData.Popularities[s] *= 0.30f;
                        }
                        foreach (var a in avail) a?.MarketData?.ClampPopularities();
                    }
                }
            }
        }

        public static (float ipc, float power, float clock) CalculateStats(
            IsaParadigm paradigm, float wIpc, float wEff, float wClock,
            IEnumerable<string> features, bool hasLegacyCompatibility,
            float vanillaBaseIpc = 1f, float vanillaBasePower = 1f)
        {
            float sum = Mathf.Max(0.001f, wIpc + wEff + wClock);
            float dIpc = wIpc / sum - 0.333f;
            float dEff = wEff / sum - 0.333f;
            float dClk = wClock / sum - 0.333f;

            float paraIpc = paradigm == IsaParadigm.VLIW ? 0.97f : 0.91f;
            float paraPow = paradigm == IsaParadigm.RISC ? 0.90f : (paradigm == IsaParadigm.VLIW ? 1.05f : 1.00f);
            float paraClk = paradigm == IsaParadigm.VLIW ? 0.94f : (paradigm == IsaParadigm.RISC ? 1.02f : 0.95f);

            float baseIpc = Mathf.Lerp(1f, Mathf.Clamp(vanillaBaseIpc, 0.75f, 1.35f), 0.35f);
            float basePow = Mathf.Lerp(1f, Mathf.Clamp(vanillaBasePower, 0.70f, 1.35f), 0.35f);

            float triIpc = 1f + dIpc * 0.28f - dEff * 0.08f - dClk * 0.09f;
            float triPow = 1f - dEff * 0.32f + dIpc * 0.16f + dClk * 0.22f;
            float triClk = 1f + dClk * 0.28f - dIpc * 0.08f - dEff * 0.09f;

            float compatIpc = hasLegacyCompatibility ? 1.00f : 1.03f;
            float compatPow = hasLegacyCompatibility ? 1.01f : 0.97f;

            float sumIpc = 0f, sumPowPos = 0f, sumPowNeg = 0f, sumClk = 0f;
            if (features != null)
            {
                foreach (var fid in features)
                {
                    var n = IsaTechTree.Get(fid);
                    if (n == null) continue;
                    sumIpc += n.IpcBonus;
                    if (n.PowerDelta >= 0f) sumPowPos += n.PowerDelta;
                    else sumPowNeg += n.PowerDelta;
                    sumClk += n.ClockBonus;
                }
            }

            float featScale = DynamicIsaPlugin.FeatureStatScale?.Value ?? 1f;
            float effIpc = (sumIpc <= 0.32f ? sumIpc : 0.32f + (sumIpc - 0.32f) * 0.50f) * featScale;
            float effPow = (sumPowPos * 0.45f + sumPowNeg) * featScale;

            float finalIpc = Mathf.Clamp(baseIpc * paraIpc * triIpc * compatIpc * (1f + effIpc), 0.78f, 1.55f);
            float finalPow = Mathf.Clamp(basePow * paraPow * triPow * compatPow * Mathf.Clamp(1f + effPow, 0.65f, 1.28f), 0.58f, 1.38f);
            float finalClk = Mathf.Clamp(paraClk * triClk * Mathf.Clamp(1f + sumClk * 0.75f * featScale, 0.84f, 1.24f), 0.80f, 1.30f);
            return (finalIpc, finalPow, finalClk);
        }

        public static void RefreshAllProfileStats()
        {
            if (ArchitectureManager.Instance == null) return;
            foreach (var arch in ArchitectureManager.Instance.Architectures)
                if (arch != null) SyncProfileToArchitecture(arch, GetOrCreateProfile(arch));
        }

        public static (float desk, float srv, float mob, float ind) CalculateSegmentAppeals(IsaProfile profile, int currentYear)
        {
            if (profile == null) return (1f, 1f, 1f, 1f);
            if (!string.IsNullOrEmpty(profile.UniqueID) && profile.CachedAppealsYear == currentYear)
                return profile.CachedAppeals;

            float d = 0.96f + (profile.FocusIpc - 0.33f) * 0.20f + (profile.FocusClock - 0.33f) * 0.24f;
            float s = 0.96f + (profile.FocusIpc - 0.33f) * 0.30f + (profile.FocusEfficiency - 0.33f) * 0.14f;
            float m = 0.94f + (profile.FocusEfficiency - 0.33f) * 0.45f - (profile.FocusClock - 0.33f) * 0.14f;
            float i = 0.96f + (profile.FocusEfficiency - 0.33f) * 0.18f + (profile.FocusIpc - 0.33f) * 0.10f;

            if (profile.Paradigm == IsaParadigm.RISC) { m += 0.24f; i += 0.10f; }
            else if (profile.Paradigm == IsaParadigm.VLIW) { s += 0.10f; m -= 0.14f; }
            else { d += 0.10f; s += 0.06f; m -= 0.22f; }

            foreach (var fid in profile.Features)
            {
                var n = IsaTechTree.Get(fid);
                if (n == null) continue;
                d += n.DesktopAppeal; s += n.ServerAppeal; m += n.MobileAppeal; i += n.IndustrialAppeal;
            }

            if (profile.Paradigm == IsaParadigm.CISC) m *= 0.65f;
            int bitWidth = profile.MaxBitWidth;
            if (currentYear >= 1988 && bitWidth < 32) { d *= 0.65f; s *= 0.50f; }
            if (currentYear >= 2003 && bitWidth < 64)
            {
                float decay = Mathf.Clamp(1f - (currentYear - 2002) * 0.07f, 0.38f, 1f);
                d *= Mathf.Lerp(1f, 0.62f, 1f - decay);
                s *= decay;
            }
            if (currentYear >= 2013 && bitWidth < 64) m *= 0.72f;
            if (currentYear >= 2007 && !profile.HasFeature("isa_hw_virt")) s *= 0.72f;

            var res = (Mathf.Clamp(d, 0.35f, 1.80f), Mathf.Clamp(s, 0.35f, 1.85f), Mathf.Clamp(m, 0.30f, 1.85f), Mathf.Clamp(i, 0.45f, 1.75f));
            if (!string.IsNullOrEmpty(profile.UniqueID))
            {
                profile.CachedAppealsYear = currentYear;
                profile.CachedAppeals = res;
            }
            return res;
        }

        public static float GetClockMultiplier(Architecture arch) =>
            arch != null && !string.IsNullOrEmpty(arch.UniqueID) && Profiles.TryGetValue(arch.UniqueID, out var p) && p.CachedClockMult > 0f
                ? p.CachedClockMult : 1f;

        public static void SyncProfileToArchitecture(Architecture arch, IsaProfile profile)
        {
            if (arch == null || profile == null) return;
            profile.NormalizeWeights();
            var stats = CalculateStats(profile.Paradigm, profile.FocusIpc, profile.FocusEfficiency, profile.FocusClock,
                profile.Features, profile.CompatibleIds.Count > 0, profile.VanillaBaseIpc, profile.VanillaBasePower);

            profile.CachedClockMult = stats.clock;
            profile.CachedAppealsYear = -1;
            arch.IpcMultiplier = stats.ipc;
            arch.PowerConsumptionMultiplier = stats.power;
            arch.Royalties = profile.BaseRoyalty;
            arch.Type = profile.Paradigm == IsaParadigm.RISC ? IsaType.RISC : IsaType.CISC;

            if (profile.IsCustomCreated || arch.ProjectCost <= 0f)
            {
                int yr = Mathf.Max(1971, profile.CreatedYear);
                float eraScale = yr < 1985 ? 0.12f : (yr < 1995 ? 0.35f : (yr < 2005 ? 0.65f : 1.0f));
                int fc = profile.Features?.Count ?? 0;
                arch.ProjectCost = Mathf.Round((4_000_000f + fc * 2_500_000f) * eraScale);
                arch.ProjectTime = Mathf.Clamp(20 + fc * 2, 20, 50);
            }

            if (arch.CompatibleArchitectures == null) arch.CompatibleArchitectures = new List<Architecture>();
            arch.CompatibleArchitectures.Clear();
            if (ArchitectureManager.Instance != null)
            {
                foreach (var cid in profile.CompatibleIds)
                {
                    var target = ArchitectureManager.Instance.GetArchitecture(cid);
                    if (target != null && target != arch && !arch.CompatibleArchitectures.Contains(target))
                        arch.CompatibleArchitectures.Add(target);
                }
            }
        }

        public static void ApplyFeatureToArchitecture(Architecture arch, string techId)
        {
            if (arch == null || string.IsNullOrEmpty(techId)) return;
            var prof = GetOrCreateProfile(arch);
            var node = IsaTechTree.Get(techId);
            if (node != null && IsFeatureBlockedForArchitecture(arch, prof, node)) return;
            if (prof.Features.Add(techId)) SyncProfileToArchitecture(arch, prof);
        }

        public static IsaProfile GetOrCreateProfile(Architecture arch)
        {
            if (arch == null) return null;
            string uid = string.IsNullOrEmpty(arch.UniqueID) ? arch.Name : arch.UniqueID;
            if (Profiles.TryGetValue(uid, out var existing)) return existing;

            var prof = BuildDefaultProfileForVanilla(arch, uid);
            Profiles[uid] = prof;
            SyncProfileToArchitecture(arch, prof);
            return prof;
        }

        private static IsaProfile BuildDefaultProfileForVanilla(Architecture arch, string uid)
        {
            bool isArm = arch.IsARM || uid.StartsWith("ARM", StringComparison.OrdinalIgnoreCase);
            bool isArm64 = uid.Equals("ARM64", StringComparison.OrdinalIgnoreCase);
            bool isX86 = uid.Equals("x86", StringComparison.OrdinalIgnoreCase);
            bool isX64 = uid.Equals("x86-64", StringComparison.OrdinalIgnoreCase);
            bool isIA64 = uid.Equals("IA-64", StringComparison.OrdinalIgnoreCase);
            bool isRisc = arch.Type == IsaType.RISC || isArm;
            var para = isIA64 ? IsaParadigm.VLIW : (isRisc ? IsaParadigm.RISC : IsaParadigm.CISC);
            var vb = GetTrueVanillaBaseline(uid, para);

            var p = new IsaProfile
            {
                UniqueID = uid, Name = arch.Name, Paradigm = para,
                CreatorCompanyID = arch.OwnerIDs != null && arch.OwnerIDs.Count > 0 ? arch.OwnerIDs[0] : "",
                CreatedYear = arch.ReleaseDate != null ? arch.ReleaseDate.Year : 1971,
                CreatedMonth = arch.ReleaseDate != null ? arch.ReleaseDate.Month : 1,
                VanillaBaseIpc = vb.ipc, VanillaBasePower = vb.pow,
                BaseRoyalty = arch.Royalties, DarkColor = arch.DarkModeColor, LightColor = arch.LightModeColor,
                IsCustomCreated = false, IsProprietary = isIA64
            };

            if (isIA64)
            {
                p.FocusIpc = 0.56f; p.FocusEfficiency = 0.22f; p.FocusClock = 0.22f;
                p.Features.UnionWith(new[] { "isa_microcode", "isa_pipelining", "isa_superscalar", "isa_vliw_epic", "isa_64bit_clean", "isa_fpu" });
            }
            else if (isX64)
            {
                p.CompatibleIds.Add("x86");
                p.Features.UnionWith(BaselineX64Features);
            }
            else if (isX86)
            {
                p.Features.UnionWith(new[] { "isa_microcode", "isa_16bit", "isa_pipelining" });
            }
            else if (isArm64)
            {
                p.FocusIpc = 0.34f; p.FocusEfficiency = 0.44f; p.FocusClock = 0.22f;
                p.CompatibleIds.Add("ARM");
                p.Features.UnionWith(BaselineArm64Features);
            }
            else if (isArm || isRisc)
            {
                p.FocusIpc = 0.30f; p.FocusEfficiency = 0.48f; p.FocusClock = 0.22f;
                p.Features.UnionWith(BaselineArm32Features);
                if (p.CreatedYear >= 1990) p.Features.Add("isa_clock_gating");
            }
            else
            {
                p.Features.Add("isa_microcode");
            }

            if (arch.CompatibleArchitectures != null)
            {
                foreach (var c in arch.CompatibleArchitectures)
                    if (c != null && !string.IsNullOrEmpty(c.UniqueID) && !p.CompatibleIds.Contains(c.UniqueID))
                        p.CompatibleIds.Add(c.UniqueID);
            }
            return p;
        }

        public static CompanyIsaResearchState GetCompanyResearch(ICompany company)
        {
            if (company == null) return null;
            string cid = string.IsNullOrEmpty(company.UniqueID) ? $"SAVE_{company.SaveID}" : company.UniqueID;
            if (!CompanyResearch.TryGetValue(cid, out var state))
            {
                state = new CompanyIsaResearchState { CompanyID = cid, Funding = 1f };
                int year = DateController.Instance != null ? DateController.Instance.CurrentDate.Year : 1971;
                foreach (var n in IsaTechTree.Nodes)
                {
                    if (year >= n.UnlockYear + 6 && state.AreDependenciesMet(n))
                    {
                        state.UnlockedFeatures.Add(n.Id);
                        state.Progress[n.Id] = 1f;
                    }
                }
                CompanyResearch[cid] = state;
            }
            return state;
        }

        public static bool CanCompanyUseArchitecture(ICompany company, Architecture arch, out float effectiveRoyalty) =>
            CanCompanyUseArchitectureCore(company, arch, false, out _, out effectiveRoyalty);

        public static bool CanCompanyUseArchitecture(ICompany company, Architecture arch, out string statusLabel, out float effectiveRoyalty) =>
            CanCompanyUseArchitectureCore(company, arch, true, out statusLabel, out effectiveRoyalty);

        private static bool CanCompanyUseArchitectureCore(ICompany company, Architecture arch, bool buildLabel, out string statusLabel, out float effectiveRoyalty)
        {
            effectiveRoyalty = arch != null ? arch.Royalties : 0f;
            statusLabel = buildLabel ? "Open" : null;
            if (company == null || arch == null) return false;

            if (arch.OwnerIDs != null && arch.OwnerIDs.Contains(company.UniqueID))
            {
                effectiveRoyalty = 0f;
                if (buildLabel) statusLabel = arch.OwnerIDs.Count > 1 ? "Co-Owner" : "Owned";
                return true;
            }

            if (ContractMeta.Count > 0)
            {
                var license = FindActiveIsaContract(company, arch.UniqueID, ContractIdLicense);
                if (license != null)
                {
                    effectiveRoyalty = GetContractRoyalty(license);
                    if (buildLabel) statusLabel = $"Licensed {effectiveRoyalty * 100f:0.#}%";
                    return true;
                }
            }

            if (arch.IsARM)
            {
                if (buildLabel) statusLabel = $"Leg Holdings {effectiveRoyalty * 100f:0.#}%";
                return true;
            }

            var prof = GetOrCreateProfile(arch);
            if (prof != null && prof.IsProprietary && arch.OwnerIDs != null && arch.OwnerIDs.Count > 0)
            {
                if (buildLabel) statusLabel = "Cross-License Req.";
                return false;
            }

            if (arch.OwnerIDs == null || arch.OwnerIDs.Count == 0)
            {
                effectiveRoyalty = 0f;
                if (buildLabel) statusLabel = "Open Domain";
                return true;
            }

            if (buildLabel) statusLabel = $"Open {effectiveRoyalty * 100f:0.#}%";
            return true;
        }

        public static BusinessContract FindActiveIsaContract(ICompany client, string archUid, int contractTypeId)
        {
            if (ContractMeta.Count == 0 || BusinessContractManager.Instance == null || client == null || string.IsNullOrEmpty(archUid))
                return null;
            var signed = BusinessContractManager.Instance.GetSignedContracts(client);
            if (signed == null) return null;

            foreach (var c in signed)
            {
                if (c == null || c.ContractID != contractTypeId || (c.Client != client && c.Provider != client)) continue;
                var meta = FindMetaForContract(c);
                if (meta != null && meta.ArchitectureID == archUid)
                {
                    if (contractTypeId == ContractIdLicense && c.Client != client) continue;
                    return c;
                }
            }
            return null;
        }

        public static IsaContractMetadata FindMetaForContract(BusinessContract c)
        {
            if (c == null) return null;
            int hashArch = c.ContractValues != null && c.ContractValues.Count >= 4 ? c.ContractValues[3] : 0;
            for (int i = 0; i < ContractMeta.Count; i++)
            {
                var m = ContractMeta[i];
                if (m.ContractType == c.ContractID && m.ProviderID == c.ProviderID && m.ClientID == c.ClientID &&
                    m.StartYear == c.StartDate.Year && m.StartMonth == c.StartDate.Month &&
                    (hashArch == 0 || m.ArchitectureID.GetHashCode() == hashArch))
                    return m;
            }
            return null;
        }

        public static float GetContractRoyalty(BusinessContract c) =>
            FindMetaForContract(c)?.RoyaltyRate ?? (c?.MonetaryValues != null && c.MonetaryValues.Count > 0 ? c.MonetaryValues[0] : 0.05f);

        internal static Architecture SpawnArchitectureObject(
            ArchitectureManager mgr, string uid, string name, IsaParadigm paradigm, Date relDate,
            List<string> owners, Color32 darkCol, Color32 lightCol, float royalty, List<float> initialPops)
        {
            var go = new GameObject($"DynamicISA_{uid}");
            go.transform.SetParent(mgr.transform, false);
            var arch = go.AddComponent<Architecture>();
            arch.UniqueID = uid;
            arch.Name = name;
            arch.Type = paradigm == IsaParadigm.RISC ? IsaType.RISC : IsaType.CISC;
            arch.ReleaseDate = relDate;
            arch.OwnerIDs = owners ?? new List<string>();
            arch.CompatibleArchitectures = new List<Architecture>();
            arch.DarkModeColor = darkCol;
            arch.LightModeColor = lightCol;
            arch.Royalties = royalty;
            arch.MarketData = new ArchitectureMarketData();
            arch.MarketData.Initialize(arch);

            if (initialPops != null && initialPops.Count == MarketHelper.SegmentCount)
            {
                arch.MarketData.Popularities = initialPops;
            }
            else
            {
                var pops = new List<float>(MarketHelper.SegmentCount);
                for (int i = 0; i < MarketHelper.SegmentCount; i++) pops.Add(0.01f);
                arch.MarketData.Popularities = pops;
            }

            mgr.Architectures.Add(arch);
            return arch;
        }

        public static Architecture CreateOrUpdateCustomArchitecture(
            string existingUid, string name, IsaParadigm paradigm, ICompany creator,
            float wIpc, float wEff, float wClock, IEnumerable<string> features, IEnumerable<string> compatibleIds,
            bool isProprietary, float royaltyRate, bool triggerEventPopup)
        {
            var mgr = ArchitectureManager.Instance;
            if (mgr == null || creator == null) return null;

            bool isNew = string.IsNullOrEmpty(existingUid) || mgr.GetArchitecture(existingUid) == null;
            Architecture arch;
            IsaProfile profile;

            if (isNew)
            {
                string cleanUid = string.IsNullOrEmpty(existingUid) ? BuildUniqueId(name) : existingUid;
                var curDate = DateController.Instance != null ? DateController.Instance.CurrentDate : new DateTime(1971, 1, 1);
                GenerateDistinctColors(cleanUid, out var darkCol, out var lightCol);

                arch = SpawnArchitectureObject(
                    mgr, cleanUid, name, paradigm, new Date(curDate.Year, curDate.Month),
                    new List<string> { creator.UniqueID }, darkCol, lightCol, royaltyRate, null);

                profile = new IsaProfile
                {
                    UniqueID = cleanUid, Name = name, Paradigm = paradigm, CreatorCompanyID = creator.UniqueID,
                    CreatedYear = curDate.Year, CreatedMonth = curDate.Month, Revision = 1,
                    DarkColor = darkCol, LightColor = lightCol, IsCustomCreated = true
                };
                Profiles[cleanUid] = profile;
            }
            else
            {
                arch = mgr.GetArchitecture(existingUid);
                profile = GetOrCreateProfile(arch);
                if (!string.IsNullOrEmpty(name)) { arch.Name = name; profile.Name = name; }
                profile.Revision++;
                profile.Paradigm = paradigm;
            }

            profile.FocusIpc = wIpc; profile.FocusEfficiency = wEff; profile.FocusClock = wClock;
            profile.NormalizeWeights();
            profile.Features = new HashSet<string>(features ?? Array.Empty<string>());
            profile.CompatibleIds = compatibleIds != null
                ? compatibleIds.Where(id => !string.IsNullOrEmpty(id) && id != arch.UniqueID).Distinct().ToList()
                : new List<string>();
            profile.IsProprietary = isProprietary;
            profile.BaseRoyalty = Mathf.Clamp(royaltyRate, 0f, 0.25f);
            SyncProfileToArchitecture(arch, profile);

            if (isNew && profile.CompatibleIds.Count > 0 && Market.Instance != null)
            {
                for (int i = 0; i < MarketHelper.SegmentCount; i++)
                {
                    float inherited = 0f;
                    foreach (var cid in profile.CompatibleIds)
                    {
                        var parent = mgr.GetArchitecture(cid);
                        if (parent?.MarketData?.Popularities != null && i < parent.MarketData.Popularities.Count)
                            inherited = Mathf.Max(inherited, parent.MarketData.Popularities[i] * 0.22f);
                    }
                    arch.MarketData.Popularities[i] = Mathf.Clamp(0.02f + inherited, 0.01f, 0.35f);
                }
                arch.MarketData.ClampPopularities();
            }

            if (Market.Instance != null)
            {
                var list = MarketAvailArchF?.GetValue(Market.Instance) as List<Architecture>;
                if (list != null && !list.Contains(arch)) list.Add(arch);
            }

            if (triggerEventPopup && isNew && DateController.Instance != null && !DateController.Instance.IsFastFowardSimulating
                && (GameManager.Instance == null || !GameManager.Instance.IsLoading))
            {
                UnityEngine.Object.FindFirstObjectByType<ArchitectureEventWindow>()?.HandleRelease(arch);
            }
            return arch;
        }

        private static string BuildUniqueId(string name)
        {
            string slug = new string((name ?? "ISA").Where(c => char.IsLetterOrDigit(c) || c == '-' || c == '_').ToArray());
            if (string.IsNullOrEmpty(slug)) slug = "CustomISA";
            string candidate = slug;
            int n = 2;
            while (ArchitectureManager.Instance.GetArchitecture(candidate) != null) candidate = $"{slug}_{n++}";
            return candidate;
        }

        public static void GenerateDistinctColors(string uid, out Color32 dark, out Color32 light)
        {
            if (uid == "IA-64") { dark = new Color32(215, 72, 102, 255); light = new Color32(190, 48, 82, 255); return; }
            float hue = ((uint)(uid ?? "ISA").GetHashCode() % 360u) / 360f;
            dark = Color.HSVToRGB(hue, 0.68f, 0.88f);
            light = Color.HSVToRGB(hue, 0.78f, 0.70f);
        }

        public static void ClearAllRuntimeState()
        {
            var mgr = ArchitectureManager.Instance;
            if (mgr != null)
            {
                for (int i = mgr.Architectures.Count - 1; i >= 0; i--)
                {
                    var a = mgr.Architectures[i];
                    if (a != null && Profiles.TryGetValue(a.UniqueID, out var p) && p.IsCustomCreated)
                    {
                        mgr.Architectures.RemoveAt(i);
                        UnityEngine.Object.Destroy(a.gameObject);
                    }
                }
            }
            Profiles.Clear();
            CompanyResearch.Clear();
            ContractMeta.Clear();
        }

        public static void EnsureFallbackArchitectureExists(string uid)
        {
            var mgr = ArchitectureManager.Instance;
            if (string.IsNullOrEmpty(uid) || mgr == null || mgr.GetArchitecture(uid) != null) return;

            GenerateDistinctColors(uid, out var dCol, out var lCol);
            var pops = new List<float>(MarketHelper.SegmentCount);
            for (int i = 0; i < MarketHelper.SegmentCount; i++) pops.Add(0.05f);
            var arch = SpawnArchitectureObject(
                mgr, uid, uid == "IA-64" ? "Inlet 64 (IA-64)" : uid,
                uid.StartsWith("ARM", StringComparison.OrdinalIgnoreCase) ? IsaParadigm.RISC : IsaParadigm.CISC,
                new Date(1971, 1), new List<string> { "PLAYER" }, dCol, lCol, 0.05f, pops);
            GetOrCreateProfile(arch);
        }
    }
}
