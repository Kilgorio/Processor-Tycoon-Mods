using System;
using System.Collections.Generic;
using ProcessorTycoon;
using ProcessorTycoon.UI;
using ProcessorTycoon.UI.Themes;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DynamicISA
{
    internal static class RectTransformExt
    {
        public static RectTransform SetAnchorStretch(this RectTransform rt, float minX, float minY, float maxX, float maxY,
            float ox0 = 0f, float oy0 = 0f, float ox1 = 0f, float oy1 = 0f)
        {
            if (rt == null) return null;
            rt.anchorMin = new Vector2(minX, minY);
            rt.anchorMax = new Vector2(maxX, maxY);
            rt.offsetMin = new Vector2(ox0, oy0);
            rt.offsetMax = new Vector2(ox1, oy1);
            return rt;
        }

        public static RectTransform SetTopAnchored(this RectTransform rt, float y, float height, float widthDelta = -20f)
        {
            if (rt == null) return null;
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, y);
            rt.sizeDelta = new Vector2(widthDelta, height);
            return rt;
        }
    }

    public static class IsaUiHelper
    {
        private static TMP_FontAsset _cachedFont;
        private static Sprite _cachedRoundedSprite;
        private static TMP_Dropdown _cachedDropdownSrc;

        public static bool IsDark => ThemeManager.Instance == null || ThemeManager.Instance.CurrentThemeIsDark;
        public static Color PanelBg => IsDark ? new Color(0.145f, 0.153f, 0.165f, 0.99f) : new Color(0.93f, 0.94f, 0.96f, 0.99f);
        public static Color CardBg => IsDark ? new Color(0.195f, 0.204f, 0.220f, 1f) : new Color(0.86f, 0.88f, 0.91f, 1f);
        public static Color CardAltBg => IsDark ? new Color(0.172f, 0.180f, 0.194f, 1f) : new Color(0.89f, 0.90f, 0.93f, 1f);
        public static Color HeaderBg => IsDark ? new Color(0.118f, 0.125f, 0.137f, 1f) : new Color(0.82f, 0.84f, 0.88f, 1f);
        public static Color BorderCol => IsDark ? new Color(0.28f, 0.30f, 0.33f, 1f) : new Color(0.68f, 0.71f, 0.76f, 1f);
        public static Color AccentBlue => new Color(0.22f, 0.52f, 0.82f, 1f);
        public static Color AccentGreen => new Color(0.20f, 0.66f, 0.38f, 1f);
        public static Color AccentRed => new Color(0.78f, 0.25f, 0.27f, 1f);
        public static Color AccentAmber => new Color(0.85f, 0.58f, 0.18f, 1f);
        public static Color TextPrimary => IsDark ? new Color(0.92f, 0.93f, 0.95f, 1f) : new Color(0.12f, 0.14f, 0.17f, 1f);
        public static Color TextMuted => IsDark ? new Color(0.64f, 0.67f, 0.72f, 1f) : new Color(0.38f, 0.42f, 0.48f, 1f);

        public static TMP_FontAsset GetGameFont()
        {
            if (_cachedFont != null) return _cachedFont;
            foreach (var t in UnityEngine.Object.FindObjectsByType<TMP_Text>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                if (t != null && t.font != null) return _cachedFont = t.font;
            return TMP_Settings.defaultFontAsset;
        }

        public static Sprite GetRoundedSprite()
        {
            if (_cachedRoundedSprite != null) return _cachedRoundedSprite;
            const int s = 32;
            const float r = 6f;
            var tex = new Texture2D(s, s, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear,
                hideFlags = HideFlags.HideAndDontSave
            };
            var px = new Color32[s * s];
            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float dx = Math.Max(0f, Math.Max(r - x - 0.5f, x + 0.5f - (s - r)));
                    float dy = Math.Max(0f, Math.Max(r - y - 0.5f, y + 0.5f - (s - r)));
                    byte a = (byte)Mathf.RoundToInt(Mathf.Clamp01(r - Mathf.Sqrt(dx * dx + dy * dy) + 0.5f) * 255f);
                    px[y * s + x] = new Color32(255, 255, 255, a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            _cachedRoundedSprite = Sprite.Create(tex, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(8, 8, 8, 8));
            _cachedRoundedSprite.hideFlags = HideFlags.HideAndDontSave;
            return _cachedRoundedSprite;
        }

        public static GameObject CreatePanel(string name, Transform parent, Color color, bool rounded = true)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.color = color;
            if (rounded)
            {
                img.sprite = GetRoundedSprite();
                img.type = Image.Type.Sliced;
            }
            return go;
        }

        public static TMP_Text CreateText(string name, Transform parent, string text, float size, TextAlignmentOptions align = TextAlignmentOptions.Left, Color? col = null, FontStyles style = FontStyles.Normal)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            var tmp = go.GetComponent<TextMeshProUGUI>();
            var font = GetGameFont();
            if (font != null) tmp.font = font;
            tmp.text = text;
            tmp.fontSize = size;
            tmp.alignment = align;
            tmp.color = col ?? TextPrimary;
            tmp.fontStyle = style;
            tmp.textWrappingMode = TextWrappingModes.Normal;
            return tmp;
        }

        public static Button CreateButton(string name, Transform parent, string label, Color bgColor, float fontSize = 14f, Action onClick = null)
        {
            var go = CreatePanel(name, parent, bgColor, true);
            var btn = go.AddComponent<Button>();
            var cb = btn.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1.12f, 1.12f, 1.12f, 1f);
            cb.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.6f);
            btn.colors = cb;

            var txt = CreateText("Label", go.transform, label, fontSize, TextAlignmentOptions.Center, Color.white);
            txt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 6f, 2f, -6f, -2f);
            if (onClick != null) btn.onClick.AddListener(() => onClick());
            return btn;
        }

        public static Toggle CreateCheckbox(string name, Transform parent, string label, float fontSize = 13f, Action<bool> onChanged = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Toggle));
            go.transform.SetParent(parent, false);
            var toggle = go.GetComponent<Toggle>();

            var boxGo = CreatePanel("Box", go.transform, IsDark ? new Color(0.11f, 0.12f, 0.13f, 1f) : new Color(0.76f, 0.78f, 0.82f, 1f), true);
            var boxRt = boxGo.GetComponent<RectTransform>();
            boxRt.anchorMin = boxRt.anchorMax = new Vector2(0f, 0.5f);
            boxRt.pivot = new Vector2(0f, 0.5f);
            boxRt.anchoredPosition = new Vector2(2f, 0f);
            boxRt.sizeDelta = new Vector2(18f, 18f);

            var checkGo = CreatePanel("Check", boxGo.transform, AccentBlue, true);
            checkGo.GetComponent<RectTransform>().SetAnchorStretch(0.18f, 0.18f, 0.82f, 0.82f);

            var txt = CreateText("Label", go.transform, label, fontSize, TextAlignmentOptions.Left, TextPrimary);
            txt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 26f, 0f, -2f, 0f);

            toggle.targetGraphic = boxGo.GetComponent<Image>();
            toggle.graphic = checkGo.GetComponent<Image>();
            if (onChanged != null) toggle.onValueChanged.AddListener(v => onChanged(v));
            return toggle;
        }

        public static Slider CreateSlider(string name, Transform parent, float min, float max, bool wholeNumbers, Action<float> onChanged = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Slider));
            go.transform.SetParent(parent, false);
            var slider = go.GetComponent<Slider>();
            slider.minValue = min;
            slider.maxValue = max;
            slider.wholeNumbers = wholeNumbers;

            var bg = CreatePanel("Background", go.transform, IsDark ? new Color(0.11f, 0.12f, 0.13f, 1f) : new Color(0.75f, 0.77f, 0.80f, 1f), true);
            var bgRt = bg.GetComponent<RectTransform>();
            bgRt.anchorMin = new Vector2(0f, 0.5f);
            bgRt.anchorMax = new Vector2(1f, 0.5f);
            bgRt.sizeDelta = new Vector2(0f, 6f);

            var fillArea = new GameObject("Fill Area", typeof(RectTransform));
            fillArea.transform.SetParent(go.transform, false);
            var faRt = fillArea.GetComponent<RectTransform>();
            faRt.anchorMin = new Vector2(0f, 0.5f);
            faRt.anchorMax = new Vector2(1f, 0.5f);
            faRt.sizeDelta = new Vector2(0f, 6f);

            var fill = CreatePanel("Fill", fillArea.transform, AccentBlue, true);
            slider.fillRect = fill.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);

            var handleArea = new GameObject("Handle Slide Area", typeof(RectTransform));
            handleArea.transform.SetParent(go.transform, false);
            var haRt = handleArea.GetComponent<RectTransform>();
            haRt.anchorMin = new Vector2(0f, 0.5f);
            haRt.anchorMax = new Vector2(1f, 0.5f);
            haRt.pivot = new Vector2(0.5f, 0.5f);
            haRt.anchoredPosition = Vector2.zero;
            haRt.sizeDelta = new Vector2(-14f, 0f);

            var handle = CreatePanel("Handle", handleArea.transform, Color.white, true);
            var hRt = handle.GetComponent<RectTransform>();
            hRt.anchorMin = hRt.anchorMax = hRt.pivot = new Vector2(0.5f, 0.5f);
            hRt.sizeDelta = new Vector2(14f, 14f);
            slider.handleRect = hRt;
            slider.targetGraphic = handle.GetComponent<Image>();

            if (onChanged != null) slider.onValueChanged.AddListener(v => onChanged(v));
            return slider;
        }

        public static TMP_InputField CreateInputField(string name, Transform parent, string placeholderText, float fontSize = 14f)
        {
            var go = CreatePanel(name, parent, IsDark ? new Color(0.11f, 0.12f, 0.13f, 1f) : Color.white, true);
            go.SetActive(false);

            var outline = go.AddComponent<Outline>();
            outline.effectColor = BorderCol;
            outline.effectDistance = new Vector2(1f, -1f);

            var textArea = new GameObject("Text Area", typeof(RectTransform), typeof(RectMask2D));
            textArea.transform.SetParent(go.transform, false);
            var taRt = textArea.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 8f, 4f, -8f, -4f);

            var placeholder = CreateText("Placeholder", textArea.transform, placeholderText, fontSize, TextAlignmentOptions.Left, TextMuted, FontStyles.Italic);
            placeholder.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            placeholder.raycastTarget = false;

            var txt = CreateText("Text", textArea.transform, "", fontSize, TextAlignmentOptions.Left, TextPrimary);
            txt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            txt.textWrappingMode = TextWrappingModes.NoWrap;
            txt.raycastTarget = false;

            var input = go.AddComponent<TMP_InputField>();
            input.targetGraphic = go.GetComponent<Image>();
            input.textViewport = taRt;
            input.textComponent = txt;
            input.placeholder = placeholder;
            input.fontAsset = GetGameFont();
            input.pointSize = fontSize;
            input.characterLimit = 22;
            input.text = "";

            go.SetActive(true);
            return input;
        }

        public static void SetDropdownOptions(TMP_Dropdown dd, List<string> options, int selectedIndex = 0)
        {
            if (dd == null) return;
            dd.ClearOptions();
            if (options != null && options.Count > 0)
            {
                dd.AddOptions(options);
                int idx = Mathf.Clamp(selectedIndex, 0, options.Count - 1);
                dd.SetValueWithoutNotify(idx);
                dd.RefreshShownValue();
                if (dd.captionText != null)
                {
                    dd.captionText.text = options[idx];
                    dd.captionText.color = TextPrimary;
                    dd.captionText.gameObject.SetActive(true);
                }
            }
            else if (dd.captionText != null)
            {
                dd.captionText.text = "";
            }
        }

        private static TMP_Dropdown FindDropdownSource()
        {
            if (_cachedDropdownSrc != null) return _cachedDropdownSrc;
            foreach (var candidate in UnityEngine.Object.FindObjectsByType<DropdownUI>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                var td = candidate != null ? candidate.GetComponent<TMP_Dropdown>() : null;
                if (td != null && td.template != null && td.captionText != null && td.itemText != null)
                {
                    _cachedDropdownSrc = td;
                    if (!candidate.gameObject.activeInHierarchy) break;
                }
            }
            return _cachedDropdownSrc;
        }

        public static TMP_Dropdown CloneNativeDropdown(string name, Transform parent)
        {
            var srcTmp = FindDropdownSource();
            if (srcTmp != null)
            {
                var go = UnityEngine.Object.Instantiate(srcTmp.gameObject, parent, false);
                go.name = name;

                if (ThemeManager.Instance?.CurrentTheme != null)
                    go.GetComponent<ThemeableDropdown>()?.ApplyTheme(ThemeManager.Instance.CurrentTheme);

                if (go.GetComponent<DropdownUI>() is DropdownUI ddUi) UnityEngine.Object.DestroyImmediate(ddUi);
                if (go.GetComponent<ButtonUIState>() is ButtonUIState btnState) UnityEngine.Object.DestroyImmediate(btnState);
                if (go.GetComponent<ThemeableDropdown>() is ThemeableDropdown thDd) UnityEngine.Object.DestroyImmediate(thDd);

                var clonedDd = go.GetComponent<TMP_Dropdown>();
                clonedDd.onValueChanged = new TMP_Dropdown.DropdownEvent();

                var leftoverList = go.transform.Find("Dropdown List");
                if (leftoverList != null) UnityEngine.Object.DestroyImmediate(leftoverList.gameObject);

                foreach (var t in go.GetComponentsInChildren<TMP_Text>(true))
                {
                    if (t == null || t == clonedDd.captionText || t == clonedDd.itemText) continue;
                    if (clonedDd.template != null && t.transform.IsChildOf(clonedDd.template)) continue;
                    if (t.gameObject != go) UnityEngine.Object.DestroyImmediate(t.gameObject);
                    else t.text = "";
                }

                if (clonedDd.captionText == null || !clonedDd.captionText.transform.IsChildOf(go.transform))
                    clonedDd.captionText = CreateText("Label", go.transform, "", 13f, TextAlignmentOptions.Left, TextPrimary);

                if (clonedDd.captionText != null)
                {
                    if (clonedDd.captionText.GetComponent<ThemeableText>() is ThemeableText thTxt)
                        UnityEngine.Object.DestroyImmediate(thTxt);
                    clonedDd.captionText.gameObject.SetActive(true);
                    clonedDd.captionText.text = "";
                    clonedDd.captionText.fontSize = 13f;
                    clonedDd.captionText.color = TextPrimary;
                    clonedDd.captionText.alignment = TextAlignmentOptions.Left;
                    clonedDd.captionText.textWrappingMode = TextWrappingModes.NoWrap;
                    clonedDd.captionText.overflowMode = TextOverflowModes.Ellipsis;
                    clonedDd.captionText.raycastTarget = false;
                    clonedDd.captionText.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 10f, 2f, -26f, -2f);
                }

                if (clonedDd.itemText != null)
                {
                    clonedDd.itemText.color = TextPrimary;
                    clonedDd.itemText.textWrappingMode = TextWrappingModes.NoWrap;
                    clonedDd.itemText.overflowMode = TextOverflowModes.Ellipsis;
                    if (clonedDd.itemText.transform.parent is RectTransform itemTr)
                    {
                        itemTr.sizeDelta = new Vector2(itemTr.sizeDelta.x, Mathf.Max(28f, itemTr.sizeDelta.y));
                        if (itemTr.parent is RectTransform ctTr)
                            ctTr.sizeDelta = new Vector2(ctTr.sizeDelta.x, Mathf.Max(28f, ctTr.sizeDelta.y));
                    }
                }

                if (clonedDd.template != null)
                {
                    clonedDd.template.sizeDelta = new Vector2(clonedDd.template.sizeDelta.x, Mathf.Clamp(Mathf.Max(140f, clonedDd.template.sizeDelta.y), 140f, 200f));
                    clonedDd.template.gameObject.SetActive(false);
                }

                if (clonedDd.targetGraphic != null) clonedDd.targetGraphic.raycastTarget = true;
                clonedDd.interactable = true;
                go.SetActive(true);
                return clonedDd;
            }

            // Self-contained fallback TMP_Dropdown
            var fbGo = CreatePanel(name, parent, CardBg, true);
            var caption = CreateText("Label", fbGo.transform, "", 13f, TextAlignmentOptions.Left, TextPrimary);
            caption.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 10f, 2f, -24f, -2f);

            var tmpl = CreatePanel("Template", fbGo.transform, PanelBg, true);
            var tmplRt = tmpl.GetComponent<RectTransform>();
            tmplRt.anchorMin = new Vector2(0f, 0f); tmplRt.anchorMax = new Vector2(1f, 0f);
            tmplRt.pivot = new Vector2(0.5f, 1f); tmplRt.sizeDelta = new Vector2(0f, 140f);
            var viewport = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D));
            viewport.transform.SetParent(tmpl.transform, false);
            var vpRt = viewport.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            var content = new GameObject("Content", typeof(RectTransform));
            content.transform.SetParent(viewport.transform, false);
            var ctRt = content.GetComponent<RectTransform>().SetTopAnchored(0f, 28f, 0f);
            var sr = tmpl.AddComponent<ScrollRect>();
            sr.viewport = vpRt; sr.content = ctRt; sr.horizontal = false;

            var itemGo = new GameObject("Item", typeof(RectTransform), typeof(Toggle));
            itemGo.transform.SetParent(content.transform, false);
            itemGo.GetComponent<RectTransform>().SetTopAnchored(0f, 28f, 0f);
            var itemBg = CreatePanel("Item Background", itemGo.transform, CardBg, false);
            itemBg.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f);
            var itemTxt = CreateText("Item Label", itemGo.transform, "Option", 12.5f, TextAlignmentOptions.Left, TextPrimary);
            itemTxt.GetComponent<RectTransform>().SetAnchorStretch(0f, 0f, 1f, 1f, 10f, 2f, -10f, -2f);
            var itemToggle = itemGo.GetComponent<Toggle>();
            itemToggle.targetGraphic = itemBg.GetComponent<Image>();

            tmpl.SetActive(false);
            var dd = fbGo.AddComponent<TMP_Dropdown>();
            dd.targetGraphic = fbGo.GetComponent<Image>();
            dd.template = tmplRt;
            dd.captionText = caption;
            dd.itemText = itemTxt;
            return dd;
        }

        public static string FormatMoneyShort(float amount) => StringFormatter.FloatToMoney(amount) ?? $"${amount:N0}";

        public static string FormatMoneyCompact(float amount) =>
            amount >= 1e9f ? $"${amount / 1e9f:0.#}B" :
            amount >= 1e6f ? $"${amount / 1e6f:0.#}M" :
            amount >= 1e3f ? $"${amount / 1e3f:0.#}K" : $"${amount:0}";
    }
}
