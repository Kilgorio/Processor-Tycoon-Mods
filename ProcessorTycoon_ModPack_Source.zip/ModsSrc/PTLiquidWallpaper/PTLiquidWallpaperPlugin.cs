using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using ProcessorTycoon.Desktop.Customization;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace PTLiquidWallpaper
{
    public enum LiquidPreset
    {
        Custom,
        Cobalt,
        Cyan,
        Cyberpunk,
        Emerald,
        Sunset,
        Rainbow
    }

    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class PTLiquidWallpaperPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.processortycoon.liquidwallpaper";
        public const string PluginName = "PT Liquid Desktop Wallpaper";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log;
        internal static PTLiquidWallpaperPlugin Instance;

        internal static ConfigEntry<bool> Enabled;
        internal static ConfigEntry<LiquidPreset> Preset;
        internal static ConfigEntry<bool> ReactThroughWindows;
        internal static ConfigEntry<bool> AmbientSwirl;
        internal static ConfigEntry<float> Opacity;

        internal static ConfigEntry<float> Force;
        internal static ConfigEntry<float> Radius;
        internal static ConfigEntry<float> Curl;
        internal static ConfigEntry<float> Intensity;
        internal static ConfigEntry<float> DensityDissipation;
        internal static ConfigEntry<float> VelocityDissipation;
        internal static ConfigEntry<float> Pressure;
        internal static ConfigEntry<int> PressureIterations;

        internal static ConfigEntry<float> ColorR;
        internal static ConfigEntry<float> ColorG;
        internal static ConfigEntry<float> ColorB;
        internal static ConfigEntry<bool> Rainbow;
        internal static ConfigEntry<int> SimWidth;
        internal static ConfigEntry<int> TargetFps;

        internal static readonly FieldInfo WallpaperIsDesktopField = AccessTools.Field(typeof(Wallpaper), "isDesktop");
        internal static readonly FieldInfo WallpaperImageField = AccessTools.Field(typeof(Wallpaper), "wallpaper");

        private Harmony _harmony;
        private bool _patched;
        private bool _applyingPreset;

        private void Awake()
        {
            Instance = this;
            Log = Logger;

            Enabled = Config.Bind("1. General", "Enabled", true,
                "Enable the interactive Navier-Stokes liquid live wallpaper on the in-game PC desktop.");
            Preset = Config.Bind("1. General", "Preset", LiquidPreset.Cobalt,
                "Quick color preset for the desktop fluid wallpaper.");
            ReactThroughWindows = Config.Bind("1. General", "ReactThroughWindows", true,
                "Stir the desktop fluid even while moving the cursor over open windows (like Wallpaper Engine).");
            AmbientSwirl = Config.Bind("1. General", "AmbientSwirl", false,
                "Gently stir the liquid wallpaper automatically when idle. Off sleeps at 0% CPU when trails fade.");
            Opacity = Config.Bind("1. General", "Opacity", 0.82f,
                new ConfigDescription("Maximum opacity of the fluid overlay on the desktop wallpaper.", new AcceptableValueRange<float>(0.1f, 1f)));

            Force = Config.Bind("2. Fluid Physics", "Force", 1.1f,
                new ConfigDescription("Force multiplier applied on pointer movement.", new AcceptableValueRange<float>(0.1f, 5f)));
            Radius = Config.Bind("2. Fluid Physics", "Radius", 0.30f,
                new ConfigDescription("Radius of the pointer splat.", new AcceptableValueRange<float>(0.05f, 1.5f)));
            Curl = Config.Bind("2. Fluid Physics", "Curl", 1.9f,
                new ConfigDescription("Rotational vorticity added back into the flow.", new AcceptableValueRange<float>(0f, 10f)));
            Intensity = Config.Bind("2. Fluid Physics", "Intensity", 2.0f,
                new ConfigDescription("Strength of the color tint left by the flow.", new AcceptableValueRange<float>(0.2f, 6f)));
            DensityDissipation = Config.Bind("2. Fluid Physics", "DensityDissipation", 0.96f,
                new ConfigDescription("How much the trail persists each frame (closer to 1 lasts longer).", new AcceptableValueRange<float>(0.85f, 0.995f)));
            VelocityDissipation = Config.Bind("2. Fluid Physics", "VelocityDissipation", 0.99f,
                new ConfigDescription("How much motion persists each frame (closer to 1 lasts longer).", new AcceptableValueRange<float>(0.85f, 1.0f)));
            Pressure = Config.Bind("2. Fluid Physics", "Pressure", 0.8f,
                new ConfigDescription("How much pressure carries over between frames.", new AcceptableValueRange<float>(0.1f, 1f)));
            PressureIterations = Config.Bind("2. Fluid Physics", "PressureIterations", 4,
                new ConfigDescription("Pressure solver iterations per step.", new AcceptableValueRange<int>(1, 12)));

            ColorR = Config.Bind("3. Appearance", "ColorR", 0.259f,
                new ConfigDescription("Fluid color Red (0-1). Ignored when Rainbow is on.", new AcceptableValueRange<float>(0f, 1f)));
            ColorG = Config.Bind("3. Appearance", "ColorG", 0.357f,
                new ConfigDescription("Fluid color Green (0-1). Ignored when Rainbow is on.", new AcceptableValueRange<float>(0f, 1f)));
            ColorB = Config.Bind("3. Appearance", "ColorB", 1.0f,
                new ConfigDescription("Fluid color Blue (0-1). Ignored when Rainbow is on.", new AcceptableValueRange<float>(0f, 1f)));
            Rainbow = Config.Bind("3. Appearance", "Rainbow", false,
                "Color the trail from the flow direction instead of a fixed color.");
            SimWidth = Config.Bind("3. Appearance", "SimWidth", 128,
                new ConfigDescription("Horizontal simulation grid resolution (height auto-matches 16:9).", new AcceptableValueRange<int>(64, 256)));
            TargetFps = Config.Bind("3. Appearance", "TargetFps", 60,
                new ConfigDescription("Simulation update rate cap (FPS).", new AcceptableValueRange<int>(24, 120)));

            Enabled.SettingChanged += (_, __) => ApplyEnabledState();
            Preset.SettingChanged += (_, __) => ApplyPreset();
            SimWidth.SettingChanged += (_, __) => LiquidWallpaperController.RebuildAll();

            _harmony = new Harmony(PluginGuid);
            SceneManager.sceneLoaded += OnSceneLoaded;
            ApplyEnabledState();
            Log.LogInfo($"{PluginName} v{PluginVersion} loaded.");
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
            if (_patched)
            {
                _harmony?.UnpatchSelf();
                _patched = false;
            }
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (Enabled.Value) AttachToExistingDesktopWallpapers();
        }

        private void ApplyEnabledState()
        {
            if (Enabled.Value)
            {
                if (!_patched)
                {
                    _harmony.PatchAll(typeof(LiquidWallpaperPatches));
                    _patched = true;
                }
                AttachToExistingDesktopWallpapers();
            }
            else if (_patched)
            {
                _harmony.UnpatchSelf();
                _patched = false;
            }

            LiquidWallpaperController.RefreshAllVisibility();
        }

        private void ApplyPreset()
        {
            if (_applyingPreset || Preset.Value == LiquidPreset.Custom) return;
            _applyingPreset = true;
            try
            {
                switch (Preset.Value)
                {
                    case LiquidPreset.Cobalt:
                        ColorR.Value = 0.259f; ColorG.Value = 0.357f; ColorB.Value = 1.0f; Rainbow.Value = false;
                        break;
                    case LiquidPreset.Cyan:
                        ColorR.Value = 0.08f; ColorG.Value = 0.82f; ColorB.Value = 0.96f; Rainbow.Value = false;
                        break;
                    case LiquidPreset.Cyberpunk:
                        ColorR.Value = 0.95f; ColorG.Value = 0.16f; ColorB.Value = 0.68f; Rainbow.Value = false;
                        break;
                    case LiquidPreset.Emerald:
                        ColorR.Value = 0.12f; ColorG.Value = 0.88f; ColorB.Value = 0.45f; Rainbow.Value = false;
                        break;
                    case LiquidPreset.Sunset:
                        ColorR.Value = 1.0f; ColorG.Value = 0.42f; ColorB.Value = 0.14f; Rainbow.Value = false;
                        break;
                    case LiquidPreset.Rainbow:
                        Rainbow.Value = true;
                        break;
                }
            }
            finally
            {
                _applyingPreset = false;
            }
        }

        internal static void AttachToExistingDesktopWallpapers()
        {
            var wallpapers = FindObjectsByType<Wallpaper>(FindObjectsSortMode.None);
            for (int i = 0; i < wallpapers.Length; i++)
            {
                TryAttach(wallpapers[i]);
            }
        }

        internal static void TryAttach(Wallpaper wp)
        {
            if (wp == null) return;
            bool isDesktop = WallpaperIsDesktopField != null && (bool)WallpaperIsDesktopField.GetValue(wp);
            if (!isDesktop) return;
            LiquidWallpaperController.Attach(wp);
        }
    }

    internal static class LiquidWallpaperPatches
    {
        [HarmonyPatch(typeof(Wallpaper), nameof(Wallpaper.SetWallpaper))]
        [HarmonyPostfix]
        private static void Wallpaper_SetWallpaper_Postfix(Wallpaper __instance)
        {
            PTLiquidWallpaperPlugin.TryAttach(__instance);
        }

        [HarmonyPatch(typeof(Wallpaper), nameof(Wallpaper.SetBrightness))]
        [HarmonyPostfix]
        private static void Wallpaper_SetBrightness_Postfix(Wallpaper __instance, float brightness)
        {
            var ctrl = __instance != null ? __instance.GetComponentInChildren<LiquidWallpaperController>(true) : null;
            if (ctrl != null) ctrl.SetBrightness(brightness);
        }
    }

    /// <summary>
    /// Interactive 2D Navier-Stokes fluid live wallpaper attached directly to Processor Tycoon's desktop Wallpaper layer.
    /// Zero per-frame heap allocations; sleeps automatically when idle.
    /// </summary>
    internal class LiquidWallpaperController : MonoBehaviour
    {
        private const string LayerName = "PTLiquidWallpaper_Layer";
        private const float FixedDt = 1f / 60f;

        private static readonly List<LiquidWallpaperController> Instances = new List<LiquidWallpaperController>();

        private RawImage _rawImage;
        private RectTransform _rectTransform;
        private Texture2D _texture;
        private Color32[] _pixels;

        private int _w;
        private int _h;
        private int _n;

        // Ping-pong simulation buffers
        private float[] _velX, _velY, _velX2, _velY2;
        private float[] _dyeR, _dyeG, _dyeB, _dyeR2, _dyeG2, _dyeB2;
        private float[] _curl, _div, _pres, _pres2;

        private bool _hasPrevMouse;
        private Vector2 _prevMouseUv;
        private float _stepAccum;
        private float _idleUntil;
        private float _ambientAngle;
        private float _brightness = 1f;
        private bool _activeSim;

        public static void Attach(Wallpaper wp)
        {
            if (wp == null) return;
            var existing = wp.transform.Find(LayerName);
            if (existing != null)
            {
                var c = existing.GetComponent<LiquidWallpaperController>();
                if (c != null)
                {
                    c.RefreshVisibility();
                    return;
                }
            }

            var bgImg = PTLiquidWallpaperPlugin.WallpaperImageField?.GetValue(wp) as Image;
            var parent = bgImg != null ? bgImg.transform.parent : wp.transform;

            var go = new GameObject(LayerName, typeof(RectTransform), typeof(CanvasRenderer), typeof(RawImage), typeof(LiquidWallpaperController));
            go.transform.SetParent(parent, false);

            // Place right above the wallpaper Image so it sits behind desktop icons & windows.
            if (bgImg != null)
                go.transform.SetSiblingIndex(bgImg.transform.GetSiblingIndex() + 1);
            else
                go.transform.SetAsFirstSibling();

            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;

            var raw = go.GetComponent<RawImage>();
            raw.raycastTarget = false;
            raw.color = Color.white;

            var ctrl = go.GetComponent<LiquidWallpaperController>();
            ctrl._rawImage = raw;
            ctrl._rectTransform = rt;
            ctrl.InitBuffers();
            ctrl.RefreshVisibility();
        }

        public static void RefreshAllVisibility()
        {
            for (int i = Instances.Count - 1; i >= 0; i--)
            {
                if (Instances[i] == null) { Instances.RemoveAt(i); continue; }
                Instances[i].RefreshVisibility();
            }
        }

        public static void RebuildAll()
        {
            for (int i = Instances.Count - 1; i >= 0; i--)
            {
                if (Instances[i] == null) { Instances.RemoveAt(i); continue; }
                Instances[i].InitBuffers();
            }
        }

        private void Awake()
        {
            Instances.Add(this);
        }

        private void OnDestroy()
        {
            Instances.Remove(this);
            if (_texture != null)
            {
                Destroy(_texture);
                _texture = null;
            }
        }

        public void SetBrightness(float brightness)
        {
            _brightness = Mathf.Clamp(brightness, 0.2f, 1.5f);
            if (_rawImage != null)
            {
                float b = Mathf.Clamp01(_brightness);
                _rawImage.color = new Color(b, b, b, 1f);
            }
        }

        private void RefreshVisibility()
        {
            bool show = PTLiquidWallpaperPlugin.Enabled.Value;
            if (gameObject.activeSelf != show)
                gameObject.SetActive(show);
        }

        private void InitBuffers()
        {
            int targetW = Mathf.Clamp(PTLiquidWallpaperPlugin.SimWidth.Value, 64, 256);
            float aspect = Screen.height > 0 ? (float)Screen.width / Screen.height : 16f / 9f;
            int targetH = Mathf.Clamp(Mathf.RoundToInt(targetW / Mathf.Clamp(aspect, 1.2f, 2.4f)), 36, 160);

            _w = targetW;
            _h = targetH;
            _n = _w * _h;

            _velX = new float[_n]; _velY = new float[_n];
            _velX2 = new float[_n]; _velY2 = new float[_n];
            _dyeR = new float[_n]; _dyeG = new float[_n]; _dyeB = new float[_n];
            _dyeR2 = new float[_n]; _dyeG2 = new float[_n]; _dyeB2 = new float[_n];
            _curl = new float[_n]; _div = new float[_n];
            _pres = new float[_n]; _pres2 = new float[_n];
            _pixels = new Color32[_n];

            if (_texture != null) Destroy(_texture);
            _texture = new Texture2D(_w, _h, TextureFormat.RGBA32, false, false)
            {
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp,
                hideFlags = HideFlags.HideAndDontSave
            };
            _texture.SetPixels32(_pixels);
            _texture.Apply(false, false);

            if (_rawImage != null)
                _rawImage.texture = _texture;

            _activeSim = false;
            _idleUntil = 0f;
        }

        private void Update()
        {
            if (!PTLiquidWallpaperPlugin.Enabled.Value || _texture == null) return;

            float now = Time.unscaledTime;
            HandlePointerInput(now);

            if (PTLiquidWallpaperPlugin.AmbientSwirl.Value && now > _idleUntil - 1.5f)
            {
                _ambientAngle += Time.unscaledDeltaTime * 0.65f;
                float ax = 0.5f + Mathf.Cos(_ambientAngle) * 0.28f;
                float ay = 0.5f + Mathf.Sin(_ambientAngle * 1.3f) * 0.22f;
                float adx = -Mathf.Sin(_ambientAngle) * 2.2f;
                float ady = Mathf.Cos(_ambientAngle * 1.3f) * 2.2f;
                ApplySplat(ax, ay, adx, ady, 1.0f);
                Wake(now);
            }

            if (!_activeSim) return;

            float stepInterval = 1f / Mathf.Clamp(PTLiquidWallpaperPlugin.TargetFps.Value, 24, 120);
            _stepAccum += Mathf.Min(Time.unscaledDeltaTime, 0.05f);
            if (_stepAccum < stepInterval) return;

            float delta = Mathf.Min(_stepAccum, 1f / 30f);
            _stepAccum = 0f;

            StepFluid(delta);
            RenderToTexture();

            if (now >= _idleUntil)
            {
                _activeSim = false;
                Array.Clear(_pixels, 0, _n);
                _texture.SetPixels32(_pixels);
                _texture.Apply(false, false);
            }
        }

        private void Wake(float now)
        {
            _activeSim = true;
            float diss = Mathf.Clamp(PTLiquidWallpaperPlugin.DensityDissipation.Value, 0.85f, 0.995f);
            float frames = Mathf.Log(1e-4f) / Mathf.Log(diss);
            float sleepDelay = Mathf.Clamp((frames / 60f) + 0.5f, 1.5f, 12f);
            _idleUntil = now + sleepDelay;
        }

        private void HandlePointerInput(float now)
        {
            if (!PTLiquidWallpaperPlugin.ReactThroughWindows.Value && IsPointerOverWindow())
            {
                _hasPrevMouse = false;
                return;
            }

            Vector2 mousePos = Input.mousePosition;
            if (mousePos.x < 0f || mousePos.y < 0f || mousePos.x > Screen.width || mousePos.y > Screen.height)
            {
                _hasPrevMouse = false;
                return;
            }

            Vector2 uv = new Vector2(
                Mathf.Clamp01(mousePos.x / Mathf.Max(1f, Screen.width)),
                Mathf.Clamp01(mousePos.y / Mathf.Max(1f, Screen.height)));

            if (Input.GetMouseButtonDown(0))
            {
                float angle = now * 3.1f;
                ApplySplat(uv.x, uv.y, Mathf.Cos(angle) * 14f, Mathf.Sin(angle) * 14f, 1.25f);
                Wake(now);
            }

            if (_hasPrevMouse)
            {
                float dxPx = (uv.x - _prevMouseUv.x) * Screen.width;
                float dyPx = (uv.y - _prevMouseUv.y) * Screen.height;
                float distSq = dxPx * dxPx + dyPx * dyPx;
                if (distSq > 0.25f)
                {
                    float force = PTLiquidWallpaperPlugin.Force.Value * 0.55f;
                    float dx = Mathf.Clamp(dxPx * force, -35f, 35f);
                    float dy = Mathf.Clamp(dyPx * force, -35f, 35f);
                    ApplySplat(uv.x, uv.y, dx, dy, 1.0f);
                    Wake(now);
                }
            }

            _prevMouseUv = uv;
            _hasPrevMouse = true;
        }

        private static bool IsPointerOverWindow()
        {
            var es = EventSystem.current;
            if (es == null) return false;
            return es.IsPointerOverGameObject();
        }

        private void ApplySplat(float ux, float uy, float dx, float dy, float radiusScale)
        {
            float aspect = (float)_w / _h;
            float r = Mathf.Max(0.0005f, (PTLiquidWallpaperPlugin.Radius.Value / 100f) * radiusScale);
            float invR = 1f / r;

            // Bounding box for the Gaussian splat (cuts work by ~85%)
            float cutoffDist = Mathf.Sqrt(6.5f * r);
            int minX = Mathf.Max(0, Mathf.FloorToInt((ux - cutoffDist / aspect) * _w));
            int maxX = Mathf.Min(_w - 1, Mathf.CeilToInt((ux + cutoffDist / aspect) * _w));
            int minY = Mathf.Max(0, Mathf.FloorToInt((uy - cutoffDist) * _h));
            int maxY = Mathf.Min(_h - 1, Mathf.CeilToInt((uy + cutoffDist) * _h));

            float invW = 1f / _w;
            float invH = 1f / _h;
            float dz = Mathf.Min(10f, Mathf.Sqrt(dx * dx + dy * dy) * 0.45f + 1.5f);

            for (int y = minY; y <= maxY; y++)
            {
                float py = (y + 0.5f) * invH - uy;
                float py2 = py * py;
                int row = y * _w;
                for (int x = minX; x <= maxX; x++)
                {
                    float px = ((x + 0.5f) * invW - ux) * aspect;
                    float d2 = px * px + py2;
                    float splat = Mathf.Exp(-d2 * invR);
                    if (splat < 0.001f) continue;

                    int idx = row + x;
                    _velX[idx] += splat * dx;
                    _velY[idx] += splat * dy;
                    _dyeR[idx] += splat * Mathf.Abs(dx) * 0.22f + splat * 0.08f;
                    _dyeG[idx] += splat * Mathf.Abs(dy) * 0.22f + splat * 0.08f;
                    _dyeB[idx] += splat * dz * 0.14f;
                }
            }
        }

        private void StepFluid(float delta)
        {
            int w = _w, h = _h;
            float curlStrength = PTLiquidWallpaperPlugin.Curl.Value;

            // 1. Curl (vorticity)
            for (int y = 0; y < h; y++)
            {
                int yB = y > 0 ? y - 1 : 0;
                int yT = y < h - 1 ? y + 1 : h - 1;
                int row = y * w, rowB = yB * w, rowT = yT * w;
                for (int x = 0; x < w; x++)
                {
                    int xL = x > 0 ? x - 1 : 0;
                    int xR = x < w - 1 ? x + 1 : w - 1;
                    float vL = _velY[row + xL];
                    float vR = _velY[row + xR];
                    float uT = _velX[rowT + x];
                    float uB = _velX[rowB + x];
                    _curl[row + x] = vR - vL - uT + uB;
                }
            }

            // 2. Vorticity confinement
            if (curlStrength > 0.001f)
            {
                for (int y = 0; y < h; y++)
                {
                    int yB = y > 0 ? y - 1 : 0;
                    int yT = y < h - 1 ? y + 1 : h - 1;
                    int row = y * w, rowB = yB * w, rowT = yT * w;
                    for (int x = 0; x < w; x++)
                    {
                        int xL = x > 0 ? x - 1 : 0;
                        int xR = x < w - 1 ? x + 1 : w - 1;
                        float cL = _curl[row + xL];
                        float cR = _curl[row + xR];
                        float cT = _curl[rowT + x];
                        float cB = _curl[rowB + x];
                        float cC = _curl[row + x];

                        float fx = (Mathf.Abs(cT) - Mathf.Abs(cB)) * 0.5f;
                        float fy = (Mathf.Abs(cR) - Mathf.Abs(cL)) * 0.5f;
                        float len = Mathf.Sqrt(fx * fx + fy * fy) + 1f;
                        float scale = (curlStrength * cC / len) * FixedDt;

                        int idx = row + x;
                        _velX[idx] += fx * scale;
                        _velY[idx] -= fy * scale;
                    }
                }
            }

            // 3. Divergence (with reflective wall boundaries)
            for (int y = 0; y < h; y++)
            {
                int row = y * w;
                int rowB = (y > 0 ? y - 1 : 0) * w;
                int rowT = (y < h - 1 ? y + 1 : h - 1) * w;
                for (int x = 0; x < w; x++)
                {
                    int idx = row + x;
                    float cx = _velX[idx];
                    float cy = _velY[idx];
                    float uL = x > 0 ? _velX[row + x - 1] : -cx;
                    float uR = x < w - 1 ? _velX[row + x + 1] : -cx;
                    float vB = y > 0 ? _velY[rowB + x] : -cy;
                    float vT = y < h - 1 ? _velY[rowT + x] : -cy;
                    _div[idx] = 0.5f * (uR - uL + vT - vB);
                }
            }

            // 4. Pressure decay + Jacobi iterations
            float pCarry = Mathf.Pow(PTLiquidWallpaperPlugin.Pressure.Value, delta * 60f);
            for (int i = 0; i < _n; i++) _pres[i] *= pCarry;

            int iters = Mathf.Clamp(PTLiquidWallpaperPlugin.PressureIterations.Value, 1, 12);
            for (int iter = 0; iter < iters; iter++)
            {
                for (int y = 0; y < h; y++)
                {
                    int row = y * w;
                    int rowB = (y > 0 ? y - 1 : 0) * w;
                    int rowT = (y < h - 1 ? y + 1 : h - 1) * w;
                    for (int x = 0; x < w; x++)
                    {
                        int xL = x > 0 ? x - 1 : 0;
                        int xR = x < w - 1 ? x + 1 : w - 1;
                        int idx = row + x;
                        _pres2[idx] = (_pres[row + xL] + _pres[row + xR] + _pres[rowB + x] + _pres[rowT + x] - _div[idx]) * 0.25f;
                    }
                }
                var tmp = _pres; _pres = _pres2; _pres2 = tmp;
            }

            // 5. Gradient subtraction
            for (int y = 0; y < h; y++)
            {
                int row = y * w;
                int rowB = (y > 0 ? y - 1 : 0) * w;
                int rowT = (y < h - 1 ? y + 1 : h - 1) * w;
                for (int x = 0; x < w; x++)
                {
                    int xL = x > 0 ? x - 1 : 0;
                    int xR = x < w - 1 ? x + 1 : w - 1;
                    int idx = row + x;
                    _velX[idx] -= (_pres[row + xR] - _pres[row + xL]);
                    _velY[idx] -= (_pres[rowT + x] - _pres[rowB + x]);
                }
            }

            // 6. Semi-Lagrangian advection (velocity & dye)
            float velDiss = Mathf.Pow(PTLiquidWallpaperPlugin.VelocityDissipation.Value, delta * 60f);
            float dyeDiss = Mathf.Pow(PTLiquidWallpaperPlugin.DensityDissipation.Value, delta * 60f);
            float maxX = w - 1.001f;
            float maxY = h - 1.001f;

            for (int y = 0; y < h; y++)
            {
                int row = y * w;
                for (int x = 0; x < w; x++)
                {
                    int idx = row + x;
                    float sx = Mathf.Clamp(x - FixedDt * _velX[idx], 0f, maxX);
                    float sy = Mathf.Clamp(y - FixedDt * _velY[idx], 0f, maxY);

                    int x0 = (int)sx;
                    int y0 = (int)sy;
                    float fx = sx - x0;
                    float fy = sy - y0;
                    float omx = 1f - fx;
                    float omy = 1f - fy;

                    int i00 = y0 * w + x0;
                    int i10 = i00 + 1;
                    int i01 = i00 + w;
                    int i11 = i01 + 1;

                    float w00 = omx * omy;
                    float w10 = fx * omy;
                    float w01 = omx * fy;
                    float w11 = fx * fy;

                    _velX2[idx] = (_velX[i00] * w00 + _velX[i10] * w10 + _velX[i01] * w01 + _velX[i11] * w11) * velDiss;
                    _velY2[idx] = (_velY[i00] * w00 + _velY[i10] * w10 + _velY[i01] * w01 + _velY[i11] * w11) * velDiss;

                    _dyeR2[idx] = (_dyeR[i00] * w00 + _dyeR[i10] * w10 + _dyeR[i01] * w01 + _dyeR[i11] * w11) * dyeDiss;
                    _dyeG2[idx] = (_dyeG[i00] * w00 + _dyeG[i10] * w10 + _dyeG[i01] * w01 + _dyeG[i11] * w11) * dyeDiss;
                    _dyeB2[idx] = (_dyeB[i00] * w00 + _dyeB[i10] * w10 + _dyeB[i01] * w01 + _dyeB[i11] * w11) * dyeDiss;
                }
            }

            Swap(ref _velX, ref _velX2);
            Swap(ref _velY, ref _velY2);
            Swap(ref _dyeR, ref _dyeR2);
            Swap(ref _dyeG, ref _dyeG2);
            Swap(ref _dyeB, ref _dyeB2);
        }

        private void RenderToTexture()
        {
            float intensity = PTLiquidWallpaperPlugin.Intensity.Value * 0.5f;
            float maxAlpha = PTLiquidWallpaperPlugin.Opacity.Value;
            bool rainbow = PTLiquidWallpaperPlugin.Rainbow.Value;

            float baseR = PTLiquidWallpaperPlugin.ColorR.Value;
            float baseG = PTLiquidWallpaperPlugin.ColorG.Value;
            float baseB = PTLiquidWallpaperPlugin.ColorB.Value;

            for (int i = 0; i < _n; i++)
            {
                float dr = _dyeR[i];
                float dg = _dyeG[i];
                float db = _dyeB[i];
                float mag = Mathf.Sqrt(dr * dr + dg * dg + db * db);

                if (mag < 0.002f)
                {
                    _pixels[i] = default;
                    continue;
                }

                float overlay = (1f - Mathf.Exp(-mag * intensity)) * maxAlpha;
                float r, g, b;
                if (rainbow)
                {
                    float invMag = 1f / Mathf.Max(mag, 0.001f);
                    // Flow-direction iridescent tint
                    float vx = _velX[i];
                    float vy = _velY[i];
                    float angle = Mathf.Atan2(vy, vx);
                    r = Mathf.Clamp01(0.5f + 0.5f * Mathf.Cos(angle) + dr * invMag * 0.35f);
                    g = Mathf.Clamp01(0.5f + 0.5f * Mathf.Cos(angle + 2.094f) + dg * invMag * 0.35f);
                    b = Mathf.Clamp01(0.5f + 0.5f * Mathf.Cos(angle + 4.188f) + db * invMag * 0.35f);
                }
                else
                {
                    // Luminous core highlight as density increases (matches the glowing blue-white core in Liquid.tsx)
                    float core = Mathf.Clamp01((mag - 0.8f) * 0.28f);
                    r = Mathf.Clamp01(baseR + (1f - baseR) * core);
                    g = Mathf.Clamp01(baseG + (1f - baseG) * core);
                    b = Mathf.Clamp01(baseB + (1f - baseB) * core);
                }

                _pixels[i] = new Color32(
                    (byte)(r * 255f),
                    (byte)(g * 255f),
                    (byte)(b * 255f),
                    (byte)(Mathf.Clamp01(overlay) * 255f));
            }

            _texture.SetPixels32(_pixels);
            _texture.Apply(false, false);
        }

        private static void Swap(ref float[] a, ref float[] b)
        {
            var t = a;
            a = b;
            b = t;
        }
    }
}
